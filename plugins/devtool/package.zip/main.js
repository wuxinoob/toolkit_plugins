/**
 * Windows 全能开发与系统小工具箱 (DevToolbox v0.3.0)
 * 采用原生 Rust Sidecar 驱动，覆盖 11 大常用开发与生产力工具：
 * 端口管理、文件锁排查、句柄分析、Hosts管理、UWP网络回环豁免、端口转发映射、
 * 软链接/联接管理、Defender编译加白、开发服务管家、PATH环境诊断、防休眠。
 */

export default {
  manifest: {
    id: 'devtool',
    name: '开发助手',
    version: '0.3.0',
    api: 3,
  },

  activate(ctx) {
    const { el, native, render } = ctx.ui;
    const protocol = ctx.protocol;
    const { Kind } = protocol;

    // ----------------- Sidecar 通信客户端 -----------------
    let sidecarHandle = null;
    let seq = 0;
    const pending = new Map();

    async function getSidecar() {
      if (sidecarHandle) return sidecarHandle;
      sidecarHandle = await ctx.sidecar('devtool-core', {
        exe: 'devtool.exe',
        pollMs: 25,
        timeoutMs: 150,
        onFrame: (env) => {
          if (env.kind !== Kind.RES && env.kind !== Kind.ERR) return;
          const p = pending.get(env.id);
          if (!p) return;
          pending.delete(env.id);
          if (env.kind === Kind.ERR) {
            p.reject(new Error(env.msg || env.code || 'sidecar error'));
          } else {
            p.resolve(env.p);
          }
        },
        onEnd: (env) => {
          sidecarHandle = null;
          const reason = env?.kind === Kind.EXIT ? `sidecar exited (${env.p})` : 'sidecar disconnected';
          for (const p of pending.values()) p.reject(new Error(reason));
          pending.clear();
        },
      });
      return sidecarHandle;
    }

    async function invoke(svc, act, p = {}) {
      const h = await getSidecar();
      const id = ++seq;
      const resPromise = new Promise((resolve, reject) => {
        pending.set(id, { resolve, reject });
      });
      await h.send(protocol.req(id, svc, act, p));
      return resPromise;
    }

    // ----------------- 全局状态 -----------------
    let currentTab = 'port';
    let rootContainer = null;

    // 1. 端口状态
    let portsList = [];
    let portFilter = '';
    let portLoading = false;
    let portError = '';

    // 2. 文件锁状态
    let lockPath = '';
    let lockResults = [];
    let lockSearched = false;
    let lockLoading = false;
    let lockError = '';

    // 3. 句柄状态
    let handlePid = '';
    let handleList = [];
    let handleLoading = false;
    let handleError = '';

    // 4. Hosts 状态
    let hostsContent = '';
    let hostsPath = '';
    let hostsBakPath = '';
    let hostsBakExists = false;
    let hostsLoading = false;
    let hostsSaving = false;
    let hostsError = '';
    let hostsSuccessMsg = '';
    let quickIp = '';
    let quickDomain = '';

    // 5. UWP 回环状态
    let uwpList = [];
    let uwpFilter = '';
    let uwpLoading = false;
    let uwpError = '';

    // 6. 端口转发状态
    let proxyList = [];
    let proxyLoading = false;
    let proxyError = '';
    let newProxyListenPort = '';
    let newProxyConnectPort = '';
    let newProxyConnectAddr = '127.0.0.1';

    // 7. 软链接/联接状态
    let symlinkInspectPath = '';
    let symlinkInspectResult = null;
    let symlinkInspectLoading = false;
    let junctionLinkPath = '';
    let junctionTargetPath = '';
    let junctionCreating = false;

    // 8. Defender 加白状态
    let defenderPaths = [];
    let defenderReqAdmin = false;
    let defenderLoading = false;
    let defenderElevating = false;
    let defenderLoaded = false;
    let defenderRtProtection = true;
    let defenderAvEnabled = true;
    let defenderEngineVer = '';
    let defenderSigVer = '';
    let newDefenderPath = '';

    // 9. 开发服务状态
    let serviceList = [];
    let serviceLoading = false;

    // 10. 环境诊断状态
    let envReport = null;
    let envLoading = false;

    // 11. 防休眠状态
    let awakeActive = false;
    let awakeKeepDisplay = false;

    // ----------------- 业务逻辑动作 -----------------
    async function loadPorts() {
      portLoading = true;
      portError = '';
      updateUI();
      try {
        const res = await invoke('port', 'list');
        portsList = res.ports || [];
      } catch (err) {
        portError = err.message || String(err);
      } finally {
        portLoading = false;
        updateUI();
      }
    }

    async function killProcess(pid, uac = false) {
      if (!confirm(`确定要强制结束 PID: ${pid} 的进程吗？`)) return;
      try {
        await invoke('port', 'kill', { pid, uac });
        ctx.ui.notify?.(`已向 PID ${pid} 发送终止信号`, { title: '操作成功' });
        await loadPorts();
        if (lockPath && lockSearched) await detectLock(lockPath);
      } catch (err) {
        if (!uac && confirm(`普通权限终止失败: ${err.message}\n是否尝试通过 UAC 管理员提权强制终止？`)) {
          await killProcess(pid, true);
        } else {
          alert(`终止进程失败: ${err.message}`);
        }
      }
    }

    async function detectLock(targetPath) {
      if (!targetPath) return;
      lockPath = targetPath;
      lockLoading = true;
      lockError = '';
      lockSearched = true;
      lockResults = [];
      updateUI();
      const inp = document.getElementById('devtool-lock-input');
      if (inp && inp.value !== lockPath) inp.value = lockPath;
      try {
        const res = await invoke('lock', 'detect', { path: targetPath });
        lockResults = res.locks || [];
      } catch (err) {
        lockError = err.message || String(err);
      } finally {
        lockLoading = false;
        updateUI();
        const inpAfter = document.getElementById('devtool-lock-input');
        if (inpAfter && inpAfter.value !== lockPath) inpAfter.value = lockPath;
      }
    }

    async function scheduleRebootDelete(path, uac = false) {
      if (!confirm(`确定要在下次 Windows 重启时彻底删除该文件吗？\n${path}`)) return;
      try {
        await invoke('lock', 'reboot_delete', { path, uac });
        alert('已登记至系统内核！该文件将在下次 Windows 重启自检阶段自动删除。');
      } catch (err) {
        if (!uac && confirm(`普通权限写入失败: ${err.message}\n是否以管理员提权登记？`)) {
          await scheduleRebootDelete(path, true);
        } else {
          alert(`登记失败: ${err.message}`);
        }
      }
    }

    async function queryHandles(pid) {
      if (!pid) return;
      handlePid = String(pid);
      handleLoading = true;
      handleError = '';
      updateUI();
      const inp = document.getElementById('devtool-handle-input');
      if (inp && inp.value !== handlePid) inp.value = handlePid;
      try {
        const res = await invoke('handle', 'list', { pid: Number(pid), max_count: 300 });
        handleList = res.handles || [];
      } catch (err) {
        handleError = err.message || String(err);
      } finally {
        handleLoading = false;
        updateUI();
        const inpAfter = document.getElementById('devtool-handle-input');
        if (inpAfter && inpAfter.value !== handlePid) inpAfter.value = handlePid;
      }
    }

    function syncHostsTextarea(val) {
      if (val === undefined || val === null) return;
      setTimeout(() => {
        const ta = document.getElementById('devtool-hosts-textarea');
        if (ta && ta.value !== val) ta.value = val;
        const stats = document.getElementById('devtool-hosts-stats');
        if (stats) {
          const lines = val ? val.split('\n').length : 0;
          stats.textContent = `当前统计: ${lines} 行 · ${val.length} 字符`;
        }
      }, 0);
    }

    async function loadHosts() {
      hostsLoading = true;
      hostsError = '';
      hostsSuccessMsg = '';
      updateUI();
      try {
        const res = await invoke('hosts', 'read');
        hostsContent = res.content || '';
        hostsPath = res.path || '';
        hostsBakPath = res.bak_path || '';
        hostsBakExists = !!res.bak_exists;
        syncHostsTextarea(hostsContent);
      } catch (err) {
        hostsError = err.message || String(err);
      } finally {
        hostsLoading = false;
        updateUI();
        syncHostsTextarea(hostsContent);
      }
    }

    async function loadHostsBak() {
      if (!confirm('确定要从 host.bak 备份文件载入内容吗？\n当前编辑区的内容将被替换为备份内容（需点击「保存 Hosts」写入系统）。')) return;
      hostsLoading = true;
      hostsError = '';
      hostsSuccessMsg = '';
      updateUI();
      try {
        const res = await invoke('hosts', 'read_bak');
        hostsContent = res.content || '';
        hostsSuccessMsg = '已从 host.bak 成功载入备份内容，请在下方检查，确认无误后点击「保存 Hosts」写入系统。';
        syncHostsTextarea(hostsContent);
      } catch (err) {
        hostsError = `载入 host.bak 失败: ${err.message || String(err)}`;
      } finally {
        hostsLoading = false;
        updateUI();
        syncHostsTextarea(hostsContent);
      }
    }

    async function saveHosts(uac = false) {
      const ta = document.getElementById('devtool-hosts-textarea');
      if (ta) hostsContent = ta.value;

      hostsSaving = true;
      hostsError = '';
      hostsSuccessMsg = '';
      updateUI();
      try {
        const res = await invoke('hosts', 'write', { content: hostsContent, uac });
        hostsBakExists = true;
        hostsSuccessMsg = 'Hosts 文件已成功修改并刷新 DNS！原文件已安全备份为 host.bak';
        ctx.ui.notify?.('Hosts 文件已成功修改，原文件已备份为 host.bak', { title: '修改成功' });
      } catch (err) {
        if (!uac && confirm(`普通权限无法直接写入系统 Hosts (${err.message})\n是否请求 UAC 提权并以管理员权限保存并备份？`)) {
          await saveHosts(true);
          return;
        } else {
          hostsError = `保存 Hosts 失败: ${err.message || String(err)}`;
        }
      } finally {
        hostsSaving = false;
        updateUI();
        syncHostsTextarea(hostsContent);
      }
    }

    function addQuickHost() {
      const ta = document.getElementById('devtool-hosts-textarea');
      if (ta) hostsContent = ta.value;

      const ip = quickIp.trim();
      const domain = quickDomain.trim();
      if (!ip || !domain) {
        alert('请输入完整的 IP 地址和域名');
        return;
      }
      const line = `${ip} ${domain}`;
      if (hostsContent.endsWith('\n') || hostsContent.length === 0) {
        hostsContent += line + '\n';
      } else {
        hostsContent += '\n' + line + '\n';
      }
      quickIp = '';
      quickDomain = '';
      hostsSuccessMsg = `已将规则「${line}」追加至编辑框末尾，请点击「保存 Hosts」写入生效。`;
      updateUI();
      syncHostsTextarea(hostsContent);
    }

    async function flushDns() {
      try {
        await invoke('dns', 'flush');
        ctx.ui.notify?.('Windows 本地 DNS 解析缓存已清空', { title: 'DNS 刷新完成' });
      } catch (err) {
        alert(`清空 DNS 失败: ${err.message}`);
      }
    }

    // UWP
    async function loadUwp() {
      uwpLoading = true;
      uwpError = '';
      updateUI();
      try {
        const res = await invoke('uwp', 'list');
        uwpList = res.apps || [];
      } catch (err) {
        uwpError = err.message || String(err);
      } finally {
        uwpLoading = false;
        updateUI();
      }
    }

    async function setUwpExempt(sid, enable, uac = false) {
      try {
        await invoke('uwp', 'set', { sid, enable, uac });
        const app = uwpList.find((a) => a.sid === sid);
        if (app) app.is_exempt = enable;
        ctx.ui.notify?.(`已${enable ? '开启' : '关闭'}该 UWP 回环豁免`);
        updateUI();
      } catch (err) {
        if (!uac && confirm(`需要管理员权限设置 UWP 回环豁免\n是否通过 UAC 提权执行？`)) {
          await setUwpExempt(sid, enable, true);
        } else {
          alert(`操作失败: ${err.message}`);
        }
      }
    }

    // 端口转发
    async function loadProxies() {
      proxyLoading = true;
      proxyError = '';
      updateUI();
      try {
        const res = await invoke('proxy', 'list');
        proxyList = res.proxies || [];
      } catch (err) {
        proxyError = err.message || String(err);
      } finally {
        proxyLoading = false;
        updateUI();
      }
    }

    async function addProxy(uac = false) {
      const lp = Number(newProxyListenPort);
      const cp = Number(newProxyConnectPort);
      if (!lp || !cp) { alert('请输入有效的监听端口与目标端口'); return; }
      try {
        await invoke('proxy', 'add', {
          listen_address: '0.0.0.0',
          listen_port: lp,
          connect_address: newProxyConnectAddr || '127.0.0.1',
          connect_port: cp,
          uac,
        });
        ctx.ui.notify?.(`端口转发已添加: 0.0.0.0:${lp} -> ${newProxyConnectAddr}:${cp}`);
        newProxyListenPort = '';
        newProxyConnectPort = '';
        await loadProxies();
      } catch (err) {
        if (!uac && confirm(`配置端口转发需要管理员权限\n是否通过 UAC 提权执行？`)) {
          await addProxy(true);
        } else {
          alert(`添加端口转发失败: ${err.message}`);
        }
      }
    }

    async function deleteProxy(listenPort, uac = false) {
      if (!confirm(`确定删除监听端口为 ${listenPort} 的转发规则吗？`)) return;
      try {
        await invoke('proxy', 'delete', { listen_address: '0.0.0.0', listen_port: Number(listenPort), uac });
        ctx.ui.notify?.(`已删除端口 ${listenPort} 转发`);
        await loadProxies();
      } catch (err) {
        if (!uac && confirm(`删除端口转发需要管理员权限\n是否通过 UAC 提权执行？`)) {
          await deleteProxy(listenPort, true);
        } else {
          alert(`删除失败: ${err.message}`);
        }
      }
    }

    // 软链接
    async function inspectPath() {
      if (!symlinkInspectPath) return;
      symlinkInspectLoading = true;
      updateUI();
      try {
        symlinkInspectResult = await invoke('symlink', 'inspect', { path: symlinkInspectPath });
      } catch (err) {
        alert(`探测失败: ${err.message}`);
      } finally {
        symlinkInspectLoading = false;
        updateUI();
      }
    }

    async function createJunction() {
      if (!junctionLinkPath || !junctionTargetPath) { alert('请输入联接路径与目标真实目录'); return; }
      junctionCreating = true;
      updateUI();
      try {
        await invoke('symlink', 'create_junction', { link_path: junctionLinkPath, target_path: junctionTargetPath });
        ctx.ui.notify?.('目录联接 (Junction) 创建成功！', { title: '成功' });
        junctionLinkPath = '';
        junctionTargetPath = '';
      } catch (err) {
        alert(`创建失败: ${err.message}`);
      } finally {
        junctionCreating = false;
        updateUI();
      }
    }

    // Defender
    async function loadDefender() {
      defenderLoading = true;
      updateUI();
      try {
        const res = await invoke('defender', 'list');
        defenderPaths = res.paths || [];
        defenderReqAdmin = res.requires_admin || false;
        defenderRtProtection = res.real_time_protection !== false;
        defenderAvEnabled = res.antivirus_enabled !== false;
        defenderEngineVer = res.engine_version || '';
        defenderSigVer = res.signature_version || '';
        defenderLoaded = true;
      } catch (err) {
        // ignore
      } finally {
        defenderLoading = false;
        updateUI();
      }
    }

    async function loadDefenderElevated() {
      defenderElevating = true;
      updateUI();
      try {
        const res = await invoke('defender', 'list_elevated');
        defenderPaths = res.paths || [];
        defenderReqAdmin = false;
        defenderLoaded = true;
        ctx.ui.notify?.(`已成功读取 ${defenderPaths.length} 个 Defender 排除项`, { title: '提权读取成功' });
      } catch (err) {
        alert(`提权读取排除项失败: ${err.message || err}`);
      } finally {
        defenderElevating = false;
        updateUI();
      }
    }

    async function addDefenderExclusion(path, uac = false) {
      if (!path) {
        alert('请输入或选择需要加白的目录路径');
        return;
      }
      try {
        await invoke('defender', 'add', { path, uac });
        ctx.ui.notify?.(`已加入 Defender 排除目录: ${path}`);
        newDefenderPath = '';
        const inp = document.getElementById('devtool-defender-input');
        if (inp) inp.value = '';
        if (!defenderReqAdmin) {
          await loadDefenderElevated();
        } else {
          await loadDefender();
        }
      } catch (err) {
        if (!uac && confirm(`添加 Defender 排除项需要管理员权限\n是否通过 UAC 提权执行？`)) {
          await addDefenderExclusion(path, true);
        } else {
          alert(`添加失败: ${err.message}`);
        }
      }
    }

    async function removeDefenderExclusion(path, uac = true) {
      if (!confirm(`确定要将以下路径从 Defender 排除项中移除吗？\n${path}`)) return;
      try {
        await invoke('defender', 'remove', { path, uac });
        ctx.ui.notify?.(`已从 Defender 排除目录移除: ${path}`);
        await (defenderReqAdmin ? loadDefender() : loadDefenderElevated());
      } catch (err) {
        alert(`移除失败: ${err.message || err}`);
      }
    }

    // 服务
    async function loadServices() {
      serviceLoading = true;
      updateUI();
      try {
        const res = await invoke('service', 'list');
        serviceList = res.services || [];
      } catch (err) {
        // ignore
      } finally {
        serviceLoading = false;
        updateUI();
      }
    }

    async function controlService(name, action, uac = false) {
      try {
        await invoke('service', 'control', { name, action, uac });
        ctx.ui.notify?.(`服务 ${name} 已执行 ${action}`);
        await loadServices();
      } catch (err) {
        if (!uac && confirm(`控制服务需要管理员权限\n是否通过 UAC 提权执行？`)) {
          await controlService(name, action, true);
        } else {
          alert(`服务操作失败: ${err.message}`);
        }
      }
    }

    async function runEnvDiag() {
      envLoading = true;
      updateUI();
      try {
        envReport = await invoke('env', 'diag');
      } catch (err) {
        // ignore
      } finally {
        envLoading = false;
        updateUI();
      }
    }

    async function toggleAwake() {
      try {
        const next = !awakeActive;
        const res = await invoke('awake', 'set', { enable: next, keep_display: awakeKeepDisplay });
        awakeActive = res.active;
        ctx.ui.notify?.(awakeActive ? '防休眠已启用（系统保持常亮）' : '防休眠已停用');
      } catch (err) {
        alert(`防休眠切换失败: ${err.message}`);
      }
      updateUI();
    }

    // 拖拽挂钩
    ctx.onDrop((paths) => {
      if (paths && paths.length > 0) {
        currentTab = 'lock';
        detectLock(paths[0]);
      }
    });

    // ----------------- 渲染各组件 -----------------
    function renderTabs() {
      const groups = [
        {
          title: '排查与诊断',
          tabs: [
            { id: 'port', label: '端口占用' },
            { id: 'lock', label: '文件锁解锁' },
            { id: 'handle', label: '句柄分析' },
            { id: 'env', label: 'PATH诊断' },
          ],
        },
        {
          title: '网络与代理',
          tabs: [
            { id: 'hosts', label: 'Hosts & DNS' },
            { id: 'uwp', label: 'UWP回环代理' },
            { id: 'proxy', label: '端口转发映射' },
          ],
        },
        {
          title: '开发与系统',
          tabs: [
            { id: 'symlink', label: '软链接联接' },
            { id: 'defender', label: 'Defender加白' },
            { id: 'service', label: '开发服务' },
            { id: 'awake', label: '防休眠' },
          ],
        },
      ];

      return el('div', { style: 'display:flex;gap:16px;margin-bottom:16px;border-bottom:1px solid var(--color-border);padding-bottom:10px;flex-wrap:wrap;' },
        ...groups.map((g) =>
          el('div', { style: 'display:flex;gap:4px;align-items:center;' },
            el('span', { style: 'font-size:11px;color:var(--color-fg-muted);font-weight:600;margin-right:4px;' }, g.title + ':'),
            ...g.tabs.map((t) =>
              el('button', {
                class: `tb-tab ${currentTab === t.id ? 'tb-tab-active' : ''}`,
                style: 'cursor:pointer;padding:4px 10px;font-size:12px;',
                onclick: () => {
                  currentTab = t.id;
                  ctx.storage?.set('activeTab', t.id).catch(() => {});
                  if (t.id === 'port' && portsList.length === 0) loadPorts();
                  if (t.id === 'hosts' && !hostsContent) loadHosts();
                  if (t.id === 'uwp' && uwpList.length === 0) loadUwp();
                  if (t.id === 'proxy' && proxyList.length === 0) loadProxies();
                  if (t.id === 'defender' && !defenderLoaded) loadDefender();
                  if (t.id === 'service' && serviceList.length === 0) loadServices();
                  if (t.id === 'env' && !envReport) runEnvDiag();
                  updateUI();
                },
              }, t.label)
            )
          )
        )
      );
    }

    // 1. 端口视图
    function getFilteredPorts() {
      if (!portFilter) return portsList;
      const q = portFilter.toLowerCase();
      return portsList.filter((p) => (
        String(p.local_port).includes(q) ||
        p.process_name.toLowerCase().includes(q) ||
        String(p.pid).includes(q) ||
        p.state.toLowerCase().includes(q)
      ));
    }

    function renderPortTableRows() {
      const filtered = getFilteredPorts();
      return el('table', { class: 'tb-table', style: 'width:100%;text-align:left;border-collapse:collapse;' },
        el('thead', {},
          el('tr', { style: 'background:var(--color-bg-subtle);' },
            el('th', { style: 'padding:8px;' }, '协议'),
            el('th', { style: 'padding:8px;' }, '本地地址与端口'),
            el('th', { style: 'padding:8px;' }, '状态'),
            el('th', { style: 'padding:8px;' }, 'PID'),
            el('th', { style: 'padding:8px;' }, '进程名'),
            el('th', { style: 'padding:8px;text-align:right;' }, '操作')
          )
        ),
        el('tbody', {},
          filtered.slice(0, 120).map((item) =>
            el('tr', { style: 'border-top:1px solid var(--color-border);font-size:12px;' },
              el('td', { style: 'padding:6px 8px;' }, el('span', { class: 'tb-badge' }, `${item.protocol} ${item.ip_version}`)),
              el('td', { style: 'padding:6px 8px;font-weight:600;' }, el('span', { class: 'tb-mono' }, `${item.local_addr}:${item.local_port}`)),
              el('td', { style: 'padding:6px 8px;' }, el('span', { class: `tb-badge ${item.state === 'LISTENING' ? 'tb-badge-ok' : ''}` }, item.state)),
              el('td', { style: 'padding:6px 8px;' }, el('span', { class: 'tb-mono', style: 'cursor:pointer;', title: '分析句柄', onclick: () => { currentTab = 'handle'; queryHandles(item.pid); } }, String(item.pid))),
              el('td', { style: 'padding:6px 8px;' }, el('span', { title: item.process_path }, item.process_name)),
              el('td', { style: 'padding:6px 8px;text-align:right;' },
                el('button', { class: 'tb-btn tb-btn-danger tb-btn-sm', onclick: () => killProcess(item.pid) }, '强杀进程')
              )
            )
          )
        )
      );
    }

    function updatePortFilterOnly() {
      const wrap = document.getElementById('devtool-port-table-wrap');
      if (wrap) render(wrap, renderPortTableRows());
      const badge = document.getElementById('devtool-port-count-badge');
      if (badge) {
        const filtered = getFilteredPorts();
        badge.textContent = `共 ${filtered.length} / ${portsList.length} 项`;
      }
    }

    function renderPortView() {
      const filtered = getFilteredPorts();
      return el('div', { class: 'tb-pane' },
        el('div', { style: 'display:flex;gap:8px;align-items:center;margin-bottom:12px;' },
          (native || el)('input', {
            id: 'devtool-port-filter-input',
            class: 'tb-input',
            style: 'width:260px;',
            placeholder: '过滤端口 / 进程名 / PID...',
            defaultValue: portFilter,
            value: portFilter,
            oninput: (e) => {
              portFilter = e.target.value;
              updatePortFilterOnly();
            },
          }),
          el('button', { class: 'tb-btn tb-btn-primary', disabled: portLoading, onclick: loadPorts }, portLoading ? '扫描中...' : '刷新端口'),
          el('span', { id: 'devtool-port-count-badge', class: 'tb-badge' }, `共 ${filtered.length} / ${portsList.length} 项`)
        ),
        el('div', { id: 'devtool-port-table-wrap', style: 'max-height:520px;overflow-y:auto;border:1px solid var(--color-border);border-radius:6px;' },
          renderPortTableRows()
        )
      );
    }

    // 2. 文件锁
    function renderLockView() {
      return el('div', { class: 'tb-pane' },
        el('div', { style: 'background:var(--color-bg-subtle);padding:14px;border-radius:8px;border:1px dashed var(--color-border);margin-bottom:14px;' },
          el('div', { style: 'font-weight:600;margin-bottom:4px;' }, '文件/目录锁解锁器 (Restart Manager + 重启删除)'),
          el('div', { style: 'font-size:12px;color:var(--color-fg-muted);margin-bottom:10px;' }, '排查占用 node_modules、构建缓存或 DLL 的进程。支持直接拖入文件/目录！'),
          el('div', { style: 'display:flex;gap:8px;' },
            (native || el)('input', {
              id: 'devtool-lock-input',
              class: 'tb-input',
              style: 'flex:1;',
              placeholder: '输入或粘贴路径，例如 D:\\project\\target',
              defaultValue: lockPath,
              value: lockPath,
              oninput: (e) => { lockPath = e.target.value; },
              onkeydown: (e) => { if (e.key === 'Enter') detectLock(lockPath); },
            }),
            el('button', {
              class: 'tb-btn tb-btn-ghost',
              title: '使用原生对话框选择目录',
              onclick: async () => {
                try {
                  const p = await ctx.files.pick({ folder: true, directory: lockPath || undefined, title: '选择要排查占用的目录' });
                  if (p && p.length) {
                    lockPath = p[0];
                    const inp = document.getElementById('devtool-lock-input');
                    if (inp) inp.value = lockPath;
                    detectLock(lockPath);
                  }
                } catch (e) { console.warn(e); }
              },
            }, '选择目录'),
            el('button', {
              class: 'tb-btn tb-btn-ghost',
              title: '使用原生对话框选择文件',
              onclick: async () => {
                try {
                  const p = await ctx.files.pick({ folder: false, directory: lockPath || undefined, title: '选择要排查占用的文件' });
                  if (p && p.length) {
                    lockPath = p[0];
                    const inp = document.getElementById('devtool-lock-input');
                    if (inp) inp.value = lockPath;
                    detectLock(lockPath);
                  }
                } catch (e) { console.warn(e); }
              },
            }, '选择文件'),
            el('button', { class: 'tb-btn tb-btn-primary', disabled: lockLoading, onclick: () => detectLock(lockPath) }, lockLoading ? '排查中...' : '排查占用'),
          )
        ),
        lockResults.length > 0
          ? el('div', {},
              el('div', { style: 'font-weight:600;margin-bottom:8px;' }, `发现 ${lockResults.length} 个占用进程：`),
              ...lockResults.map((r) =>
                el('div', { class: 'tb-card', style: 'padding:10px 14px;margin-bottom:8px;display:flex;justify-content:space-between;align-items:center;' },
                  el('div', {},
                    el('div', { style: 'font-weight:600;' }, `${r.process_name} (PID: ${r.pid})`),
                    el('div', { style: 'font-size:11px;color:var(--color-fg-muted);' }, `${r.app_name || r.app_type} · ${r.process_path || '-'}`)
                  ),
                  el('button', { class: 'tb-btn tb-btn-danger tb-btn-sm', onclick: () => killProcess(r.pid) }, '终止并释放')
                )
              )
            )
          : lockSearched && !lockLoading
          ? el('div', { style: 'text-align:center;padding:24px;background:var(--color-bg-subtle);border-radius:6px;' },
              el('div', { class: 'tb-badge tb-badge-ok', style: 'font-size:13px;padding:6px 12px;margin-bottom:8px;' }, '✓ 未检测到常规用户进程锁定'),
              el('div', {},
                el('button', { class: 'tb-btn tb-btn-ghost tb-btn-sm', onclick: () => scheduleRebootDelete(lockPath) }, '若属顽固驱动独占，登记为「开机自检时删除」')
              )
            )
          : null
      );
    }

    // 3. 句柄分析
    function renderHandleView() {
      return el('div', { class: 'tb-pane' },
        el('div', { style: 'display:flex;gap:8px;align-items:center;margin-bottom:12px;' },
          (native || el)('input', {
            id: 'devtool-handle-input',
            class: 'tb-input',
            style: 'width:200px;',
            placeholder: '输入进程 PID',
            defaultValue: handlePid,
            value: handlePid,
            oninput: (e) => { handlePid = e.target.value; },
            onkeydown: (e) => { if (e.key === 'Enter') queryHandles(handlePid); },
          }),
          el('button', { class: 'tb-btn tb-btn-primary', disabled: handleLoading, onclick: () => queryHandles(handlePid) }, handleLoading ? '检索中...' : '深度检索句柄'),
          el('span', { style: 'font-size:12px;color:var(--color-fg-muted);' }, '内置看门狗 50ms 超时与命名管道防死锁保护。')
        ),
        el('div', { style: 'max-height:500px;overflow-y:auto;border:1px solid var(--color-border);border-radius:6px;' },
          el('table', { class: 'tb-table', style: 'width:100%;text-align:left;border-collapse:collapse;' },
            el('thead', {},
              el('tr', { style: 'background:var(--color-bg-subtle);' },
                el('th', { style: 'padding:8px;' }, '句柄值'),
                el('th', { style: 'padding:8px;' }, '对象类型'),
                el('th', { style: 'padding:8px;' }, '内核对象名称 / 路径')
              )
            ),
            el('tbody', {},
              handleList.map((h) =>
                el('tr', { style: 'border-top:1px solid var(--color-border);font-size:12px;' },
                  el('td', { style: 'padding:6px 8px;' }, el('span', { class: 'tb-mono' }, `0x${h.handle_value.toString(16)}`)),
                  el('td', { style: 'padding:6px 8px;' }, el('span', { class: 'tb-badge' }, h.object_type)),
                  el('td', { style: 'padding:6px 8px;font-family:monospace;word-break:break-all;' }, h.object_name || '-')
                )
              )
            )
          )
        )
      );
    }

    // 4. Hosts & DNS
    function renderHostsView() {
      const lineCount = hostsContent ? hostsContent.split('\n').length : 0;
      const charCount = hostsContent ? hostsContent.length : 0;

      return el('div', { class: 'tb-pane' },
        // 头部标题与控制区
        el('div', { style: 'display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:12px;flex-wrap:wrap;gap:8px;' },
          el('div', {},
            el('div', { style: 'font-weight:700;font-size:15px;display:flex;align-items:center;gap:8px;' },
              'Hosts 文件直接编辑',
              hostsBakExists
                ? el('span', { class: 'tb-badge tb-badge-ok', style: 'font-size:11px;' }, '已备份 host.bak')
                : el('span', { class: 'tb-badge', style: 'font-size:11px;color:var(--color-fg-muted);' }, '保存时自动备份为 host.bak')
            ),
            el('div', { style: 'font-size:12px;color:var(--color-fg-muted);margin-top:3px;' },
              `路径: ${hostsPath || 'C:\\Windows\\System32\\drivers\\etc\\hosts'} · 替换前自动保存副本至 host.bak`
            )
          ),
          el('div', { style: 'display:flex;gap:8px;align-items:center;' },
            el('button', { class: 'tb-btn tb-btn-ghost', onclick: flushDns, title: '刷新系统 DNS 解析缓存' }, '⚡ 刷新 DNS 缓存'),
            el('button', { class: 'tb-btn', disabled: hostsLoading, onclick: loadHosts }, hostsLoading ? '读取中...' : '🔄 重新读取'),
            hostsBakExists ? el('button', { class: 'tb-btn', onclick: loadHostsBak, title: '载入上次备份的 host.bak 内容' }, '⏪ 载入 host.bak') : null,
            el('button', {
              class: 'tb-btn tb-btn-primary',
              disabled: hostsSaving || hostsLoading,
              onclick: () => saveHosts(false),
              style: 'font-weight:600;'
            }, hostsSaving ? '保存与备份中...' : '💾 保存 Hosts (自动备份 host.bak)')
          )
        ),

        // 快捷添加单条规则栏
        el('div', { style: 'display:flex;gap:8px;align-items:center;margin-bottom:10px;padding:8px 12px;background:var(--color-bg-subtle);border-radius:6px;border:1px solid var(--color-border);' },
          el('span', { style: 'font-size:12px;font-weight:600;white-space:nowrap;' }, '快捷添加:'),
          (native || el)('input', {
            class: 'tb-input',
            style: 'width:140px;font-size:12px;padding:4px 8px;',
            placeholder: 'IP (如 127.0.0.1)',
            defaultValue: quickIp,
            value: quickIp,
            oninput: (e) => { quickIp = e.target.value; }
          }),
          (native || el)('input', {
            class: 'tb-input',
            style: 'width:200px;font-size:12px;padding:4px 8px;',
            placeholder: '域名 (如 myapp.local)',
            defaultValue: quickDomain,
            value: quickDomain,
            oninput: (e) => { quickDomain = e.target.value; }
          }),
          el('button', { class: 'tb-btn', style: 'padding:4px 10px;font-size:12px;', onclick: addQuickHost }, '➕ 追加至下方'),
          el('span', { style: 'font-size:11px;color:var(--color-fg-muted);margin-left:auto;' }, '也可以直接在下方多行编辑区自由修改')
        ),

        // 提示信息栏（成功 / 错误）
        hostsSuccessMsg ? el('div', {
          style: 'padding:8px 12px;background:rgba(16,185,129,0.1);color:#10b981;border:1px solid rgba(16,185,129,0.3);border-radius:6px;font-size:12px;margin-bottom:10px;'
        }, `✓ ${hostsSuccessMsg}`) : null,

        hostsError ? el('div', {
          style: 'padding:8px 12px;background:rgba(239,68,68,0.1);color:#ef4444;border:1px solid rgba(239,68,68,0.3);border-radius:6px;font-size:12px;margin-bottom:10px;'
        }, `✕ ${hostsError}`) : null,

        // 主编辑器：优先使用原生 native('textarea')，规避 Vue 组件受控模式在输入时重置内容
        (native || el)('textarea', {
          id: 'devtool-hosts-textarea',
          class: 'tb-textarea tb-mono',
          style: 'width:100%;height:440px;padding:12px;font-size:13px;line-height:1.6;background:var(--color-bg);color:var(--color-fg);box-sizing:border-box;border:1px solid var(--color-border);border-radius:6px;tab-size:4;resize:vertical;font-family:Consolas,Monaco,Courier New,monospace;',
          placeholder: '# 在此直接编辑修改 Windows hosts 文件...',
          defaultValue: hostsContent,
          oninput: (e) => {
            hostsContent = e.target.value;
            const stats = document.getElementById('devtool-hosts-stats');
            if (stats) {
              const lines = hostsContent ? hostsContent.split('\n').length : 0;
              stats.textContent = `当前统计: ${lines} 行 · ${hostsContent.length} 字符`;
            }
          },
        }, hostsContent),

        // 底部状态栏
        el('div', { style: 'display:flex;justify-content:space-between;align-items:center;margin-top:6px;font-size:11px;color:var(--color-fg-muted);' },
          el('span', { id: 'devtool-hosts-stats' }, `当前统计: ${lineCount} 行 · ${charCount} 字符`),
          el('span', {}, '提示: 保存时将以 host.bak 备份现有文件，并自动清空 DNS 解析缓存使规则立即生效。')
        )
      );
    }

    // 5. UWP 回环豁免
    function renderUwpTableRows() {
      const filtered = uwpList.filter((a) => !uwpFilter || a.display_name.toLowerCase().includes(uwpFilter.toLowerCase()) || a.name.toLowerCase().includes(uwpFilter.toLowerCase()));
      return el('table', { class: 'tb-table', style: 'width:100%;text-align:left;border-collapse:collapse;' },
        el('thead', {},
          el('tr', { style: 'background:var(--color-bg-subtle);' },
            el('th', { style: 'padding:8px;' }, '应用名称'),
            el('th', { style: 'padding:8px;' }, '状态'),
            el('th', { style: 'padding:8px;text-align:right;' }, '回环权限开关')
          )
        ),
        el('tbody', {},
          filtered.map((app) =>
            el('tr', { style: 'border-top:1px solid var(--color-border);font-size:12px;' },
              el('td', { style: 'padding:6px 8px;' },
                el('div', { style: 'font-weight:600;' }, app.display_name),
                el('div', { style: 'font-size:11px;color:var(--color-fg-muted);' }, app.name)
              ),
              el('td', { style: 'padding:6px 8px;' },
                el('span', { class: `tb-badge ${app.is_exempt ? 'tb-badge-ok' : ''}` }, app.is_exempt ? '已允许回环' : '默认沙箱隔离')
              ),
              el('td', { style: 'padding:6px 8px;text-align:right;' },
                el('button', {
                  class: `tb-btn tb-btn-sm ${app.is_exempt ? 'tb-btn-danger' : 'tb-btn-primary'}`,
                  onclick: () => setUwpExempt(app.sid, !app.is_exempt),
                }, app.is_exempt ? '取消豁免' : '允许连接本地代理')
              )
            )
          )
        )
      );
    }

    function updateUwpFilterOnly() {
      const wrap = document.getElementById('devtool-uwp-table-wrap');
      if (wrap) render(wrap, renderUwpTableRows());
    }

    function renderUwpView() {
      return el('div', { class: 'tb-pane' },
        el('div', { style: 'display:flex;gap:8px;align-items:center;margin-bottom:12px;' },
          (native || el)('input', {
            id: 'devtool-uwp-filter-input',
            class: 'tb-input',
            style: 'width:280px;',
            placeholder: '过滤应用名称或包名...',
            defaultValue: uwpFilter,
            value: uwpFilter,
            oninput: (e) => {
              uwpFilter = e.target.value;
              updateUwpFilterOnly();
            },
          }),
          el('button', { class: 'tb-btn', disabled: uwpLoading, onclick: loadUwp }, uwpLoading ? '加载中...' : '重新读取'),
          el('span', { style: 'font-size:12px;color:var(--color-fg-muted);' }, '开启豁免后，UWP/商店应用可正常连接本地 127.0.0.1 代理（Fiddler / Charles / Clash）。')
        ),
        el('div', { id: 'devtool-uwp-table-wrap', style: 'max-height:500px;overflow-y:auto;border:1px solid var(--color-border);border-radius:6px;' },
          renderUwpTableRows()
        )
      );
    }

    // 6. 端口转发映射
    function renderProxyView() {
      return el('div', { class: 'tb-pane' },
        el('div', { style: 'background:var(--color-bg-subtle);padding:14px;border-radius:8px;border:1px solid var(--color-border);margin-bottom:16px;' },
          el('div', { style: 'font-weight:600;margin-bottom:6px;' }, '新建端口转发规则 (基于 Windows 原生 netsh portproxy)'),
          el('div', { style: 'font-size:12px;color:var(--color-fg-muted);margin-bottom:10px;' }, '用于打通 Windows 端口与 WSL2、Docker 或局域网内网穿透。'),
          el('div', { style: 'display:flex;gap:8px;align-items:center;flex-wrap:wrap;' },
            el('span', { style: 'font-size:12px;' }, '监听端口:'),
            (native || el)('input', { class: 'tb-input', style: 'width:90px;', placeholder: '如 8080', defaultValue: newProxyListenPort, value: newProxyListenPort, oninput: (e) => newProxyListenPort = e.target.value }),
            el('span', { style: 'font-size:12px;' }, '➔ 目标地址:'),
            (native || el)('input', { class: 'tb-input', style: 'width:120px;', placeholder: '127.0.0.1', defaultValue: newProxyConnectAddr, value: newProxyConnectAddr, oninput: (e) => newProxyConnectAddr = e.target.value }),
            el('span', { style: 'font-size:12px;' }, '目标端口:'),
            (native || el)('input', { class: 'tb-input', style: 'width:90px;', placeholder: '如 3000', defaultValue: newProxyConnectPort, value: newProxyConnectPort, oninput: (e) => newProxyConnectPort = e.target.value }),
            el('button', { class: 'tb-btn tb-btn-primary', onclick: () => addProxy(false) }, '添加转发规则 (支持UAC)')
          )
        ),
        el('div', { style: 'margin-bottom:8px;font-weight:600;' }, `当前活跃的端口转发规则 (${proxyList.length})：`),
        proxyList.length === 0
          ? el('div', { style: 'text-align:center;padding:24px;color:var(--color-fg-muted);' }, '当前无活动的端口转发规则')
          : el('div', { style: 'border:1px solid var(--color-border);border-radius:6px;overflow:hidden;' },
              el('table', { class: 'tb-table', style: 'width:100%;text-align:left;border-collapse:collapse;' },
                el('thead', {},
                  el('tr', { style: 'background:var(--color-bg-subtle);' },
                    el('th', { style: 'padding:8px;' }, '监听地址与端口'),
                    el('th', { style: 'padding:8px;' }, '➔ 目标地址与端口'),
                    el('th', { style: 'padding:8px;text-align:right;' }, '操作')
                  )
                ),
                el('tbody', {},
                  proxyList.map((p) =>
                    el('tr', { style: 'border-top:1px solid var(--color-border);font-size:12px;' },
                      el('td', { style: 'padding:6px 8px;font-weight:600;' }, `${p.listen_address}:${p.listen_port}`),
                      el('td', { style: 'padding:6px 8px;' }, `${p.connect_address}:${p.connect_port}`),
                      el('td', { style: 'padding:6px 8px;text-align:right;' },
                        el('button', { class: 'tb-btn tb-btn-danger tb-btn-sm', onclick: () => deleteProxy(p.listen_port) }, '删除规则')
                      )
                    )
                  )
                )
              )
            )
      );
    }

    // 7. 软链接与目录联接
    function renderSymlinkView() {
      return el('div', { class: 'tb-pane' },
        el('div', { style: 'display:grid;grid-template-columns:1fr 1fr;gap:16px;' },
          // 探测
          el('div', { class: 'tb-card', style: 'padding:14px;' },
            el('div', { style: 'font-weight:600;margin-bottom:6px;' }, '软链接/目录联接 (Junction) 溯源探测'),
            el('div', { style: 'font-size:12px;color:var(--color-fg-muted);margin-bottom:10px;' }, '查看某个目录是否为联接点，并查明其真实磁盘指向。'),
            el('div', { style: 'display:flex;gap:8px;margin-bottom:12px;' },
              (native || el)('input', {
                id: 'devtool-symlink-inspect-input',
                class: 'tb-input',
                style: 'flex:1;',
                placeholder: '输入待检测路径',
                defaultValue: symlinkInspectPath,
                value: symlinkInspectPath,
                oninput: (e) => symlinkInspectPath = e.target.value,
              }),
              el('button', {
                class: 'tb-btn tb-btn-ghost',
                onclick: async () => {
                  try {
                    const p = await ctx.files.pick({ folder: true, directory: symlinkInspectPath || undefined, title: '选择待溯源的目录' });
                    if (p && p.length) {
                      symlinkInspectPath = p[0];
                      const inp = document.getElementById('devtool-symlink-inspect-input');
                      if (inp) inp.value = symlinkInspectPath;
                      inspectPath();
                    }
                  } catch (e) { console.warn(e); }
                }
              }, '选择目录'),
              el('button', { class: 'tb-btn tb-btn-primary', disabled: symlinkInspectLoading, onclick: inspectPath }, '检测')
            ),
            symlinkInspectResult
              ? el('div', { style: 'font-size:12px;background:var(--color-bg-subtle);padding:10px;border-radius:6px;' },
                  el('div', {}, `类型: ${symlinkInspectResult.is_reparse_point ? '目录联接 / 软链接 (Reparse Point)' : '普通目录/文件'}`),
                  symlinkInspectResult.target_path
                    ? el('div', { style: 'font-weight:600;margin-top:4px;color:var(--color-fg-brand);' }, `真实目标: ${symlinkInspectResult.target_path}`)
                    : null
                )
              : null
          ),

          // 创建联接
          el('div', { class: 'tb-card', style: 'padding:14px;' },
            el('div', { style: 'font-weight:600;margin-bottom:6px;' }, '创建目录联接 (Junction / mklink)'),
            el('div', { style: 'font-size:12px;color:var(--color-fg-muted);margin-bottom:10px;' }, '用于将 C 盘庞大的 node_modules 或 .cargo 缓存无痛迁移到大容量磁盘。无需管理员权限！'),
            el('div', { style: 'display:flex;flex-direction:column;gap:8px;' },
              el('div', { style: 'display:flex;gap:6px;' },
                (native || el)('input', {
                  id: 'devtool-junction-link-input',
                  class: 'tb-input',
                  style: 'flex:1;',
                  placeholder: '联接点路径 (新路径，如 C:\\Users\\...\\.cargo)',
                  defaultValue: junctionLinkPath,
                  value: junctionLinkPath,
                  oninput: (e) => junctionLinkPath = e.target.value,
                }),
                el('button', {
                  class: 'tb-btn tb-btn-ghost',
                  onclick: async () => {
                    try {
                      const p = await ctx.files.pick({ folder: true, directory: junctionLinkPath || undefined, title: '选择联接点所在目录' });
                      if (p && p.length) {
                        junctionLinkPath = p[0];
                        const inp = document.getElementById('devtool-junction-link-input');
                        if (inp) inp.value = junctionLinkPath;
                        updateUI();
                      }
                    } catch (e) { console.warn(e); }
                  }
                }, '选择')
              ),
              el('div', { style: 'display:flex;gap:6px;' },
                (native || el)('input', {
                  id: 'devtool-junction-target-input',
                  class: 'tb-input',
                  style: 'flex:1;',
                  placeholder: '目标真实文件夹 (现有真实目录，如 D:\\cache\\.cargo)',
                  defaultValue: junctionTargetPath,
                  value: junctionTargetPath,
                  oninput: (e) => junctionTargetPath = e.target.value,
                }),
                el('button', {
                  class: 'tb-btn tb-btn-ghost',
                  onclick: async () => {
                    try {
                      const p = await ctx.files.pick({ folder: true, directory: junctionTargetPath || undefined, title: '选择真实目标目录' });
                      if (p && p.length) {
                        junctionTargetPath = p[0];
                        const inp = document.getElementById('devtool-junction-target-input');
                        if (inp) inp.value = junctionTargetPath;
                        updateUI();
                      }
                    } catch (e) { console.warn(e); }
                  }
                }, '选择')
              ),
              el('button', { class: 'tb-btn tb-btn-primary', disabled: junctionCreating, onclick: createJunction }, junctionCreating ? '创建中...' : '建立联接')
            )
          )
        )
      );
    }

    // 8. Defender 加白
    function renderDefenderView() {
      return el('div', { class: 'tb-pane' },
        // 防护状态卡片
        el('div', { style: 'background:var(--color-bg-subtle);padding:14px;border-radius:8px;border:1px solid var(--color-border);margin-bottom:14px;' },
          el('div', { style: 'display:flex;justify-content:space-between;align-items:center;margin-bottom:10px;' },
            el('div', { style: 'font-weight:600;display:flex;align-items:center;gap:8px;' },
              el('span', { style: 'font-size:16px;' }, '🛡️'),
              'Windows Defender 安全防护与编译状态'
            ),
            el('button', {
              class: 'tb-btn tb-btn-sm',
              disabled: defenderLoading,
              onclick: loadDefender,
            }, defenderLoading ? '检测中...' : '刷新状态')
          ),
          el('div', { style: 'display:flex;gap:10px;flex-wrap:wrap;align-items:center;' },
            el('span', { class: `tb-badge ${defenderRtProtection ? 'tb-badge-ok' : 'tb-badge-warn'}` },
              defenderRtProtection ? '● 实时保护: 已开启' : '○ 实时保护: 已关闭'
            ),
            el('span', { class: `tb-badge ${defenderAvEnabled ? 'tb-badge-ok' : 'tb-badge-warn'}` },
              defenderAvEnabled ? '● 杀毒引擎: 运行中' : '○ 杀毒引擎: 未就绪'
            ),
            defenderEngineVer ? el('span', { class: 'tb-badge tb-mono' }, `引擎版本: ${defenderEngineVer}`) : null,
            defenderSigVer ? el('span', { class: 'tb-badge tb-mono' }, `病毒库: ${defenderSigVer}`) : null
          )
        ),

        // 加白输入卡片
        el('div', { style: 'background:var(--color-bg-subtle);padding:14px;border-radius:8px;border:1px solid var(--color-border);margin-bottom:16px;' },
          el('div', { style: 'font-weight:600;margin-bottom:4px;' }, '项目编译目录加白 (大幅提升构建速度)'),
          el('div', { style: 'font-size:12px;color:var(--color-fg-muted);margin-bottom:10px;' },
            '将代码工作区、node_modules、Rust target、Go/C++ 输出目录排除实时扫描，避免杀毒软件高频拦截磁盘读写，构建速度提升 3~5 倍。'
          ),
          el('div', { style: 'display:flex;gap:8px;' },
            (native || el)('input', {
              id: 'devtool-defender-input',
              class: 'tb-input',
              style: 'flex:1;',
              placeholder: '输入或选择需要加白的文件夹路径，例如 D:\\code\\my-project',
              defaultValue: newDefenderPath,
              value: newDefenderPath,
              oninput: (e) => newDefenderPath = e.target.value,
            }),
            el('button', {
              class: 'tb-btn tb-btn-ghost',
              onclick: async () => {
                try {
                  const p = await ctx.files.pick({ folder: true, directory: newDefenderPath || undefined, title: '选择需要排除扫描的项目目录' });
                  if (p && p.length) {
                    newDefenderPath = p[0];
                    const inp = document.getElementById('devtool-defender-input');
                    if (inp) inp.value = newDefenderPath;
                    updateUI();
                  }
                } catch (e) { console.warn(e); }
              }
            }, '选择目录'),
            el('button', {
              class: 'tb-btn tb-btn-primary',
              onclick: () => addDefenderExclusion(newDefenderPath, false)
            }, '添加排除项')
          )
        ),

        // 排除项列表与管理
        el('div', { style: 'border:1px solid var(--color-border);border-radius:8px;padding:14px;' },
          el('div', { style: 'display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;' },
            el('div', { style: 'font-weight:600;display:flex;align-items:center;gap:6px;' },
              '已配置的排除目录',
              el('span', { class: 'tb-badge' }, `${defenderPaths.length} 项`)
            ),
            el('div', { style: 'display:flex;gap:8px;' },
              defenderReqAdmin
                ? el('button', {
                    class: 'tb-btn tb-btn-primary tb-btn-sm',
                    disabled: defenderElevating,
                    onclick: loadDefenderElevated,
                  }, defenderElevating ? '提权读取中...' : '🛡️ 通过 UAC 提权读取列表')
                : el('button', {
                    class: 'tb-btn tb-btn-ghost tb-btn-sm',
                    disabled: defenderElevating,
                    onclick: loadDefenderElevated,
                  }, defenderElevating ? '读取中...' : '🛡️ 重新提权读取')
            )
          ),

          defenderReqAdmin && defenderPaths.length === 0
            ? el('div', { style: 'background:rgba(234, 179, 8, 0.08);border:1px solid rgba(234, 179, 8, 0.25);border-radius:6px;padding:14px;color:var(--color-fg);' },
                el('div', { style: 'font-weight:600;margin-bottom:4px;color:#d97706;display:flex;align-items:center;gap:6px;' },
                  '🔒 Windows 安全权限限制说明'
                ),
                el('div', { style: 'font-size:12px;color:var(--color-fg-muted);line-height:1.6;margin-bottom:12px;' },
                  'Windows 10/11 操作系统出于安全防护，默认禁止以普通用户权限直接查询已有的 Defender 排除列表（以防恶意软件刺探加白目录漏洞）。\n' +
                  '点击下方【🛡️ 立即提权读取】按钮，系统将弹出一次管理员授权窗口，授权后即可直接查看已配置的排除路径并执行移除管理。'
                ),
                el('button', {
                  class: 'tb-btn tb-btn-sm tb-btn-primary',
                  disabled: defenderElevating,
                  onclick: loadDefenderElevated,
                }, defenderElevating ? '提权读取中...' : '🛡️ 立即提权读取')
              )
            : defenderPaths.length === 0
              ? el('div', { style: 'text-align:center;padding:24px;color:var(--color-fg-muted);font-size:13px;' },
                  '未检测到已配置的 Defender 排除目录。'
                )
              : el('div', { style: 'display:flex;flex-direction:column;gap:6px;' },
                  ...defenderPaths.map((p) =>
                    el('div', {
                      style: 'display:flex;justify-content:space-between;align-items:center;padding:8px 12px;background:var(--color-bg-subtle);border-radius:6px;border:1px solid var(--color-border);'
                    },
                      el('span', { class: 'tb-mono', style: 'font-size:12px;word-break:break-all;' }, p),
                      el('button', {
                        class: 'tb-btn tb-btn-danger tb-btn-sm',
                        style: 'margin-left:12px;flex-shrink:0;',
                        onclick: () => removeDefenderExclusion(p, true)
                      }, '移除')
                    )
                  )
                )
        )
      );
    }

    // 9. 开发服务
    function renderServiceView() {
      return el('div', { class: 'tb-pane' },
        el('div', { style: 'display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;' },
          el('div', { style: 'font-weight:600;' }, '开发相关后台系统服务管家'),
          el('button', { class: 'tb-btn', disabled: serviceLoading, onclick: loadServices }, serviceLoading ? '刷新中...' : '刷新服务列表')
        ),
        serviceList.length === 0
          ? el('div', { style: 'text-align:center;padding:24px;color:var(--color-fg-muted);' }, serviceLoading ? '正在检索 Windows 系统服务...' : '未检测到常见开发数据库或容器服务')
          : el('div', { style: 'border:1px solid var(--color-border);border-radius:6px;overflow:hidden;' },
              el('table', { class: 'tb-table', style: 'width:100%;text-align:left;border-collapse:collapse;' },
                el('thead', {},
                  el('tr', { style: 'background:var(--color-bg-subtle);' },
                    el('th', { style: 'padding:8px;' }, '服务名 / 显示名'),
                    el('th', { style: 'padding:8px;' }, '状态'),
                    el('th', { style: 'padding:8px;' }, '启动类型'),
                    el('th', { style: 'padding:8px;text-align:right;' }, '控制动作')
                  )
                ),
                el('tbody', {},
                  serviceList.map((s) =>
                    el('tr', { style: 'border-top:1px solid var(--color-border);font-size:12px;' },
                      el('td', { style: 'padding:6px 8px;' },
                        el('div', { style: 'font-weight:600;' }, s.display_name),
                        el('div', { style: 'font-size:11px;color:var(--color-fg-muted);' }, s.name)
                      ),
                      el('td', { style: 'padding:6px 8px;' },
                        el('span', { class: `tb-badge ${s.status === 'Running' ? 'tb-badge-ok' : ''}` }, s.status)
                      ),
                      el('td', { style: 'padding:6px 8px;color:var(--color-fg-muted);' }, s.start_type),
                      el('td', { style: 'padding:6px 8px;text-align:right;' },
                        el('div', { style: 'display:flex;gap:4px;justify-content:flex-end;' },
                          s.status === 'Running'
                            ? el('button', { class: 'tb-btn tb-btn-danger tb-btn-sm', onclick: () => controlService(s.name, 'stop') }, '停止')
                            : el('button', { class: 'tb-btn tb-btn-primary tb-btn-sm', onclick: () => controlService(s.name, 'start') }, '启动'),
                          el('button', { class: 'tb-btn tb-btn-ghost tb-btn-sm', onclick: () => controlService(s.name, 'restart') }, '重启')
                        )
                      )
                    )
                  )
                )
              )
            )
      );
    }

    // 10. PATH 诊断
    function renderEnvView() {
      return el('div', { class: 'tb-pane' },
        el('div', { style: 'display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;' },
          el('div', { style: 'font-weight:600;' }, 'Windows 环境变量与开发工具多版本阴影诊断'),
          el('button', { class: 'tb-btn tb-btn-primary', disabled: envLoading, onclick: runEnvDiag }, envLoading ? '诊断中...' : '重新诊断')
        ),
        envReport
          ? el('div', { style: 'display:flex;flex-direction:column;gap:16px;' },
              el('div', { class: 'tb-card' },
                el('div', { class: 'tb-card-head', style: 'padding:10px 14px;font-weight:600;background:var(--color-bg-subtle);' }, '开发工具阴影与多版本检测 (Shadow Collision)'),
                el('div', { class: 'tb-card-body', style: 'padding:12px;' },
                  el('div', { style: 'display:grid;grid-template-columns:repeat(auto-fill, minmax(260px, 1fr));gap:8px;' },
                    envReport.tools.map((t) =>
                      el('div', { style: `border:1px solid ${t.has_shadow ? 'var(--color-danger, #ef4444)' : 'var(--color-border)'};padding:8px 12px;border-radius:6px;background:var(--color-bg-subtle);` },
                        el('div', { style: 'display:flex;justify-content:space-between;align-items:center;margin-bottom:4px;' },
                          el('span', { style: 'font-weight:600;' }, t.tool_name),
                          t.has_shadow ? el('span', { class: 'tb-badge tb-badge-bad' }, '冲突') : t.active_path ? el('span', { class: 'tb-badge tb-badge-ok' }, '正常') : el('span', { class: 'tb-badge' }, '未安装')
                        ),
                        el('div', { style: 'font-size:11px;color:var(--color-fg-muted);word-break:break-all;' }, t.active_path ? `当前生效: ${t.active_path}` : '未找到')
                      )
                    )
                  )
                )
              )
            )
          : el('div', { style: 'padding:24px;text-align:center;color:var(--color-fg-muted);' }, '点击上方按钮开始诊断')
      );
    }

    // 11. 防休眠 Awake
    function renderAwakeView() {
      return el('div', { class: 'tb-pane' },
        el('div', { style: 'max-width:540px;background:var(--color-bg-subtle);border:1px solid var(--color-border);padding:24px;border-radius:8px;' },
          el('div', { style: 'font-size:16px;font-weight:600;margin-bottom:8px;' }, '系统防休眠保持助手 (Awake)'),
          el('div', { style: 'color:var(--color-fg-muted);font-size:13px;margin-bottom:16px;' }, '保持编译、训练与下载持续进行，阻止系统自动睡眠。'),
          el('div', { style: 'display:flex;align-items:center;gap:12px;margin-bottom:16px;' },
            el('button', {
              class: `tb-btn ${awakeActive ? 'tb-btn-danger' : 'tb-btn-primary'}`,
              style: 'padding:10px 24px;',
              onclick: toggleAwake,
            }, awakeActive ? '⏹ 停止防休眠' : '▶ 启用防休眠'),
            el('span', { class: `tb-badge ${awakeActive ? 'tb-badge-ok' : ''}` }, awakeActive ? '● 防休眠工作中' : '○ 已停用')
          ),
          el('div', { style: 'display:flex;align-items:center;gap:8px;' },
            (native || el)('input', { type: 'checkbox', id: 'keep_disp', checked: awakeKeepDisplay, onchange: (e) => { awakeKeepDisplay = e.target.checked; if (awakeActive) toggleAwake(); } }),
            el('label', { for: 'keep_disp', style: 'font-size:13px;cursor:pointer;' }, '同时阻止屏幕自动熄屏')
          )
        )
      );
    }

    function updateUI() {
      if (!rootContainer) return;
      render(rootContainer,
        el('div', { class: 'tb-pane tb-pane-pad', style: 'padding:16px;max-width:1200px;margin:0 auto;' },
          el('div', { style: 'display:flex;justify-content:space-between;align-items:center;margin-bottom:14px;' },
            el('div', {},
              el('div', { style: 'font-size:18px;font-weight:700;display:flex;align-items:center;gap:8px;' },
                'Windows 全能开发与系统小工具箱 (DevToolbox)',
                el('span', { class: 'tb-badge tb-badge-ok', style: 'font-size:11px;' }, 'v0.3.1 Full')
              ),
              el('div', { style: 'font-size:12px;color:var(--color-fg-muted);margin-top:2px;' }, '端口占用 · 文件锁 · 句柄分析 · Hosts/DNS · UWP代理回环 · 端口转发 · 软链接 · Defender加白 · 开发服务 · PATH诊断 · 防休眠')
            )
          ),
          renderTabs(),
          currentTab === 'port' ? renderPortView() :
          currentTab === 'lock' ? renderLockView() :
          currentTab === 'handle' ? renderHandleView() :
          currentTab === 'hosts' ? renderHostsView() :
          currentTab === 'uwp' ? renderUwpView() :
          currentTab === 'proxy' ? renderProxyView() :
          currentTab === 'symlink' ? renderSymlinkView() :
          currentTab === 'defender' ? renderDefenderView() :
          currentTab === 'service' ? renderServiceView() :
          currentTab === 'env' ? renderEnvView() :
          renderAwakeView()
        )
      );
    }

    ctx.registerView('main', async (root) => {
      rootContainer = root;
      try {
        const savedTab = await ctx.storage.get('activeTab');
        if (savedTab && typeof savedTab === 'string') {
          currentTab = savedTab;
        }
      } catch (_) {}
      updateUI();
      if (currentTab === 'port') loadPorts();
      else if (currentTab === 'hosts') loadHosts();
      else if (currentTab === 'uwp') loadUwp();
      else if (currentTab === 'proxy') loadProxies();
      else if (currentTab === 'defender') loadDefender();
      else if (currentTab === 'service') loadServices();
      else if (currentTab === 'env') runEnvDiag();
    });
  },

  async deactivate(ctx) {
    try {
      await ctx.closeStream('devtool-core');
    } catch (_) {}
  },
};
