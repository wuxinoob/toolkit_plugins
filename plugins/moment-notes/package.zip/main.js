(function(){
  if (typeof window !== 'undefined') {
    window.__injectMomentNotesStyles = function(targetDoc) {
      var doc = targetDoc || (typeof document !== 'undefined' ? document : null);
      if (!doc) return;
      var styleId = 'moment-notes-plugin-styles';
      if (!doc.getElementById(styleId)) {
        var s = doc.createElement('style');
        s.id = styleId;
        s.textContent = ".menu-item[data-v-fd7620eb]{--level-indent:14px;height:40px;padding-left:calc(12px + var(--item-level,0) * var(--level-indent));cursor:pointer;color:var(--text-secondary);border:1px solid #0000;border-radius:10px;flex-shrink:0;justify-content:space-between;align-items:center;margin-bottom:6px;padding-right:10px;transition:opacity .2s cubic-bezier(.4,0,.2,1),background-color .2s cubic-bezier(.4,0,.2,1),border-color .2s cubic-bezier(.4,0,.2,1),box-shadow .2s cubic-bezier(.4,0,.2,1),color .2s cubic-bezier(.4,0,.2,1),transform .2s cubic-bezier(.4,0,.2,1);display:flex;position:relative}.menu-item .active-indicator[data-v-fd7620eb]{background:var(--accent-color);border-radius:0 4px 4px 0;width:3px;height:0;transition:height .25s cubic-bezier(.34,1.56,.64,1);position:absolute;left:0}.menu-item[data-v-fd7620eb]:hover{background:var(--item-hover-bg);color:var(--text-primary)}.menu-item.active[data-v-fd7620eb]{background:var(--panel-bg);border-color:var(--panel-border);color:var(--text-primary);box-shadow:var(--shadow-sm);font-weight:600}.menu-item.active .active-indicator[data-v-fd7620eb]{height:16px}.menu-item.active .item-icon[data-v-fd7620eb]{color:var(--accent-color)}.menu-item.active .item-badge[data-v-fd7620eb]{background:var(--accent-color);color:var(--text-on-accent)}.item-left[data-v-fd7620eb]{flex:1;align-items:center;gap:10px;min-width:0;display:flex}.item-left .item-icon[data-v-fd7620eb]{width:16px;height:16px;color:var(--text-muted);flex-shrink:0;transition:color .2s}.item-left .item-name[data-v-fd7620eb]{white-space:nowrap;text-overflow:ellipsis;-webkit-user-select:none;user-select:none;font-size:14px;overflow:hidden}.item-badge[data-v-fd7620eb]{background:var(--badge-bg);color:var(--text-secondary);border-radius:20px;padding:2px 8px;font-size:11px;font-weight:600;transition:opacity .2s,background-color .2s,color .2s,transform .2s}.category-node[data-v-fd7620eb]{display:block}.sub-categories[data-v-fd7620eb]{grid-template-rows:1fr;transition:grid-template-rows .22s cubic-bezier(.4,0,.2,1);display:grid;overflow:visible}.sub-categories .sub-categories-inner[data-v-fd7620eb]{overflow:hidden}.sub-categories.is-collapsed[data-v-fd7620eb]{grid-template-rows:0fr;overflow:hidden}.menu-item .collapse-toggle[data-v-fd7620eb]{width:20px;height:20px;color:var(--text-muted);cursor:pointer;z-index:2;background:0 0;border-radius:4px;flex-shrink:0;justify-content:center;align-self:center;align-items:center;margin-left:-8px;margin-right:2px;transition:opacity .15s,background-color .15s,color .15s,transform .15s;display:flex}.menu-item .collapse-toggle[data-v-fd7620eb]:hover{color:var(--text-primary)}.menu-item .collapse-toggle:hover .toggle-icon[data-v-fd7620eb]{transform:scale(1.12)}.menu-item .collapse-toggle:hover .toggle-icon.is-expanded[data-v-fd7620eb]{transform:rotate(90deg)scale(1.12)}.menu-item .collapse-toggle .toggle-icon[data-v-fd7620eb]{stroke-width:2.5px;width:12px;height:12px;transition:transform .2s cubic-bezier(.4,0,.2,1),color .2s;display:block}.menu-item .collapse-toggle .toggle-icon.is-expanded[data-v-fd7620eb]{transform:rotate(90deg)}.menu-item.has-actions:hover .item-badge[data-v-fd7620eb]{opacity:0;transform:scale(.8)}.menu-item.has-actions:hover .item-actions[data-v-fd7620eb]{opacity:1;pointer-events:auto;transform:translate(0)}.menu-item.dragging[data-v-fd7620eb]{opacity:.45;background:var(--item-hover-bg);border-color:var(--accent-color);box-shadow:none;border-style:dashed}.menu-item.dragging .item-badge[data-v-fd7620eb],.menu-item.dragging .item-actions[data-v-fd7620eb],.menu-item.dragging .active-indicator[data-v-fd7620eb],.menu-item.dragging .collapse-toggle[data-v-fd7620eb]{opacity:0!important}.menu-item.drag-inside[data-v-fd7620eb]{background:var(--drag-inside-bg)!important;border-color:var(--accent-color)!important;box-shadow:inset 0 0 0 1px var(--accent-color), var(--shadow-sm)!important}.menu-item.category-list-move[data-v-fd7620eb]{transition:none}.sidebar-menu.is-dragging .menu-item.category-list-move[data-v-fd7620eb]{transition:transform .25s cubic-bezier(.16,1,.3,1)}.menu-item.category-list-enter-active[data-v-fd7620eb],.menu-item.category-list-leave-active[data-v-fd7620eb]{transition:opacity .22s cubic-bezier(.4,0,.2,1),height .22s cubic-bezier(.4,0,.2,1),min-height .22s cubic-bezier(.4,0,.2,1),margin-bottom .22s cubic-bezier(.4,0,.2,1),padding-top .22s cubic-bezier(.4,0,.2,1),padding-bottom .22s cubic-bezier(.4,0,.2,1),border-top-width .22s cubic-bezier(.4,0,.2,1),border-bottom-width .22s cubic-bezier(.4,0,.2,1);overflow:hidden}.menu-item.category-list-enter-from[data-v-fd7620eb],.menu-item.category-list-leave-to[data-v-fd7620eb]{opacity:0;border-top-width:0;border-bottom-width:0;height:0;min-height:0;margin-bottom:0;padding-top:0;padding-bottom:0}.item-right[data-v-fd7620eb]{justify-content:flex-end;align-items:center;width:48px;height:20px;display:flex;position:relative}.item-actions[data-v-fd7620eb]{opacity:0;pointer-events:none;align-items:center;gap:4px;transition:opacity .2s cubic-bezier(.16,1,.3,1),transform .2s cubic-bezier(.16,1,.3,1);display:flex;position:absolute;right:0;transform:translate(10px)}.action-btn[data-v-fd7620eb]{width:24px;height:24px;color:var(--text-muted);cursor:pointer;background:0 0;border:none;border-radius:6px;flex-shrink:0;justify-content:center;align-items:center;display:flex}.action-btn[data-v-fd7620eb]:hover{background:var(--action-btn-hover-bg);color:var(--btn-hover-color)}.action-btn.delete[data-v-fd7620eb]:hover{background:var(--action-btn-danger-hover-bg);color:var(--danger-color)}.action-btn .action-icon[data-v-fd7620eb]{width:14px;height:14px}.item-edit-wrapper[data-v-fd7620eb]{align-items:center;gap:6px;width:100%;display:flex}.item-edit-input[data-v-fd7620eb]{background:var(--input-bg);border:1px solid var(--input-border);color:var(--text-primary);border-radius:6px;flex:1;width:100%;padding:4px 8px;font-size:13px}.edit-btn[data-v-fd7620eb]{background:var(--accent-color);width:24px;height:24px;color:var(--text-on-accent);border-radius:6px;flex-shrink:0;justify-content:center;align-items:center;transition:background-color .2s,color .2s,transform .2s;display:flex}.edit-btn.confirm[data-v-fd7620eb]:hover{background:var(--accent-hover)}.edit-btn .btn-icon-small[data-v-fd7620eb]{width:12px;height:12px}@media (width<=1049px){.menu-item[data-v-fd7620eb]{height:36px;padding-left:calc(10px + var(--item-level,0) * 12px);padding-right:6px}.menu-item .collapse-toggle[data-v-fd7620eb]{margin-right:0}.item-left[data-v-fd7620eb]{gap:6px}}.menu-item[data-v-c8d83775]{--level-indent:14px;height:40px;padding-left:calc(12px + var(--item-level,0) * var(--level-indent));cursor:pointer;color:var(--text-secondary);border:1px solid #0000;border-radius:10px;flex-shrink:0;justify-content:space-between;align-items:center;margin-bottom:6px;padding-right:10px;transition:opacity .2s cubic-bezier(.4,0,.2,1),background-color .2s cubic-bezier(.4,0,.2,1),border-color .2s cubic-bezier(.4,0,.2,1),box-shadow .2s cubic-bezier(.4,0,.2,1),color .2s cubic-bezier(.4,0,.2,1),transform .2s cubic-bezier(.4,0,.2,1);display:flex;position:relative}.menu-item .active-indicator[data-v-c8d83775]{background:var(--accent-color);border-radius:0 4px 4px 0;width:3px;height:0;transition:height .25s cubic-bezier(.34,1.56,.64,1);position:absolute;left:0}.menu-item[data-v-c8d83775]:hover{background:var(--item-hover-bg);color:var(--text-primary)}.menu-item.active[data-v-c8d83775]{background:var(--panel-bg);border-color:var(--panel-border);color:var(--text-primary);box-shadow:var(--shadow-sm);font-weight:600}.menu-item.active .active-indicator[data-v-c8d83775]{height:16px}.menu-item.active .item-icon[data-v-c8d83775]{color:var(--accent-color)}.menu-item.active .item-badge[data-v-c8d83775]{background:var(--accent-color);color:var(--text-on-accent)}.menu-item.trash-item.active .item-icon[data-v-c8d83775]{color:var(--danger-color,#ff4d4f)!important}.menu-item.trash-item.active .item-badge[data-v-c8d83775]{background:var(--danger-color,#ff4d4f)!important;color:var(--text-on-accent,#fff)!important}.item-left[data-v-c8d83775]{flex:1;align-items:center;gap:10px;min-width:0;display:flex}.item-left .item-icon[data-v-c8d83775]{width:16px;height:16px;color:var(--text-muted);flex-shrink:0;transition:color .2s}.item-left .item-name[data-v-c8d83775]{white-space:nowrap;text-overflow:ellipsis;-webkit-user-select:none;user-select:none;font-size:14px;overflow:hidden}.item-badge[data-v-c8d83775]{background:var(--badge-bg);color:var(--text-secondary);border-radius:20px;padding:2px 8px;font-size:11px;font-weight:600;transition:opacity .2s,background-color .2s,color .2s,transform .2s}@media (width<=1049px){.menu-item[data-v-c8d83775]{height:36px;padding-left:calc(10px + var(--item-level,0) * 10px);padding-right:6px}.item-left[data-v-c8d83775]{gap:6px}}.sidebar-menu[data-v-f6c8c0b7]{overflow-y:auto;overflow-y:overlay;flex-direction:column;flex:1;margin-top:14px;padding:16px 12px;display:flex;position:relative}.sidebar-menu.uTools[data-v-f6c8c0b7]{margin-top:14px;padding-top:0}.category-list-wrapper[data-v-f6c8c0b7]{flex-shrink:0;display:block;position:relative}.drag-indicator-line[data-v-f6c8c0b7]{background:var(--accent-color);z-index:100;pointer-events:none;--level-indent:14px;height:2px;left:calc(14px + var(--item-level,0) * var(--level-indent));border-radius:1px;transition:top .12s cubic-bezier(.4,0,.2,1),left .12s cubic-bezier(.4,0,.2,1);position:absolute;right:10px}@media (width<=1049px){.drag-indicator-line[data-v-f6c8c0b7]{--level-indent:10px;left:calc(10px + var(--item-level,0) * var(--level-indent));right:6px}}.menu-divider[data-v-f6c8c0b7]{background:var(--divider-color);opacity:.8;flex-shrink:0;height:1px;margin:2px 0 8px}@media (width<=1049px){.sidebar-menu[data-v-f6c8c0b7]{margin-top:8px;padding:10px 8px}.sidebar-menu.uTools[data-v-f6c8c0b7]{margin-top:10px;padding-top:0}.menu-divider[data-v-f6c8c0b7]{margin:0 0 6px}}.category-add-container[data-v-052ae00a]{width:100%;height:36px}@media (width<=1049px){.category-add-container[data-v-052ae00a]{height:34px}}.add-category-btn[data-v-052ae00a]{background:var(--accent-light);width:100%;height:100%;color:var(--accent-color);border:1px dashed var(--accent-border-dashed);border-radius:10px;justify-content:center;align-items:center;gap:8px;padding:0 10px;font-size:13px;font-weight:600;transition:background-color .2s,border-color .2s,color .2s,transform .2s;display:flex}.add-category-btn[data-v-052ae00a]:hover{background:var(--accent-color);color:var(--text-on-accent);border-color:#0000}.add-category-btn .add-icon[data-v-052ae00a]{width:15px;height:15px}.add-category-input-wrapper[data-v-052ae00a]{align-items:center;gap:8px;height:100%;display:flex}.add-input[data-v-052ae00a]{background:var(--input-bg);border:1px solid var(--input-border);height:100%;color:var(--text-primary);border-radius:8px;flex:1;width:100%;padding:0 12px;font-size:13px}.add-input[data-v-052ae00a]:focus{border-color:var(--accent-color);box-shadow:0 0 0 2px var(--accent-light)}.add-actions[data-v-052ae00a]{gap:4px;height:100%;display:flex}.add-confirm-btn[data-v-052ae00a],.add-cancel-btn[data-v-052ae00a]{aspect-ratio:1;border-radius:8px;justify-content:center;align-items:center;height:100%;transition:background-color .2s,color .2s,transform .2s;display:flex}.add-confirm-btn .btn-icon[data-v-052ae00a],.add-cancel-btn .btn-icon[data-v-052ae00a]{width:14px;height:14px}.add-confirm-btn[data-v-052ae00a]{background:var(--accent-color);color:var(--text-on-accent)}.add-confirm-btn[data-v-052ae00a]:hover{background:var(--accent-hover)}.add-cancel-btn[data-v-052ae00a]{background:var(--btn-bg);color:var(--text-secondary);border:1px solid var(--btn-border)}.add-cancel-btn[data-v-052ae00a]:hover{background:var(--btn-hover-bg);color:var(--btn-hover-color);border-color:var(--btn-hover-border)}.sidebar-container[data-v-c869d7d5]{background:var(--sidebar-bg);border-right:1px solid var(--panel-border);z-index:2;flex-direction:column;flex-shrink:0;height:100%;display:flex;position:relative}.sidebar-header[data-v-c869d7d5]{-webkit-app-region:drag;-webkit-user-select:none;user-select:none;border-bottom:1px solid #ffffff0d;justify-content:space-between;align-items:center;gap:12px;padding:18px 18px 0;display:flex}.sidebar-header .sidebar-brand[data-v-c869d7d5]{align-items:center;gap:12px;display:flex}.sidebar-header .logo[data-v-c869d7d5]{width:30px;height:30px;color:var(--accent-color)}.sidebar-header .header-title[data-v-c869d7d5]{font-family:var(--font-display);color:var(--text-primary);letter-spacing:.5px;font-size:18px;font-weight:700}.mobile-sidebar-close[data-v-c869d7d5]{display:none}.sidebar-footer[data-v-c869d7d5]{padding:16px 12px;-webkit-app-region:no-drag!important}.sidebar-footer-actions[data-v-c869d7d5]{align-items:center;width:100%;display:flex}.category-add-wrapper[data-v-c869d7d5]{flex:1}.settings-btn[data-v-c869d7d5]{background:var(--btn-bg);border:1px solid var(--btn-border);width:36px;height:36px;color:var(--text-muted);cursor:pointer;border-radius:10px;flex-shrink:0;justify-content:center;align-items:center;margin-left:8px;transition:width .25s cubic-bezier(.16,1,.3,1),margin-left .25s cubic-bezier(.16,1,.3,1),opacity .25s cubic-bezier(.16,1,.3,1),background-color .25s cubic-bezier(.16,1,.3,1),border-color .25s cubic-bezier(.16,1,.3,1),color .25s cubic-bezier(.16,1,.3,1),transform .25s cubic-bezier(.16,1,.3,1);display:flex;overflow:hidden}.settings-btn[data-v-c869d7d5]:hover{background:var(--btn-hover-bg);color:var(--accent-color);border-color:var(--btn-hover-border)}.settings-btn:hover .settings-btn-icon[data-v-c869d7d5]{transform:rotate(45deg)}.settings-btn .settings-btn-icon[data-v-c869d7d5]{width:16px;height:16px;transition:transform .4s cubic-bezier(.16,1,.3,1)}.settings-btn.is-hidden[data-v-c869d7d5]{opacity:0;pointer-events:none;border-color:#0000;width:0;margin-left:0}.resize-handle[data-v-c869d7d5]{cursor:col-resize;z-index:10;background:0 0;justify-content:center;width:10px;height:100%;display:flex;position:absolute;top:0;right:-5px;-webkit-app-region:no-drag!important}.resize-handle[data-v-c869d7d5]:after{content:\"\";background-color:#0000;width:3px;height:100%;transition:background-color .2s}.resize-handle[data-v-c869d7d5]:hover:after,.resize-handle.resizing[data-v-c869d7d5]:after{background-color:var(--accent-color)}@media (width<=1049px){.sidebar-header[data-v-c869d7d5]{gap:8px;padding:14px 14px 0}.sidebar-footer[data-v-c869d7d5]{padding:12px 8px}.settings-btn[data-v-c869d7d5]{border-radius:8px;width:34px;height:34px;margin-left:6px}.settings-btn .settings-btn-icon[data-v-c869d7d5]{width:14px;height:14px}}@media (width<=599px){.sidebar-container[data-v-c869d7d5]{box-shadow:none;-webkit-backdrop-filter:var(--glass-blur-heavy,blur(28px) saturate(190%));border-right:1px solid var(--panel-border);transition:transform .25s cubic-bezier(.4,0,.2,1);top:0;bottom:0;left:0;transform:translate(-100%);z-index:9000!important;background:var(--drawer-bg,#121826f2)!important;width:min(300px,82vw)!important;height:100%!important;position:fixed!important}.sidebar-container.mobile-open[data-v-c869d7d5]{transform:translate(0);box-shadow:0 0 40px #0000008c}.sidebar-header[data-v-c869d7d5]{padding:16px 14px 12px}.mobile-sidebar-close[data-v-c869d7d5]{background:var(--btn-bg);border:1px solid var(--btn-border);width:32px;height:32px;color:var(--text-muted);cursor:pointer;border-radius:8px;justify-content:center;align-items:center;transition:background-color .2s,color .2s;display:flex!important}.mobile-sidebar-close[data-v-c869d7d5]:hover,.mobile-sidebar-close[data-v-c869d7d5]:active{background:var(--btn-hover-bg);color:var(--text-primary)}.mobile-sidebar-close .close-icon[data-v-c869d7d5]{width:16px;height:16px}.resize-handle[data-v-c869d7d5]{display:none!important}}.search-section[data-v-665aab41]{flex:1;align-items:center;max-width:320px;display:flex;-webkit-app-region:no-drag!important}.search-wrapper[data-v-665aab41]{box-sizing:border-box;background:#0000001f;border:1px solid #ffffff0d;border-radius:12px;align-items:center;width:100%;height:38px;transition:background-color .3s cubic-bezier(.16,1,.3,1),border-color .3s cubic-bezier(.16,1,.3,1),box-shadow .3s cubic-bezier(.16,1,.3,1);display:flex;position:relative}.light-theme .search-wrapper[data-v-665aab41]{background:#fff9;border-color:#00000014}.search-wrapper[data-v-665aab41]:focus-within{border-color:var(--accent-color);box-shadow:0 0 0 3px var(--accent-light);background:#0000002e}.light-theme .search-wrapper[data-v-665aab41]:focus-within{background:#fff}.search-icon[data-v-665aab41]{width:16px;height:16px;color:var(--text-muted);pointer-events:none;position:absolute;left:12px}.search-input[data-v-665aab41]{width:100%;height:100%;color:var(--text-primary);box-sizing:border-box;background:0 0;border:none;outline:none;padding:0 64px 0 36px;font-size:13px}.search-input[data-v-665aab41]::placeholder{color:var(--text-muted)}.clear-search-btn[data-v-665aab41]{width:20px;height:20px;color:var(--text-muted);cursor:pointer;background:0 0;border:none;border-radius:50%;justify-content:center;align-items:center;padding:0;transition:background-color .2s,color .2s,transform .2s;display:flex;position:absolute;top:50%;right:36px;transform:translateY(-50%)}.clear-search-btn[data-v-665aab41]:hover{color:var(--text-primary);background:#ffffff1a}.light-theme .clear-search-btn[data-v-665aab41]:hover{background:#0000000d}.clear-icon[data-v-665aab41]{width:12px;height:12px}.search-target-wrapper[data-v-665aab41]{align-items:center;display:flex;position:absolute;top:50%;right:8px;transform:translateY(-50%)}.target-trigger-btn[data-v-665aab41]{width:26px;height:26px;color:var(--text-secondary);cursor:pointer;background:0 0;border:none;border-radius:6px;justify-content:center;align-items:center;padding:0;transition:background-color .2s,color .2s,transform .2s;display:flex}.target-trigger-btn[data-v-665aab41]:hover,.target-trigger-btn.active[data-v-665aab41]{color:var(--text-primary);background:#ffffff1a}.light-theme .target-trigger-btn[data-v-665aab41]:hover,.light-theme .target-trigger-btn.active[data-v-665aab41]{background:#0000000d}.target-trigger-btn .chevron-icon[data-v-665aab41]{opacity:.7;flex-shrink:0;width:14px;height:14px;transition:transform .2s}.target-trigger-btn .chevron-icon.open[data-v-665aab41]{transform:rotate(180deg)}.target-popover[data-v-665aab41]{background:var(--popover-bg);border:1px solid var(--popover-border);box-shadow:var(--popover-shadow);z-index:100;border-radius:12px;min-width:120px;padding:6px;animation:.2s cubic-bezier(.16,1,.3,1) popoverFadeIn-665aab41;position:absolute;top:calc(100% + 6px);right:0}.target-popover .popover-title[data-v-665aab41]{color:var(--text-muted);margin-bottom:6px;padding:2px 6px;font-size:10px;font-weight:700}.target-list[data-v-665aab41]{flex-direction:column;gap:2px;max-height:120px;display:flex;overflow-y:auto}.target-list[data-v-665aab41]::-webkit-scrollbar{width:3px}.target-list[data-v-665aab41]::-webkit-scrollbar-thumb{background:#fff3;border-radius:3px}.light-theme .target-list[data-v-665aab41]::-webkit-scrollbar-thumb{background:#00000026}.target-list[data-v-665aab41]::-webkit-scrollbar-track{background:0 0}.target-item[data-v-665aab41]{text-align:left;color:var(--text-secondary);cursor:pointer;box-sizing:border-box;background:0 0;border:none;border-radius:6px;justify-content:space-between;align-items:center;width:100%;padding:6px 8px;font-size:11px;transition:background-color .2s,color .2s,transform .2s;display:flex}.target-item[data-v-665aab41]:hover{background:var(--item-hover-bg);color:var(--text-primary)}.target-item.selected[data-v-665aab41]{background:var(--accent-light);color:var(--accent-color);font-weight:600}.target-item .target-text[data-v-665aab41]{text-overflow:ellipsis;white-space:nowrap;flex:1;overflow:hidden}.target-item .check-icon[data-v-665aab41]{flex-shrink:0;margin-left:6px;font-size:10px}@keyframes popoverFadeIn-665aab41{0%{opacity:0;transform:translateY(-8px)scale(.95)}to{opacity:1;transform:translateY(0)scale(1)}}@media (width<=1049px){.search-section[data-v-665aab41]{max-width:280px}.search-wrapper[data-v-665aab41]{border-radius:10px;height:34px}.search-input[data-v-665aab41]{padding:0 54px 0 32px;font-size:12px}.search-icon[data-v-665aab41]{width:14px;height:14px;left:10px}.clear-search-btn[data-v-665aab41]{width:18px;height:18px;right:32px}.clear-icon[data-v-665aab41]{width:10px;height:10px}.target-trigger-btn[data-v-665aab41]{width:22px;height:22px;padding:0;right:4px}.target-trigger-btn .chevron-icon[data-v-665aab41]{width:12px;height:12px}}@media (width<=599px){.search-section[data-v-665aab41]{flex:1;min-width:0;max-width:none!important}.search-wrapper[data-v-665aab41]{height:34px}}.action-popover-wrapper[data-v-afdbde53]{align-items:center;display:flex;position:relative}.icon-btn[data-v-afdbde53]{background:var(--btn-bg);border:1px solid var(--btn-border);width:38px;height:38px;color:var(--text-secondary);cursor:pointer;background-clip:padding-box;border-radius:12px;justify-content:center;align-items:center;transition:background-color .2s,border-color .2s,color .2s,transform .2s;display:flex}.icon-btn[data-v-afdbde53]:hover:not(:disabled){background:var(--btn-hover-bg);color:var(--btn-hover-color);border-color:var(--btn-hover-border)}.icon-btn .btn-icon[data-v-afdbde53]{width:16px;height:16px}.icon-btn.active[data-v-afdbde53]{color:var(--accent-color);background:var(--accent-light);border-color:#6366f140}.sort-popover[data-v-afdbde53]{background:var(--popover-bg);border:1px solid var(--popover-border);box-shadow:var(--popover-shadow);z-index:100;border-radius:12px;min-width:150px;padding:8px;animation:.2s cubic-bezier(.16,1,.3,1) popoverFadeIn-afdbde53;position:absolute;top:calc(100% + 8px);right:0}.sort-popover .popover-title[data-v-afdbde53]{color:var(--text-muted);margin-bottom:6px;padding:0 4px;font-size:10px;font-weight:700}.sort-popover.placement-top[data-v-afdbde53]{animation:.2s cubic-bezier(.16,1,.3,1) popoverFadeInUp-afdbde53;top:auto;bottom:calc(100% + 8px)}@keyframes popoverFadeInUp-afdbde53{0%{opacity:0;transform:translateY(8px)scale(.95)}to{opacity:1;transform:translateY(0)scale(1)}}.sort-list[data-v-afdbde53]{flex-direction:column;gap:2px;display:flex}.sort-item[data-v-afdbde53]{text-align:left;width:100%;color:var(--text-secondary);cursor:pointer;background:0 0;border:none;border-radius:6px;align-items:center;gap:8px;padding:6px 8px;font-size:11px;display:flex}.sort-item[data-v-afdbde53]:hover{background:var(--item-hover-bg);color:var(--text-primary)}.sort-item.active[data-v-afdbde53]{background:var(--accent-light);color:var(--accent-color);font-weight:600}.sort-item .sort-item-icon[data-v-afdbde53]{font-size:12px}.sort-item .sort-direction[data-v-afdbde53]{opacity:.85;margin-left:auto;font-size:11px;font-weight:700}@keyframes popoverFadeIn-afdbde53{0%{opacity:0;transform:translateY(-8px)scale(.95)}to{opacity:1;transform:translateY(0)scale(1)}}@media (width<=1049px){.icon-btn[data-v-afdbde53]{border-radius:10px;width:34px;height:34px}}.action-popover-wrapper[data-v-7bea2273]{align-items:center;display:flex;position:relative}.icon-btn[data-v-7bea2273]{background:var(--btn-bg);border:1px solid var(--btn-border);width:38px;height:38px;color:var(--text-secondary);cursor:pointer;background-clip:padding-box;border-radius:12px;justify-content:center;align-items:center;transition:background-color .2s,border-color .2s,color .2s,transform .2s;display:flex}.icon-btn[data-v-7bea2273]:hover:not(:disabled){background:var(--btn-hover-bg);color:var(--btn-hover-color);border-color:var(--btn-hover-border)}.icon-btn .btn-icon[data-v-7bea2273]{width:16px;height:16px}.icon-btn.active[data-v-7bea2273]{color:var(--accent-color);background:var(--accent-light);border-color:#6366f140}.columns-popover[data-v-7bea2273]{background:var(--popover-bg);border:1px solid var(--popover-border);box-shadow:var(--popover-shadow);z-index:100;border-radius:12px;min-width:130px;padding:8px;animation:.2s cubic-bezier(.16,1,.3,1) popoverFadeIn-7bea2273;position:absolute;top:calc(100% + 8px);right:0}.columns-popover .popover-title[data-v-7bea2273]{color:var(--text-muted);letter-spacing:.5px;text-transform:uppercase;margin-bottom:6px;padding:0 4px;font-size:10px;font-weight:700}.columns-list[data-v-7bea2273]{flex-direction:column;gap:2px;display:flex}.columns-item[data-v-7bea2273]{text-align:left;width:100%;color:var(--text-secondary);cursor:pointer;background:0 0;border:none;border-radius:6px;align-items:center;gap:8px;padding:6px 8px;font-size:11px;transition:background-color .15s,color .15s,transform .15s;display:flex}.columns-item[data-v-7bea2273]:hover{background:var(--item-hover-bg);color:var(--text-primary)}.columns-item.active[data-v-7bea2273]{background:var(--accent-light);color:var(--accent-color);font-weight:600}.columns-item .columns-item-icon[data-v-7bea2273]{flex-shrink:0;font-size:12px}@keyframes popoverFadeIn-7bea2273{0%{opacity:0;transform:translateY(-8px)scale(.95)}to{opacity:1;transform:translateY(0)scale(1)}}@media (width<=1049px){.icon-btn[data-v-7bea2273]{border-radius:10px;width:34px;height:34px}}.action-bar-container[data-v-304113ad]{z-index:50;-webkit-app-region:drag;justify-content:space-between;align-items:center;gap:16px;padding:16px 24px 0;display:flex;position:relative}.actions-wrapper[data-v-304113ad]{align-items:center;gap:10px;display:flex;-webkit-app-region:no-drag!important}.icon-btn[data-v-304113ad]{background:var(--btn-bg);border:1px solid var(--btn-border);width:38px;height:38px;color:var(--text-secondary);cursor:pointer;background-clip:padding-box;border-radius:12px;justify-content:center;align-items:center;transition:opacity .2s,background-color .2s,border-color .2s,color .2s,transform .2s;display:flex}.icon-btn[data-v-304113ad]:focus,.icon-btn[data-v-304113ad]:focus-visible{outline:none}.icon-btn[data-v-304113ad]:hover:not(:disabled){background:var(--btn-hover-bg);color:var(--btn-hover-color);border-color:var(--btn-hover-border)}.icon-btn[data-v-304113ad]:disabled{opacity:.4;cursor:not-allowed}.icon-btn.danger[data-v-304113ad]:hover:not(:disabled){background:var(--danger-hover-bg);border-color:var(--danger-hover-border);color:var(--danger-color)}.icon-btn.webdav-sync-btn.syncing[data-v-304113ad]{color:#3b82f6;border-color:#3b82f666}.icon-btn.webdav-sync-btn.success[data-v-304113ad]{color:#22c55e}.icon-btn.webdav-sync-btn.error[data-v-304113ad]{color:#ef4444}.icon-btn .btn-icon[data-v-304113ad]{width:16px;height:16px}.icon-btn .spin[data-v-304113ad]{animation:1s linear infinite spin-304113ad}.icon-btn.active[data-v-304113ad]{color:var(--accent-color);background:var(--accent-light);border-color:#6366f140}@keyframes spin-304113ad{0%{transform:rotate(0)}to{transform:rotate(360deg)}}.primary-btn[data-v-304113ad]{background:var(--accent-color);color:#fff;border-radius:12px;align-items:center;gap:8px;height:38px;padding:0 16px;font-size:13px;font-weight:600;line-height:38px;transition:opacity .2s,background-color .2s,box-shadow .2s,transform .2s;display:flex;box-shadow:0 4px 12px -2px #6366f14d}.primary-btn[data-v-304113ad]:hover:not(:disabled){background:var(--accent-hover);transform:translateY(-1px);box-shadow:0 6px 16px -2px #6366f166}.primary-btn[data-v-304113ad]:active:not(:disabled){transform:translateY(0)}.primary-btn[data-v-304113ad]:disabled{opacity:.5;cursor:not-allowed;box-shadow:none}.primary-btn .btn-icon-plus[data-v-304113ad]{width:16px;height:16px}.primary-btn.danger-btn[data-v-304113ad]{background:var(--danger-color,#ff4d4f);box-shadow:0 4px 12px -2px #ff4d4f4d}.primary-btn.danger-btn[data-v-304113ad]:hover:not(:disabled){background:#ff7875;box-shadow:0 6px 16px -2px #ff4d4f66}.primary-btn.add-btn[data-v-304113ad]:hover:not(:disabled){transform:none;box-shadow:0 4px 12px -2px #6366f14d}.primary-btn.add-btn[data-v-304113ad]:active:not(:disabled){transform:none}.window-control-wrapper[data-v-304113ad]{align-items:center;gap:10px;margin-left:4px;display:flex}.window-control-divider[data-v-304113ad]{background:var(--panel-border,#ffffff1f);width:1px;height:22px}.window-pin-btn[data-v-304113ad]{-webkit-tap-highlight-color:transparent;outline:none!important}.window-pin-btn[data-v-304113ad]:focus,.window-pin-btn[data-v-304113ad]:focus-visible{box-shadow:none!important;outline:none!important}.window-pin-btn[data-v-304113ad]{transition:opacity .2s,background-color .2s,border-color .2s,color .2s,transform .15s}.window-pin-btn[data-v-304113ad]:hover:not(:disabled){transform:scale(1.05);background:var(--card-btn-hover-bg)!important;color:var(--card-btn-hover-color)!important}.window-pin-btn.is-pinned[data-v-304113ad]{background:var(--accent-light,#6366f129)!important;color:var(--accent-color,#6366f1)!important;box-shadow:none!important;border-color:#0000!important;outline:none!important}.window-pin-btn.is-pinned[data-v-304113ad]:focus,.window-pin-btn.is-pinned[data-v-304113ad]:focus-visible{box-shadow:none!important;border-color:#0000!important;outline:none!important}.window-pin-btn.is-pinned .btn-icon.pinned[data-v-304113ad]{transform:rotate(45deg)}.window-pin-btn[data-v-304113ad]:active:not(:disabled){transform:scale(.95)}@media (width<=1049px){.action-bar-container[data-v-304113ad]{gap:12px;padding:12px 16px 0}.actions-wrapper[data-v-304113ad]{gap:6px}.icon-btn[data-v-304113ad]{border-radius:10px;width:34px;height:34px}.primary-btn[data-v-304113ad]{border-radius:10px;height:34px;padding:0 12px}}@media (width<=869px){.primary-btn[data-v-304113ad]{justify-content:center;width:34px;padding:0}.primary-btn span[data-v-304113ad]{display:none}}.mobile-category-trigger[data-v-304113ad]{display:none}@media (width<=599px){.action-bar-container[data-v-304113ad]{gap:8px;padding:10px 12px 0}.mobile-category-trigger[data-v-304113ad]{background:var(--btn-bg);border:1px solid var(--btn-border);height:34px;color:var(--text-primary);cursor:pointer;white-space:nowrap;border-radius:10px;flex-shrink:0;align-items:center;gap:6px;max-width:125px;padding:0 10px;transition:background-color .15s,transform .15s;display:flex}.mobile-category-trigger[data-v-304113ad]:active{transform:scale(.96)}.mobile-category-trigger .mobile-menu-icon[data-v-304113ad]{width:15px;height:15px;color:var(--accent-color);flex-shrink:0}.mobile-category-trigger .mobile-category-name[data-v-304113ad]{text-overflow:ellipsis;white-space:nowrap;font-size:13px;font-weight:600;overflow:hidden}.desktop-only-action[data-v-304113ad]{display:none!important}}.header-left-actions[data-v-37a74fe5]{z-index:2;align-items:center;gap:9px;transition:left .2s,gap .2s;display:flex;position:absolute;top:-8px;left:20px}.header-left-actions.is-full-screen[data-v-37a74fe5]{gap:12px;left:24px}.header-left-actions.is-full-screen button[data-v-37a74fe5]{padding:7px}.header-left-actions.is-full-screen button .pin-icon[data-v-37a74fe5],.header-left-actions.is-full-screen button .detach-icon[data-v-37a74fe5],.header-left-actions.is-full-screen button .preview-icon[data-v-37a74fe5],.header-left-actions.is-full-screen button svg[data-v-37a74fe5]{width:15px;height:15px}.header-left-actions button[data-v-37a74fe5]{background:var(--card-border);color:var(--card-text);box-shadow:var(--shadow-sm);border-radius:50%;justify-content:center;align-items:center;padding:6px;transition:transform .2s cubic-bezier(.34,1.56,.64,1),background-color .2s,color .2s;display:flex}.dark-theme .header-left-actions button[data-v-37a74fe5]{background:var(--card-border-dark);color:var(--card-text-dark)}.header-left-actions button .pin-icon[data-v-37a74fe5],.header-left-actions button .detach-icon[data-v-37a74fe5],.header-left-actions button .preview-icon[data-v-37a74fe5],.header-left-actions button svg[data-v-37a74fe5]{width:13px;height:13px;transition:transform .2s cubic-bezier(.34,1.56,.64,1)}.header-left-actions button[data-v-37a74fe5]:hover{background:var(--card-btn-hover-bg);color:var(--card-btn-hover-color);transform:scale(1.1)}.header-left-actions .pin-btn[data-v-37a74fe5]:hover{transform:scale(1.1)rotate(15deg)}.card-header[data-v-37a74fe5]{justify-content:space-between;align-items:center;min-height:24px;margin-top:6px;display:flex}.card-header.is-full-screen[data-v-37a74fe5]{min-height:32px;margin-top:4px;margin-bottom:4px}.card-title[data-v-37a74fe5]{letter-spacing:.2px;white-space:nowrap;text-overflow:ellipsis;flex:1;padding-right:24px;font-size:14px;font-weight:700;overflow:hidden}.card-title.is-full-screen[data-v-37a74fe5]{font-size:15px}.title-input[data-v-37a74fe5]{background:var(--input-bg);border:1px solid var(--input-border);color:inherit;border-radius:8px;flex:1;width:100%;padding:4px 10px;font-size:13px;font-weight:600}.title-input.is-full-screen[data-v-37a74fe5]{min-height:32px;padding:6px 12px;font-size:15px}.title-input[data-v-37a74fe5]:focus{background:var(--input-bg);border-color:var(--card-border)}.dark-theme .title-input[data-v-37a74fe5]:focus{border-color:var(--card-border-dark)}.edit-trigger-btn[data-v-37a74fe5]{opacity:0;color:inherit;background:var(--card-bg);border-radius:6px;justify-content:center;align-items:center;margin-left:6px;padding:6px;transition:opacity .2s,background .2s;display:flex}.dark-theme .edit-trigger-btn[data-v-37a74fe5]{background:var(--card-bg-dark)}.edit-trigger-btn[data-v-37a74fe5]:hover{background:var(--card-btn-hover-bg);color:var(--card-btn-hover-color)}.edit-trigger-btn .edit-icon[data-v-37a74fe5]{width:13px;height:13px}.edit-trigger-btn.is-full-screen[data-v-37a74fe5]{border-radius:7px;padding:7px}.edit-trigger-btn.is-full-screen .edit-icon[data-v-37a74fe5]{width:15px;height:15px}.absolute-edit-btn[data-v-37a74fe5]{z-index:2;margin-left:0;position:absolute;top:12px;right:16px}.absolute-edit-btn.is-full-screen[data-v-37a74fe5]{top:14px;right:20px}.absolute-edit-btn.is-full-screen.is-immersive-full-screen[data-v-37a74fe5]{top:24px;right:74px}@media (width<=1049px){.absolute-edit-btn[data-v-37a74fe5]{top:10px;right:12px}}.markdown-body{font-family:var(--font-sans);color:inherit;word-break:break-word;overflow-wrap:break-word;max-width:100%;font-size:13px;line-height:1.6}.markdown-body p{margin-bottom:.5em}.markdown-body p:last-child{margin-bottom:0}.markdown-body h1,.markdown-body h2,.markdown-body h3,.markdown-body h4,.markdown-body h5,.markdown-body h6{color:inherit;margin-top:.8em;margin-bottom:.4em;font-weight:700;line-height:1.35}.markdown-body h1:first-child,.markdown-body h2:first-child,.markdown-body h3:first-child,.markdown-body h4:first-child,.markdown-body h5:first-child,.markdown-body h6:first-child{margin-top:0}.markdown-body h1{border-bottom:1px dashed var(--popover-border);padding-bottom:4px;font-size:1.3em}.markdown-body h2{font-size:1.15em}.markdown-body h3{font-size:1.05em}.markdown-body h4,.markdown-body h5,.markdown-body h6{font-size:1em}.markdown-body ul,.markdown-body ol{margin-bottom:.5em;padding-left:1.4em}.markdown-body li{margin-bottom:.25em}.markdown-body li input[type=checkbox]{vertical-align:middle;margin-right:6px}.markdown-body blockquote{border-left:3px solid var(--accent-color);opacity:.9;background:#00000008;border-radius:0 6px 6px 0;margin:.5em 0;padding:4px 10px}.dark-theme .markdown-body blockquote{background:#ffffff0d}.markdown-body code{background:#0000000f;border-radius:4px;padding:2px 5px;font-family:monospace,SFMono-Regular,Consolas;font-size:.88em}.dark-theme .markdown-body code{background:#ffffff1f}.markdown-body pre{background:#0000000f;border-radius:8px;margin:.6em 0;padding:8px 10px;overflow-x:auto}.dark-theme .markdown-body pre{background:#00000040}.markdown-body pre code{background:0 0;padding:0;font-size:12px}.markdown-body a{color:var(--accent-color);cursor:pointer;text-decoration:underline}.markdown-body a:hover{opacity:.85}.markdown-body img{box-sizing:border-box;cursor:zoom-in;border-radius:8px;margin:6px 0;transition:transform .2s;display:block;max-width:100%!important;height:auto!important}.markdown-body img:hover{transform:scale(1.01)}.markdown-body .media-audio-card{border:1px solid var(--popover-border);background:#00000008;border-radius:8px;flex-direction:column;gap:6px;margin:8px 0;padding:8px 12px;display:flex}.dark-theme .markdown-body .media-audio-card{background:#ffffff0a}.markdown-body .media-audio-card .media-audio-header{color:inherit;align-items:center;gap:6px;min-width:0;font-size:11px;font-weight:500;display:flex}.markdown-body .media-audio-card .media-audio-icon{color:var(--accent-color);flex-shrink:0;align-items:center;display:flex}.markdown-body .media-audio-card .media-audio-title{text-overflow:ellipsis;white-space:nowrap;flex:1;overflow:hidden}.markdown-body .media-audio-card .media-audio-size{opacity:.65;flex-shrink:0;font-size:10px}.markdown-body .media-audio-card .media-audio-element{border-radius:4px;outline:none;width:100%;height:32px}.markdown-body .media-video-card{border:1px solid var(--popover-border);background:#00000008;border-radius:8px;flex-direction:column;gap:6px;margin:8px 0;padding:8px 10px;display:flex}.dark-theme .markdown-body .media-video-card{background:#ffffff0a}.markdown-body .media-video-card .media-video-header{color:inherit;align-items:center;gap:6px;min-width:0;font-size:11px;font-weight:500;display:flex}.markdown-body .media-video-card .media-video-icon{color:var(--accent-color);flex-shrink:0;align-items:center;display:flex}.markdown-body .media-video-card .media-video-title{text-overflow:ellipsis;white-space:nowrap;flex:1;overflow:hidden}.markdown-body .media-video-card .media-video-size{opacity:.65;flex-shrink:0;font-size:10px}.markdown-body .media-video-card .media-video-element{background:#000;border-radius:6px;outline:none;width:100%;max-height:280px}.markdown-body .attachment-file-chip{border:1px solid var(--popover-border);cursor:pointer;-webkit-user-select:none;user-select:none;background:#00000008;border-radius:8px;justify-content:space-between;align-items:center;gap:8px;margin:6px 0;padding:8px 10px;transition:all .18s;display:flex}.dark-theme .markdown-body .attachment-file-chip{background:#ffffff0a}.markdown-body .attachment-file-chip:hover{background:var(--item-hover-bg);border-color:var(--accent-color);transform:translateY(-1px);box-shadow:0 2px 6px #0000000a}.markdown-body .attachment-file-chip .chip-main{flex:1;align-items:center;gap:8px;min-width:0;display:flex}.markdown-body .attachment-file-chip .chip-icon{flex-shrink:0;justify-content:center;align-items:center;display:flex}.markdown-body .attachment-file-chip .chip-text{flex-direction:column;flex:1;min-width:0;display:flex}.markdown-body .attachment-file-chip .chip-filename{text-overflow:ellipsis;white-space:nowrap;color:inherit;font-size:12px;font-weight:500;line-height:1.3;overflow:hidden}.markdown-body .attachment-file-chip .chip-meta{opacity:.65;margin-top:2px;font-size:10px;line-height:1.2}.markdown-body .attachment-file-chip .chip-actions{flex-shrink:0;align-items:center;gap:4px;display:flex}.markdown-body .attachment-file-chip .chip-action-btn{background:var(--btn-bg);color:inherit;border:1px solid var(--btn-border);cursor:pointer;border-radius:5px;align-items:center;gap:3px;padding:3px 8px;font-size:11px;font-weight:500;transition:all .15s;display:inline-flex}.markdown-body .attachment-file-chip .chip-action-btn:hover{background:var(--card-btn-hover-bg);color:var(--card-btn-hover-color);border-color:var(--card-btn-hover-bg)}.markdown-body .attachment-file-chip .chip-action-btn.secondary{opacity:.75;padding:3px 5px}.markdown-body .attachment-file-chip .chip-action-btn.secondary:hover{opacity:1}.markdown-body .attachment-file-chip .chip-action-btn .action-text{font-size:10px}.markdown-body table{border-collapse:collapse;width:100%;margin:.6em 0;font-size:12px}.markdown-body table th,.markdown-body table td{border:1px solid var(--popover-border);text-align:left;padding:4px 8px}.markdown-body table th{background:#0000000a;font-weight:600}.dark-theme .markdown-body table th{background:#ffffff0f}.markdown-body hr{border:none;border-top:1px dashed var(--popover-border);margin:.8em 0}.card-body[data-v-63e79998]{min-height:32px;overflow-y:auto;overflow-y:overlay;flex-direction:column;flex:1;padding-top:4px;padding-bottom:8px;transition:background-color .2s,outline .2s;display:flex;position:relative}.card-body.is-view-mode[data-v-63e79998]{overflow:hidden}.card-body.is-drag-over[data-v-63e79998]{outline:2px dashed var(--accent-color);outline-offset:-2px;background:rgba(var(--accent-color,100, 100, 255), .06);border-radius:6px}.card-body-content[data-v-63e79998]{overflow-y:auto;overflow-y:overlay;flex:1;overflow-x:hidden;background:0 0!important}.card-body-content[data-v-63e79998]::-webkit-scrollbar{width:6px;background:0 0!important}.card-body-content[data-v-63e79998]::-webkit-scrollbar-track{box-shadow:none!important;background:0 0!important;border:none!important}.card-body-content[data-v-63e79998]::-webkit-scrollbar-track-piece{box-shadow:none!important;background:0 0!important;border:none!important}.card-body-content[data-v-63e79998]::-webkit-scrollbar-corner{box-shadow:none!important;background:0 0!important;border:none!important}.card-body-content[data-v-63e79998]:hover::-webkit-scrollbar-thumb{background:#0000001f}.dark-theme .card-body-content[data-v-63e79998]:hover::-webkit-scrollbar-thumb{background:#ffffff26}@media (prefers-color-scheme:dark){.card-body-content[data-v-63e79998]:hover::-webkit-scrollbar-thumb{background:#ffffff26}.light-theme .card-body-content[data-v-63e79998]:hover::-webkit-scrollbar-thumb{background:#0000001f}}.card-body-content[data-v-63e79998]::-webkit-scrollbar-thumb{background:#0000000a;border-radius:4px}.card-body-content[data-v-63e79998]::-webkit-scrollbar-thumb:hover{background:#00000026!important}.dark-theme .card-body-content[data-v-63e79998]::-webkit-scrollbar-thumb{background:#ffffff0a}.dark-theme .card-body-content[data-v-63e79998]::-webkit-scrollbar-thumb:hover{background:#ffffff2e!important}@media (prefers-color-scheme:dark){.card-body-content[data-v-63e79998]::-webkit-scrollbar-thumb{background:#ffffff0a}.card-body-content[data-v-63e79998]::-webkit-scrollbar-thumb:hover{background:#ffffff2e!important}.light-theme .card-body-content[data-v-63e79998]::-webkit-scrollbar-thumb{background:#0000000a}.light-theme .card-body-content[data-v-63e79998]::-webkit-scrollbar-thumb:hover{background:#00000026!important}}.card-content[data-v-63e79998]{font-family:var(--font-sans);white-space:pre-wrap;word-break:break-all;overflow-wrap:break-word;font-size:13px;line-height:1.6}.content-textarea[data-v-63e79998]{width:100%;height:100%;min-height:100%;overflow-y:auto;overflow-y:overlay;background:var(--input-bg);border:1px solid var(--input-border);color:inherit;resize:none;border-radius:8px;padding:8px 10px;font-size:12px;line-height:1.6}.content-textarea.is-full-screen[data-v-63e79998]{padding:10px 12px;font-size:15px;line-height:1.75}.content-textarea[data-v-63e79998]::-webkit-scrollbar{width:6px;background:0 0!important}.content-textarea[data-v-63e79998]::-webkit-scrollbar-track{box-shadow:none!important;background:0 0!important;border:none!important}.content-textarea[data-v-63e79998]::-webkit-scrollbar-track-piece{box-shadow:none!important;background:0 0!important;border:none!important}.content-textarea[data-v-63e79998]::-webkit-scrollbar-corner{box-shadow:none!important;background:0 0!important;border:none!important}.content-textarea[data-v-63e79998]:focus{background:var(--input-bg);border-color:var(--card-border)}.dark-theme .content-textarea[data-v-63e79998]:focus{border-color:var(--card-border-dark)}.note-tags-list[data-v-63e79998]{flex-wrap:wrap;flex-shrink:0;gap:6px;max-height:48px;margin-top:6px;display:flex;overflow:hidden}.note-tags-list-measure[data-v-63e79998]{visibility:hidden;pointer-events:none;z-index:-9999;opacity:0;flex-wrap:wrap;gap:6px;display:flex;position:absolute;top:0;left:0;right:0}.note-tag-badge[data-v-63e79998]{background:var(--badge-bg);border:1px solid var(--popover-border);color:inherit;opacity:.85;cursor:pointer;line-clamp:2;-webkit-line-clamp:2;word-break:break-all;white-space:normal;border-radius:99px;-webkit-box-orient:vertical;max-width:100%;padding:0 8px;font-size:10px;font-weight:500;line-height:20px;transition:background-color .15s,opacity .15s;display:-webkit-inline-box;overflow:hidden}.note-tag-badge[data-v-63e79998]:hover{opacity:1;background:var(--card-btn-hover-bg);color:var(--card-btn-hover-color)}.note-tag-badge.more[data-v-63e79998]{cursor:help}.note-tag-badge.more[data-v-63e79998]:hover{background:var(--badge-bg);color:inherit;opacity:.85}.tags-editor[data-v-c51a1ed9]{border-top:1px dashed var(--popover-border);flex-wrap:wrap;align-items:center;gap:6px;margin-bottom:6px;padding-top:10px;display:flex}.edit-tag-badge[data-v-c51a1ed9]{background:var(--badge-bg);border:1px solid var(--popover-border);color:inherit;border-radius:6px;align-items:center;gap:4px;padding:2px 8px;font-size:11px;display:inline-flex}.edit-tag-badge .delete-tag-btn[data-v-c51a1ed9]{color:inherit;cursor:pointer;opacity:.6;background:0 0;border:none;justify-content:center;align-items:center;padding:0 2px;font-size:12px;font-weight:700;transition:opacity .2s;display:flex}.edit-tag-badge .delete-tag-btn[data-v-c51a1ed9]:hover{opacity:1}.tag-input-wrapper[data-v-c51a1ed9]{flex:1;align-items:center;min-width:100px;display:inline-flex;position:relative}.tag-input[data-v-c51a1ed9]{background:var(--badge-bg);border:none;border:1px dashed var(--popover-border);color:inherit;border-radius:6px;width:100%;padding:3px 22px 3px 8px;font-size:11px}.tag-input[data-v-c51a1ed9]:focus{border-style:solid;border-color:var(--card-border);outline:none}.dark-theme .tag-input[data-v-c51a1ed9]:focus{border-color:var(--card-border-dark)}.tag-input[data-v-c51a1ed9]::placeholder{color:inherit;opacity:.5}.arrow-btn[data-v-c51a1ed9]{color:inherit;opacity:.6;cursor:pointer;background:0 0;border:none;justify-content:center;align-items:center;padding:2px;transition:opacity .2s,transform .2s;display:flex;position:absolute;top:50%;right:4px;transform:translateY(-50%)}.arrow-btn[data-v-c51a1ed9]:hover{opacity:1}.arrow-btn .arrow-icon[data-v-c51a1ed9]{transition:transform .2s}.arrow-btn .arrow-icon.open[data-v-c51a1ed9]{transform:rotate(180deg)}.tags-dropdown[data-v-c51a1ed9]{background:var(--popover-bg);border:1px solid var(--popover-border);width:100%;min-width:120px;max-width:200px;max-height:150px;box-shadow:var(--popover-shadow);z-index:100;border-radius:6px;padding:4px 0;position:absolute;top:calc(100% + 4px);right:0;overflow-y:auto}.tags-dropdown .dropdown-item[data-v-c51a1ed9]{cursor:pointer;color:var(--text-secondary);justify-content:space-between;align-items:center;padding:6px 10px;font-size:11px;transition:background-color .2s,color .2s,transform .2s;display:flex}.tags-dropdown .dropdown-item[data-v-c51a1ed9]:hover{background:var(--item-hover-bg);color:var(--text-primary)}.tags-dropdown .dropdown-item.selected[data-v-c51a1ed9]{color:var(--accent-color);background:var(--accent-light);font-weight:500}.tags-dropdown .dropdown-item .tag-text[data-v-c51a1ed9]{text-overflow:ellipsis;white-space:nowrap;flex:1;margin-right:8px;overflow:hidden}.tags-dropdown .dropdown-item .check-icon[data-v-c51a1ed9]{flex-shrink:0;font-size:10px}.tags-dropdown .dropdown-item.empty[data-v-c51a1ed9]{color:var(--text-muted);cursor:default;justify-content:center;padding:8px 10px}.tags-dropdown .dropdown-item.empty[data-v-c51a1ed9]:hover{background:0 0}.base-popover-wrapper[data-v-c3d9d743]{display:inline-block;position:relative}.base-popover-panel[data-v-c3d9d743]{background:var(--popover-bg);border:1px solid var(--popover-border);box-shadow:var(--popover-shadow);z-index:100;-webkit-backdrop-filter:blur(16px);border-radius:12px;padding:8px;position:absolute}.base-popover-panel.align-right[data-v-c3d9d743]{right:0}.base-popover-panel.align-left[data-v-c3d9d743]{left:0}.base-popover-panel.placement-top[data-v-c3d9d743]{bottom:calc(100% + 8px)}.base-popover-panel.placement-bottom[data-v-c3d9d743]{top:calc(100% + 8px)}.popover-header[data-v-c3d9d743]{color:var(--text-muted);margin-bottom:6px;padding:0 4px;font-size:10px;font-weight:700}.popover-content[data-v-c3d9d743]{flex-direction:column;gap:2px;display:flex}.popover-fade-enter-active[data-v-c3d9d743],.popover-fade-leave-active[data-v-c3d9d743]{transition:opacity .18s cubic-bezier(.16,1,.3,1),transform .18s cubic-bezier(.16,1,.3,1)}.placement-top.popover-fade-enter-from[data-v-c3d9d743],.placement-top.popover-fade-leave-to[data-v-c3d9d743]{opacity:0;transform:translateY(8px)scale(.95)}.placement-bottom.popover-fade-enter-from[data-v-c3d9d743],.placement-bottom.popover-fade-leave-to[data-v-c3d9d743]{opacity:0;transform:translateY(-8px)scale(.95)}.edit-footer[data-v-bee22605]{justify-content:space-between;align-items:center;gap:8px;margin-top:6px;display:flex}.edit-tools[data-v-bee22605]{align-items:center;display:flex}.edit-tool-btn[data-v-bee22605]{background:var(--btn-bg);color:inherit;border:1px solid var(--btn-border);cursor:pointer;opacity:.85;border-radius:6px;align-items:center;gap:4px;padding:4px 8px;font-size:11px;font-weight:500;transition:all .15s;display:inline-flex}.edit-tool-btn[data-v-bee22605]:hover{opacity:1;background:var(--card-btn-hover-bg);color:var(--card-btn-hover-color);border-color:var(--card-btn-hover-bg)}.edit-tool-btn .edit-tool-icon[data-v-bee22605]{width:12px;height:12px}.edit-actions[data-v-bee22605]{align-items:center;gap:8px;display:flex}.edit-btn[data-v-bee22605]{border-radius:8px;padding:6px 12px;font-size:11px;font-weight:600}.edit-btn.cancel[data-v-bee22605]{background:var(--btn-bg);color:inherit;border:1px solid var(--btn-border)}.edit-btn.cancel[data-v-bee22605]:hover{background:var(--card-btn-hover-bg);color:var(--card-btn-hover-color);border-color:var(--card-btn-hover-bg)}.edit-btn.save[data-v-bee22605]{background:var(--card-text);color:var(--card-bg)}.dark-theme .edit-btn.save[data-v-bee22605]{background:var(--card-text-dark);color:var(--card-bg-dark)}.edit-btn.save[data-v-bee22605]:hover{opacity:.9}.card-footer[data-v-bee22605]{border-top:1px dashed var(--popover-border);color:inherit;opacity:.8;justify-content:space-between;align-items:center;min-width:0;padding-top:8px;font-size:10px;transition:opacity .25s;display:flex}.card-meta-info[data-v-bee22605]{white-space:nowrap;text-overflow:ellipsis;opacity:.75;-webkit-user-select:none;user-select:none;cursor:default;flex:1;min-width:0;font-size:11px;line-height:1;display:block;overflow:hidden}.card-actions[data-v-bee22605]{opacity:0;pointer-events:none;white-space:nowrap;flex-shrink:0;align-items:center;gap:4px;max-width:0;transition:opacity .25s cubic-bezier(.16,1,.3,1),max-width .25s cubic-bezier(.16,1,.3,1);display:flex;overflow:hidden}.card-actions.is-deleted-actions[data-v-bee22605]{opacity:.75;pointer-events:auto;max-width:140px;overflow:hidden}.card-actions.is-deleted-actions[data-v-bee22605]:hover{opacity:1}.card-actions.has-active-popover[data-v-bee22605]{opacity:1;pointer-events:auto;max-width:160px;overflow:visible}.action-popover-wrapper[data-v-bee22605]{position:relative}.action-btn[data-v-bee22605]{width:20px;height:20px;color:inherit;cursor:pointer;background:0 0;border:none;border-radius:6px;flex-shrink:0;justify-content:center;align-items:center;display:flex}.action-btn[data-v-bee22605]:hover{background:var(--card-btn-hover-bg);color:var(--card-btn-hover-color)}.action-btn.delete[data-v-bee22605]:hover{background:var(--danger-hover-bg);color:var(--danger-color)}.action-btn .action-icon[data-v-bee22605]{width:12px;height:12px}.color-picker-list[data-v-bee22605]{gap:4px;padding:2px;display:flex}.color-dot[data-v-bee22605]{cursor:pointer;border-radius:50%;justify-content:center;align-items:center;width:18px;height:18px;display:flex}.color-dot .dot-check-icon[data-v-bee22605]{width:10px;height:10px;color:var(--text-primary)}.folder-list[data-v-bee22605]{flex-direction:column;gap:2px;max-height:150px;display:flex;overflow-y:auto}.folder-item[data-v-bee22605]{text-align:left;color:var(--text-secondary);border-radius:6px;align-items:center;min-width:0;padding:6px 8px;font-size:11px;display:flex}.folder-item[data-v-bee22605]:hover{background:var(--item-hover-bg);color:var(--text-primary)}.folder-item.active[data-v-bee22605]{background:var(--accent-light);color:var(--accent-color);font-weight:600}.folder-item .folder-name-text[data-v-bee22605]{white-space:nowrap;text-overflow:ellipsis;flex:1;min-width:0;overflow:hidden}.format-list[data-v-bee22605]{flex-direction:column;gap:2px;display:flex}.format-item[data-v-bee22605]{color:var(--text-secondary);cursor:pointer;text-align:left;background:0 0;border:none;border-radius:6px;align-items:center;gap:6px;width:100%;padding:6px 8px;font-size:11px;transition:all .15s;display:flex}.format-item[data-v-bee22605]:hover{background:var(--item-hover-bg);color:var(--text-primary)}.format-item.active[data-v-bee22605]{background:var(--accent-light);color:var(--accent-color);font-weight:600}.format-item .item-icon[data-v-bee22605]{width:12px;height:12px}.note-card[data-v-04582bcc]{--card-bg:#fff3c2bf;--card-border:#ffe680;--card-text:#453908;--card-bg-dark:#40391cbf;--card-border-dark:#6b5f2e;--card-text-dark:#fff0b3;min-height:90px;max-height:var(--card-max-height,300px);cursor:default;background:var(--card-bg);border:1px solid var(--card-border);color:var(--card-text);border-radius:16px;flex-direction:column;padding:16px 18px 8px;display:flex;position:relative}.note-card.enable-hover-anim[data-v-04582bcc]{transition:transform .35s cubic-bezier(.16,1,.3,1),box-shadow .35s cubic-bezier(.16,1,.3,1)}.note-card.enable-hover-anim[data-v-04582bcc]:hover{box-shadow:var(--shadow-md);transform:translateY(-4px)}.dark-theme .note-card[data-v-04582bcc]{background:var(--card-bg-dark);border-color:var(--card-border-dark);color:var(--card-text-dark);--card-btn-hover-bg:var(--card-btn-hover-bg-dark);--card-btn-hover-color:var(--card-btn-hover-color-dark)}.note-card[data-v-04582bcc]:hover .edit-trigger-btn,.note-card[data-v-04582bcc]:hover .card-footer{opacity:1}.note-card[data-v-04582bcc]:hover .card-footer .card-actions{opacity:1;pointer-events:auto;max-width:160px;overflow:hidden}.note-card[data-v-04582bcc]:hover .card-footer .card-actions.has-active-popover{overflow:visible}.note-card.pinned[data-v-04582bcc]{box-shadow:0 8px 20px -8px var(--accent-light);border-width:1.5px}.note-card.pinned[data-v-04582bcc] .pin-icon{fill:currentColor;transform:rotate(45deg)}.note-card.editing[data-v-04582bcc]{z-index:10;cursor:default;min-height:220px;box-shadow:var(--shadow-md)!important;transform:none!important}.note-card.has-active-popover[data-v-04582bcc]{z-index:10}.note-card.dragging[data-v-04582bcc]{opacity:.35;transform:scale(.98);box-shadow:none!important;border-style:dashed!important}.note-card[draggable=true][data-v-04582bcc],.note-card[draggable=true][data-v-04582bcc]:active{cursor:default}.note-card .note-drag-handle[data-v-04582bcc]{z-index:1;cursor:default;border-radius:16px 16px 0 0;justify-content:center;align-items:flex-start;height:16px;transition:background-color .2s;display:flex;position:absolute;top:0;left:0;right:0}.note-card .note-drag-handle[data-v-04582bcc]:after{content:\"\";opacity:0;background:currentColor;border-radius:1.5px;width:24px;height:3px;margin-top:3.5px;transition:opacity .2s}.note-card .note-drag-handle[data-v-04582bcc]:hover:after{opacity:.15}.note-card .note-drag-handle[data-v-04582bcc]:active{cursor:default}.note-card.is-full-screen[data-v-04582bcc]{z-index:100;width:90vw;max-width:90vw;height:85vh;max-height:85vh;padding:20px 24px 16px;box-shadow:0 24px 48px #00000059}.note-card.is-full-screen.is-immersive-full-screen[data-v-04582bcc]{width:100vw;max-width:100vw;height:100vh;max-height:100vh;box-shadow:none!important;border:none!important;border-radius:0!important}.note-card.is-full-screen .note-drag-handle[data-v-04582bcc]{display:none}.note-card.is-full-screen[data-v-04582bcc] .card-header{min-height:32px;margin-top:4px;margin-bottom:4px}.note-card.is-full-screen[data-v-04582bcc] .card-title{font-size:15px}.note-card.is-full-screen[data-v-04582bcc] .title-input{min-height:32px;padding:6px 12px;font-size:15px}.note-card.is-full-screen[data-v-04582bcc] .card-body{font-size:15px;line-height:1.7}.note-card.is-full-screen[data-v-04582bcc] .markdown-body,.note-card.is-full-screen[data-v-04582bcc] .card-content{font-size:15px;line-height:1.75}.note-card.is-full-screen[data-v-04582bcc] .content-textarea{padding:10px 12px;font-size:15px;line-height:1.75}.note-card.is-full-screen[data-v-04582bcc] .edit-trigger-btn{border-radius:7px;padding:7px}.note-card.is-full-screen[data-v-04582bcc] .edit-trigger-btn .edit-icon{width:15px;height:15px}.note-card.is-full-screen[data-v-04582bcc] .card-footer{opacity:1;padding-top:12px}.note-card.is-full-screen[data-v-04582bcc] .card-meta-info,.note-card.is-full-screen[data-v-04582bcc] .updated-time,.note-card.is-full-screen[data-v-04582bcc] .char-count{font-size:12px}.note-card.is-full-screen[data-v-04582bcc] .card-actions{opacity:1!important;pointer-events:auto!important;gap:6px!important;max-width:200px!important;overflow:hidden!important}.note-card.is-full-screen[data-v-04582bcc] .card-actions.has-active-popover{overflow:visible!important}.note-card.is-full-screen[data-v-04582bcc] .action-btn{border-radius:7px!important;width:24px!important;height:24px!important}.note-card.is-full-screen[data-v-04582bcc] .action-btn .action-icon{width:14px!important;height:14px!important}@media (width<=1049px){.note-card[data-v-04582bcc]{min-height:80px;padding:14px 16px 8px}}@media (width<=599px){.note-card[data-v-04582bcc]{border-radius:12px;padding:14px 14px 8px}.note-card[data-v-04582bcc] .edit-trigger-btn{opacity:.85}.note-card[data-v-04582bcc] .card-footer{opacity:1}.note-card[data-v-04582bcc] .card-footer .card-actions{opacity:1;pointer-events:auto;max-width:180px;overflow:visible}.note-card[data-v-04582bcc] .action-btn{width:24px;height:24px}.note-card[data-v-04582bcc] .action-btn .action-icon{width:13px;height:13px}.note-card.is-full-screen[data-v-04582bcc]{width:100vw!important;max-width:100vw!important;height:100vh!important;max-height:100vh!important;padding:16px 14px calc(16px + env(safe-area-inset-bottom,0px)) 14px!important;border-radius:0!important}}.note-grid-container[data-v-9d5c9090]{flex:1;height:calc(100% - 71px);padding:24px;overflow-y:auto}.notes-grid[data-v-9d5c9090]{--grid-gap:20px;box-sizing:border-box;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));align-content:start;gap:20px;width:100%;display:grid;position:relative}.notes-grid[data-v-9d5c9090]>*{min-width:0;max-width:100%}.empty-state[data-v-9d5c9090]{text-align:center;flex-direction:column;justify-content:center;align-items:center;height:80%;padding:40px 20px;display:flex}.empty-illustration-wrapper[data-v-9d5c9090]{margin-bottom:20px}.empty-icon[data-v-9d5c9090]{width:64px;height:64px;color:var(--text-muted);opacity:.35}.empty-title[data-v-9d5c9090]{font-family:var(--font-display);color:var(--text-secondary);margin-bottom:8px;font-size:18px;font-weight:600}.empty-desc[data-v-9d5c9090]{color:var(--text-muted);max-width:320px;margin-bottom:24px;font-size:13px;line-height:1.5}.create-first-btn[data-v-9d5c9090]{background:var(--accent-light);color:var(--accent-color);border:1px solid var(--accent-border-dashed);border-radius:12px;align-items:center;gap:8px;padding:10px 20px;font-size:13px;font-weight:600;display:flex}.create-first-btn[data-v-9d5c9090]:hover{background:var(--accent-color);color:var(--text-on-accent);box-shadow:var(--shadow-sm);border-color:#0000;transform:translateY(-1px)}.create-first-btn .btn-icon[data-v-9d5c9090]{width:15px;height:15px}.animate-pulse[data-v-9d5c9090]{animation:2s cubic-bezier(.4,0,.6,1) infinite pulse-9d5c9090}@keyframes pulse-9d5c9090{0%,to{opacity:.35}50%{opacity:.15}}.notes-list-move[data-v-9d5c9090]{transition:transform .4s cubic-bezier(.16,1,.3,1)}.notes-list-enter-active[data-v-9d5c9090],.notes-list-leave-active[data-v-9d5c9090]{transition:opacity .35s cubic-bezier(.16,1,.3,1),transform .35s cubic-bezier(.16,1,.3,1)}.notes-list-enter-from[data-v-9d5c9090],.notes-list-leave-to[data-v-9d5c9090]{opacity:0;transform:scale(.9)translateY(15px)}.notes-list-leave-active[data-v-9d5c9090]{pointer-events:none;width:var(--leave-card-width,250px);box-sizing:border-box;max-width:100%;position:absolute}@media (width<=1049px){.note-grid-container[data-v-9d5c9090]{height:calc(100% - 59px);padding:16px}.notes-grid[data-v-9d5c9090]{--grid-gap:12px;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:12px}}@media (width<=599px){.note-grid-container[data-v-9d5c9090]{padding:10px 12px calc(76px + env(safe-area-inset-bottom,0px)) 12px!important;height:calc(100% - 52px)!important}.notes-grid[data-v-9d5c9090]{grid-template-columns:1fr;--grid-gap:12px!important;gap:12px!important}.notes-list-leave-active[data-v-9d5c9090]{width:var(--leave-card-width,100%);max-width:100%}}.toast-container[data-v-6b48d4c5]{box-shadow:var(--popover-shadow);z-index:9030;pointer-events:none;border:1px solid #0000;border-radius:12px;align-items:center;gap:10px;max-width:90%;padding:12px 20px;transition:opacity .3s cubic-bezier(.16,1,.3,1),transform .3s cubic-bezier(.16,1,.3,1);display:flex;position:fixed;left:50%;transform:translate(-50%)}.toast-container.position-top[data-v-6b48d4c5]{top:64px}.toast-container.position-bottom[data-v-6b48d4c5]{bottom:24px}.toast-icon[data-v-6b48d4c5]{flex-shrink:0;width:18px;height:18px}.toast-text[data-v-6b48d4c5]{letter-spacing:.2px;font-size:13px;font-weight:600}.toast-success[data-v-6b48d4c5]{background:var(--toast-success-bg);border-color:var(--toast-success-border);color:var(--toast-success-text)}.toast-success .toast-icon[data-v-6b48d4c5]{color:var(--toast-success-text)}.toast-info[data-v-6b48d4c5]{background:var(--toast-info-bg);border-color:var(--toast-info-border);color:var(--toast-info-text)}.toast-info .toast-icon[data-v-6b48d4c5]{color:var(--toast-info-text)}.toast-warning[data-v-6b48d4c5]{background:var(--toast-warning-bg);border-color:var(--toast-warning-border);color:var(--toast-warning-text)}.toast-warning .toast-icon[data-v-6b48d4c5]{color:var(--toast-warning-text)}.toast-error[data-v-6b48d4c5]{background:var(--toast-error-bg);border-color:var(--toast-error-border);color:var(--toast-error-text)}.toast-error .toast-icon[data-v-6b48d4c5]{color:var(--toast-error-text)}.toast-container.toast-top-enter-active[data-v-6b48d4c5],.toast-container.toast-top-leave-active[data-v-6b48d4c5]{transition:opacity .3s cubic-bezier(.16,1,.3,1),transform .3s cubic-bezier(.16,1,.3,1)}.toast-container.toast-top-enter-from[data-v-6b48d4c5]{opacity:0;transform:translate(-50%,-30px)scale(.9)}.toast-container.toast-top-leave-to[data-v-6b48d4c5]{opacity:0;transform:translate(-50%,-20px)scale(.95)}.toast-container.toast-bottom-enter-active[data-v-6b48d4c5],.toast-container.toast-bottom-leave-active[data-v-6b48d4c5]{transition:opacity .3s cubic-bezier(.16,1,.3,1),transform .3s cubic-bezier(.16,1,.3,1)}.toast-container.toast-bottom-enter-from[data-v-6b48d4c5]{opacity:0;transform:translate(-50%,30px)scale(.9)}.toast-container.toast-bottom-leave-to[data-v-6b48d4c5]{opacity:0;transform:translate(-50%,20px)scale(.95)}.modal-overlay[data-v-fdea4c1b]{background:var(--modal-overlay-bg);z-index:9020;justify-content:center;align-items:center;width:100vw;height:100vh;display:flex;position:fixed;top:0;left:0}.modal-container[data-v-fdea4c1b]{background:var(--popover-bg);border:1px solid var(--popover-border);width:90%;max-width:360px;box-shadow:var(--shadow-lg);border-radius:20px;flex-direction:column;gap:16px;padding:24px;display:flex;transform:translateY(0)}.modal-header[data-v-fdea4c1b]{align-items:center;gap:12px;display:flex}.warning-icon-wrapper[data-v-fdea4c1b]{background:var(--warning-bg);color:var(--warning-color);border-radius:12px;justify-content:center;align-items:center;padding:8px;display:flex}.warning-icon[data-v-fdea4c1b]{width:20px;height:20px}.modal-title[data-v-fdea4c1b]{font-family:var(--font-display);color:var(--text-primary);font-size:16px;font-weight:700}.modal-body[data-v-fdea4c1b]{padding-left:2px}.modal-message[data-v-fdea4c1b]{color:var(--text-secondary);font-size:13px;line-height:1.6}.modal-footer[data-v-fdea4c1b]{justify-content:flex-end;gap:10px;margin-top:6px;display:flex}.modal-btn[data-v-fdea4c1b]{border-radius:10px;padding:10px 18px;font-size:12px;font-weight:600}.modal-btn.cancel[data-v-fdea4c1b]{background:var(--btn-bg);border:1px solid var(--btn-border);color:var(--text-secondary)}.modal-btn.cancel[data-v-fdea4c1b]:hover{background:var(--btn-hover-bg);color:var(--btn-hover-color);border-color:var(--btn-hover-border)}.modal-btn.confirm[data-v-fdea4c1b]{background:var(--danger-color);color:var(--text-on-accent);box-shadow:0 4px 12px -2px var(--danger-hover-border)}.modal-btn.confirm[data-v-fdea4c1b]:hover{opacity:.9;box-shadow:0 6px 16px -2px var(--danger-hover-border)}.modal-fade-enter-active[data-v-fdea4c1b],.modal-fade-leave-active[data-v-fdea4c1b]{transition:opacity .3s cubic-bezier(.16,1,.3,1)}.modal-fade-enter-active .modal-container[data-v-fdea4c1b],.modal-fade-leave-active .modal-container[data-v-fdea4c1b]{transition:opacity .3s cubic-bezier(.34,1.56,.64,1),transform .3s cubic-bezier(.34,1.56,.64,1)}.modal-fade-enter-from[data-v-fdea4c1b],.modal-fade-leave-to[data-v-fdea4c1b]{opacity:0}.modal-fade-enter-from .modal-container[data-v-fdea4c1b],.modal-fade-leave-to .modal-container[data-v-fdea4c1b]{opacity:0;transform:scale(.9)translateY(10px)}.setting-item[data-v-aba8af24]{box-sizing:border-box;border-bottom:1px solid #ffffff08;flex-direction:column;gap:8px;width:100%;display:flex}.setting-item[data-v-aba8af24]:last-child{border-bottom:none}.setting-item .item-header[data-v-aba8af24]{flex-direction:column;gap:4px;display:flex}.setting-item .item-label[data-v-aba8af24]{color:var(--text-secondary);width:fit-content;font-size:13px;font-weight:600;transition:color .2s}.setting-item .item-label[data-tooltip][data-v-aba8af24],.setting-item .item-label[data-tooltip-custom][data-v-aba8af24]{cursor:help}.setting-item .item-label[data-tooltip][data-v-aba8af24]:hover,.setting-item .item-label[data-tooltip-custom][data-v-aba8af24]:hover{color:var(--accent-color)}.setting-item .item-desc[data-v-aba8af24]{color:var(--text-muted);font-size:11px;line-height:1.5}.setting-item .item-control[data-v-aba8af24]{gap:10px;width:100%;margin:4px 0;display:flex}.setting-item.type-component>.item-header>.item-label[data-v-aba8af24]{color:var(--text-primary);margin-bottom:2px;font-size:14.5px;font-weight:700}.setting-item.type-component>.item-header>.item-label[data-v-aba8af24]:not([data-tooltip]){cursor:default}.setting-item.type-component>.item-header>.item-label[data-v-aba8af24]:not([data-tooltip]):hover{color:var(--text-primary)}.setting-item.type-component>.item-header>.item-desc[data-v-aba8af24]{color:var(--text-secondary);font-size:12px}@media (width<=599px){.setting-item[data-v-aba8af24]{width:100%!important}}.tooltip-table-container[data-v-aba8af24]{padding:2px 0;font-family:inherit}.tooltip-table-container .tooltip-title[data-v-aba8af24]{color:var(--text-primary);margin-bottom:6px;font-size:12px;font-weight:600}.tooltip-table-container .tooltip-table[data-v-aba8af24]{border-collapse:collapse;white-space:normal;width:100%;margin-bottom:6px}.tooltip-table-container .tooltip-table th[data-v-aba8af24],.tooltip-table-container .tooltip-table td[data-v-aba8af24]{text-align:left;padding:4px 8px;font-size:10.5px;line-height:1.4}.tooltip-table-container .tooltip-table th[data-v-aba8af24]{color:var(--text-secondary);border-bottom:1px solid var(--panel-border);font-weight:600}.tooltip-table-container .tooltip-table td[data-v-aba8af24]{color:var(--text-primary);border-bottom:1px solid #ffffff0a}.light-theme .tooltip-table-container .tooltip-table td[data-v-aba8af24]{border-bottom:1px solid #0000000a}.tooltip-table-container .tooltip-table tr:last-child td[data-v-aba8af24]{border-bottom:none}.tooltip-table-container .tooltip-table code[data-v-aba8af24]{color:var(--accent-color);background:#6366f11f;border:1px solid #6366f126;border-radius:4px;padding:1px 4px;font-family:Consolas,Monaco,monospace;font-size:10px;font-weight:600}.tooltip-table-container .tooltip-footer[data-v-aba8af24]{color:var(--text-muted);border-top:1px solid var(--panel-border);font-size:10px}.group-control[data-v-ec9a612e]{gap:10px;width:100%;margin:4px 0;display:flex}.group-control.button-row[data-v-ec9a612e]{flex-wrap:wrap}.hidden-file-input[data-v-ec9a612e]{display:none}.action-btn[data-v-ec9a612e]{background:var(--btn-bg);border:1px solid var(--btn-border);height:36px;color:var(--text-secondary);cursor:pointer;background-clip:padding-box;border-radius:10px;justify-content:center;align-items:center;gap:8px;padding:0 14px;font-size:12px;font-weight:500;line-height:36px;transition:background-color .2s,border-color .2s,color .2s,transform .2s;display:flex}.action-btn[data-v-ec9a612e]:hover{background:var(--btn-hover-bg);color:var(--btn-hover-color);border-color:var(--btn-hover-border)}.action-btn .control-icon[data-v-ec9a612e]{width:16px;height:16px}.webdav-settings-panel[data-v-fc620bcb]{flex-direction:column;gap:16px;width:100%;display:flex}.sync-status-card[data-v-fc620bcb]{background:var(--card-bg,#ffffff0d);border:1px solid var(--border-color,#ffffff1a);-webkit-backdrop-filter:blur(10px);backdrop-filter:blur(10px);border-radius:14px;justify-content:space-between;align-items:center;padding:12px 16px;transition:all .3s;display:flex}.sync-status-card.success[data-v-fc620bcb]{background:#22c55e14;border-color:#22c55e59}.sync-status-card.error[data-v-fc620bcb]{background:#ef444414;border-color:#ef444459}.sync-status-card.syncing[data-v-fc620bcb]{background:#3b82f614;border-color:#3b82f659}.sync-status-card .status-left[data-v-fc620bcb]{align-items:center;gap:12px;display:flex}.sync-status-card .status-icon-box[data-v-fc620bcb]{background:#ffffff14;border-radius:10px;justify-content:center;align-items:center;width:38px;height:38px;display:flex}.sync-status-card .status-icon-box .icon-idle[data-v-fc620bcb]{width:20px;height:20px;color:var(--text-secondary)}.sync-status-card .status-icon-box .icon-syncing[data-v-fc620bcb]{color:#3b82f6;width:20px;height:20px}.sync-status-card .status-icon-box .icon-success[data-v-fc620bcb]{color:#22c55e;width:20px;height:20px}.sync-status-card .status-icon-box .icon-error[data-v-fc620bcb]{color:#ef4444;width:20px;height:20px}.sync-status-card .status-info[data-v-fc620bcb]{flex-direction:column;gap:2px;display:flex}.sync-status-card .status-info .status-title[data-v-fc620bcb]{color:var(--text-primary);font-size:14px;font-weight:600}.sync-status-card .status-info .status-sub[data-v-fc620bcb]{color:var(--text-secondary);font-size:12px}.sync-status-card .sync-now-btn[data-v-fc620bcb]{color:var(--text-primary);cursor:pointer;background:#ffffff1a;border:1px solid #ffffff26;border-radius:8px;align-items:center;gap:6px;padding:6px 14px;font-size:12px;font-weight:500;transition:all .2s;display:flex}.sync-status-card .sync-now-btn[data-v-fc620bcb]:hover:not(:disabled){background:#ffffff2e;transform:translateY(-1px)}.sync-status-card .sync-now-btn[data-v-fc620bcb]:disabled{opacity:.5;cursor:not-allowed}.sync-status-card .sync-now-btn .btn-icon[data-v-fc620bcb]{width:14px;height:14px}.form-container[data-v-fc620bcb]{flex-direction:column;gap:14px;display:flex}.setting-row[data-v-fc620bcb]{justify-content:space-between;align-items:center;padding:10px 0;display:flex}.setting-row.sub-row[data-v-fc620bcb]{border-top:1px dashed #ffffff14;padding-top:6px}.setting-row .row-label-group[data-v-fc620bcb]{flex-direction:column;gap:3px;display:flex}.setting-row .row-label-group .row-title[data-v-fc620bcb]{color:var(--text-primary);font-size:14px;font-weight:500}.setting-row .row-label-group .row-desc[data-v-fc620bcb]{color:var(--text-secondary);font-size:12px}.switch-control[data-v-fc620bcb]{cursor:pointer;-webkit-user-select:none;user-select:none;width:44px;height:24px;display:inline-block;position:relative}.switch-control input[data-v-fc620bcb]{opacity:0;width:0;height:0;position:absolute}.switch-control .slider[data-v-fc620bcb]{background:var(--btn-bg,#78788029);border:1px solid var(--btn-border,#7878803d);box-sizing:border-box;border-radius:24px;transition:all .3s cubic-bezier(.2,.8,.2,1);position:absolute;inset:0}.switch-control .slider[data-v-fc620bcb]:before{content:\"\";background-color:var(--text-secondary,#94a3b8);border-radius:50%;width:16px;height:16px;transition:all .3s cubic-bezier(.2,.8,.2,1);position:absolute;top:3px;left:3px;box-shadow:0 1px 3px #0003}.switch-control:hover .slider[data-v-fc620bcb]{background:var(--btn-hover-bg,#7878803d);border-color:var(--btn-hover-border,#7878805c)}.switch-control input:checked+.slider[data-v-fc620bcb]{background:var(--accent-color,#6366f1);border-color:#6366f14d;box-shadow:0 4px 12px #6366f133}.switch-control input:checked+.slider[data-v-fc620bcb]:before{background-color:#fff;transform:translate(20px);box-shadow:0 2px 4px #00000040}.fields-group[data-v-fc620bcb]{background:#ffffff08;border:1px solid #ffffff14;border-radius:12px;flex-direction:column;gap:14px;padding:14px;display:flex}.input-field-item[data-v-fc620bcb]{flex-direction:column;gap:6px;display:flex}.input-field-item .field-label[data-v-fc620bcb]{color:var(--text-primary);font-size:13px;font-weight:500}.input-field-item .field-hint[data-v-fc620bcb]{color:var(--text-secondary);font-size:11px}.field-row-double[data-v-fc620bcb]{grid-template-columns:1fr 1fr;gap:12px;display:grid}.text-input[data-v-fc620bcb]{width:100%;color:var(--text-primary);background:var(--input-bg,#0000001a);border:1px solid var(--input-border,#78788033);box-sizing:border-box;border-radius:8px;outline:none;padding:8px 12px;font-size:13px;transition:all .2s}.text-input[data-v-fc620bcb]:focus{border-color:var(--accent-color,#6366f1);background:var(--input-focus-bg,#00000026)}.password-wrapper[data-v-fc620bcb]{align-items:center;display:flex;position:relative}.password-wrapper .pwd-input[data-v-fc620bcb]{padding-right:36px}.password-wrapper .eye-btn[data-v-fc620bcb]{color:var(--text-secondary);cursor:pointer;background:0 0;border:none;justify-content:center;align-items:center;padding:4px;display:flex;position:absolute;right:8px}.password-wrapper .eye-btn[data-v-fc620bcb]:hover{color:var(--text-primary)}.password-wrapper .eye-btn .eye-icon[data-v-fc620bcb]{width:16px;height:16px}.tombstone-info-box[data-v-fc620bcb]{background:#3b82f614;border:1px solid #3b82f633;border-radius:8px;align-items:flex-start;gap:10px;padding:10px 12px;display:flex}.tombstone-info-box .shield-icon[data-v-fc620bcb]{color:#3b82f6;flex-shrink:0;width:18px;height:18px;margin-top:2px}.tombstone-info-box .info-content[data-v-fc620bcb]{flex-direction:column;gap:2px;display:flex}.tombstone-info-box .info-content .info-title[data-v-fc620bcb]{color:#3b82f6;font-size:12px;font-weight:600}.tombstone-info-box .info-content .info-desc[data-v-fc620bcb]{color:var(--text-secondary);font-size:11px;line-height:1.4}.actions-row[data-v-fc620bcb]{grid-template-columns:1fr 1fr;gap:8px;margin-top:4px;display:grid}.actions-row .tool-btn[data-v-fc620bcb]{cursor:pointer;border:1px solid #0000;border-radius:8px;justify-content:center;align-items:center;gap:6px;padding:8px 12px;font-size:12px;font-weight:500;transition:all .2s;display:flex}.actions-row .tool-btn .btn-icon[data-v-fc620bcb]{width:14px;height:14px}.actions-row .tool-btn[data-v-fc620bcb]:hover:not(:disabled){transform:translateY(-1px)}.actions-row .tool-btn[data-v-fc620bcb]:disabled{opacity:.5;cursor:not-allowed}.actions-row .tool-btn.test-btn[data-v-fc620bcb]{color:var(--text-primary);background:#ffffff14;border-color:#ffffff26}.actions-row .tool-btn.test-btn[data-v-fc620bcb]:hover:not(:disabled){background:#ffffff26}.actions-row .tool-btn.sync-btn[data-v-fc620bcb]{color:#60a5fa;background:#3b82f633;border-color:#3b82f659}.actions-row .tool-btn.sync-btn[data-v-fc620bcb]:hover:not(:disabled){background:#3b82f64d}.actions-row .tool-btn.force-btn[data-v-fc620bcb]{color:#fbbf24;background:#f59e0b26;border-color:#f59e0b4d}.actions-row .tool-btn.force-btn[data-v-fc620bcb]:hover:not(:disabled){background:#f59e0b40}.actions-row .tool-btn.pull-btn[data-v-fc620bcb]{color:#c084fc;background:#a855f726;border-color:#a855f74d}.actions-row .tool-btn.pull-btn[data-v-fc620bcb]:hover:not(:disabled){background:#a855f740}.test-result-box[data-v-fc620bcb]{border-radius:8px;align-items:center;gap:8px;padding:8px 12px;font-size:12px;display:flex}.test-result-box.success[data-v-fc620bcb]{color:#22c55e;background:#22c55e1a;border:1px solid #22c55e4d}.test-result-box.error[data-v-fc620bcb]{color:#ef4444;background:#ef44441a;border:1px solid #ef44444d}.test-result-box .res-icon[data-v-fc620bcb]{flex-shrink:0;width:16px;height:16px}.spin[data-v-fc620bcb]{animation:1s linear infinite spin-fc620bcb}@keyframes spin-fc620bcb{0%{transform:rotate(0)}to{transform:rotate(360deg)}}.about-wrapper[data-v-9f151106]{flex-direction:column;gap:16px;width:100%;display:flex}.about-card[data-v-9f151106]{background:#ffffff03;border:1px solid #ffffff08;border-radius:12px;align-items:center;gap:16px;padding:14px 0;display:flex}.about-card .about-logo[data-v-9f151106]{width:44px;height:44px}.about-card .app-name[data-v-9f151106]{color:var(--text-primary);font-size:15px;font-weight:700}.about-card .app-version[data-v-9f151106]{color:var(--text-muted);margin-top:2px;font-size:11px}.about-desc[data-v-9f151106]{color:var(--text-secondary);font-size:13px;line-height:1.6}.setting-input-wrapper[data-v-046f66af]{width:100%}.setting-input[data-v-046f66af]{background:var(--input-bg,#0000000d);border:1px solid var(--input-border,#ffffff14);width:100%;height:36px;color:var(--text-primary);border-radius:10px;outline:none;padding:0 12px;font-size:13px;transition:background-color .2s,border-color .2s,box-shadow .2s,color .2s}.setting-input[data-v-046f66af]:hover:not(:disabled){border-color:var(--accent-color)}.setting-input[data-v-046f66af]:focus{border-color:var(--accent-color);box-shadow:0 0 0 2px var(--accent-light)}.setting-input[data-v-046f66af]::placeholder{color:var(--text-muted);font-size:12px}.setting-textarea-wrapper[data-v-fcaf2087]{width:100%}.setting-textarea[data-v-fcaf2087]{background:var(--input-bg,#0000000d);border:1px solid var(--input-border,#ffffff14);width:100%;color:var(--text-primary);resize:none;border-radius:10px;outline:none;min-height:60px;padding:8px 12px;font-family:inherit;font-size:13px;line-height:1.5;transition:background-color .2s,border-color .2s,box-shadow .2s,color .2s}.setting-textarea[data-v-fcaf2087]:hover:not(:disabled){border-color:var(--accent-color)}.setting-textarea[data-v-fcaf2087]:focus{border-color:var(--accent-color);background:var(--input-focus-bg,#00000014);box-shadow:0 0 0 2px var(--accent-light)}.setting-textarea[data-v-fcaf2087]::placeholder{color:var(--text-muted);font-size:12px}.custom-select-container[data-v-ca7f9b55]{-webkit-user-select:none;user-select:none;width:100%;position:relative}.select-trigger[data-v-ca7f9b55]{background:var(--input-bg,#0000000d);border:1px solid var(--input-border,#ffffff14);height:36px;color:var(--text-primary);cursor:pointer;border-radius:10px;justify-content:space-between;align-items:center;padding:0 12px;font-size:13px;transition:background-color .2s,border-color .2s,box-shadow .2s,color .2s,transform .2s;display:flex}.select-trigger[data-v-ca7f9b55]:hover{border-color:var(--accent-color)}.select-trigger.open[data-v-ca7f9b55]{border-color:var(--accent-color);box-shadow:0 0 0 2px var(--accent-light)}.trigger-content[data-v-ca7f9b55]{text-overflow:ellipsis;white-space:nowrap;flex:1;align-items:center;gap:8px;display:flex;overflow:hidden}.item-content-wrapper[data-v-ca7f9b55]{flex:1;align-items:center;gap:8px;display:flex;overflow:hidden}.item-label[data-v-ca7f9b55]{text-overflow:ellipsis;white-space:nowrap;flex:1;overflow:hidden}.color-badge-dot[data-v-ca7f9b55]{border-radius:50%;flex-shrink:0;width:12px;height:12px;transition:background-color .2s,border-color .2s;box-shadow:0 1px 3px #00000026}.trigger-text[data-v-ca7f9b55]{text-overflow:ellipsis;white-space:nowrap;overflow:hidden}.trigger-text.placeholder[data-v-ca7f9b55]{color:var(--text-muted)}.arrow-icon[data-v-ca7f9b55]{width:16px;height:16px;color:var(--text-secondary);flex-shrink:0;margin-left:8px;transition:transform .2s}.arrow-icon.rotate[data-v-ca7f9b55]{transform:rotate(180deg)}.select-dropdown[data-v-ca7f9b55]{background:var(--popover-bg);border:1px solid var(--popover-border);width:100%;max-height:200px;box-shadow:var(--popover-shadow);z-index:1000;backface-visibility:hidden;border-radius:12px;flex-direction:column;gap:4px;padding:4px;display:flex;position:absolute;top:calc(100% + 6px);left:0;overflow-y:auto;transform:translateZ(0)}.dropdown-item[data-v-ca7f9b55]{height:32px;color:var(--text-secondary);cursor:pointer;border-radius:8px;justify-content:space-between;align-items:center;padding:0 12px;font-size:12px;line-height:32px;transition:background-color .15s,color .15s,transform .15s;display:flex}.dropdown-item[data-v-ca7f9b55]:hover{background:var(--item-hover-bg,#ffffff0a);color:var(--text-primary)}.dropdown-item.active[data-v-ca7f9b55]{background:var(--accent-light);color:var(--accent-color);font-weight:600}.check-icon[data-v-ca7f9b55]{width:14px;height:14px;color:var(--accent-color);flex-shrink:0}.slide-up-enter-active[data-v-ca7f9b55],.slide-up-leave-active[data-v-ca7f9b55]{transition:opacity .2s cubic-bezier(.16,1,.3,1),transform .2s cubic-bezier(.16,1,.3,1)}.slide-up-enter-from[data-v-ca7f9b55],.slide-up-leave-to[data-v-ca7f9b55]{opacity:0;transform:translateY(-8px)scale(.98)}.setting-radio-group[data-v-3a9334ad]{flex-wrap:wrap;gap:10px;width:100%;display:flex}.radio-btn[data-v-3a9334ad]{background:var(--btn-bg,#ffffff08);border:1px solid var(--btn-border,#ffffff0d);height:36px;color:var(--text-secondary);cursor:pointer;border-radius:10px;justify-content:center;align-items:center;gap:8px;padding:0 14px;font-size:12px;font-weight:500;line-height:36px;transition:background-color .2s,border-color .2s,color .2s,transform .2s;display:flex}.radio-btn[data-v-3a9334ad]:hover{background:var(--btn-hover-bg,#ffffff14);color:var(--text-primary);border-color:var(--btn-hover-border,#ffffff1a)}.radio-btn.active[data-v-3a9334ad]{background:var(--accent-light);color:var(--accent-color);border-color:#6366f140;font-weight:600}.radio-btn .control-icon[data-v-3a9334ad]{width:14px;height:14px}.setting-btn[data-v-f0bed8f6]{white-space:nowrap;cursor:pointer;box-sizing:border-box;border:1px solid #0000;border-radius:10px;justify-content:center;align-items:center;gap:8px;height:36px;padding:0 14px;font-size:12px;font-weight:600;line-height:36px;transition:opacity .2s,background-color .2s,border-color .2s,box-shadow .2s,color .2s,filter .2s,transform .2s;display:flex}.setting-btn.variant-primary[data-v-f0bed8f6]{background:var(--accent-color);color:#fff;box-shadow:0 4px 10px -2px #6366f140}.setting-btn.variant-primary[data-v-f0bed8f6]:hover:not(:disabled){background:var(--accent-hover);transform:translateY(-1px);box-shadow:0 6px 14px -2px #6366f159}.setting-btn.variant-danger[data-v-f0bed8f6]{background:var(--danger-color,#ff4d4f);color:#fff;box-shadow:0 4px 10px -2px #ff4d4f33}.setting-btn.variant-danger[data-v-f0bed8f6]:hover:not(:disabled){background:#ff7875;transform:translateY(-1px);box-shadow:0 6px 14px -2px #ff4d4f4d}.setting-btn.variant-secondary[data-v-f0bed8f6]{background:var(--btn-bg,#ffffff08);border-color:var(--btn-border,#ffffff0d);color:var(--text-secondary)}.setting-btn.variant-secondary[data-v-f0bed8f6]:hover:not(:disabled){background:var(--btn-hover-bg,#ffffff14);color:var(--text-primary);border-color:var(--btn-hover-border,#ffffff1a);transform:translateY(-1px)}.setting-btn.has-custom-color[data-v-f0bed8f6]{filter:drop-shadow(0 4px 6px #00000026);background:var(--custom-btn-color)!important;color:#fff!important;border-color:#0000!important}.setting-btn.has-custom-color[data-v-f0bed8f6]:hover:not(:disabled){filter:brightness(1.1)drop-shadow(0 6px 10px #0003);transform:translateY(-1px)}.setting-btn.has-custom-color[data-v-f0bed8f6]:active:not(:disabled){filter:brightness(.9)drop-shadow(0 3px 5px #00000026);transform:translateY(0)}.setting-btn[data-v-f0bed8f6]:active:not(:disabled){transform:translateY(0)}.setting-btn[data-v-f0bed8f6]:disabled{opacity:.4;cursor:not-allowed;box-shadow:none!important;filter:none!important}.setting-btn[data-v-f0bed8f6] .control-icon{flex-shrink:0;width:14px;height:14px}.shortcut-input-group[data-v-3481f3a1]{box-sizing:border-box;align-items:center;gap:8px;width:100%;display:flex}.shortcut-input-box[data-v-3481f3a1]{background:var(--input-bg,#0000000d);border:1px solid var(--input-border,#ffffff14);height:36px;color:var(--text-primary);cursor:pointer;-webkit-user-select:none;user-select:none;box-sizing:border-box;border-radius:10px;outline:none;flex:1;justify-content:space-between;align-items:center;padding:0 12px;font-size:13px;transition:background-color .2s,border-color .2s,box-shadow .2s,color .2s;display:flex}.shortcut-input-box[data-v-3481f3a1]:hover:not(.disabled){border-color:var(--accent-color)}.shortcut-input-box[data-v-3481f3a1]:focus:not(.disabled){border-color:var(--accent-color);box-shadow:0 0 0 2px var(--accent-light)}.shortcut-input-box.recording[data-v-3481f3a1]{border-color:var(--accent-color);box-shadow:0 0 0 2px var(--accent-light);color:var(--accent-color);background:var(--accent-light)}.shortcut-input-box.disabled[data-v-3481f3a1]{opacity:.5;cursor:not-allowed}.shortcut-input-box .shortcut-text[data-v-3481f3a1]{font-family:var(--font-mono,monospace);font-weight:600}.shortcut-input-box .rec-badge[data-v-3481f3a1]{background:var(--danger-color,#ef4444);color:#fff;border-radius:4px;padding:2px 5px;font-size:9px;font-weight:700;animation:1.5s infinite pulse-3481f3a1}.control-btn[data-v-3481f3a1]{border:1px solid var(--btn-border);background:var(--btn-bg);width:36px;height:36px;color:var(--text-secondary);cursor:pointer;background-clip:padding-box;border-radius:10px;flex-shrink:0;justify-content:center;align-items:center;transition:opacity .2s,background-color .2s,border-color .2s,color .2s,transform .2s;display:flex}.control-btn[data-v-3481f3a1]:hover:not(:disabled){background:var(--btn-hover-bg);color:var(--btn-hover-color);border-color:var(--btn-hover-border)}.control-btn[data-v-3481f3a1]:disabled{opacity:.4;cursor:not-allowed}.control-btn.danger[data-v-3481f3a1]:hover:not(:disabled){color:var(--danger-color);background:var(--danger-hover-bg);border-color:var(--danger-hover-border)}.control-btn .control-icon[data-v-3481f3a1]{width:16px;height:16px}@keyframes pulse-3481f3a1{0%{opacity:1}50%{opacity:.5}to{opacity:1}}.setting-slider-container[data-v-9193e12a]{align-items:center;gap:10px;width:100%;display:flex}.setting-range-input[data-v-9193e12a]{appearance:none;background:#0000000f;border-radius:3px;outline:none;flex:1;height:6px;margin:0;padding:0;transition:background .2s}.dark-theme .setting-range-input[data-v-9193e12a]{background:#ffffff38}.setting-range-input[data-v-9193e12a]:hover{background:#00000014}.dark-theme .setting-range-input[data-v-9193e12a]:hover{background:#ffffff40}.setting-range-input[data-v-9193e12a]::-webkit-slider-thumb{appearance:none;background:var(--accent-color,#6366f1);cursor:pointer;border:2px solid var(--popover-bg,#fff);border-radius:50%;width:16px;height:16px;transition:transform .1s,background-color .2s;box-shadow:0 2px 6px #0003}.setting-range-input[data-v-9193e12a]::-webkit-slider-thumb:hover{background:var(--accent-hover,#4f46e5);transform:scale(1.15)}.setting-range-input[data-v-9193e12a]::-moz-range-thumb{background:var(--accent-color,#6366f1);cursor:pointer;border:2px solid var(--popover-bg,#fff);border-radius:50%;width:16px;height:16px;transition:transform .1s,background-color .2s;box-shadow:0 2px 6px #0003}.setting-range-input[data-v-9193e12a]::-moz-range-thumb:hover{background:var(--accent-hover,#4f46e5);transform:scale(1.15)}.setting-range-input[data-v-9193e12a]:focus::-webkit-slider-thumb{box-shadow:0 0 0 4px var(--accent-light,#6366f133)}.setting-range-input[data-v-9193e12a]:focus::-moz-range-thumb{box-shadow:0 0 0 4px var(--accent-light,#6366f133)}.setting-slider-value[data-v-9193e12a]{color:var(--text-secondary);text-align:right;min-width:36px;font-family:monospace;font-size:13px;font-weight:600}.setting-switch-container[data-v-c6d0f8ca]{cursor:pointer;-webkit-user-select:none;user-select:none;align-items:center;padding:4px 0;display:inline-flex}.switch-track[data-v-c6d0f8ca]{background:var(--btn-bg,#ffffff0d);border:1px solid var(--btn-border,#ffffff14);cursor:pointer;border-radius:100px;outline:none;width:44px;height:22px;padding:0;transition:background-color .3s cubic-bezier(.2,.8,.2,1),border-color .3s cubic-bezier(.2,.8,.2,1),box-shadow .2s;position:relative}.switch-track[data-v-c6d0f8ca]:hover{background:var(--btn-hover-bg,#ffffff14);border-color:var(--btn-hover-border,#ffffff1f)}.switch-track[data-v-c6d0f8ca]:focus-visible{box-shadow:0 0 0 2px #6366f159}.switch-track.checked[data-v-c6d0f8ca]{background:var(--accent-color,#6366f1);border-color:#6366f14d;box-shadow:0 4px 12px #6366f133}.switch-track.checked[data-v-c6d0f8ca]:hover{background:var(--accent-hover,#4f46e5)}.switch-track.checked .switch-thumb[data-v-c6d0f8ca]{background:#fff;transform:translate(22px);box-shadow:0 2px 4px #0003}.switch-thumb[data-v-c6d0f8ca]{background:var(--text-secondary,#ccc);border-radius:50%;width:16px;height:16px;transition:transform .25s cubic-bezier(.25,1,.5,1),background-color .25s cubic-bezier(.25,1,.5,1);position:absolute;top:2px;left:2px;box-shadow:0 1px 3px #00000026}.setting-control-container[data-v-e378b87f]{display:contents}.setting-text-content[data-v-e378b87f]{width:100%}.setting-text-content[data-v-e378b87f] ul{flex-direction:column;gap:8px;margin:0;padding:0;list-style:none;display:flex}.setting-text-content[data-v-e378b87f] ul li{color:var(--text-muted);padding-left:12px;font-size:11px;line-height:1.5;position:relative}.setting-text-content[data-v-e378b87f] ul li:before{content:\"•\";color:var(--accent-color);position:absolute;left:0}.quick-actions-row[data-v-e378b87f]{gap:10px;width:100%;display:flex}.modal-overlay[data-v-d4e116ee]{background:var(--modal-overlay-bg);z-index:9000;justify-content:center;align-items:center;width:100vw;height:100vh;display:flex;position:fixed;top:0;left:0}.modal-container[data-v-d4e116ee]{background:var(--popover-bg);border:1px solid var(--popover-border);width:90%;max-width:620px;height:480px;box-shadow:var(--shadow-lg);border-radius:20px;flex-direction:column;display:flex;overflow:hidden}.modal-header[data-v-d4e116ee]{border-bottom:1px solid #ffffff0d;flex-shrink:0;justify-content:space-between;align-items:center;padding:16px 24px;display:flex}.modal-header .header-title-area[data-v-d4e116ee]{color:var(--text-primary);align-items:center;gap:10px;display:flex}.modal-header .header-title-area .header-icon[data-v-d4e116ee]{width:20px;height:20px;color:var(--accent-color)}.modal-header .header-title-area h3[data-v-d4e116ee]{font-family:var(--font-display);font-size:16px;font-weight:700}.modal-header .close-btn[data-v-d4e116ee]{width:28px;height:28px;color:var(--text-muted);cursor:pointer;border-radius:8px;justify-content:center;align-items:center;transition:background-color .2s,color .2s,transform .2s;display:flex}.modal-header .close-btn[data-v-d4e116ee]:hover{background:var(--btn-hover-bg);color:var(--text-primary)}.modal-header .close-btn .close-icon[data-v-d4e116ee]{width:16px;height:16px}.modal-body[data-v-d4e116ee]{flex:1;display:flex;overflow:hidden}.tab-sidebar[data-v-d4e116ee]{background:#00000005;border-right:1px solid #ffffff0d;flex-direction:column;flex-shrink:0;gap:6px;width:140px;padding:12px 8px;display:flex}.tab-item[data-v-d4e116ee]{height:36px;color:var(--text-secondary);cursor:pointer;border-radius:10px;align-items:center;gap:10px;width:100%;padding:0 14px;font-size:13px;font-weight:500;line-height:36px;transition:background-color .2s,color .2s,transform .2s;display:flex}.tab-item[data-v-d4e116ee]:hover{background:var(--btn-hover-bg);color:var(--text-primary)}.tab-item.active[data-v-d4e116ee]{background:var(--accent-light);color:var(--accent-color);font-weight:600}.tab-item .tab-icon[data-v-d4e116ee]{width:16px;height:16px}.settings-content[data-v-d4e116ee]{background:0 0;flex:1;padding:20px;overflow-y:auto}.settings-panel[data-v-d4e116ee]{flex-flow:wrap;gap:16px 14px;display:flex}.panel-title[data-v-d4e116ee]{color:var(--text-primary);border-left:3px solid var(--accent-color);width:100%;margin-bottom:4px;padding-left:8px;font-size:16px;font-weight:700;line-height:1.2}.quick-actions-row[data-v-d4e116ee]{gap:10px;width:100%;display:flex}.modal-fade-enter-active[data-v-d4e116ee],.modal-fade-leave-active[data-v-d4e116ee]{will-change:opacity;transition:opacity .3s cubic-bezier(.16,1,.3,1)}.modal-fade-enter-active .modal-container[data-v-d4e116ee],.modal-fade-leave-active .modal-container[data-v-d4e116ee]{will-change:transform, opacity;transition:transform .3s cubic-bezier(.34,1.56,.64,1),opacity .3s}.modal-fade-enter-from[data-v-d4e116ee],.modal-fade-leave-to[data-v-d4e116ee]{opacity:0}.modal-fade-enter-from .modal-container[data-v-d4e116ee],.modal-fade-leave-to .modal-container[data-v-d4e116ee]{opacity:0;transform:scale(.92)translateY(12px)}@media (width<=599px){.modal-container[data-v-d4e116ee]{width:95%;height:90vh}.modal-body[data-v-d4e116ee]{flex-direction:column}.tab-sidebar[data-v-d4e116ee]{border-bottom:1px solid #ffffff0d;border-right:none;flex-direction:row;width:100%;height:48px;padding:6px;overflow-x:auto}.tab-sidebar .tab-item[data-v-d4e116ee]{justify-content:center;height:100%;padding:0 10px}.tab-sidebar .tab-item span[data-v-d4e116ee]{display:none}.settings-content[data-v-d4e116ee]{padding:16px}}.tree-node-wrapper[data-v-7a5b65dc]{flex-direction:column;display:flex}.category-item[data-v-7a5b65dc]{background:var(--item-bg,#00000008);cursor:pointer;-webkit-user-select:none;user-select:none;border:1px solid #0000;border-radius:8px;justify-content:space-between;align-items:center;margin-bottom:4px;padding-top:7px;padding-bottom:7px;padding-right:12px;transition:all .2s;display:flex}.category-item[data-v-7a5b65dc]:hover{background:var(--item-hover-bg,#0000000f)}.category-item.active[data-v-7a5b65dc]{background:var(--item-active-bg,#3b82f614);border-color:#3b82f64d}.category-item .item-left[data-v-7a5b65dc]{flex:1;align-items:center;gap:6px;min-width:0;display:flex}.category-item .item-left .collapse-toggle[data-v-7a5b65dc]{width:18px;height:18px;color:var(--text-secondary,#888);cursor:pointer;border-radius:4px;flex-shrink:0;justify-content:center;align-items:center;transition:background .15s,color .15s;display:flex}.category-item .item-left .collapse-toggle[data-v-7a5b65dc]:hover{color:var(--text-primary,#333);background:#00000014}.category-item .item-left .collapse-toggle .toggle-icon[data-v-7a5b65dc]{stroke-width:2.2px;width:14px;height:14px;transition:transform .2s cubic-bezier(.4,0,.2,1)}.category-item .item-left .collapse-toggle .toggle-icon.is-expanded[data-v-7a5b65dc]{transform:rotate(90deg)}.category-item .item-left .collapse-spacer[data-v-7a5b65dc]{flex-shrink:0;width:18px;height:18px}.category-item .item-left .checkbox-icon[data-v-7a5b65dc]{width:16px;height:16px;color:var(--text-secondary,#999);flex-shrink:0}.category-item .item-left .checkbox-icon.checked[data-v-7a5b65dc]{color:var(--primary-color,#3b82f6)}.category-item .item-left .folder-icon[data-v-7a5b65dc]{width:15px;height:15px;color:var(--text-secondary,#666);flex-shrink:0}.category-item .item-left .cat-name[data-v-7a5b65dc]{white-space:nowrap;text-overflow:ellipsis;font-size:13px;font-weight:500;overflow:hidden}.category-item .badge[data-v-7a5b65dc]{color:var(--text-secondary,#666);background:#0000000f;border-radius:10px;flex-shrink:0;padding:2px 8px;font-size:11px}.tree-children[data-v-7a5b65dc]{flex-direction:column;display:flex}.category-selector-section[data-v-68819e8b]{flex-direction:column;gap:8px;display:flex}.selection-toolbar[data-v-68819e8b]{justify-content:space-between;align-items:center;display:flex}.selection-toolbar .sub-title[data-v-68819e8b]{color:var(--text-primary,#333);font-size:13px;font-weight:600}.selection-toolbar .text-action-btn[data-v-68819e8b]{height:20px;color:var(--primary-color,#3b82f6);cursor:pointer;background:0 0;border:none;border-radius:4px;padding:0 6px;font-size:12px;font-weight:500;line-height:20px;transition:background .2s}.selection-toolbar .text-action-btn[data-v-68819e8b]:hover{background:#3b82f61a}.category-list[data-v-68819e8b]{flex-direction:column;gap:2px;max-height:240px;padding-right:4px;display:flex;overflow-y:auto}.category-item.uncategorized-item[data-v-68819e8b]{background:var(--item-bg,#00000008);cursor:pointer;-webkit-user-select:none;user-select:none;border:1px solid #0000;border-radius:8px;justify-content:space-between;align-items:center;margin-top:4px;padding:7px 12px 7px 10px;transition:all .2s;display:flex}.category-item.uncategorized-item[data-v-68819e8b]:hover{background:var(--item-hover-bg,#0000000f)}.category-item.uncategorized-item.active[data-v-68819e8b]{background:var(--item-active-bg,#3b82f614);border-color:#3b82f64d}.category-item.uncategorized-item .item-left[data-v-68819e8b]{flex:1;align-items:center;gap:6px;min-width:0;display:flex}.category-item.uncategorized-item .item-left .collapse-spacer[data-v-68819e8b]{flex-shrink:0;width:18px;height:18px}.category-item.uncategorized-item .item-left .checkbox-icon[data-v-68819e8b]{width:16px;height:16px;color:var(--text-secondary,#999);flex-shrink:0}.category-item.uncategorized-item .item-left .checkbox-icon.checked[data-v-68819e8b]{color:var(--primary-color,#3b82f6)}.category-item.uncategorized-item .item-left .folder-icon[data-v-68819e8b]{width:15px;height:15px;color:var(--text-secondary,#666);flex-shrink:0}.category-item.uncategorized-item .item-left .cat-name[data-v-68819e8b]{white-space:nowrap;text-overflow:ellipsis;font-size:13px;font-weight:500;overflow:hidden}.category-item.uncategorized-item .badge[data-v-68819e8b]{color:var(--text-secondary,#666);background:#0000000f;border-radius:10px;flex-shrink:0;padding:2px 8px;font-size:11px}.modal-backdrop[data-v-55cadf58]{z-index:9010;-webkit-backdrop-filter:blur(8px);backdrop-filter:blur(8px);background:#00000073;justify-content:center;align-items:center;display:flex;position:fixed;inset:0}.modal-card[data-v-55cadf58]{background:var(--card-bg,#fffffff2);border:1px solid var(--border-color,#fff3);width:440px;max-width:90vw;color:var(--text-primary,#333);border-radius:16px;flex-direction:column;display:flex;overflow:hidden;box-shadow:0 20px 40px #00000040}.modal-header[data-v-55cadf58]{border-bottom:1px solid var(--border-color,#00000014);justify-content:space-between;align-items:center;padding:16px 20px;display:flex}.modal-header .header-title[data-v-55cadf58]{align-items:center;gap:8px;font-size:16px;font-weight:600;display:flex}.modal-header .header-title .header-icon[data-v-55cadf58]{width:18px;height:18px;color:var(--primary-color,#3b82f6)}.modal-header .close-btn[data-v-55cadf58]{width:28px;height:28px;color:var(--text-secondary,#666);cursor:pointer;background:0 0;border:none;border-radius:8px;justify-content:center;align-items:center;transition:background .2s,color .2s;display:flex}.modal-header .close-btn[data-v-55cadf58]:hover{background:var(--btn-hover-bg,#0000000d);color:var(--text-primary,#111)}.modal-header .close-btn .close-icon[data-v-55cadf58]{width:16px;height:16px}.modal-body[data-v-55cadf58]{flex-direction:column;gap:12px;padding:16px 20px;display:flex}.modal-body .section-desc[data-v-55cadf58]{color:var(--text-secondary,#666);margin:0;font-size:13px}.options-section[data-v-55cadf58]{flex-direction:column;gap:8px;margin-top:4px;display:flex}.options-section .option-item[data-v-55cadf58]{color:var(--text-primary,#444);cursor:pointer;-webkit-user-select:none;user-select:none;align-items:center;gap:8px;padding:4px 0;font-size:12px;display:flex}.options-section .option-item .checkbox-icon[data-v-55cadf58]{width:15px;height:15px;color:var(--text-secondary,#999)}.options-section .option-item .checkbox-icon.checked[data-v-55cadf58]{color:var(--primary-color,#3b82f6)}.options-section .option-item .option-icon[data-v-55cadf58]{width:14px;height:14px;color:var(--text-secondary,#666)}.options-section .option-item .option-label[data-v-55cadf58]{font-size:12px}.modal-footer[data-v-55cadf58]{border-top:1px solid var(--border-color,#00000014);background:var(--footer-bg,#00000005);justify-content:space-between;align-items:center;padding:14px 20px;display:flex}.modal-footer .summary-info[data-v-55cadf58]{color:var(--text-secondary,#666);font-size:12px}.modal-footer .footer-actions[data-v-55cadf58]{align-items:center;gap:8px;display:flex}.btn[data-v-55cadf58]{cursor:pointer;border:1px solid #0000;border-radius:8px;align-items:center;gap:6px;height:32px;padding:0 14px;font-size:12px;font-weight:500;transition:all .2s;display:flex}.btn.btn-cancel[data-v-55cadf58]{border-color:var(--btn-border,#00000026);color:var(--text-secondary,#666);background:0 0}.btn.btn-cancel[data-v-55cadf58]:hover{background:var(--btn-hover-bg,#0000000d)}.btn.btn-primary[data-v-55cadf58]{background:var(--primary-color,#3b82f6);color:#fff}.btn.btn-primary[data-v-55cadf58]:hover:not(:disabled){background:var(--primary-hover-color,#2563eb)}.btn.btn-primary[data-v-55cadf58]:disabled{opacity:.5;cursor:not-allowed}.btn.btn-primary .btn-icon[data-v-55cadf58]{width:14px;height:14px}.modal-fade-enter-active[data-v-55cadf58],.modal-fade-leave-active[data-v-55cadf58]{transition:opacity .25s cubic-bezier(.16,1,.3,1)}.modal-fade-enter-active .modal-card[data-v-55cadf58],.modal-fade-leave-active .modal-card[data-v-55cadf58]{transition:transform .25s cubic-bezier(.16,1,.3,1)}.modal-fade-enter-from[data-v-55cadf58],.modal-fade-leave-to[data-v-55cadf58]{opacity:0}.modal-fade-enter-from .modal-card[data-v-55cadf58],.modal-fade-leave-to .modal-card[data-v-55cadf58]{transform:scale(.95)translateY(10px)}.file-info-card[data-v-35d9eb71]{background:var(--item-bg,#3b82f60d);border:1px solid #3b82f626;border-radius:10px;flex-direction:column;gap:6px;padding:12px 14px;display:flex}.file-info-card .info-meta[data-v-35d9eb71]{color:var(--text-secondary,#666);justify-content:space-between;align-items:center;font-size:12px;display:flex}.file-info-card .info-meta .meta-item[data-v-35d9eb71]{align-items:center;gap:5px;display:flex}.file-info-card .info-meta .meta-item .meta-icon[data-v-35d9eb71]{width:13px;height:13px}.file-info-card .info-stats[data-v-35d9eb71]{color:var(--primary-color,#3b82f6);align-items:center;gap:8px;font-size:12px;font-weight:500;display:flex}.section-container[data-v-763fbc99]{flex-direction:column;gap:8px;display:flex}.section-container .section-title[data-v-763fbc99]{color:var(--text-primary,#333);font-size:13px;font-weight:600}.mode-grid[data-v-763fbc99]{grid-template-columns:1fr 1fr;gap:10px;display:grid}.mode-card[data-v-763fbc99]{border:1.5px solid var(--border-color,#0000001a);background:var(--item-bg,#00000005);cursor:pointer;-webkit-user-select:none;user-select:none;border-radius:10px;padding:10px 12px;transition:all .2s}.mode-card[data-v-763fbc99]:hover{border-color:#3b82f666}.mode-card.active[data-v-763fbc99]{border-color:var(--primary-color,#3b82f6);background:#3b82f614}.mode-card.danger.active[data-v-763fbc99]{background:#ef444414;border-color:#ef4444}.mode-card .mode-header[data-v-763fbc99]{align-items:center;gap:6px;margin-bottom:4px;font-size:13px;font-weight:600;display:flex}.mode-card .mode-header .mode-icon[data-v-763fbc99]{width:15px;height:15px}.mode-card .mode-header .mode-icon.merge[data-v-763fbc99]{color:#3b82f6}.mode-card .mode-header .mode-icon.overwrite[data-v-763fbc99]{color:#ef4444}.mode-card .mode-desc[data-v-763fbc99]{color:var(--text-secondary,#666);margin:0;font-size:11px;line-height:1.4}.modal-backdrop[data-v-feff713e]{z-index:9010;-webkit-backdrop-filter:blur(8px);backdrop-filter:blur(8px);background:#00000073;justify-content:center;align-items:center;display:flex;position:fixed;inset:0}.modal-card[data-v-feff713e]{background:var(--card-bg,#fffffff2);border:1px solid var(--border-color,#fff3);width:480px;max-width:92vw;max-height:85vh;color:var(--text-primary,#333);border-radius:16px;flex-direction:column;display:flex;overflow:hidden;box-shadow:0 20px 40px #00000040}.modal-header[data-v-feff713e]{border-bottom:1px solid var(--border-color,#00000014);justify-content:space-between;align-items:center;padding:16px 20px;display:flex}.modal-header .header-title[data-v-feff713e]{align-items:center;gap:8px;font-size:16px;font-weight:600;display:flex}.modal-header .header-title .header-icon[data-v-feff713e]{width:18px;height:18px;color:var(--primary-color,#3b82f6)}.modal-header .close-btn[data-v-feff713e]{width:28px;height:28px;color:var(--text-secondary,#666);cursor:pointer;background:0 0;border:none;border-radius:8px;justify-content:center;align-items:center;transition:background .2s,color .2s;display:flex}.modal-header .close-btn[data-v-feff713e]:hover{background:var(--btn-hover-bg,#0000000d);color:var(--text-primary,#111)}.modal-header .close-btn .close-icon[data-v-feff713e]{width:16px;height:16px}.modal-body[data-v-feff713e]{flex-direction:column;gap:16px;padding:16px 20px;display:flex;overflow-y:auto}.section-container[data-v-feff713e]{flex-direction:column;gap:8px;display:flex}.options-section[data-v-feff713e]{flex-direction:column;gap:8px;margin-top:4px;display:flex}.options-section .option-item[data-v-feff713e]{color:var(--text-primary,#444);cursor:pointer;-webkit-user-select:none;user-select:none;align-items:center;gap:8px;padding:4px 0;font-size:12px;display:flex}.options-section .option-item .checkbox-icon[data-v-feff713e]{width:15px;height:15px;color:var(--text-secondary,#999)}.options-section .option-item .checkbox-icon.checked[data-v-feff713e]{color:var(--primary-color,#3b82f6)}.options-section .option-item .option-icon[data-v-feff713e]{width:14px;height:14px;color:var(--text-secondary,#666)}.options-section .option-item .option-label[data-v-feff713e]{font-size:12px}.modal-footer[data-v-feff713e]{border-top:1px solid var(--border-color,#00000014);background:var(--footer-bg,#00000005);justify-content:space-between;align-items:center;padding:14px 20px;display:flex}.modal-footer .summary-info[data-v-feff713e]{color:var(--text-secondary,#666);font-size:12px}.modal-footer .footer-actions[data-v-feff713e]{align-items:center;gap:8px;display:flex}.btn[data-v-feff713e]{cursor:pointer;border:1px solid #0000;border-radius:8px;align-items:center;gap:6px;height:32px;padding:0 14px;font-size:12px;font-weight:500;transition:all .2s;display:flex}.btn.btn-cancel[data-v-feff713e]{border-color:var(--btn-border,#00000026);color:var(--text-secondary,#666);background:0 0}.btn.btn-cancel[data-v-feff713e]:hover{background:var(--btn-hover-bg,#0000000d)}.btn.btn-primary[data-v-feff713e]{background:var(--primary-color,#3b82f6);color:#fff}.btn.btn-primary[data-v-feff713e]:hover:not(:disabled){background:var(--primary-hover-color,#2563eb)}.btn.btn-primary[data-v-feff713e]:disabled{opacity:.5;cursor:not-allowed}.btn.btn-primary .btn-icon[data-v-feff713e]{width:14px;height:14px}.btn.btn-danger[data-v-feff713e]{color:#fff;background:#ef4444}.btn.btn-danger[data-v-feff713e]:hover:not(:disabled){background:#dc2626}.btn.btn-danger[data-v-feff713e]:disabled{opacity:.5;cursor:not-allowed}.btn.btn-danger .btn-icon[data-v-feff713e]{width:14px;height:14px}.modal-fade-enter-active[data-v-feff713e],.modal-fade-leave-active[data-v-feff713e]{transition:opacity .25s cubic-bezier(.16,1,.3,1)}.modal-fade-enter-active .modal-card[data-v-feff713e],.modal-fade-leave-active .modal-card[data-v-feff713e]{transition:transform .25s cubic-bezier(.16,1,.3,1)}.modal-fade-enter-from[data-v-feff713e],.modal-fade-leave-to[data-v-feff713e]{opacity:0}.modal-fade-enter-from .modal-card[data-v-feff713e],.modal-fade-leave-to .modal-card[data-v-feff713e]{transform:scale(.95)translateY(10px)}.mobile-bottom-bar[data-v-0aafe83f]{display:none}@media (width<=599px){.mobile-bottom-bar[data-v-0aafe83f]{height:calc(56px + env(safe-area-inset-bottom,0px));padding:0 16px env(safe-area-inset-bottom,0px) 16px;background:var(--dock-bg,#121826eb);border-top:1px solid var(--panel-border);-webkit-backdrop-filter:var(--glass-blur-dock,blur(24px) saturate(180%));z-index:100;box-sizing:border-box;justify-content:space-around;align-items:center;display:flex;position:fixed;bottom:0;left:0;right:0;box-shadow:0 -4px 24px #00000029}.nav-tab-btn[data-v-0aafe83f]{color:var(--text-secondary);cursor:pointer;background:0 0;border:none;border-radius:8px;flex-direction:column;justify-content:center;align-items:center;gap:3px;min-width:48px;padding:4px 10px;transition:color .15s,transform .15s;display:flex}.nav-tab-btn[data-v-0aafe83f]:active{transform:scale(.92)}.nav-tab-btn.active[data-v-0aafe83f]{color:var(--accent-color)}.nav-tab-btn .tab-icon[data-v-0aafe83f]{width:19px;height:19px}.nav-tab-wrapper[data-v-0aafe83f]{flex-direction:column;justify-content:center;align-items:center;gap:3px;min-width:48px;display:flex;position:relative}.nav-tab-wrapper[data-v-0aafe83f] .icon-btn{width:auto;height:auto;color:var(--text-secondary);background:0 0;border:none;padding:0}.nav-tab-wrapper[data-v-0aafe83f] .icon-btn:hover{background:0 0}.nav-tab-wrapper[data-v-0aafe83f] .icon-btn.active{color:var(--accent-color);background:0 0}.nav-tab-wrapper[data-v-0aafe83f] .icon-btn .btn-icon{width:19px;height:19px}.tab-label[data-v-0aafe83f]{color:inherit;-webkit-user-select:none;user-select:none;font-size:10px;font-weight:500;line-height:1}.center-fab-wrapper[data-v-0aafe83f]{justify-content:center;align-items:center;margin-top:-12px;display:flex;position:relative}.center-fab-btn[data-v-0aafe83f]{background:var(--accent-color);color:#fff;border:3px solid var(--body-bg,#181b24);cursor:pointer;border-radius:50%;justify-content:center;align-items:center;width:48px;height:48px;transition:transform .2s cubic-bezier(.34,1.56,.64,1),box-shadow .2s;display:flex;box-shadow:0 4px 14px -2px #6366f180}.center-fab-btn[data-v-0aafe83f]:active{transform:scale(.9);box-shadow:0 2px 8px -2px #6366f166}.center-fab-btn .fab-icon[data-v-0aafe83f]{stroke-width:2.5px;width:24px;height:24px}}.dashboard-layout[data-v-50e44fed]{background:0 0;width:100%;height:100%;display:flex;overflow:hidden}.main-panel[data-v-50e44fed]{background:#ffffff03;flex-direction:column;flex:1;min-width:0;height:100%;display:flex;position:relative}.mobile-sidebar-backdrop[data-v-50e44fed]{display:none}@media (width<=599px){.mobile-sidebar-backdrop[data-v-50e44fed]{-webkit-backdrop-filter:blur(10px);width:100vw;height:100vh;z-index:calc(9000 - 1);cursor:pointer;background:#0009;display:block;position:fixed;inset:0}}.drawer-fade-enter-active[data-v-50e44fed],.drawer-fade-leave-active[data-v-50e44fed]{transition:opacity .25s cubic-bezier(.16,1,.3,1)}.drawer-fade-enter-from[data-v-50e44fed],.drawer-fade-leave-to[data-v-50e44fed]{opacity:0}.fade-slide-enter-active[data-v-50e44fed],.fade-slide-leave-active[data-v-50e44fed]{transition:opacity .25s cubic-bezier(.16,1,.3,1),transform .25s cubic-bezier(.16,1,.3,1)}.fade-slide-enter-from[data-v-50e44fed]{opacity:0;transform:translateY(6px)}.fade-slide-leave-to[data-v-50e44fed]{opacity:0;transform:translateY(-6px)}.image-preview-overlay[data-v-a2450027]{z-index:9040;-webkit-backdrop-filter:blur(12px);-webkit-user-select:none;user-select:none;cursor:zoom-out;background:#000000bf;flex-direction:column;justify-content:center;align-items:center;display:flex;position:fixed;inset:0;overflow:hidden}.page-close-btn[data-v-a2450027]{color:#fff;cursor:pointer;z-index:9050;-webkit-backdrop-filter:blur(8px);background:#ffffff26;border:1px solid #fff3;border-radius:50%;justify-content:center;align-items:center;width:36px;height:36px;transition:background-color .2s cubic-bezier(.16,1,.3,1),border-color .2s cubic-bezier(.16,1,.3,1),box-shadow .2s cubic-bezier(.16,1,.3,1),color .2s cubic-bezier(.16,1,.3,1),transform .15s;display:flex;position:fixed;top:24px;right:28px;box-shadow:0 4px 12px #00000040}.light-theme .page-close-btn[data-v-a2450027]{background:#00000040;border-color:#0000001a}.page-close-btn[data-v-a2450027]:hover{color:#fff;background:#ef4444e6;border-color:#ef4444e6;box-shadow:0 6px 18px #ef444466}.page-close-btn:hover .close-icon[data-v-a2450027]{transform:scale(1.15)rotate(90deg)}.page-close-btn[data-v-a2450027]:active{transform:scale(.92)}.page-close-btn .close-icon[data-v-a2450027]{width:18px;height:18px;transition:transform .25s cubic-bezier(.16,1,.3,1)}.nav-btn[data-v-a2450027]{z-index:9050;-webkit-backdrop-filter:blur(16px);backdrop-filter:blur(16px);color:#ffffffe6;cursor:pointer;background:#1e1e1ea6;border:1px solid #ffffff2e;border-radius:50%;justify-content:center;align-items:center;width:44px;height:44px;transition:all .2s cubic-bezier(.16,1,.3,1);display:flex;position:absolute;top:50%;transform:translateY(-50%);box-shadow:0 8px 24px #0000004d}.nav-btn.prev-btn[data-v-a2450027]{left:24px}.nav-btn.next-btn[data-v-a2450027]{right:24px}.nav-btn[data-v-a2450027]:hover{color:#fff;background:#ffffff38;border-color:#ffffff59;box-shadow:0 12px 32px #0006}.nav-btn[data-v-a2450027]:active{transform:translateY(-50%)scale(.95)}.nav-btn .nav-icon[data-v-a2450027]{width:22px;height:22px}.preview-toolbar[data-v-a2450027]{-webkit-backdrop-filter:blur(16px);backdrop-filter:blur(16px);z-index:9050;cursor:default;background:#1e1e1eb3;border:1px solid #ffffff26;border-radius:30px;align-items:center;gap:8px;padding:8px 16px;display:flex;position:absolute;bottom:24px;box-shadow:0 8px 32px #0000004d}.tool-btn[data-v-a2450027]{color:#fff;cursor:pointer;opacity:.85;background:0 0;border:none;border-radius:50%;justify-content:center;align-items:center;width:28px;height:28px;transition:all .2s;display:flex}.tool-btn[data-v-a2450027]:hover{opacity:1;background:#fff3}.tool-btn .tool-icon[data-v-a2450027]{width:16px;height:16px}.scale-text[data-v-a2450027]{color:#ffffffe6;text-align:center;min-width:40px;font-size:12px;font-weight:600}.counter-divider[data-v-a2450027]{background:#fff3;width:1px;height:14px;margin:0 2px}.image-counter[data-v-a2450027]{color:#ffffffd9;font-variant-numeric:tabular-nums;padding:0 4px;font-size:12px;font-weight:500}.image-container[data-v-a2450027]{cursor:default;justify-content:center;align-items:center;display:flex;position:relative}.preview-img[data-v-a2450027]{object-fit:contain;cursor:grab;-webkit-user-select:none;user-select:none;border-radius:8px;max-width:90vw;max-height:85vh;transition:transform .15s cubic-bezier(.16,1,.3,1);box-shadow:0 16px 48px #00000080}.preview-img.is-dragging[data-v-a2450027]{cursor:grabbing;transition:none}.preview-img[data-v-a2450027]:active{cursor:grabbing}.modal-fade-enter-active[data-v-a2450027],.modal-fade-leave-active[data-v-a2450027]{transition:opacity .25s}.modal-fade-enter-from[data-v-a2450027],.modal-fade-leave-to[data-v-a2450027]{opacity:0}.note-preview-overlay[data-v-a45284cc]{z-index:9000;background:var(--modal-overlay-bg);-webkit-user-select:text;user-select:text;justify-content:center;align-items:center;display:flex;position:fixed;inset:0}.note-preview-overlay.is-immersive[data-v-a45284cc]{background:0 0}.page-close-btn[data-v-a45284cc]{color:#fff;cursor:pointer;z-index:9050;-webkit-backdrop-filter:blur(8px);background:#ffffff26;border:1px solid #fff3;border-radius:50%;justify-content:center;align-items:center;width:36px;height:36px;transition:background-color .2s cubic-bezier(.16,1,.3,1),border-color .2s cubic-bezier(.16,1,.3,1),box-shadow .2s cubic-bezier(.16,1,.3,1),color .2s cubic-bezier(.16,1,.3,1),transform .15s;display:flex;position:fixed;top:24px;right:28px;box-shadow:0 4px 12px #00000040}.light-theme .page-close-btn[data-v-a45284cc]{background:#00000040;border-color:#0000001a}.page-close-btn[data-v-a45284cc]:hover{color:#fff;background:#ef4444e6;border-color:#ef4444e6;box-shadow:0 6px 18px #ef444466}.page-close-btn:hover .close-icon[data-v-a45284cc]{transform:scale(1.15)rotate(90deg)}.page-close-btn[data-v-a45284cc]:active{transform:scale(.92)}.page-close-btn .close-icon[data-v-a45284cc]{width:18px;height:18px;transition:transform .25s cubic-bezier(.16,1,.3,1)}.note-preview-content[data-v-a45284cc]{justify-content:center;align-items:center;display:flex}.note-preview-content.is-immersive[data-v-a45284cc]{width:100%;height:100%}.preview-modal-fade-enter-active[data-v-a45284cc],.preview-modal-fade-leave-active[data-v-a45284cc]{will-change:opacity;transition:opacity .3s cubic-bezier(.16,1,.3,1)}.preview-modal-fade-enter-active .note-preview-content[data-v-a45284cc],.preview-modal-fade-leave-active .note-preview-content[data-v-a45284cc]{will-change:transform, opacity;transition:transform .3s cubic-bezier(.34,1.56,.64,1),opacity .3s}.preview-modal-fade-enter-from[data-v-a45284cc],.preview-modal-fade-leave-to[data-v-a45284cc]{opacity:0}.preview-modal-fade-enter-from .note-preview-content[data-v-a45284cc],.preview-modal-fade-leave-to .note-preview-content[data-v-a45284cc]{opacity:0;transform:scale(.92)translateY(12px)}.app-wrapper{background-color:#181b24;background:linear-gradient(135deg, var(--bg-gradient-start,#1e222e) 0%, var(--bg-gradient-end,#141720) 100%);border:1px solid var(--panel-border,#ffffff14);box-sizing:border-box;border-radius:10px;flex-direction:column;width:100%;height:100%;display:flex;overflow:hidden}.app-wrapper .dashboard-layout{flex:1;min-height:0}html.detached-note-window,body.detached-note-window{width:100%;height:100%;margin:0;padding:0;overflow:hidden;background:0 0!important;border:none!important}#moment-notes-app-root{box-sizing:border-box;width:100%;height:100%;margin:0;padding:0;background:0 0!important}.detached-note-shell[data-v-a8a11bf6]{box-sizing:border-box;background:var(--detached-note-bg);border:1px solid var(--detached-note-border);width:100%;height:100%;color:var(--text-primary);box-shadow:none;border-radius:10px;transition:border-radius .15s,border-color .15s;position:relative;overflow:hidden}.detached-note-shell.is-maximized[data-v-a8a11bf6]{box-shadow:none;border:none;border-radius:0}.dark-theme .detached-note-shell[data-v-a8a11bf6],.detached-note-shell.dark-theme[data-v-a8a11bf6]{background:var(--detached-note-bg-dark);border-color:var(--detached-note-border-dark);box-shadow:none}.dark-theme .detached-note-shell.is-maximized[data-v-a8a11bf6],.detached-note-shell.dark-theme.is-maximized[data-v-a8a11bf6]{box-shadow:none;border:none}.window-drag-region[data-v-a8a11bf6]{z-index:120;-webkit-app-region:drag;height:42px;position:absolute;inset:0 124px auto 0}.window-controls[data-v-a8a11bf6]{z-index:130;-webkit-app-region:no-drag;align-items:center;gap:8px;display:flex;position:absolute;top:10px;right:12px}.window-control[data-v-a8a11bf6]{background:var(--detached-note-border);width:28px;height:28px;color:var(--detached-note-text);box-shadow:var(--shadow-sm);border-radius:50%;justify-content:center;align-items:center;padding:6px;transition:transform .2s cubic-bezier(.34,1.56,.64,1),background-color .2s,color .2s;display:flex}.dark-theme .window-control[data-v-a8a11bf6]{background:var(--detached-note-border-dark);color:var(--detached-note-text-dark)}.window-control.pin-btn[data-v-a8a11bf6]:hover{background:var(--detached-note-btn-hover-bg);color:var(--detached-note-btn-hover-color);transform:scale(1.1)rotate(15deg)}.dark-theme .window-control.pin-btn[data-v-a8a11bf6]:hover{background:var(--detached-note-btn-hover-bg-dark);color:var(--detached-note-btn-hover-color-dark)}.window-control.pin-btn.active[data-v-a8a11bf6]{background:var(--detached-note-btn-hover-bg);color:var(--detached-note-btn-hover-color);transform:scale(1.05)}.dark-theme .window-control.pin-btn.active[data-v-a8a11bf6]{background:var(--detached-note-btn-hover-bg-dark);color:var(--detached-note-btn-hover-color-dark)}.window-control.pin-btn.active .pin-icon[data-v-a8a11bf6]{fill:currentColor;transform:rotate(45deg)}.window-control.maximize-btn[data-v-a8a11bf6]:hover{background:var(--detached-note-btn-hover-bg);color:var(--detached-note-btn-hover-color);transform:scale(1.1)}.dark-theme .window-control.maximize-btn[data-v-a8a11bf6]:hover{background:var(--detached-note-btn-hover-bg-dark);color:var(--detached-note-btn-hover-color-dark)}.window-control.close-btn[data-v-a8a11bf6]:hover{background:var(--danger-hover-bg);color:var(--danger-color);transform:scale(1.1)}.window-control-icon[data-v-a8a11bf6]{width:14px;height:14px;transition:transform .2s cubic-bezier(.34,1.56,.64,1)}.note-window-content[data-v-a8a11bf6]{width:100%;height:100%}.note-window-content[data-v-a8a11bf6] .note-card.is-full-screen{width:100%;max-width:none;height:100%;max-height:none;padding-top:48px;box-shadow:none!important;background:0 0!important;border:0!important;border-radius:0!important}.note-window-content[data-v-a8a11bf6] .absolute-edit-btn{top:46px}.note-missing-state[data-v-a8a11bf6]{width:100%;height:100%;color:var(--text-secondary);flex-direction:column;justify-content:center;align-items:center;gap:16px;display:flex}.close-missing-btn[data-v-a8a11bf6]{background:var(--btn-bg);border:1px solid var(--btn-border);color:var(--text-primary);border-radius:7px;padding:7px 16px}.close-missing-btn[data-v-a8a11bf6]:hover{background:var(--btn-hover-bg);border-color:var(--btn-hover-border)}:root{--font-sans:\"Inter\", -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, Helvetica, Arial, sans-serif;--font-display:\"Outfit\", var(--font-sans);--bg-gradient-start:#f8fafc;--bg-gradient-end:#e2e8f0;--panel-bg:#ffffff73;--panel-border:#fff9;--sidebar-bg:#ffffff4d;--drawer-bg:#fffffff0;--dock-bg:#ffffffeb;--glass-blur-heavy:blur(28px) saturate(190%);--glass-blur-dock:blur(24px) saturate(180%);--text-primary:#0f172a;--text-secondary:#475569;--text-muted:#94a3b8;--accent-color:#6366f1;--accent-hover:#4f46e5;--accent-light:#6366f11a;--shadow-sm:0 3px 8px -2px #0f172a1f;--shadow-md:0 10px 25px -5px #0f172a14, 0 8px 16px -6px #0f172a14;--shadow-lg:0 20px 40px -15px #0f172a1f;--divider-color:#0f172a14;--drag-inside-bg:#6366f11f;--popover-bg:#fff;--popover-border:#0f172a14;--popover-shadow:var(--shadow-md);--input-bg:#fffc;--input-border:#0f172a14;--btn-bg:#fffc;--btn-border:#00000014;--btn-hover-bg:var(--accent-light);--btn-hover-border:#6366f133;--btn-hover-color:var(--accent-color);--item-hover-bg:#0f172a0a;--action-btn-hover-bg:#e1e1fc;--action-btn-danger-hover-bg:#fee2e2;--danger-color:#ef4444;--danger-hover-bg:#ef44441a;--danger-hover-border:#ef444440;--badge-bg:#0f172a0f;--text-on-accent:#fff;--accent-border-dashed:#6366f14d;--modal-overlay-bg:#0f172a59;--warning-bg:#f59e0b26;--warning-color:#f59e0b;--toast-success-bg:#dbfadbd9;--toast-success-border:#aff4af;--toast-success-text:#0a430a;--toast-info-bg:#d3effdd9;--toast-info-border:#a3ddfa;--toast-info-text:#063147;--toast-warning-bg:#fff5ccd9;--toast-warning-border:#ffe98f;--toast-warning-text:#473a06;--toast-error-bg:#fcd9e5d9;--toast-error-border:#f8afc7;--toast-error-text:#45081c}@media (prefers-color-scheme:dark){:root{--bg-gradient-start:#0f172a;--bg-gradient-end:#020617;--panel-bg:#0f172a73;--panel-border:#ffffff14;--sidebar-bg:#0f172a33;--drawer-bg:#121826f2;--dock-bg:#121826eb;--glass-blur-heavy:blur(28px) saturate(190%);--glass-blur-dock:blur(24px) saturate(180%);--text-primary:#f8fafc;--text-secondary:#cbd5e1;--text-muted:#64748b;--accent-color:#818cf8;--accent-hover:#6366f1;--accent-light:#818cf826;--shadow-sm:0 2px 8px -2px #0003;--shadow-md:0 10px 25px -5px #0000004d, 0 8px 16px -6px #0000004d;--shadow-lg:0 20px 40px -15px #0006;--divider-color:#f8fafc14;--drag-inside-bg:#818cf82e;--popover-bg:#1e293b;--popover-border:#ffffff14;--popover-shadow:var(--shadow-lg);--input-bg:#00000026;--input-border:#ffffff14;--btn-bg:#ffffff0d;--btn-border:#ffffff14;--btn-hover-bg:#ffffff1f;--btn-hover-border:#ffffff26;--btn-hover-color:var(--text-primary);--item-hover-bg:#ffffff14;--action-btn-hover-bg:#334155;--action-btn-danger-hover-bg:#2d1921;--danger-color:#f87171;--danger-hover-bg:#f8717126;--danger-hover-border:#f8717140;--badge-bg:#ffffff1a;--text-on-accent:#fff;--accent-border-dashed:#818cf859;--modal-overlay-bg:#00000080;--warning-bg:#f59e0b33;--warning-color:#fbbf24;--toast-success-bg:#1d351dcc;--toast-success-border:#325d32;--toast-success-text:#b8f9b8;--toast-info-bg:#1a313dcc;--toast-info-border:#2e576b;--toast-info-text:#b6e4fb;--toast-warning-bg:#40391ccc;--toast-warning-border:#6b5f2e;--toast-warning-text:#fff0b3;--toast-error-bg:#401c28cc;--toast-error-border:#6b2e42;--toast-error-text:#fbb6cd}}.dark-theme,:root[data-theme=dark],html[data-theme=dark]{--bg-gradient-start:#0f172a;--bg-gradient-end:#020617;--panel-bg:#0f172a73;--panel-border:#ffffff14;--sidebar-bg:#0f172a33;--drawer-bg:#121826f2;--dock-bg:#121826eb;--glass-blur-heavy:blur(28px) saturate(190%);--glass-blur-dock:blur(24px) saturate(180%);--text-primary:#f8fafc;--text-secondary:#cbd5e1;--text-muted:#64748b;--accent-color:#818cf8;--accent-hover:#6366f1;--accent-light:#818cf826;--shadow-sm:0 2px 8px -2px #0003;--shadow-md:0 10px 25px -5px #0000004d, 0 8px 16px -6px #0000004d;--shadow-lg:0 20px 40px -15px #0006;--divider-color:#f8fafc14;--drag-inside-bg:#818cf82e;--popover-bg:#1e293b;--popover-border:#ffffff14;--popover-shadow:var(--shadow-lg);--input-bg:#00000026;--input-border:#ffffff14;--btn-bg:#ffffff0d;--btn-border:#ffffff14;--btn-hover-bg:#ffffff1f;--btn-hover-border:#ffffff26;--btn-hover-color:var(--text-primary);--item-hover-bg:#ffffff14;--action-btn-hover-bg:#334155;--action-btn-danger-hover-bg:#2d1921;--danger-color:#f87171;--danger-hover-bg:#f8717126;--danger-hover-border:#f8717140;--badge-bg:#ffffff1a;--text-on-accent:#fff;--accent-border-dashed:#818cf859;--modal-overlay-bg:#00000080;--warning-bg:#f59e0b33;--warning-color:#fbbf24;--toast-success-bg:#1d351dcc;--toast-success-border:#325d32;--toast-success-text:#b8f9b8;--toast-info-bg:#1a313dcc;--toast-info-border:#2e576b;--toast-info-text:#b6e4fb;--toast-warning-bg:#40391ccc;--toast-warning-border:#6b5f2e;--toast-warning-text:#fff0b3;--toast-error-bg:#401c28cc;--toast-error-border:#6b2e42;--toast-error-text:#fbb6cd}.light-theme,:root[data-theme=light],html[data-theme=light]{--bg-gradient-start:#f8fafc;--bg-gradient-end:#e2e8f0;--panel-bg:#ffffff73;--panel-border:#fff9;--sidebar-bg:#ffffff4d;--drawer-bg:#fffffff0;--dock-bg:#ffffffeb;--glass-blur-heavy:blur(28px) saturate(190%);--glass-blur-dock:blur(24px) saturate(180%);--text-primary:#0f172a;--text-secondary:#475569;--text-muted:#94a3b8;--accent-color:#6366f1;--accent-hover:#4f46e5;--accent-light:#6366f11a;--shadow-sm:0 2px 8px -2px #0f172a0d;--shadow-md:0 10px 25px -5px #0f172a14, 0 8px 16px -6px #0f172a14;--shadow-lg:0 20px 40px -15px #0f172a1f;--divider-color:#0f172a14;--drag-inside-bg:#6366f11f;--popover-bg:#fff;--popover-border:#0f172a14;--popover-shadow:var(--shadow-md);--input-bg:#fffc;--input-border:#0f172a14;--btn-bg:#fffc;--btn-border:#00000014;--btn-hover-bg:var(--accent-light);--btn-hover-border:#6366f133;--btn-hover-color:var(--accent-color);--item-hover-bg:#0f172a0a;--action-btn-hover-bg:#e1e1fc;--action-btn-danger-hover-bg:#fee2e2;--danger-color:#ef4444;--danger-hover-bg:#ef44441a;--danger-hover-border:#ef444440;--badge-bg:#0f172a0f;--text-on-accent:#fff;--accent-border-dashed:#6366f14d;--modal-overlay-bg:#0f172a4d;--warning-bg:#f59e0b26;--warning-color:#f59e0b;--toast-success-bg:#dbfadbd9;--toast-success-border:#aff4af;--toast-success-text:#0a430a;--toast-info-bg:#d3effdd9;--toast-info-border:#a3ddfa;--toast-info-text:#063147;--toast-warning-bg:#fff5ccd9;--toast-warning-border:#ffe98f;--toast-warning-text:#473a06;--toast-error-bg:#fcd9e5d9;--toast-error-border:#f8afc7;--toast-error-text:#45081c}*{box-sizing:border-box;margin:0;padding:0}:focus-visible{outline:2px solid var(--accent-color);outline-offset:2px}body,html{width:100vw;height:100vh;font-family:var(--font-sans);color:var(--text-primary);-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale;overflow:hidden;background:0 0!important}#app,#moment-notes-app-root{width:100%;height:100%;margin:0;padding:0;overflow:hidden;background:0 0!important}::-webkit-scrollbar{width:6px;height:6px;background:0 0!important}::-webkit-scrollbar-track{box-shadow:none!important;background:0 0!important;border:none!important}::-webkit-scrollbar-track-piece{box-shadow:none!important;background:0 0!important;border:none!important}::-webkit-scrollbar-corner{box-shadow:none!important;background:0 0!important;border:none!important}::-webkit-scrollbar-thumb{background:#0f172a14;background:color-mix(in srgb, var(--text-primary) 8%, transparent);border-radius:4px}::-webkit-scrollbar-thumb:hover{background:#0f172a2e;background:color-mix(in srgb, var(--text-primary) 18%, transparent)}.dark-theme ::-webkit-scrollbar-thumb{background:#ffffff14}.dark-theme ::-webkit-scrollbar-thumb:hover{background:#ffffff2e}@media (prefers-color-scheme:dark){::-webkit-scrollbar-thumb{background:#ffffff14}::-webkit-scrollbar-thumb:hover{background:#ffffff2e}}.app-wrapper{background:linear-gradient(135deg, var(--bg-gradient-start) 0%, #ebf0f5 100%)}.app-wrapper.dark-theme,.dark-theme .app-wrapper,.app-wrapper .dark-theme{background:linear-gradient(135deg, var(--bg-gradient-start) 0%, #070e22 100%)}.app-wrapper.light-theme,.light-theme .app-wrapper,.app-wrapper .light-theme{background:linear-gradient(135deg, var(--bg-gradient-start) 0%, #ebf0f5 100%)}@media (prefers-color-scheme:dark){.app-wrapper{background:linear-gradient(135deg, var(--bg-gradient-start) 0%, #070e22 100%)}}.app-wrapper .note-grid-container,.app-wrapper .sidebar-menu,.app-wrapper .note-card-body,.app-wrapper .tag-editor-tags,.app-wrapper .tag-list-scroll,.app-wrapper .card-body-content,.app-wrapper .content-textarea{scroll-behavior:smooth;-webkit-overflow-scrolling:touch;overflow-y:overlay!important}.app-wrapper ::-webkit-scrollbar{width:10px;height:10px;background:0 0!important}.app-wrapper ::-webkit-scrollbar-track{box-shadow:none!important;background:0 0!important;border:none!important}.app-wrapper ::-webkit-scrollbar-track-piece{box-shadow:none!important;background:0 0!important;border:none!important}.app-wrapper ::-webkit-scrollbar-corner{box-shadow:none!important;background:0 0!important;border:none!important}.app-wrapper ::-webkit-scrollbar-thumb{background:#0f172a14 padding-box padding-box;border:2px solid #0000;border-radius:6px}.app-wrapper ::-webkit-scrollbar-thumb:hover{background-color:#0f172a2e!important}.app-wrapper.dark-theme ::-webkit-scrollbar-thumb{background:#ffffff14 padding-box padding-box}.dark-theme .app-wrapper ::-webkit-scrollbar-thumb{background:#ffffff14 padding-box padding-box}.app-wrapper .dark-theme::-webkit-scrollbar-thumb{background:#ffffff14 padding-box padding-box}.app-wrapper.dark-theme ::-webkit-scrollbar-thumb:hover{background-color:#ffffff2e!important}.dark-theme .app-wrapper ::-webkit-scrollbar-thumb:hover{background-color:#ffffff2e!important}.app-wrapper .dark-theme::-webkit-scrollbar-thumb:hover{background-color:#ffffff2e!important}button{cursor:pointer;background:0 0;border:none;font-family:inherit;transition:transform .2s cubic-bezier(.4,0,.2,1)}button:active{transform:scale(.95)}input,textarea{resize:none;border:1px solid #0000;outline:none;font-family:inherit;transition:background-color .2s cubic-bezier(.4,0,.2,1),border-color .2s cubic-bezier(.4,0,.2,1),box-shadow .2s cubic-bezier(.4,0,.2,1)}.toast-enter-active,.toast-leave-active{transition:opacity .3s cubic-bezier(.16,1,.3,1),transform .3s cubic-bezier(.16,1,.3,1)}.toast-enter-from{opacity:0;transform:translateY(30px)scale(.9)}.toast-leave-to{opacity:0;transform:translateY(-20px)scale(.95)}.global-tooltip{z-index:99999;color:var(--text-primary);background:var(--popover-bg);border:1px solid var(--panel-border);box-shadow:var(--shadow-md);pointer-events:none;opacity:0;visibility:hidden;white-space:pre-line;word-break:break-all;overflow-wrap:break-word;border-radius:6px;max-width:340px;padding:6px 12px;font-size:11px;font-weight:500;line-height:1.4;transition:opacity .15s cubic-bezier(.4,0,.2,1),transform .15s cubic-bezier(.4,0,.2,1),visibility .15s cubic-bezier(.4,0,.2,1);position:fixed;top:-9999px;left:-9999px;transform:translateY(4px)scale(.95)}.global-tooltip.show{opacity:1;visibility:visible;transform:translateY(0)scale(1)}.dark-theme .global-tooltip{color:#f1f5f9;background:#0a0a0ce0;border-color:#ffffff0d;box-shadow:0 10px 30px -10px #000000b3}@media (prefers-color-scheme:dark){.global-tooltip{color:#f1f5f9;background:#0a0a0ce0;border-color:#ffffff0d;box-shadow:0 10px 30px -10px #000000b3}.light-theme .global-tooltip{background:var(--popover-bg);border-color:var(--panel-border);color:var(--text-primary);box-shadow:var(--shadow-md)}}\n/*$vite$:1*/";
        doc.head.appendChild(s);
      }
    };
  }
})();
//#region node_modules/@vue/shared/dist/shared.esm-bundler.js
// @__NO_SIDE_EFFECTS__
function e(e) {
	let t = /* @__PURE__ */ Object.create(null);
	for (let n of e.split(",")) t[n] = 1;
	return (e) => e in t;
}
var t = {}, n = [], r = () => {}, i = () => !1, a = (e) => e.charCodeAt(0) === 111 && e.charCodeAt(1) === 110 && (e.charCodeAt(2) > 122 || e.charCodeAt(2) < 97), o = (e) => e.startsWith("onUpdate:"), s = Object.assign, c = (e, t) => {
	let n = e.indexOf(t);
	n > -1 && e.splice(n, 1);
}, l = Object.prototype.hasOwnProperty, u = (e, t) => l.call(e, t), d = Array.isArray, f = (e) => x(e) === "[object Map]", p = (e) => x(e) === "[object Set]", m = (e) => x(e) === "[object Date]", h = (e) => typeof e == "function", g = (e) => typeof e == "string", _ = (e) => typeof e == "symbol", v = (e) => typeof e == "object" && !!e, y = (e) => (v(e) || h(e)) && h(e.then) && h(e.catch), b = Object.prototype.toString, x = (e) => b.call(e), S = (e) => x(e).slice(8, -1), C = (e) => x(e) === "[object Object]", w = (e) => g(e) && e !== "NaN" && e[0] !== "-" && "" + parseInt(e, 10) === e, ee = /* @__PURE__ */ e(",key,ref,ref_for,ref_key,onVnodeBeforeMount,onVnodeMounted,onVnodeBeforeUpdate,onVnodeUpdated,onVnodeBeforeUnmount,onVnodeUnmounted"), te = (e) => {
	let t = /* @__PURE__ */ Object.create(null);
	return ((n) => t[n] || (t[n] = e(n)));
}, ne = /-\w/g, T = te((e) => e.replace(ne, (e) => e.slice(1).toUpperCase())), re = /\B([A-Z])/g, ie = te((e) => e.replace(re, "-$1").toLowerCase()), ae = te((e) => e.charAt(0).toUpperCase() + e.slice(1)), oe = te((e) => e ? `on${ae(e)}` : ""), se = (e, t) => !Object.is(e, t), ce = (e, ...t) => {
	for (let n = 0; n < e.length; n++) e[n](...t);
}, le = (e, t, n, r = !1) => {
	Object.defineProperty(e, t, {
		configurable: !0,
		enumerable: !1,
		writable: r,
		value: n
	});
}, E = (e) => {
	let t = parseFloat(e);
	return isNaN(t) ? e : t;
}, ue = (e) => {
	let t = g(e) ? Number(e) : NaN;
	return isNaN(t) ? e : t;
}, de, fe = () => de ||= typeof globalThis < "u" ? globalThis : typeof self < "u" ? self : typeof window < "u" ? window : typeof global < "u" ? global : {};
function D(e) {
	if (d(e)) {
		let t = {};
		for (let n = 0; n < e.length; n++) {
			let r = e[n], i = g(r) ? ge(r) : D(r);
			if (i) for (let e in i) t[e] = i[e];
		}
		return t;
	} else if (g(e) || v(e)) return e;
}
var pe = /;(?![^(]*\))/g, me = /:([^]+)/, he = /\/\*[^]*?\*\//g;
function ge(e) {
	let t = {};
	return e.replace(he, "").split(pe).forEach((e) => {
		if (e) {
			let n = e.split(me);
			n.length > 1 && (t[n[0].trim()] = n[1].trim());
		}
	}), t;
}
function O(e) {
	let t = "";
	if (g(e)) t = e;
	else if (d(e)) for (let n = 0; n < e.length; n++) {
		let r = O(e[n]);
		r && (t += r + " ");
	}
	else if (v(e)) for (let n in e) e[n] && (t += n + " ");
	return t.trim();
}
var _e = "itemscope,allowfullscreen,formnovalidate,ismap,nomodule,novalidate,readonly", ve = /* @__PURE__ */ e(_e);
_e + "";
function k(e) {
	return !!e || e === "";
}
function ye(e, t) {
	if (e.length !== t.length) return !1;
	let n = !0;
	for (let r = 0; n && r < e.length; r++) n = A(e[r], t[r]);
	return n;
}
function A(e, t) {
	if (e === t) return !0;
	let n = m(e), r = m(t);
	if (n || r) return n && r ? e.getTime() === t.getTime() : !1;
	if (n = _(e), r = _(t), n || r) return e === t;
	if (n = d(e), r = d(t), n || r) return n && r ? ye(e, t) : !1;
	if (n = v(e), r = v(t), n || r) {
		if (!n || !r || Object.keys(e).length !== Object.keys(t).length) return !1;
		for (let n in e) {
			let r = e.hasOwnProperty(n), i = t.hasOwnProperty(n);
			if (r && !i || !r && i || !A(e[n], t[n])) return !1;
		}
	}
	return String(e) === String(t);
}
function be(e, t) {
	return e.findIndex((e) => A(e, t));
}
var xe = (e) => !!(e && e.__v_isRef === !0), j = (e) => g(e) ? e : e == null ? "" : d(e) || v(e) && (e.toString === b || !h(e.toString)) ? xe(e) ? j(e.value) : JSON.stringify(e, Se, 2) : String(e), Se = (e, t) => xe(t) ? Se(e, t.value) : f(t) ? { [`Map(${t.size})`]: [...t.entries()].reduce((e, [t, n], r) => (e[Ce(t, r) + " =>"] = n, e), {}) } : p(t) ? { [`Set(${t.size})`]: [...t.values()].map((e) => Ce(e)) } : _(t) ? Ce(t) : v(t) && !d(t) && !C(t) ? String(t) : t, Ce = (e, t = "") => _(e) ? `Symbol(${e.description ?? t})` : e, we, Te = class {
	constructor(e = !1) {
		this.detached = e, this._active = !0, this._on = 0, this.effects = [], this.cleanups = [], this._isPaused = !1, this._warnOnRun = !0, this.__v_skip = !0, !e && we && (we.active ? (this.parent = we, this.index = (we.scopes ||= []).push(this) - 1) : (this._active = !1, this._warnOnRun = !1));
	}
	get active() {
		return this._active;
	}
	pause() {
		if (this._active) {
			this._isPaused = !0;
			let e, t;
			if (this.scopes) for (e = 0, t = this.scopes.length; e < t; e++) this.scopes[e].pause();
			for (e = 0, t = this.effects.length; e < t; e++) this.effects[e].pause();
		}
	}
	resume() {
		if (this._active && this._isPaused) {
			this._isPaused = !1;
			let e, t;
			if (this.scopes) for (e = 0, t = this.scopes.length; e < t; e++) this.scopes[e].resume();
			for (e = 0, t = this.effects.length; e < t; e++) this.effects[e].resume();
		}
	}
	run(e) {
		if (this._active) {
			let t = we;
			try {
				return we = this, e();
			} finally {
				we = t;
			}
		}
	}
	on() {
		++this._on === 1 && (this.prevScope = we, we = this);
	}
	off() {
		if (this._on > 0 && --this._on === 0) {
			if (we === this) we = this.prevScope;
			else {
				let e = we;
				for (; e;) {
					if (e.prevScope === this) {
						e.prevScope = this.prevScope;
						break;
					}
					e = e.prevScope;
				}
			}
			this.prevScope = void 0;
		}
	}
	stop(e) {
		if (this._active) {
			this._active = !1;
			let t, n;
			for (t = 0, n = this.effects.length; t < n; t++) this.effects[t].stop();
			for (this.effects.length = 0, t = 0, n = this.cleanups.length; t < n; t++) this.cleanups[t]();
			if (this.cleanups.length = 0, this.scopes) {
				for (t = 0, n = this.scopes.length; t < n; t++) this.scopes[t].stop(!0);
				this.scopes.length = 0;
			}
			if (!this.detached && this.parent && !e) {
				let e = this.parent.scopes.pop();
				e && e !== this && (this.parent.scopes[this.index] = e, e.index = this.index);
			}
			this.parent = void 0;
		}
	}
};
function Ee(e) {
	return new Te(e);
}
function De() {
	return we;
}
function Oe(e, t = !1) {
	we && we.cleanups.push(e);
}
var M, ke = /* @__PURE__ */ new WeakSet(), Ae = class {
	constructor(e) {
		this.fn = e, this.deps = void 0, this.depsTail = void 0, this.flags = 5, this.next = void 0, this.cleanup = void 0, this.scheduler = void 0, we && (we.active ? we.effects.push(this) : this.flags &= -2);
	}
	pause() {
		this.flags |= 64;
	}
	resume() {
		this.flags & 64 && (this.flags &= -65, ke.has(this) && (ke.delete(this), this.trigger()));
	}
	notify() {
		this.flags & 2 && !(this.flags & 32) || this.flags & 8 || Pe(this);
	}
	run() {
		if (!(this.flags & 1)) return this.fn();
		this.flags |= 2, qe(this), Le(this);
		let e = M, t = Ue;
		M = this, Ue = !0;
		try {
			return this.fn();
		} finally {
			Re(this), M = e, Ue = t, this.flags &= -3;
		}
	}
	stop() {
		if (this.flags & 1) {
			for (let e = this.deps; e; e = e.nextDep) Ve(e);
			this.deps = this.depsTail = void 0, qe(this), this.onStop && this.onStop(), this.flags &= -2;
		}
	}
	trigger() {
		this.flags & 64 ? ke.add(this) : this.scheduler ? this.scheduler() : this.runIfDirty();
	}
	runIfDirty() {
		ze(this) && this.run();
	}
	get dirty() {
		return ze(this);
	}
}, je = 0, Me, Ne;
function Pe(e, t = !1) {
	if (e.flags |= 8, t) {
		e.next = Ne, Ne = e;
		return;
	}
	e.next = Me, Me = e;
}
function Fe() {
	je++;
}
function Ie() {
	if (--je > 0) return;
	if (Ne) {
		let e = Ne;
		for (Ne = void 0; e;) {
			let t = e.next;
			e.next = void 0, e.flags &= -9, e = t;
		}
	}
	let e;
	for (; Me;) {
		let t = Me;
		for (Me = void 0; t;) {
			let n = t.next;
			if (t.next = void 0, t.flags &= -9, t.flags & 1) try {
				t.trigger();
			} catch (t) {
				e ||= t;
			}
			t = n;
		}
	}
	if (e) throw e;
}
function Le(e) {
	for (let t = e.deps; t; t = t.nextDep) t.version = -1, t.prevActiveLink = t.dep.activeLink, t.dep.activeLink = t;
}
function Re(e) {
	let t, n = e.depsTail, r = n;
	for (; r;) {
		let e = r.prevDep;
		r.version === -1 ? (r === n && (n = e), Ve(r), He(r)) : t = r, r.dep.activeLink = r.prevActiveLink, r.prevActiveLink = void 0, r = e;
	}
	e.deps = t, e.depsTail = n;
}
function ze(e) {
	for (let t = e.deps; t; t = t.nextDep) if (t.dep.version !== t.version || t.dep.computed && (Be(t.dep.computed) || t.dep.version !== t.version)) return !0;
	return !!e._dirty;
}
function Be(e) {
	if (e.flags & 4 && !(e.flags & 16) || (e.flags &= -17, e.globalVersion === Je) || (e.globalVersion = Je, !e.isSSR && e.flags & 128 && (!e.deps && !e._dirty || !ze(e)))) return;
	e.flags |= 2;
	let t = e.dep, n = M, r = Ue;
	M = e, Ue = !0;
	try {
		Le(e);
		let n = e.fn(e._value);
		(t.version === 0 || se(n, e._value)) && (e.flags |= 128, e._value = n, t.version++);
	} catch (e) {
		throw t.version++, e;
	} finally {
		M = n, Ue = r, Re(e), e.flags &= -3;
	}
}
function Ve(e, t = !1) {
	let { dep: n, prevSub: r, nextSub: i } = e;
	if (r && (r.nextSub = i, e.prevSub = void 0), i && (i.prevSub = r, e.nextSub = void 0), n.subs === e && (n.subs = r, !r && n.computed)) {
		n.computed.flags &= -5;
		for (let e = n.computed.deps; e; e = e.nextDep) Ve(e, !0);
	}
	!t && !--n.sc && n.map && n.map.delete(n.key);
}
function He(e) {
	let { prevDep: t, nextDep: n } = e;
	t && (t.nextDep = n, e.prevDep = void 0), n && (n.prevDep = t, e.nextDep = void 0);
}
var Ue = !0, We = [];
function Ge() {
	We.push(Ue), Ue = !1;
}
function Ke() {
	let e = We.pop();
	Ue = e === void 0 ? !0 : e;
}
function qe(e) {
	let { cleanup: t } = e;
	if (e.cleanup = void 0, t) {
		let e = M;
		M = void 0;
		try {
			t();
		} finally {
			M = e;
		}
	}
}
var Je = 0, Ye = class {
	constructor(e, t) {
		this.sub = e, this.dep = t, this.version = t.version, this.nextDep = this.prevDep = this.nextSub = this.prevSub = this.prevActiveLink = void 0;
	}
}, Xe = class {
	constructor(e) {
		this.computed = e, this.version = 0, this.activeLink = void 0, this.subs = void 0, this.map = void 0, this.key = void 0, this.sc = 0, this.__v_skip = !0;
	}
	track(e) {
		if (!M || !Ue || M === this.computed) return;
		let t = this.activeLink;
		if (t === void 0 || t.sub !== M) t = this.activeLink = new Ye(M, this), M.deps ? (t.prevDep = M.depsTail, M.depsTail.nextDep = t, M.depsTail = t) : M.deps = M.depsTail = t, Ze(t);
		else if (t.version === -1 && (t.version = this.version, t.nextDep)) {
			let e = t.nextDep;
			e.prevDep = t.prevDep, t.prevDep && (t.prevDep.nextDep = e), t.prevDep = M.depsTail, t.nextDep = void 0, M.depsTail.nextDep = t, M.depsTail = t, M.deps === t && (M.deps = e);
		}
		return t;
	}
	trigger(e) {
		this.version++, Je++, this.notify(e);
	}
	notify(e) {
		Fe();
		try {
			for (let e = this.subs; e; e = e.prevSub) e.sub.notify() && e.sub.dep.notify();
		} finally {
			Ie();
		}
	}
};
function Ze(e) {
	if (e.dep.sc++, e.sub.flags & 4) {
		let t = e.dep.computed;
		if (t && !e.dep.subs) {
			t.flags |= 20;
			for (let e = t.deps; e; e = e.nextDep) Ze(e);
		}
		let n = e.dep.subs;
		n !== e && (e.prevSub = n, n && (n.nextSub = e)), e.dep.subs = e;
	}
}
var Qe = /* @__PURE__ */ new WeakMap(), $e = /* @__PURE__ */ Symbol(""), et = /* @__PURE__ */ Symbol(""), tt = /* @__PURE__ */ Symbol("");
function nt(e, t, n) {
	if (Ue && M) {
		let t = Qe.get(e);
		t || Qe.set(e, t = /* @__PURE__ */ new Map());
		let r = t.get(n);
		r || (t.set(n, r = new Xe()), r.map = t, r.key = n), r.track();
	}
}
function rt(e, t, n, r, i, a) {
	let o = Qe.get(e);
	if (!o) {
		Je++;
		return;
	}
	let s = (e) => {
		e && e.trigger();
	};
	if (Fe(), t === "clear") o.forEach(s);
	else {
		let i = d(e), a = i && w(n);
		if (i && n === "length") {
			let e = Number(r);
			o.forEach((t, n) => {
				(n === "length" || n === tt || !_(n) && n >= e) && s(t);
			});
		} else switch ((n !== void 0 || o.has(void 0)) && s(o.get(n)), a && s(o.get(tt)), t) {
			case "add":
				i ? a && s(o.get("length")) : (s(o.get($e)), f(e) && s(o.get(et)));
				break;
			case "delete":
				i || (s(o.get($e)), f(e) && s(o.get(et)));
				break;
			case "set":
				f(e) && s(o.get($e));
				break;
		}
	}
	Ie();
}
function it(e, t) {
	let n = Qe.get(e);
	return n && n.get(t);
}
function at(e) {
	let t = /* @__PURE__ */ P(e);
	return t === e ? t : (nt(t, "iterate", tt), /* @__PURE__ */ Ut(e) ? t : t.map(Kt));
}
function ot(e) {
	return nt(e = /* @__PURE__ */ P(e), "iterate", tt), e;
}
function N(e, t) {
	return /* @__PURE__ */ Ht(e) ? qt(/* @__PURE__ */ Vt(e) ? Kt(t) : t) : Kt(t);
}
var st = {
	__proto__: null,
	[Symbol.iterator]() {
		return ct(this, Symbol.iterator, (e) => N(this, e));
	},
	concat(...e) {
		return at(this).concat(...e.map((e) => d(e) ? at(e) : e));
	},
	entries() {
		return ct(this, "entries", (e) => (e[1] = N(this, e[1]), e));
	},
	every(e, t) {
		return ut(this, "every", e, t, void 0, arguments);
	},
	filter(e, t) {
		return ut(this, "filter", e, t, (e) => e.map((e) => N(this, e)), arguments);
	},
	find(e, t) {
		return ut(this, "find", e, t, (e) => N(this, e), arguments);
	},
	findIndex(e, t) {
		return ut(this, "findIndex", e, t, void 0, arguments);
	},
	findLast(e, t) {
		return ut(this, "findLast", e, t, (e) => N(this, e), arguments);
	},
	findLastIndex(e, t) {
		return ut(this, "findLastIndex", e, t, void 0, arguments);
	},
	forEach(e, t) {
		return ut(this, "forEach", e, t, void 0, arguments);
	},
	includes(...e) {
		return ft(this, "includes", e);
	},
	indexOf(...e) {
		return ft(this, "indexOf", e);
	},
	join(e) {
		return at(this).join(e);
	},
	lastIndexOf(...e) {
		return ft(this, "lastIndexOf", e);
	},
	map(e, t) {
		return ut(this, "map", e, t, void 0, arguments);
	},
	pop() {
		return pt(this, "pop");
	},
	push(...e) {
		return pt(this, "push", e);
	},
	reduce(e, ...t) {
		return dt(this, "reduce", e, t);
	},
	reduceRight(e, ...t) {
		return dt(this, "reduceRight", e, t);
	},
	shift() {
		return pt(this, "shift");
	},
	some(e, t) {
		return ut(this, "some", e, t, void 0, arguments);
	},
	splice(...e) {
		return pt(this, "splice", e);
	},
	toReversed() {
		return at(this).toReversed();
	},
	toSorted(e) {
		return at(this).toSorted(e);
	},
	toSpliced(...e) {
		return at(this).toSpliced(...e);
	},
	unshift(...e) {
		return pt(this, "unshift", e);
	},
	values() {
		return ct(this, "values", (e) => N(this, e));
	}
};
function ct(e, t, n) {
	let r = ot(e), i = r[t]();
	return r !== e && !/* @__PURE__ */ Ut(e) && (i._next = i.next, i.next = () => {
		let e = i._next();
		return e.done || (e.value = n(e.value)), e;
	}), i;
}
var lt = Array.prototype;
function ut(e, t, n, r, i, a) {
	let o = ot(e), s = o !== e && !/* @__PURE__ */ Ut(e), c = o[t];
	if (c !== lt[t]) {
		let t = c.apply(e, a);
		return s ? Kt(t) : t;
	}
	let l = n;
	o !== e && (s ? l = function(t, r) {
		return n.call(this, N(e, t), r, e);
	} : n.length > 2 && (l = function(t, r) {
		return n.call(this, t, r, e);
	}));
	let u = c.call(o, l, r);
	return s && i ? i(u) : u;
}
function dt(e, t, n, r) {
	let i = ot(e), a = i !== e && !/* @__PURE__ */ Ut(e), o = n, s = !1;
	i !== e && (a ? (s = r.length === 0, o = function(t, r, i) {
		return s && (s = !1, t = N(e, t)), n.call(this, t, N(e, r), i, e);
	}) : n.length > 3 && (o = function(t, r, i) {
		return n.call(this, t, r, i, e);
	}));
	let c = i[t](o, ...r);
	return s ? N(e, c) : c;
}
function ft(e, t, n) {
	let r = /* @__PURE__ */ P(e);
	nt(r, "iterate", tt);
	let i = r[t](...n);
	return (i === -1 || i === !1) && /* @__PURE__ */ Wt(n[0]) ? (n[0] = /* @__PURE__ */ P(n[0]), r[t](...n)) : i;
}
function pt(e, t, n = []) {
	Ge(), Fe();
	let r = (/* @__PURE__ */ P(e))[t].apply(e, n);
	return Ie(), Ke(), r;
}
var mt = /* @__PURE__ */ e("__proto__,__v_isRef,__isVue"), ht = new Set(/* @__PURE__ */ Object.getOwnPropertyNames(Symbol).filter((e) => e !== "arguments" && e !== "caller").map((e) => Symbol[e]).filter(_));
function gt(e) {
	_(e) || (e = String(e));
	let t = /* @__PURE__ */ P(this);
	return nt(t, "has", e), t.hasOwnProperty(e);
}
var _t = class {
	constructor(e = !1, t = !1) {
		this._isReadonly = e, this._isShallow = t;
	}
	get(e, t, n) {
		if (t === "__v_skip") return e.__v_skip;
		let r = this._isReadonly, i = this._isShallow;
		if (t === "__v_isReactive") return !r;
		if (t === "__v_isReadonly") return r;
		if (t === "__v_isShallow") return i;
		if (t === "__v_raw") return n === (r ? i ? Ft : Pt : i ? Nt : Mt).get(e) || Object.getPrototypeOf(e) === Object.getPrototypeOf(n) ? e : void 0;
		let a = d(e);
		if (!r) {
			let e;
			if (a && (e = st[t])) return e;
			if (t === "hasOwnProperty") return gt;
		}
		let o = Reflect.get(e, t, /* @__PURE__ */ Jt(e) ? e : n);
		if ((_(t) ? ht.has(t) : mt(t)) || (r || nt(e, "get", t), i)) return o;
		if (/* @__PURE__ */ Jt(o)) {
			let e = a && w(t) ? o : o.value;
			return r && v(e) ? /* @__PURE__ */ zt(e) : e;
		}
		return v(o) ? r ? /* @__PURE__ */ zt(o) : /* @__PURE__ */ Lt(o) : o;
	}
}, vt = class extends _t {
	constructor(e = !1) {
		super(!1, e);
	}
	set(e, t, n, r) {
		let i = e[t], a = d(e) && w(t);
		if (!this._isShallow) {
			let e = /* @__PURE__ */ Ht(i);
			if (!/* @__PURE__ */ Ut(n) && !/* @__PURE__ */ Ht(n) && (i = /* @__PURE__ */ P(i), n = /* @__PURE__ */ P(n)), !a && /* @__PURE__ */ Jt(i) && !/* @__PURE__ */ Jt(n)) return e || (i.value = n), !0;
		}
		let o = a ? Number(t) < e.length : u(e, t), s = Reflect.set(e, t, n, /* @__PURE__ */ Jt(e) ? e : r);
		return e === /* @__PURE__ */ P(r) && (o ? se(n, i) && rt(e, "set", t, n, i) : rt(e, "add", t, n)), s;
	}
	deleteProperty(e, t) {
		let n = u(e, t), r = e[t], i = Reflect.deleteProperty(e, t);
		return i && n && rt(e, "delete", t, void 0, r), i;
	}
	has(e, t) {
		let n = Reflect.has(e, t);
		return (!_(t) || !ht.has(t)) && nt(e, "has", t), n;
	}
	ownKeys(e) {
		return nt(e, "iterate", d(e) ? "length" : $e), Reflect.ownKeys(e);
	}
}, yt = class extends _t {
	constructor(e = !1) {
		super(!0, e);
	}
	set(e, t) {
		return !0;
	}
	deleteProperty(e, t) {
		return !0;
	}
}, bt = /* @__PURE__ */ new vt(), xt = /* @__PURE__ */ new yt(), St = /* @__PURE__ */ new vt(!0), Ct = (e) => e, wt = (e) => Reflect.getPrototypeOf(e);
function Tt(e, t, n) {
	return function(...r) {
		let i = this.__v_raw, a = /* @__PURE__ */ P(i), o = f(a), c = e === "entries" || e === Symbol.iterator && o, l = e === "keys" && o, u = i[e](...r), d = n ? Ct : t ? qt : Kt;
		return !t && nt(a, "iterate", l ? et : $e), s(Object.create(u), { next() {
			let { value: e, done: t } = u.next();
			return t ? {
				value: e,
				done: t
			} : {
				value: c ? [d(e[0]), d(e[1])] : d(e),
				done: t
			};
		} });
	};
}
function Et(e) {
	return function(...t) {
		return e === "delete" ? !1 : e === "clear" ? void 0 : this;
	};
}
function Dt(e, t) {
	let n = {
		get(n) {
			let r = this.__v_raw, i = /* @__PURE__ */ P(r), a = /* @__PURE__ */ P(n);
			e || (se(n, a) && nt(i, "get", n), nt(i, "get", a));
			let { has: o } = wt(i), s = t ? Ct : e ? qt : Kt;
			if (o.call(i, n)) return s(r.get(n));
			if (o.call(i, a)) return s(r.get(a));
			r !== i && r.get(n);
		},
		get size() {
			let t = this.__v_raw;
			return !e && nt(/* @__PURE__ */ P(t), "iterate", $e), t.size;
		},
		has(t) {
			let n = this.__v_raw, r = /* @__PURE__ */ P(n), i = /* @__PURE__ */ P(t);
			return e || (se(t, i) && nt(r, "has", t), nt(r, "has", i)), t === i ? n.has(t) : n.has(t) || n.has(i);
		},
		forEach(n, r) {
			let i = this, a = i.__v_raw, o = /* @__PURE__ */ P(a), s = t ? Ct : e ? qt : Kt;
			return !e && nt(o, "iterate", $e), a.forEach((e, t) => n.call(r, s(e), s(t), i));
		}
	};
	return s(n, e ? {
		add: Et("add"),
		set: Et("set"),
		delete: Et("delete"),
		clear: Et("clear")
	} : {
		add(e) {
			let n = /* @__PURE__ */ P(this), r = wt(n), i = /* @__PURE__ */ P(e), a = !t && !/* @__PURE__ */ Ut(e) && !/* @__PURE__ */ Ht(e) ? i : e;
			return r.has.call(n, a) || se(e, a) && r.has.call(n, e) || se(i, a) && r.has.call(n, i) || (n.add(a), rt(n, "add", a, a)), this;
		},
		set(e, n) {
			!t && !/* @__PURE__ */ Ut(n) && !/* @__PURE__ */ Ht(n) && (n = /* @__PURE__ */ P(n));
			let r = /* @__PURE__ */ P(this), { has: i, get: a } = wt(r), o = i.call(r, e);
			o ||= (e = /* @__PURE__ */ P(e), i.call(r, e));
			let s = a.call(r, e);
			return r.set(e, n), o ? se(n, s) && rt(r, "set", e, n, s) : rt(r, "add", e, n), this;
		},
		delete(e) {
			let t = /* @__PURE__ */ P(this), { has: n, get: r } = wt(t), i = n.call(t, e);
			i ||= (e = /* @__PURE__ */ P(e), n.call(t, e));
			let a = r ? r.call(t, e) : void 0, o = t.delete(e);
			return i && rt(t, "delete", e, void 0, a), o;
		},
		clear() {
			let e = /* @__PURE__ */ P(this), t = e.size !== 0, n = e.clear();
			return t && rt(e, "clear", void 0, void 0, void 0), n;
		}
	}), [
		"keys",
		"values",
		"entries",
		Symbol.iterator
	].forEach((r) => {
		n[r] = Tt(r, e, t);
	}), n;
}
function Ot(e, t) {
	let n = Dt(e, t);
	return (t, r, i) => r === "__v_isReactive" ? !e : r === "__v_isReadonly" ? e : r === "__v_raw" ? t : Reflect.get(u(n, r) && r in t ? n : t, r, i);
}
var kt = { get: /* @__PURE__ */ Ot(!1, !1) }, At = { get: /* @__PURE__ */ Ot(!1, !0) }, jt = { get: /* @__PURE__ */ Ot(!0, !1) }, Mt = /* @__PURE__ */ new WeakMap(), Nt = /* @__PURE__ */ new WeakMap(), Pt = /* @__PURE__ */ new WeakMap(), Ft = /* @__PURE__ */ new WeakMap();
function It(e) {
	switch (e) {
		case "Object":
		case "Array": return 1;
		case "Map":
		case "Set":
		case "WeakMap":
		case "WeakSet": return 2;
		default: return 0;
	}
}
// @__NO_SIDE_EFFECTS__
function Lt(e) {
	return /* @__PURE__ */ Ht(e) ? e : Bt(e, !1, bt, kt, Mt);
}
// @__NO_SIDE_EFFECTS__
function Rt(e) {
	return Bt(e, !1, St, At, Nt);
}
// @__NO_SIDE_EFFECTS__
function zt(e) {
	return Bt(e, !0, xt, jt, Pt);
}
function Bt(e, t, n, r, i) {
	if (!v(e) || e.__v_raw && !(t && e.__v_isReactive) || e.__v_skip || !Object.isExtensible(e)) return e;
	let a = i.get(e);
	if (a) return a;
	let o = It(S(e));
	if (o === 0) return e;
	let s = new Proxy(e, o === 2 ? r : n);
	return i.set(e, s), s;
}
// @__NO_SIDE_EFFECTS__
function Vt(e) {
	return /* @__PURE__ */ Ht(e) ? /* @__PURE__ */ Vt(e.__v_raw) : !!(e && e.__v_isReactive);
}
// @__NO_SIDE_EFFECTS__
function Ht(e) {
	return !!(e && e.__v_isReadonly);
}
// @__NO_SIDE_EFFECTS__
function Ut(e) {
	return !!(e && e.__v_isShallow);
}
// @__NO_SIDE_EFFECTS__
function Wt(e) {
	return e ? !!e.__v_raw : !1;
}
// @__NO_SIDE_EFFECTS__
function P(e) {
	let t = e && e.__v_raw;
	return t ? /* @__PURE__ */ P(t) : e;
}
function Gt(e) {
	return !u(e, "__v_skip") && Object.isExtensible(e) && le(e, "__v_skip", !0), e;
}
var Kt = (e) => v(e) ? /* @__PURE__ */ Lt(e) : e, qt = (e) => v(e) ? /* @__PURE__ */ zt(e) : e;
// @__NO_SIDE_EFFECTS__
function Jt(e) {
	return e ? e.__v_isRef === !0 : !1;
}
// @__NO_SIDE_EFFECTS__
function F(e) {
	return Yt(e, !1);
}
function Yt(e, t) {
	return /* @__PURE__ */ Jt(e) ? e : new Xt(e, t);
}
var Xt = class {
	constructor(e, t) {
		this.dep = new Xe(), this.__v_isRef = !0, this.__v_isShallow = !1, this._rawValue = t ? e : /* @__PURE__ */ P(e), this._value = t ? e : Kt(e), this.__v_isShallow = t;
	}
	get value() {
		return this.dep.track(), this._value;
	}
	set value(e) {
		let t = this._rawValue, n = this.__v_isShallow || /* @__PURE__ */ Ut(e) || /* @__PURE__ */ Ht(e);
		e = n ? e : /* @__PURE__ */ P(e), se(e, t) && (this._rawValue = e, this._value = n ? e : Kt(e), this.dep.trigger());
	}
};
function I(e) {
	return /* @__PURE__ */ Jt(e) ? e.value : e;
}
var Zt = {
	get: (e, t, n) => t === "__v_raw" ? e : I(Reflect.get(e, t, n)),
	set: (e, t, n, r) => {
		let i = e[t];
		return /* @__PURE__ */ Jt(i) && !/* @__PURE__ */ Jt(n) ? (i.value = n, !0) : Reflect.set(e, t, n, r);
	}
};
function Qt(e) {
	return /* @__PURE__ */ Vt(e) ? e : new Proxy(e, Zt);
}
var $t = class {
	constructor(e) {
		this.__v_isRef = !0, this._value = void 0;
		let t = this.dep = new Xe(), { get: n, set: r } = e(t.track.bind(t), t.trigger.bind(t));
		this._get = n, this._set = r;
	}
	get value() {
		return this._value = this._get();
	}
	set value(e) {
		this._set(e);
	}
};
function en(e) {
	return new $t(e);
}
// @__NO_SIDE_EFFECTS__
function tn(e) {
	let t = d(e) ? Array(e.length) : {};
	for (let n in e) t[n] = an(e, n);
	return t;
}
var nn = class {
	constructor(e, t, n) {
		this._object = e, this._defaultValue = n, this.__v_isRef = !0, this._value = void 0, this._key = _(t) ? t : String(t), this._raw = /* @__PURE__ */ P(e);
		let r = !0, i = e;
		if (!d(e) || _(this._key) || !w(this._key)) do
			r = !/* @__PURE__ */ Wt(i) || /* @__PURE__ */ Ut(i);
		while (r && (i = i.__v_raw));
		this._shallow = r;
	}
	get value() {
		let e = this._object[this._key];
		return this._shallow && (e = I(e)), this._value = e === void 0 ? this._defaultValue : e;
	}
	set value(e) {
		if (this._shallow && /* @__PURE__ */ Jt(this._raw[this._key])) {
			let t = this._object[this._key];
			if (/* @__PURE__ */ Jt(t)) {
				t.value = e;
				return;
			}
		}
		this._object[this._key] = e;
	}
	get dep() {
		return it(this._raw, this._key);
	}
}, rn = class {
	constructor(e) {
		this._getter = e, this.__v_isRef = !0, this.__v_isReadonly = !0, this._value = void 0;
	}
	get value() {
		return this._value = this._getter();
	}
};
// @__NO_SIDE_EFFECTS__
function L(e, t, n) {
	return /* @__PURE__ */ Jt(e) ? e : h(e) ? new rn(e) : v(e) && arguments.length > 1 ? an(e, t, n) : /* @__PURE__ */ F(e);
}
function an(e, t, n) {
	return new nn(e, t, n);
}
var on = class {
	constructor(e, t, n) {
		this.fn = e, this.setter = t, this._value = void 0, this.dep = new Xe(this), this.__v_isRef = !0, this.deps = void 0, this.depsTail = void 0, this.flags = 16, this.globalVersion = Je - 1, this.next = void 0, this.effect = this, this.__v_isReadonly = !t, this.isSSR = n;
	}
	notify() {
		if (this.flags |= 16, !(this.flags & 8) && M !== this) return Pe(this, !0), !0;
	}
	get value() {
		let e = this.dep.track();
		return Be(this), e && (e.version = this.dep.version), this._value;
	}
	set value(e) {
		this.setter && this.setter(e);
	}
};
// @__NO_SIDE_EFFECTS__
function sn(e, t, n = !1) {
	let r, i;
	return h(e) ? r = e : (r = e.get, i = e.set), new on(r, i, n);
}
var cn = {}, ln = /* @__PURE__ */ new WeakMap(), un = void 0;
function dn(e, t = !1, n = un) {
	if (n) {
		let t = ln.get(n);
		t || ln.set(n, t = []), t.push(e);
	}
}
function fn(e, n, i = t) {
	let { immediate: a, deep: o, once: s, scheduler: l, augmentJob: u, call: f } = i, p = (e) => o ? e : /* @__PURE__ */ Ut(e) || o === !1 || o === 0 ? pn(e, 1) : pn(e), m, g, _, v, y = !1, b = !1;
	if (/* @__PURE__ */ Jt(e) ? (g = () => e.value, y = /* @__PURE__ */ Ut(e)) : /* @__PURE__ */ Vt(e) ? (g = () => p(e), y = !0) : d(e) ? (b = !0, y = e.some((e) => /* @__PURE__ */ Vt(e) || /* @__PURE__ */ Ut(e)), g = () => e.map((e) => {
		if (/* @__PURE__ */ Jt(e)) return e.value;
		if (/* @__PURE__ */ Vt(e)) return p(e);
		if (h(e)) return f ? f(e, 2) : e();
	})) : g = h(e) ? n ? f ? () => f(e, 2) : e : () => {
		if (_) {
			Ge();
			try {
				_();
			} finally {
				Ke();
			}
		}
		let t = un;
		un = m;
		try {
			return f ? f(e, 3, [v]) : e(v);
		} finally {
			un = t;
		}
	} : r, n && o) {
		let e = g, t = o === !0 ? Infinity : o;
		g = () => pn(e(), t);
	}
	let x = De(), S = () => {
		m.stop(), x && x.active && c(x.effects, m);
	};
	if (s && n) {
		let e = n;
		n = (...t) => {
			e(...t), S();
		};
	}
	let C = b ? Array(e.length).fill(cn) : cn, w = (e) => {
		if (!(!(m.flags & 1) || !m.dirty && !e)) if (n) {
			let e = m.run();
			if (o || y || (b ? e.some((e, t) => se(e, C[t])) : se(e, C))) {
				_ && _();
				let t = un;
				un = m;
				try {
					let t = [
						e,
						C === cn ? void 0 : b && C[0] === cn ? [] : C,
						v
					];
					C = e, f ? f(n, 3, t) : n(...t);
				} finally {
					un = t;
				}
			}
		} else m.run();
	};
	return u && u(w), m = new Ae(g), m.scheduler = l ? () => l(w, !1) : w, v = (e) => dn(e, !1, m), _ = m.onStop = () => {
		let e = ln.get(m);
		if (e) {
			if (f) f(e, 4);
			else for (let t of e) t();
			ln.delete(m);
		}
	}, n ? a ? w(!0) : C = m.run() : l ? l(w.bind(null, !0), !0) : m.run(), S.pause = m.pause.bind(m), S.resume = m.resume.bind(m), S.stop = S, S;
}
function pn(e, t = Infinity, n) {
	if (t <= 0 || !v(e) || e.__v_skip || (n ||= /* @__PURE__ */ new Map(), (n.get(e) || 0) >= t)) return e;
	if (n.set(e, t), t--, /* @__PURE__ */ Jt(e)) pn(e.value, t, n);
	else if (d(e)) for (let r = 0; r < e.length; r++) pn(e[r], t, n);
	else if (p(e) || f(e)) e.forEach((e) => {
		pn(e, t, n);
	});
	else if (C(e)) {
		for (let r in e) pn(e[r], t, n);
		for (let r of Object.getOwnPropertySymbols(e)) Object.prototype.propertyIsEnumerable.call(e, r) && pn(e[r], t, n);
	}
	return e;
}
//#endregion
//#region node_modules/@vue/runtime-core/dist/runtime-core.esm-bundler.js
function mn(e, t, n, r) {
	try {
		return r ? e(...r) : e();
	} catch (e) {
		gn(e, t, n);
	}
}
function hn(e, t, n, r) {
	if (h(e)) {
		let i = mn(e, t, n, r);
		return i && y(i) && i.catch((e) => {
			gn(e, t, n);
		}), i;
	}
	if (d(e)) {
		let i = [];
		for (let a = 0; a < e.length; a++) i.push(hn(e[a], t, n, r));
		return i;
	}
}
function gn(e, n, r, i = !0) {
	let a = n ? n.vnode : null, { errorHandler: o, throwUnhandledErrorInProduction: s } = n && n.appContext.config || t;
	if (n) {
		let t = n.parent, i = n.proxy, a = `https://vuejs.org/error-reference/#runtime-${r}`;
		for (; t;) {
			let n = t.ec;
			if (n) {
				for (let t = 0; t < n.length; t++) if (n[t](e, i, a) === !1) return;
			}
			t = t.parent;
		}
		if (o) {
			Ge(), mn(o, null, 10, [
				e,
				i,
				a
			]), Ke();
			return;
		}
	}
	_n(e, r, a, i, s);
}
function _n(e, t, n, r = !0, i = !1) {
	if (i) throw e;
	console.error(e);
}
var vn = [], yn = -1, bn = [], xn = null, Sn = 0, Cn = /* @__PURE__ */ Promise.resolve(), wn = null;
function Tn(e) {
	let t = wn || Cn;
	return e ? t.then(this ? e.bind(this) : e) : t;
}
function En(e) {
	let t = yn + 1, n = vn.length;
	for (; t < n;) {
		let r = t + n >>> 1, i = vn[r], a = Mn(i);
		a < e || a === e && i.flags & 2 ? t = r + 1 : n = r;
	}
	return t;
}
function Dn(e) {
	if (!(e.flags & 1)) {
		let t = Mn(e), n = vn[vn.length - 1];
		!n || !(e.flags & 2) && t >= Mn(n) ? vn.push(e) : vn.splice(En(t), 0, e), e.flags |= 1, On();
	}
}
function On() {
	wn ||= Cn.then(Nn);
}
function kn(e) {
	d(e) ? bn.push(...e) : xn && e.id === -1 ? xn.splice(Sn + 1, 0, e) : e.flags & 1 || (bn.push(e), e.flags |= 1), On();
}
function An(e, t, n = yn + 1) {
	for (; n < vn.length; n++) {
		let t = vn[n];
		if (t && t.flags & 2) {
			if (e && t.id !== e.uid) continue;
			vn.splice(n, 1), n--, t.flags & 4 && (t.flags &= -2), t(), t.flags & 4 || (t.flags &= -2);
		}
	}
}
function jn(e) {
	if (bn.length) {
		let e = [...new Set(bn)].sort((e, t) => Mn(e) - Mn(t));
		if (bn.length = 0, xn) {
			xn.push(...e);
			return;
		}
		for (xn = e, Sn = 0; Sn < xn.length; Sn++) {
			let e = xn[Sn];
			e.flags & 4 && (e.flags &= -2), e.flags & 8 || e(), e.flags &= -2;
		}
		xn = null, Sn = 0;
	}
}
var Mn = (e) => e.id == null ? e.flags & 2 ? -1 : Infinity : e.id;
function Nn(e) {
	try {
		for (yn = 0; yn < vn.length; yn++) {
			let e = vn[yn];
			e && !(e.flags & 8) && (e.flags & 4 && (e.flags &= -2), mn(e, e.i, e.i ? 15 : 14), e.flags & 4 || (e.flags &= -2));
		}
	} finally {
		for (; yn < vn.length; yn++) {
			let e = vn[yn];
			e && (e.flags &= -2);
		}
		yn = -1, vn.length = 0, jn(e), wn = null, (vn.length || bn.length) && Nn(e);
	}
}
var Pn = null, Fn = null;
function In(e) {
	let t = Pn;
	return Pn = e, Fn = e && e.type.__scopeId || null, t;
}
function R(e, t = Pn, n) {
	if (!t || e._n) return e;
	let r = (...n) => {
		r._d && wa(-1);
		let i = In(t), a;
		try {
			a = e(...n);
		} finally {
			In(i), r._d && wa(1);
		}
		return a;
	};
	return r._n = !0, r._c = !0, r._d = !0, r;
}
function Ln(e, n) {
	if (Pn === null) return e;
	let r = ao(Pn), i = e.dirs ||= [];
	for (let e = 0; e < n.length; e++) {
		let [a, o, s, c = t] = n[e];
		a && (h(a) && (a = {
			mounted: a,
			updated: a
		}), a.deep && pn(o), i.push({
			dir: a,
			instance: r,
			value: o,
			oldValue: void 0,
			arg: s,
			modifiers: c
		}));
	}
	return e;
}
function Rn(e, t, n, r) {
	let i = e.dirs, a = t && t.dirs;
	for (let o = 0; o < i.length; o++) {
		let s = i[o];
		a && (s.oldValue = a[o].value);
		let c = s.dir[r];
		c && (Ge(), hn(c, n, 8, [
			e.el,
			s,
			e,
			t
		]), Ke());
	}
}
function zn(e, t) {
	if (Ua) {
		let n = Ua.provides, r = Ua.parent && Ua.parent.provides;
		r === n && (n = Ua.provides = Object.create(r)), n[e] = t;
	}
}
function Bn(e, t, n = !1) {
	let r = Wa();
	if (r || Ei) {
		let i = Ei ? Ei._context.provides : r ? r.parent == null || r.ce ? r.vnode.appContext && r.vnode.appContext.provides : r.parent.provides : void 0;
		if (i && e in i) return i[e];
		if (arguments.length > 1) return n && h(t) ? t.call(r && r.proxy) : t;
	}
}
function Vn() {
	return !!(Wa() || Ei);
}
var Hn = /* @__PURE__ */ Symbol.for("v-scx"), Un = () => Bn(Hn);
function Wn(e, t) {
	return Kn(e, null, { flush: "sync" });
}
function Gn(e, t, n) {
	return Kn(e, t, n);
}
function Kn(e, n, i = t) {
	let { immediate: a, deep: o, flush: c, once: l } = i, u = s({}, i), d = n && a || !n && c !== "post", f;
	if (Xa) {
		if (c === "sync") {
			let e = Un();
			f = e.__watcherHandles ||= [];
		} else if (!d) {
			let e = () => {};
			return e.stop = r, e.resume = r, e.pause = r, e;
		}
	}
	let p = Ua;
	u.call = (e, t, n) => hn(e, p, t, n);
	let m = !1;
	c === "post" ? u.scheduler = (e) => {
		ia(e, p && p.suspense);
	} : c !== "sync" && (m = !0, u.scheduler = (e, t) => {
		t ? e() : Dn(e);
	}), u.augmentJob = (e) => {
		n && (e.flags |= 4), m && (e.flags |= 2, p && (e.id = p.uid, e.i = p));
	};
	let h = fn(e, n, u);
	return Xa && (f ? f.push(h) : d && h()), h;
}
function qn(e, t, n) {
	let r = this.proxy, i = g(e) ? e.includes(".") ? Jn(r, e) : () => r[e] : e.bind(r, r), a;
	h(t) ? a = t : (a = t.handler, n = t);
	let o = qa(this), s = Kn(i, a.bind(r), n);
	return o(), s;
}
function Jn(e, t) {
	let n = t.split(".");
	return () => {
		let t = e;
		for (let e = 0; e < n.length && t; e++) t = t[n[e]];
		return t;
	};
}
var Yn = /* @__PURE__ */ new WeakMap(), Xn = /* @__PURE__ */ Symbol("_vte"), Zn = (e) => e.__isTeleport, Qn = (e) => e && (e.disabled || e.disabled === ""), $n = (e) => e && (e.defer || e.defer === ""), er = (e) => typeof SVGElement < "u" && e instanceof SVGElement, tr = (e) => typeof MathMLElement == "function" && e instanceof MathMLElement, nr = (e, t) => {
	let n = e && e.to;
	return g(n) ? t ? t(n) : null : n;
}, rr = {
	name: "Teleport",
	__isTeleport: !0,
	process(e, t, n, r, i, a, o, s, c, l) {
		let { mc: u, pc: d, pbc: f, o: { insert: p, querySelector: m, createText: h, createComment: g, parentNode: _ } } = l, v = Qn(t.props), { dynamicChildren: y } = t, b = (e, t, n) => {
			e.shapeFlag & 16 && u(e.children, t, n, i, a, o, s, c);
		}, x = (e = t) => {
			let n = Qn(e.props), r = e.target = nr(e.props, m), a = cr(r, e, h, p);
			r && (o !== "svg" && er(r) ? o = "svg" : o !== "mathml" && tr(r) && (o = "mathml"), i && i.isCE && (i.ce._teleportTargets || (i.ce._teleportTargets = /* @__PURE__ */ new Set())).add(r), n || (b(e, r, a), sr(e, !1)));
		}, S = (e) => {
			let t = () => {
				Yn.get(e) === t && (Yn.delete(e), Qn(e.props) && (b(e, _(e.el) || n, e.anchor), sr(e, !0)), x(e));
			};
			Yn.set(e, t), ia(t, a);
		};
		if (e == null) {
			let e = t.el = h(""), i = t.anchor = h("");
			if (p(e, n, r), p(i, n, r), $n(t.props) || a && a.pendingBranch) {
				S(t);
				return;
			}
			v && (b(t, n, i), sr(t, !0)), x();
		} else {
			t.el = e.el;
			let r = t.anchor = e.anchor, u = Yn.get(e);
			if (u) {
				u.flags |= 8, Yn.delete(e), S(t);
				return;
			}
			t.targetStart = e.targetStart;
			let p = t.target = e.target, h = t.targetAnchor = e.targetAnchor, g = Qn(e.props), _ = g ? n : p, b = g ? r : h;
			if (o === "svg" || er(p) ? o = "svg" : (o === "mathml" || tr(p)) && (o = "mathml"), y ? (f(e.dynamicChildren, y, _, i, a, o, s), ua(e, t, !0)) : c || d(e, t, _, b, i, a, o, s, !1), v) g ? t.props && e.props && t.props.to !== e.props.to && (t.props.to = e.props.to) : ir(t, n, r, l, 1);
			else if ((t.props && t.props.to) !== (e.props && e.props.to)) {
				let e = t.target = nr(t.props, m);
				e && ir(t, e, null, l, 0);
			} else g && ir(t, p, h, l, 1);
			sr(t, v);
		}
	},
	remove(e, t, n, { um: r, o: { remove: i } }, a) {
		let { shapeFlag: o, children: s, anchor: c, targetStart: l, targetAnchor: u, target: d, props: f } = e, p = a || !Qn(f), m = Yn.get(e);
		if (m && (m.flags |= 8, Yn.delete(e)), d && (i(l), i(u)), a && i(c), !m && o & 16) for (let e = 0; e < s.length; e++) {
			let i = s[e];
			r(i, t, n, p, !!i.dynamicChildren);
		}
	},
	move: ir,
	hydrate: ar
};
function ir(e, t, n, { o: { insert: r }, m: i }, a = 2) {
	a === 0 && r(e.targetAnchor, t, n);
	let { el: o, anchor: s, shapeFlag: c, children: l, props: u } = e, d = a === 2;
	if (d && r(o, t, n), !Yn.has(e) && (!d || Qn(u)) && c & 16) for (let e = 0; e < l.length; e++) i(l[e], t, n, 2);
	d && r(s, t, n);
}
function ar(e, t, n, r, i, a, { o: { nextSibling: o, parentNode: s, querySelector: c, insert: l, createText: u } }, d) {
	function f(e, n) {
		let r = n;
		for (; r;) {
			if (r && r.nodeType === 8) {
				if (r.data === "teleport start anchor") t.targetStart = r;
				else if (r.data === "teleport anchor") {
					t.targetAnchor = r, e._lpa = t.targetAnchor && o(t.targetAnchor);
					break;
				}
			}
			r = o(r);
		}
	}
	function p(e, t) {
		t.anchor = d(o(e), t, s(e), n, r, i, a);
	}
	let m = t.target = nr(t.props, c), h = Qn(t.props);
	if (m) {
		let c = m._lpa || m.firstChild;
		t.shapeFlag & 16 && (h ? (p(e, t), f(m, c), t.targetAnchor || cr(m, t, u, l, s(e) === m ? e : null)) : (t.anchor = o(e), f(m, c), t.targetAnchor || cr(m, t, u, l), d(c && o(c), t, m, n, r, i, a))), sr(t, h);
	} else h && t.shapeFlag & 16 && (p(e, t), t.targetStart = e, t.targetAnchor = o(e));
	return t.anchor && o(t.anchor);
}
var or = rr;
function sr(e, t) {
	let n = e.ctx;
	if (n && n.ut) {
		let r, i;
		for (t ? (r = e.el, i = e.anchor) : (r = e.targetStart, i = e.targetAnchor); r && r !== i;) r.nodeType === 1 && r.setAttribute("data-v-owner", n.uid), r = r.nextSibling;
		n.ut();
	}
}
function cr(e, t, n, r, i = null) {
	let a = t.targetStart = n(""), o = t.targetAnchor = n("");
	return a[Xn] = o, e && (r(a, e, i), r(o, e, i)), o;
}
var lr = /* @__PURE__ */ Symbol("_leaveCb"), ur = /* @__PURE__ */ Symbol("_enterCb");
function dr() {
	let e = {
		isMounted: !1,
		isLeaving: !1,
		isUnmounting: !1,
		leavingVNodes: /* @__PURE__ */ new Map()
	};
	return Rr(() => {
		e.isMounted = !0;
	}), Vr(() => {
		e.isUnmounting = !0;
	}), e;
}
var fr = [Function, Array], pr = {
	mode: String,
	appear: Boolean,
	persisted: Boolean,
	onBeforeEnter: fr,
	onEnter: fr,
	onAfterEnter: fr,
	onEnterCancelled: fr,
	onBeforeLeave: fr,
	onLeave: fr,
	onAfterLeave: fr,
	onLeaveCancelled: fr,
	onBeforeAppear: fr,
	onAppear: fr,
	onAfterAppear: fr,
	onAppearCancelled: fr
}, mr = (e) => {
	let t = e.subTree;
	return t.component ? mr(t.component) : t;
}, hr = {
	name: "BaseTransition",
	props: pr,
	setup(e, { slots: t }) {
		let n = Wa(), r = dr();
		return () => {
			let i = t.default && Cr(t.default(), !0), a = i && i.length ? gr(i) : n.subTree ? K() : void 0;
			if (!a) return;
			let o = /* @__PURE__ */ P(e), { mode: s } = o;
			if (r.isLeaving) return br(a);
			let c = xr(a);
			if (!c) return br(a);
			let l = yr(c, o, r, n, (e) => l = e);
			c.type !== va && Sr(c, l);
			let u = n.subTree && xr(n.subTree);
			if (u && u.type !== va && !Da(u, c) && mr(n).type !== va) {
				let e = yr(u, o, r, n);
				if (Sr(u, e), s === "out-in" && c.type !== va) return r.isLeaving = !0, e.afterLeave = () => {
					r.isLeaving = !1, n.job.flags & 8 || n.update(), delete e.afterLeave, u = void 0;
				}, br(a);
				s === "in-out" && c.type !== va ? e.delayLeave = (e, t, n) => {
					let i = vr(r, u);
					i[String(u.key)] = u, e[lr] = () => {
						t(), e[lr] = void 0, delete l.delayedLeave, u = void 0;
					}, l.delayedLeave = () => {
						n(), delete l.delayedLeave, u = void 0;
					};
				} : u = void 0;
			} else u &&= void 0;
			return a;
		};
	}
};
function gr(e) {
	let t = e[0];
	if (e.length > 1) {
		for (let n of e) if (n.type !== va) {
			t = n;
			break;
		}
	}
	return t;
}
var _r = hr;
function vr(e, t) {
	let { leavingVNodes: n } = e, r = n.get(t.type);
	return r || (r = /* @__PURE__ */ Object.create(null), n.set(t.type, r)), r;
}
function yr(e, t, n, r, i) {
	let { appear: a, mode: o, persisted: s = !1, onBeforeEnter: c, onEnter: l, onAfterEnter: u, onEnterCancelled: f, onBeforeLeave: p, onLeave: m, onAfterLeave: h, onLeaveCancelled: g, onBeforeAppear: _, onAppear: v, onAfterAppear: y, onAppearCancelled: b } = t, x = String(e.key), S = vr(n, e), C = (e, t) => {
		e && hn(e, r, 9, t);
	}, w = (e, t) => {
		let n = t[1];
		C(e, t), d(e) ? e.every((e) => e.length <= 1) && n() : e.length <= 1 && n();
	}, ee = {
		mode: o,
		persisted: s,
		beforeEnter(t) {
			let r = c;
			if (!n.isMounted) if (a) r = _ || c;
			else return;
			t[lr] && t[lr](!0);
			let i = S[x];
			i && Da(e, i) && i.el[lr] && i.el[lr](), C(r, [t]);
		},
		enter(t) {
			if (S[x] === e) return;
			let r = l, i = u, o = f;
			if (!n.isMounted) if (a) r = v || l, i = y || u, o = b || f;
			else return;
			let s = !1;
			t[ur] = (e) => {
				s || (s = !0, C(e ? o : i, [t]), ee.delayedLeave && ee.delayedLeave(), t[ur] = void 0);
			};
			let c = t[ur].bind(null, !1);
			r ? w(r, [t, c]) : c();
		},
		leave(t, r) {
			let i = String(e.key);
			if (t[ur] && t[ur](!0), n.isUnmounting) return r();
			C(p, [t]);
			let a = !1;
			t[lr] = (n) => {
				a || (a = !0, r(), C(n ? g : h, [t]), t[lr] = void 0, S[i] === e && delete S[i]);
			};
			let o = t[lr].bind(null, !1);
			S[i] = e, m ? w(m, [t, o]) : o();
		},
		clone(e) {
			let a = yr(e, t, n, r, i);
			return i && i(a), a;
		}
	};
	return ee;
}
function br(e) {
	if (Ar(e)) return e = Ma(e), e.children = null, e;
}
function xr(e) {
	if (!Ar(e)) return Zn(e.type) && e.children ? gr(e.children) : e;
	if (e.component) return e.component.subTree;
	let { shapeFlag: t, children: n } = e;
	if (n) {
		if (t & 16) return n[0];
		if (t & 32 && h(n.default)) return n.default();
	}
}
function Sr(e, t) {
	e.shapeFlag & 6 && e.component ? (e.transition = t, Sr(e.component.subTree, t)) : e.shapeFlag & 128 ? (e.ssContent.transition = t.clone(e.ssContent), e.ssFallback.transition = t.clone(e.ssFallback)) : e.transition = t;
}
function Cr(e, t = !1, n) {
	let r = [], i = 0;
	for (let a = 0; a < e.length; a++) {
		let o = e[a], s = n == null ? o.key : String(n) + String(o.key == null ? a : o.key);
		o.type === B ? (o.patchFlag & 128 && i++, r = r.concat(Cr(o.children, t, s))) : (t || o.type !== va) && r.push(s == null ? o : Ma(o, { key: s }));
	}
	if (i > 1) for (let e = 0; e < r.length; e++) r[e].patchFlag = -2;
	return r;
}
// @__NO_SIDE_EFFECTS__
function z(e, t) {
	return h(e) ? /* @__PURE__ */ s({ name: e.name }, t, { setup: e }) : e;
}
function wr(e) {
	e.ids = [
		e.ids[0] + e.ids[2]++ + "-",
		0,
		0
	];
}
function Tr(e, t) {
	let n;
	return !!((n = Object.getOwnPropertyDescriptor(e, t)) && !n.configurable);
}
var Er = /* @__PURE__ */ new WeakMap();
function Dr(e, n, r, a, o = !1) {
	if (d(e)) {
		e.forEach((e, t) => Dr(e, n && (d(n) ? n[t] : n), r, a, o));
		return;
	}
	if (kr(a) && !o) {
		a.shapeFlag & 512 && a.type.__asyncResolved && a.component.subTree.component && Dr(e, n, r, a.component.subTree);
		return;
	}
	let s = a.shapeFlag & 4 ? ao(a.component) : a.el, l = o ? null : s, { i: f, r: p } = e, m = n && n.r, _ = f.refs === t ? f.refs = {} : f.refs, v = f.setupState, y = /* @__PURE__ */ P(v), b = v === t ? i : (e) => Tr(_, e) ? !1 : u(y, e), x = (e, t) => !(t && Tr(_, t));
	if (m != null && m !== p) {
		if (Or(n), g(m)) _[m] = null, b(m) && (v[m] = null);
		else if (/* @__PURE__ */ Jt(m)) {
			let e = n;
			x(m, e.k) && (m.value = null), e.k && (_[e.k] = null);
		}
	}
	if (h(p)) mn(p, f, 12, [l, _]);
	else {
		let t = g(p), n = /* @__PURE__ */ Jt(p);
		if (t || n) {
			let i = () => {
				if (e.f) {
					let n = t ? b(p) ? v[p] : _[p] : x(p) || !e.k ? p.value : _[e.k];
					if (o) d(n) && c(n, s);
					else if (d(n)) n.includes(s) || n.push(s);
					else if (t) _[p] = [s], b(p) && (v[p] = _[p]);
					else {
						let t = [s];
						x(p, e.k) && (p.value = t), e.k && (_[e.k] = t);
					}
				} else t ? (_[p] = l, b(p) && (v[p] = l)) : n && (x(p, e.k) && (p.value = l), e.k && (_[e.k] = l));
			};
			if (l) {
				let t = () => {
					i(), Er.delete(e);
				};
				t.id = -1, Er.set(e, t), ia(t, r);
			} else Or(e), i();
		}
	}
}
function Or(e) {
	let t = Er.get(e);
	t && (t.flags |= 8, Er.delete(e));
}
fe().requestIdleCallback, fe().cancelIdleCallback;
var kr = (e) => !!e.type.__asyncLoader, Ar = (e) => e.type.__isKeepAlive;
function jr(e, t) {
	Nr(e, "a", t);
}
function Mr(e, t) {
	Nr(e, "da", t);
}
function Nr(e, t, n = Ua) {
	let r = e.__wdc ||= () => {
		let t = n;
		for (; t;) {
			if (t.isDeactivated) return;
			t = t.parent;
		}
		return e();
	};
	if (Fr(t, r, n), n) {
		let e = n.parent;
		for (; e && e.parent;) Ar(e.parent.vnode) && Pr(r, t, n, e), e = e.parent;
	}
}
function Pr(e, t, n, r) {
	let i = Fr(t, e, r, !0);
	Hr(() => {
		c(r[t], i);
	}, n);
}
function Fr(e, t, n = Ua, r = !1) {
	if (n) {
		let i = n[e] || (n[e] = []), a = t.__weh ||= (...r) => {
			Ge();
			let i = qa(n), a = hn(t, n, e, r);
			return i(), Ke(), a;
		};
		return r ? i.unshift(a) : i.push(a), a;
	}
}
var Ir = (e) => (t, n = Ua) => {
	(!Xa || e === "sp") && Fr(e, (...e) => t(...e), n);
}, Lr = Ir("bm"), Rr = Ir("m"), zr = Ir("bu"), Br = Ir("u"), Vr = Ir("bum"), Hr = Ir("um"), Ur = Ir("sp"), Wr = Ir("rtg"), Gr = Ir("rtc");
function Kr(e, t = Ua) {
	Fr("ec", e, t);
}
var qr = "components";
function Jr(e, t) {
	return Zr(qr, e, !0, t) || e;
}
var Yr = /* @__PURE__ */ Symbol.for("v-ndc");
function Xr(e) {
	return g(e) ? Zr(qr, e, !1) || e : e || Yr;
}
function Zr(e, t, n = !0, r = !1) {
	let i = Pn || Ua;
	if (i) {
		let n = i.type;
		if (e === qr) {
			let e = oo(n, !1);
			if (e && (e === t || e === T(t) || e === ae(T(t)))) return n;
		}
		let a = Qr(i[e] || n[e], t) || Qr(i.appContext[e], t);
		return !a && r ? n : a;
	}
}
function Qr(e, t) {
	return e && (e[t] || e[T(t)] || e[ae(T(t))]);
}
function $r(e, t, n, r) {
	let i, a = n && n[r], o = d(e);
	if (o || g(e)) {
		let n = o && /* @__PURE__ */ Vt(e), r = !1, s = !1;
		n && (r = !/* @__PURE__ */ Ut(e), s = /* @__PURE__ */ Ht(e), e = ot(e)), i = Array(e.length);
		for (let n = 0, o = e.length; n < o; n++) i[n] = t(r ? s ? qt(Kt(e[n])) : Kt(e[n]) : e[n], n, void 0, a && a[n]);
	} else if (typeof e == "number") {
		i = Array(e);
		for (let n = 0; n < e; n++) i[n] = t(n + 1, n, void 0, a && a[n]);
	} else if (v(e)) if (e[Symbol.iterator]) i = Array.from(e, (e, n) => t(e, n, void 0, a && a[n]));
	else {
		let n = Object.keys(e);
		i = Array(n.length);
		for (let r = 0, o = n.length; r < o; r++) {
			let o = n[r];
			i[r] = t(e[o], o, r, a && a[r]);
		}
	}
	else i = [];
	return n && (n[r] = i), i;
}
function ei(e, t, n = {}, r, i) {
	if (Pn.ce || Pn.parent && kr(Pn.parent) && Pn.parent.ce) {
		let e = Object.keys(n).length > 0;
		return t !== "default" && (n.name = t), V(), U(B, null, [G("slot", n, r && r())], e ? -2 : 64);
	}
	let a = e[t];
	a && a._c && (a._d = !1), V();
	let o = a && ti(a(n)), s = n.key || o && o.key, c = U(B, { key: (s && !_(s) ? s : `_${t}`) + (!o && r ? "_fb" : "") }, o || (r ? r() : []), o && e._ === 1 ? 64 : -2);
	return !i && c.scopeId && (c.slotScopeIds = [c.scopeId + "-s"]), a && a._c && (a._d = !0), c;
}
function ti(e) {
	return e.some((e) => Ea(e) ? !(e.type === va || e.type === B && !ti(e.children)) : !0) ? e : null;
}
var ni = (e) => e ? Ya(e) ? ao(e) : ni(e.parent) : null, ri = /* @__PURE__ */ s(/* @__PURE__ */ Object.create(null), {
	$: (e) => e,
	$el: (e) => e.vnode.el,
	$data: (e) => e.data,
	$props: (e) => e.props,
	$attrs: (e) => e.attrs,
	$slots: (e) => e.slots,
	$refs: (e) => e.refs,
	$parent: (e) => ni(e.parent),
	$root: (e) => ni(e.root),
	$host: (e) => e.ce,
	$emit: (e) => e.emit,
	$options: (e) => pi(e),
	$forceUpdate: (e) => e.f ||= () => {
		Dn(e.update);
	},
	$nextTick: (e) => e.n ||= Tn.bind(e.proxy),
	$watch: (e) => qn.bind(e)
}), ii = (e, n) => e !== t && !e.__isScriptSetup && u(e, n), ai = {
	get({ _: e }, n) {
		if (n === "__v_skip") return !0;
		let { ctx: r, setupState: i, data: a, props: o, accessCache: s, type: c, appContext: l } = e;
		if (n[0] !== "$") {
			let e = s[n];
			if (e !== void 0) switch (e) {
				case 1: return i[n];
				case 2: return a[n];
				case 4: return r[n];
				case 3: return o[n];
			}
			else if (ii(i, n)) return s[n] = 1, i[n];
			else if (a !== t && u(a, n)) return s[n] = 2, a[n];
			else if (u(o, n)) return s[n] = 3, o[n];
			else if (r !== t && u(r, n)) return s[n] = 4, r[n];
			else ci && (s[n] = 0);
		}
		let d = ri[n], f, p;
		if (d) return n === "$attrs" && nt(e.attrs, "get", ""), d(e);
		if ((f = c.__cssModules) && (f = f[n])) return f;
		if (r !== t && u(r, n)) return s[n] = 4, r[n];
		if (p = l.config.globalProperties, u(p, n)) return p[n];
	},
	set({ _: e }, n, r) {
		let { data: i, setupState: a, ctx: o } = e;
		return ii(a, n) ? (a[n] = r, !0) : i !== t && u(i, n) ? (i[n] = r, !0) : u(e.props, n) || n[0] === "$" && n.slice(1) in e ? !1 : (o[n] = r, !0);
	},
	has({ _: { data: e, setupState: n, accessCache: r, ctx: i, appContext: a, props: o, type: s } }, c) {
		let l;
		return !!(r[c] || e !== t && c[0] !== "$" && u(e, c) || ii(n, c) || u(o, c) || u(i, c) || u(ri, c) || u(a.config.globalProperties, c) || (l = s.__cssModules) && l[c]);
	},
	defineProperty(e, t, n) {
		return n.get == null ? u(n, "value") && this.set(e, t, n.value, null) : e._.accessCache[t] = 0, Reflect.defineProperty(e, t, n);
	}
};
function oi(e) {
	return d(e) ? e.reduce((e, t) => (e[t] = null, e), {}) : e;
}
function si(e, t) {
	return !e || !t ? e || t : d(e) && d(t) ? e.concat(t) : s({}, oi(e), oi(t));
}
var ci = !0;
function li(e) {
	let t = pi(e), n = e.proxy, i = e.ctx;
	ci = !1, t.beforeCreate && di(t.beforeCreate, e, "bc");
	let { data: a, computed: o, methods: s, watch: c, provide: l, inject: u, created: f, beforeMount: p, mounted: m, beforeUpdate: g, updated: _, activated: y, deactivated: b, beforeDestroy: x, beforeUnmount: S, destroyed: C, unmounted: w, render: ee, renderTracked: te, renderTriggered: ne, errorCaptured: T, serverPrefetch: re, expose: ie, inheritAttrs: ae, components: oe, directives: se, filters: ce } = t;
	if (u && ui(u, i, null), s) for (let e in s) {
		let t = s[e];
		h(t) && (i[e] = t.bind(n));
	}
	if (a) {
		let t = a.call(n, n);
		v(t) && (e.data = /* @__PURE__ */ Lt(t));
	}
	if (ci = !0, o) for (let e in o) {
		let t = o[e], a = q({
			get: h(t) ? t.bind(n, n) : h(t.get) ? t.get.bind(n, n) : r,
			set: !h(t) && h(t.set) ? t.set.bind(n) : r
		});
		Object.defineProperty(i, e, {
			enumerable: !0,
			configurable: !0,
			get: () => a.value,
			set: (e) => a.value = e
		});
	}
	if (c) for (let e in c) fi(c[e], i, n, e);
	if (l) {
		let e = h(l) ? l.call(n) : l;
		Reflect.ownKeys(e).forEach((t) => {
			zn(t, e[t]);
		});
	}
	f && di(f, e, "c");
	function le(e, t) {
		d(t) ? t.forEach((t) => e(t.bind(n))) : t && e(t.bind(n));
	}
	if (le(Lr, p), le(Rr, m), le(zr, g), le(Br, _), le(jr, y), le(Mr, b), le(Kr, T), le(Gr, te), le(Wr, ne), le(Vr, S), le(Hr, w), le(Ur, re), d(ie)) if (ie.length) {
		let t = e.exposed ||= {};
		ie.forEach((e) => {
			Object.defineProperty(t, e, {
				get: () => n[e],
				set: (t) => n[e] = t,
				enumerable: !0
			});
		});
	} else e.exposed ||= {};
	ee && e.render === r && (e.render = ee), ae != null && (e.inheritAttrs = ae), oe && (e.components = oe), se && (e.directives = se), re && wr(e);
}
function ui(e, t, n = r) {
	d(e) && (e = vi(e));
	for (let n in e) {
		let r = e[n], i;
		i = v(r) ? "default" in r ? Bn(r.from || n, r.default, !0) : Bn(r.from || n) : Bn(r), /* @__PURE__ */ Jt(i) ? Object.defineProperty(t, n, {
			enumerable: !0,
			configurable: !0,
			get: () => i.value,
			set: (e) => i.value = e
		}) : t[n] = i;
	}
}
function di(e, t, n) {
	hn(d(e) ? e.map((e) => e.bind(t.proxy)) : e.bind(t.proxy), t, n);
}
function fi(e, t, n, r) {
	let i = r.includes(".") ? Jn(n, r) : () => n[r];
	if (g(e)) {
		let n = t[e];
		h(n) && Gn(i, n);
	} else if (h(e)) Gn(i, e.bind(n));
	else if (v(e)) if (d(e)) e.forEach((e) => fi(e, t, n, r));
	else {
		let r = h(e.handler) ? e.handler.bind(n) : t[e.handler];
		h(r) && Gn(i, r, e);
	}
}
function pi(e) {
	let t = e.type, { mixins: n, extends: r } = t, { mixins: i, optionsCache: a, config: { optionMergeStrategies: o } } = e.appContext, s = a.get(t), c;
	return s ? c = s : !i.length && !n && !r ? c = t : (c = {}, i.length && i.forEach((e) => mi(c, e, o, !0)), mi(c, t, o)), v(t) && a.set(t, c), c;
}
function mi(e, t, n, r = !1) {
	let { mixins: i, extends: a } = t;
	a && mi(e, a, n, !0), i && i.forEach((t) => mi(e, t, n, !0));
	for (let i in t) if (!(r && i === "expose")) {
		let r = hi[i] || n && n[i];
		e[i] = r ? r(e[i], t[i]) : t[i];
	}
	return e;
}
var hi = {
	data: gi,
	props: xi,
	emits: xi,
	methods: bi,
	computed: bi,
	beforeCreate: yi,
	created: yi,
	beforeMount: yi,
	mounted: yi,
	beforeUpdate: yi,
	updated: yi,
	beforeDestroy: yi,
	beforeUnmount: yi,
	destroyed: yi,
	unmounted: yi,
	activated: yi,
	deactivated: yi,
	errorCaptured: yi,
	serverPrefetch: yi,
	components: bi,
	directives: bi,
	watch: Si,
	provide: gi,
	inject: _i
};
function gi(e, t) {
	return t ? e ? function() {
		return s(h(e) ? e.call(this, this) : e, h(t) ? t.call(this, this) : t);
	} : t : e;
}
function _i(e, t) {
	return bi(vi(e), vi(t));
}
function vi(e) {
	if (d(e)) {
		let t = {};
		for (let n = 0; n < e.length; n++) t[e[n]] = e[n];
		return t;
	}
	return e;
}
function yi(e, t) {
	return e ? [...new Set([].concat(e, t))] : t;
}
function bi(e, t) {
	return e ? s(/* @__PURE__ */ Object.create(null), e, t) : t;
}
function xi(e, t) {
	return e ? d(e) && d(t) ? [.../* @__PURE__ */ new Set([...e, ...t])] : s(/* @__PURE__ */ Object.create(null), oi(e), oi(t ?? {})) : t;
}
function Si(e, t) {
	if (!e) return t;
	if (!t) return e;
	let n = s(/* @__PURE__ */ Object.create(null), e);
	for (let r in t) n[r] = yi(e[r], t[r]);
	return n;
}
function Ci() {
	return {
		app: null,
		config: {
			isNativeTag: i,
			performance: !1,
			globalProperties: {},
			optionMergeStrategies: {},
			errorHandler: void 0,
			warnHandler: void 0,
			compilerOptions: {}
		},
		mixins: [],
		components: {},
		directives: {},
		provides: /* @__PURE__ */ Object.create(null),
		optionsCache: /* @__PURE__ */ new WeakMap(),
		propsCache: /* @__PURE__ */ new WeakMap(),
		emitsCache: /* @__PURE__ */ new WeakMap()
	};
}
var wi = 0;
function Ti(e, t) {
	return function(n, r = null) {
		h(n) || (n = s({}, n)), r != null && !v(r) && (r = null);
		let i = Ci(), a = /* @__PURE__ */ new WeakSet(), o = [], c = !1, l = i.app = {
			_uid: wi++,
			_component: n,
			_props: r,
			_container: null,
			_context: i,
			_instance: null,
			version: lo,
			get config() {
				return i.config;
			},
			set config(e) {},
			use(e, ...t) {
				return a.has(e) || (e && h(e.install) ? (a.add(e), e.install(l, ...t)) : h(e) && (a.add(e), e(l, ...t))), l;
			},
			mixin(e) {
				return i.mixins.includes(e) || i.mixins.push(e), l;
			},
			component(e, t) {
				return t ? (i.components[e] = t, l) : i.components[e];
			},
			directive(e, t) {
				return t ? (i.directives[e] = t, l) : i.directives[e];
			},
			mount(a, o, s) {
				if (!c) {
					let u = l._ceVNode || G(n, r);
					return u.appContext = i, s === !0 ? s = "svg" : s === !1 && (s = void 0), o && t ? t(u, a) : e(u, a, s), c = !0, l._container = a, a.__vue_app__ = l, ao(u.component);
				}
			},
			onUnmount(e) {
				o.push(e);
			},
			unmount() {
				c && (hn(o, l._instance, 16), e(null, l._container), delete l._container.__vue_app__);
			},
			provide(e, t) {
				return i.provides[e] = t, l;
			},
			runWithContext(e) {
				let t = Ei;
				Ei = l;
				try {
					return e();
				} finally {
					Ei = t;
				}
			}
		};
		return l;
	};
}
var Ei = null;
function Di(e, n, r = t) {
	let i = Wa(), a = T(n), o = ie(n), s = Oi(e, a), c = en((s, c) => {
		let l, u = t, d;
		return Wn(() => {
			let t = e[a];
			se(l, t) && (l = t, c());
		}), {
			get() {
				return s(), r.get ? r.get(l) : l;
			},
			set(e) {
				let s = r.set ? r.set(e) : e;
				if (!se(s, l) && !(u !== t && se(e, u))) return;
				let f = i.vnode.props;
				f && (n in f || a in f || o in f) && (`onUpdate:${n}` in f || `onUpdate:${a}` in f || `onUpdate:${o}` in f) || (l = e, c()), i.emit(`update:${n}`, s), se(e, s) && se(e, u) && !se(s, d) && c(), u = e, d = s;
			}
		};
	});
	return c[Symbol.iterator] = () => {
		let e = 0;
		return { next() {
			return e < 2 ? {
				value: e++ ? s || t : c,
				done: !1
			} : { done: !0 };
		} };
	}, c;
}
var Oi = (e, t) => t === "modelValue" || t === "model-value" ? e.modelModifiers : e[`${t}Modifiers`] || e[`${T(t)}Modifiers`] || e[`${ie(t)}Modifiers`];
function ki(e, n, ...r) {
	if (e.isUnmounted) return;
	let i = e.vnode.props || t, a = r, o = n.startsWith("update:"), s = o && Oi(i, n.slice(7));
	s && (s.trim && (a = r.map((e) => g(e) ? e.trim() : e)), s.number && (a = r.map(E)));
	let c, l = i[c = oe(n)] || i[c = oe(T(n))];
	!l && o && (l = i[c = oe(ie(n))]), l && hn(l, e, 6, a);
	let u = i[c + "Once"];
	if (u) {
		if (!e.emitted) e.emitted = {};
		else if (e.emitted[c]) return;
		e.emitted[c] = !0, hn(u, e, 6, a);
	}
}
var Ai = /* @__PURE__ */ new WeakMap();
function ji(e, t, n = !1) {
	let r = n ? Ai : t.emitsCache, i = r.get(e);
	if (i !== void 0) return i;
	let a = e.emits, o = {}, c = !1;
	if (!h(e)) {
		let r = (e) => {
			let n = ji(e, t, !0);
			n && (c = !0, s(o, n));
		};
		!n && t.mixins.length && t.mixins.forEach(r), e.extends && r(e.extends), e.mixins && e.mixins.forEach(r);
	}
	return !a && !c ? (v(e) && r.set(e, null), null) : (d(a) ? a.forEach((e) => o[e] = null) : s(o, a), v(e) && r.set(e, o), o);
}
function Mi(e, t) {
	return !e || !a(t) ? !1 : (t = t.slice(2).replace(/Once$/, ""), u(e, t[0].toLowerCase() + t.slice(1)) || u(e, ie(t)) || u(e, t));
}
function Ni(e) {
	let { type: t, vnode: n, proxy: r, withProxy: i, propsOptions: [a], slots: s, attrs: c, emit: l, render: u, renderCache: d, props: f, data: p, setupState: m, ctx: h, inheritAttrs: g } = e, _ = In(e), v, y;
	try {
		if (n.shapeFlag & 4) {
			let e = i || r, t = e;
			v = Fa(u.call(t, e, d, f, m, p, h)), y = c;
		} else {
			let e = t;
			v = Fa(e.length > 1 ? e(f, {
				attrs: c,
				slots: s,
				emit: l
			}) : e(f, null)), y = t.props ? c : Pi(c);
		}
	} catch (t) {
		ba.length = 0, gn(t, e, 1), v = G(va);
	}
	let b = v;
	if (y && g !== !1) {
		let e = Object.keys(y), { shapeFlag: t } = b;
		e.length && t & 7 && (a && e.some(o) && (y = Fi(y, a)), b = Ma(b, y, !1, !0));
	}
	return n.dirs && (b = Ma(b, null, !1, !0), b.dirs = b.dirs ? b.dirs.concat(n.dirs) : n.dirs), n.transition && Sr(b, n.transition), v = b, In(_), v;
}
var Pi = (e) => {
	let t;
	for (let n in e) (n === "class" || n === "style" || a(n)) && ((t ||= {})[n] = e[n]);
	return t;
}, Fi = (e, t) => {
	let n = {};
	for (let r in e) (!o(r) || !(r.slice(9) in t)) && (n[r] = e[r]);
	return n;
};
function Ii(e, t, n) {
	let { props: r, children: i, component: a } = e, { props: o, children: s, patchFlag: c } = t, l = a.emitsOptions;
	if (t.dirs || t.transition) return !0;
	if (n && c >= 0) {
		if (c & 1024) return !0;
		if (c & 16) return r ? Li(r, o, l) : !!o;
		if (c & 8) {
			let e = t.dynamicProps;
			for (let t = 0; t < e.length; t++) {
				let n = e[t];
				if (Ri(o, r, n) && !Mi(l, n)) return !0;
			}
		}
	} else return (i || s) && (!s || !s.$stable) ? !0 : r === o ? !1 : r ? o ? Li(r, o, l) : !0 : !!o;
	return !1;
}
function Li(e, t, n) {
	let r = Object.keys(t);
	if (r.length !== Object.keys(e).length) return !0;
	for (let i = 0; i < r.length; i++) {
		let a = r[i];
		if (Ri(t, e, a) && !Mi(n, a)) return !0;
	}
	return !1;
}
function Ri(e, t, n) {
	let r = e[n], i = t[n];
	return n === "style" && v(r) && v(i) ? !A(r, i) : r !== i;
}
function zi({ vnode: e, parent: t, suspense: n }, r) {
	for (; t;) {
		let n = t.subTree;
		if (n.suspense && n.suspense.activeBranch === e && (n.suspense.vnode.el = n.el = r, e = n), n === e) (e = t.vnode).el = r, t = t.parent;
		else break;
	}
	n && n.activeBranch === e && (n.vnode.el = r);
}
var Bi = {}, Vi = () => Object.create(Bi), Hi = (e) => Object.getPrototypeOf(e) === Bi;
function Ui(e, t, n, r = !1) {
	let i = {}, a = Vi();
	e.propsDefaults = /* @__PURE__ */ Object.create(null), Gi(e, t, i, a);
	for (let t in e.propsOptions[0]) t in i || (i[t] = void 0);
	n ? e.props = r ? i : /* @__PURE__ */ Rt(i) : e.type.props ? e.props = i : e.props = a, e.attrs = a;
}
function Wi(e, t, n, r) {
	let { props: i, attrs: a, vnode: { patchFlag: o } } = e, s = /* @__PURE__ */ P(i), [c] = e.propsOptions, l = !1;
	if ((r || o > 0) && !(o & 16)) {
		if (o & 8) {
			let n = e.vnode.dynamicProps;
			for (let r = 0; r < n.length; r++) {
				let o = n[r];
				if (Mi(e.emitsOptions, o)) continue;
				let d = t[o];
				if (c) if (u(a, o)) d !== a[o] && (a[o] = d, l = !0);
				else {
					let t = T(o);
					i[t] = Ki(c, s, t, d, e, !1);
				}
				else d !== a[o] && (a[o] = d, l = !0);
			}
		}
	} else {
		Gi(e, t, i, a) && (l = !0);
		let r;
		for (let a in s) (!t || !u(t, a) && ((r = ie(a)) === a || !u(t, r))) && (c ? n && (n[a] !== void 0 || n[r] !== void 0) && (i[a] = Ki(c, s, a, void 0, e, !0)) : delete i[a]);
		if (a !== s) for (let e in a) (!t || !u(t, e)) && (delete a[e], l = !0);
	}
	l && rt(e.attrs, "set", "");
}
function Gi(e, n, r, i) {
	let [a, o] = e.propsOptions, s = !1, c;
	if (n) for (let t in n) {
		if (ee(t)) continue;
		let l = n[t], d;
		a && u(a, d = T(t)) ? !o || !o.includes(d) ? r[d] = l : (c ||= {})[d] = l : Mi(e.emitsOptions, t) || (!(t in i) || l !== i[t]) && (i[t] = l, s = !0);
	}
	if (o) {
		let n = /* @__PURE__ */ P(r), i = c || t;
		for (let t = 0; t < o.length; t++) {
			let s = o[t];
			r[s] = Ki(a, n, s, i[s], e, !u(i, s));
		}
	}
	return s;
}
function Ki(e, t, n, r, i, a) {
	let o = e[n];
	if (o != null) {
		let e = u(o, "default");
		if (e && r === void 0) {
			let e = o.default;
			if (o.type !== Function && !o.skipFactory && h(e)) {
				let { propsDefaults: a } = i;
				if (n in a) r = a[n];
				else {
					let o = qa(i);
					r = a[n] = e.call(null, t), o();
				}
			} else r = e;
			i.ce && i.ce._setProp(n, r);
		}
		o[0] && (a && !e ? r = !1 : o[1] && (r === "" || r === ie(n)) && (r = !0));
	}
	return r;
}
var qi = /* @__PURE__ */ new WeakMap();
function Ji(e, r, i = !1) {
	let a = i ? qi : r.propsCache, o = a.get(e);
	if (o) return o;
	let c = e.props, l = {}, f = [], p = !1;
	if (!h(e)) {
		let t = (e) => {
			p = !0;
			let [t, n] = Ji(e, r, !0);
			s(l, t), n && f.push(...n);
		};
		!i && r.mixins.length && r.mixins.forEach(t), e.extends && t(e.extends), e.mixins && e.mixins.forEach(t);
	}
	if (!c && !p) return v(e) && a.set(e, n), n;
	if (d(c)) for (let e = 0; e < c.length; e++) {
		let n = T(c[e]);
		Yi(n) && (l[n] = t);
	}
	else if (c) for (let e in c) {
		let t = T(e);
		if (Yi(t)) {
			let n = c[e], r = l[t] = d(n) || h(n) ? { type: n } : s({}, n), i = r.type, a = !1, o = !0;
			if (d(i)) for (let e = 0; e < i.length; ++e) {
				let t = i[e], n = h(t) && t.name;
				if (n === "Boolean") {
					a = !0;
					break;
				} else n === "String" && (o = !1);
			}
			else a = h(i) && i.name === "Boolean";
			r[0] = a, r[1] = o, (a || u(r, "default")) && f.push(t);
		}
	}
	let m = [l, f];
	return v(e) && a.set(e, m), m;
}
function Yi(e) {
	return e[0] !== "$" && !ee(e);
}
var Xi = (e) => e === "_" || e === "_ctx" || e === "$stable", Zi = (e) => d(e) ? e.map(Fa) : [Fa(e)], Qi = (e, t, n) => {
	if (t._n) return t;
	let r = R((...e) => Zi(t(...e)), n);
	return r._c = !1, r;
}, $i = (e, t, n) => {
	let r = e._ctx;
	for (let n in e) {
		if (Xi(n)) continue;
		let i = e[n];
		if (h(i)) t[n] = Qi(n, i, r);
		else if (i != null) {
			let e = Zi(i);
			t[n] = () => e;
		}
	}
}, ea = (e, t) => {
	let n = Zi(t);
	e.slots.default = () => n;
}, ta = (e, t, n) => {
	for (let r in t) (n || !Xi(r)) && (e[r] = t[r]);
}, na = (e, t, n) => {
	let r = e.slots = Vi();
	if (e.vnode.shapeFlag & 32) {
		let e = t._;
		e ? (ta(r, t, n), n && le(r, "_", e, !0)) : $i(t, r);
	} else t && ea(e, t);
}, ra = (e, n, r) => {
	let { vnode: i, slots: a } = e, o = !0, s = t;
	if (i.shapeFlag & 32) {
		let e = n._;
		e ? r && e === 1 ? o = !1 : ta(a, n, r) : (o = !n.$stable, $i(n, a)), s = n;
	} else n && (ea(e, n), s = { default: 1 });
	if (o) for (let e in a) !Xi(e) && s[e] == null && delete a[e];
}, ia = ga;
function aa(e) {
	return oa(e);
}
function oa(e, i) {
	let a = fe();
	a.__VUE__ = !0;
	let { insert: o, remove: s, patchProp: c, createElement: l, createText: u, createComment: d, setText: f, setElementText: p, parentNode: m, nextSibling: h, setScopeId: g = r, insertStaticContent: _ } = e, v = (e, t, n, r = null, i = null, a = null, o = void 0, s = null, c = !!t.dynamicChildren) => {
		if (e === t) return;
		e && !Da(e, t) && (r = ye(e), ge(e, i, a, !0), e = null), t.patchFlag === -2 && (c = !1, t.dynamicChildren = null);
		let { type: l, ref: u, shapeFlag: d } = t;
		switch (l) {
			case _a:
				y(e, t, n, r);
				break;
			case va:
				b(e, t, n, r);
				break;
			case ya:
				e ?? x(t, n, r, o);
				break;
			case B:
				oe(e, t, n, r, i, a, o, s, c);
				break;
			default: d & 1 ? w(e, t, n, r, i, a, o, s, c) : d & 6 ? se(e, t, n, r, i, a, o, s, c) : (d & 64 || d & 128) && l.process(e, t, n, r, i, a, o, s, c, xe);
		}
		u != null && i ? Dr(u, e && e.ref, a, t || e, !t) : u == null && e && e.ref != null && Dr(e.ref, null, a, e, !0);
	}, y = (e, t, n, r) => {
		if (e == null) o(t.el = u(t.children), n, r);
		else {
			let n = t.el = e.el;
			t.children !== e.children && f(n, t.children);
		}
	}, b = (e, t, n, r) => {
		e == null ? o(t.el = d(t.children || ""), n, r) : t.el = e.el;
	}, x = (e, t, n, r) => {
		[e.el, e.anchor] = _(e.children, t, n, r, e.el, e.anchor);
	}, S = ({ el: e, anchor: t }, n, r) => {
		let i;
		for (; e && e !== t;) i = h(e), o(e, n, r), e = i;
		o(t, n, r);
	}, C = ({ el: e, anchor: t }) => {
		let n;
		for (; e && e !== t;) n = h(e), s(e), e = n;
		s(t);
	}, w = (e, t, n, r, i, a, o, s, c) => {
		if (t.type === "svg" ? o = "svg" : t.type === "math" && (o = "mathml"), e == null) te(t, n, r, i, a, o, s, c);
		else {
			let n = e.el && e.el._isVueCE ? e.el : null;
			try {
				n && n._beginPatch(), re(e, t, i, a, o, s, c);
			} finally {
				n && n._endPatch();
			}
		}
	}, te = (e, t, n, r, i, a, s, u) => {
		let d, f, { props: m, shapeFlag: h, transition: g, dirs: _ } = e;
		if (d = e.el = l(e.type, a, m && m.is, m), h & 8 ? p(d, e.children) : h & 16 && T(e.children, d, null, r, i, sa(e, a), s, u), _ && Rn(e, null, r, "created"), ne(d, e, e.scopeId, s, r), m) {
			for (let e in m) e !== "value" && !ee(e) && c(d, e, null, m[e], a, r);
			"value" in m && c(d, "value", null, m.value, a), (f = m.onVnodeBeforeMount) && za(f, r, e);
		}
		_ && Rn(e, null, r, "beforeMount");
		let v = la(i, g);
		v && g.beforeEnter(d), o(d, t, n), ((f = m && m.onVnodeMounted) || v || _) && ia(() => {
			try {
				f && za(f, r, e), v && g.enter(d), _ && Rn(e, null, r, "mounted");
			} finally {}
		}, i);
	}, ne = (e, t, n, r, i) => {
		if (n && g(e, n), r) for (let t = 0; t < r.length; t++) g(e, r[t]);
		if (i) {
			let n = i.subTree;
			if (t === n || ha(n.type) && (n.ssContent === t || n.ssFallback === t)) {
				let t = i.vnode;
				ne(e, t, t.scopeId, t.slotScopeIds, i.parent);
			}
		}
	}, T = (e, t, n, r, i, a, o, s, c = 0) => {
		for (let l = c; l < e.length; l++) v(null, e[l] = s ? Ia(e[l]) : Fa(e[l]), t, n, r, i, a, o, s);
	}, re = (e, n, r, i, a, o, s) => {
		let l = n.el = e.el, { patchFlag: u, dynamicChildren: d, dirs: f } = n;
		u |= e.patchFlag & 16;
		let m = e.props || t, h = n.props || t, g;
		if (r && ca(r, !1), (g = h.onVnodeBeforeUpdate) && za(g, r, n, e), f && Rn(n, e, r, "beforeUpdate"), r && ca(r, !0), (m.innerHTML && h.innerHTML == null || m.textContent && h.textContent == null) && p(l, ""), d ? ie(e.dynamicChildren, d, l, r, i, sa(n, a), o) : s || D(e, n, l, null, r, i, sa(n, a), o, !1), u > 0) {
			if (u & 16) ae(l, m, h, r, a);
			else if (u & 2 && m.class !== h.class && c(l, "class", null, h.class, a), u & 4 && c(l, "style", m.style, h.style, a), u & 8) {
				let e = n.dynamicProps;
				for (let t = 0; t < e.length; t++) {
					let n = e[t], i = m[n], o = h[n];
					(o !== i || n === "value") && c(l, n, i, o, a, r);
				}
			}
			u & 1 && e.children !== n.children && p(l, n.children);
		} else !s && d == null && ae(l, m, h, r, a);
		((g = h.onVnodeUpdated) || f) && ia(() => {
			g && za(g, r, n, e), f && Rn(n, e, r, "updated");
		}, i);
	}, ie = (e, t, n, r, i, a, o) => {
		for (let s = 0; s < t.length; s++) {
			let c = e[s], l = t[s];
			v(c, l, c.el && (c.type === B || !Da(c, l) || c.shapeFlag & 198) ? m(c.el) : n, null, r, i, a, o, !0);
		}
	}, ae = (e, n, r, i, a) => {
		if (n !== r) {
			if (n !== t) for (let t in n) !ee(t) && !(t in r) && c(e, t, n[t], null, a, i);
			for (let t in r) {
				if (ee(t)) continue;
				let o = r[t], s = n[t];
				o !== s && t !== "value" && c(e, t, s, o, a, i);
			}
			"value" in r && c(e, "value", n.value, r.value, a);
		}
	}, oe = (e, t, n, r, i, a, s, c, l) => {
		let d = t.el = e ? e.el : u(""), f = t.anchor = e ? e.anchor : u(""), { patchFlag: p, dynamicChildren: m, slotScopeIds: h } = t;
		h && (c = c ? c.concat(h) : h), e == null ? (o(d, n, r), o(f, n, r), T(t.children || [], n, f, i, a, s, c, l)) : p > 0 && p & 64 && m && e.dynamicChildren && e.dynamicChildren.length === m.length ? (ie(e.dynamicChildren, m, n, i, a, s, c), (t.key != null || i && t === i.subTree) && ua(e, t, !0)) : D(e, t, n, f, i, a, s, c, l);
	}, se = (e, t, n, r, i, a, o, s, c) => {
		t.slotScopeIds = s, e == null ? t.shapeFlag & 512 ? i.ctx.activate(t, n, r, o, c) : le(t, n, r, i, a, o, c) : E(e, t, c);
	}, le = (e, t, n, r, i, a, o) => {
		let s = e.component = Ha(e, r, i);
		if (Ar(e) && (s.ctx.renderer = xe), Za(s, !1, o), s.asyncDep) {
			if (i && i.registerDep(s, ue, o), !e.el) {
				let r = s.subTree = G(va);
				b(null, r, t, n), e.placeholder = r.el;
			}
		} else ue(s, e, t, n, i, a, o);
	}, E = (e, t, n) => {
		let r = t.component = e.component;
		if (Ii(e, t, n)) if (r.asyncDep && !r.asyncResolved) {
			de(r, t, n);
			return;
		} else r.next = t, r.update();
		else t.el = e.el, r.vnode = t;
	}, ue = (e, t, n, r, i, a, o) => {
		let s = () => {
			if (e.isMounted) {
				let { next: t, bu: n, u: r, parent: s, vnode: c } = e;
				{
					let n = fa(e);
					if (n) {
						t && (t.el = c.el, de(e, t, o)), n.asyncDep.then(() => {
							ia(() => {
								e.isUnmounted || l();
							}, i);
						});
						return;
					}
				}
				let u = t, d;
				ca(e, !1), t ? (t.el = c.el, de(e, t, o)) : t = c, n && ce(n), (d = t.props && t.props.onVnodeBeforeUpdate) && za(d, s, t, c), ca(e, !0);
				let f = Ni(e), p = e.subTree;
				e.subTree = f, v(p, f, m(p.el), ye(p), e, i, a), t.el = f.el, u === null && zi(e, f.el), r && ia(r, i), (d = t.props && t.props.onVnodeUpdated) && ia(() => za(d, s, t, c), i);
			} else {
				let o, { el: s, props: c } = t, { bm: l, m: u, parent: d, root: f, type: p } = e, m = kr(t);
				if (ca(e, !1), l && ce(l), !m && (o = c && c.onVnodeBeforeMount) && za(o, d, t), ca(e, !0), s && Se) {
					let t = () => {
						e.subTree = Ni(e), Se(s, e.subTree, e, i, null);
					};
					m && p.__asyncHydrate ? p.__asyncHydrate(s, e, t) : t();
				} else {
					f.ce && f.ce._hasShadowRoot() && f.ce._injectChildStyle(p, e.parent ? e.parent.type : void 0);
					let o = e.subTree = Ni(e);
					v(null, o, n, r, e, i, a), t.el = o.el;
				}
				if (u && ia(u, i), !m && (o = c && c.onVnodeMounted)) {
					let e = t;
					ia(() => za(o, d, e), i);
				}
				(t.shapeFlag & 256 || d && kr(d.vnode) && d.vnode.shapeFlag & 256) && e.a && ia(e.a, i), e.isMounted = !0, t = n = r = null;
			}
		};
		e.scope.on();
		let c = e.effect = new Ae(s);
		e.scope.off();
		let l = e.update = c.run.bind(c), u = e.job = c.runIfDirty.bind(c);
		u.i = e, u.id = e.uid, c.scheduler = () => Dn(u), ca(e, !0), l();
	}, de = (e, t, n) => {
		t.component = e;
		let r = e.vnode.props;
		e.vnode = t, e.next = null, Wi(e, t.props, r, n), ra(e, t.children, n), Ge(), An(e), Ke();
	}, D = (e, t, n, r, i, a, o, s, c = !1) => {
		let l = e && e.children, u = e ? e.shapeFlag : 0, d = t.children, { patchFlag: f, shapeFlag: m } = t;
		if (f > 0) {
			if (f & 128) {
				me(l, d, n, r, i, a, o, s, c);
				return;
			} else if (f & 256) {
				pe(l, d, n, r, i, a, o, s, c);
				return;
			}
		}
		m & 8 ? (u & 16 && k(l, i, a), d !== l && p(n, d)) : u & 16 ? m & 16 ? me(l, d, n, r, i, a, o, s, c) : k(l, i, a, !0) : (u & 8 && p(n, ""), m & 16 && T(d, n, r, i, a, o, s, c));
	}, pe = (e, t, r, i, a, o, s, c, l) => {
		e ||= n, t ||= n;
		let u = e.length, d = t.length, f = Math.min(u, d), p;
		for (p = 0; p < f; p++) {
			let n = t[p] = l ? Ia(t[p]) : Fa(t[p]);
			v(e[p], n, r, null, a, o, s, c, l);
		}
		u > d ? k(e, a, o, !0, !1, f) : T(t, r, i, a, o, s, c, l, f);
	}, me = (e, t, r, i, a, o, s, c, l) => {
		let u = 0, d = t.length, f = e.length - 1, p = d - 1;
		for (; u <= f && u <= p;) {
			let n = e[u], i = t[u] = l ? Ia(t[u]) : Fa(t[u]);
			if (Da(n, i)) v(n, i, r, null, a, o, s, c, l);
			else break;
			u++;
		}
		for (; u <= f && u <= p;) {
			let n = e[f], i = t[p] = l ? Ia(t[p]) : Fa(t[p]);
			if (Da(n, i)) v(n, i, r, null, a, o, s, c, l);
			else break;
			f--, p--;
		}
		if (u > f) {
			if (u <= p) {
				let e = p + 1, n = e < d ? t[e].el : i;
				for (; u <= p;) v(null, t[u] = l ? Ia(t[u]) : Fa(t[u]), r, n, a, o, s, c, l), u++;
			}
		} else if (u > p) for (; u <= f;) ge(e[u], a, o, !0), u++;
		else {
			let m = u, h = u, g = /* @__PURE__ */ new Map();
			for (u = h; u <= p; u++) {
				let e = t[u] = l ? Ia(t[u]) : Fa(t[u]);
				e.key != null && g.set(e.key, u);
			}
			let _, y = 0, b = p - h + 1, x = !1, S = 0, C = Array(b);
			for (u = 0; u < b; u++) C[u] = 0;
			for (u = m; u <= f; u++) {
				let n = e[u];
				if (y >= b) {
					ge(n, a, o, !0);
					continue;
				}
				let i;
				if (n.key != null) i = g.get(n.key);
				else for (_ = h; _ <= p; _++) if (C[_ - h] === 0 && Da(n, t[_])) {
					i = _;
					break;
				}
				i === void 0 ? ge(n, a, o, !0) : (C[i - h] = u + 1, i >= S ? S = i : x = !0, v(n, t[i], r, null, a, o, s, c, l), y++);
			}
			let w = x ? da(C) : n;
			for (_ = w.length - 1, u = b - 1; u >= 0; u--) {
				let e = h + u, n = t[e], f = t[e + 1], p = e + 1 < d ? f.el || ma(f) : i;
				C[u] === 0 ? v(null, n, r, p, a, o, s, c, l) : x && (_ < 0 || u !== w[_] ? he(n, r, p, 2) : _--);
			}
		}
	}, he = (e, t, n, r, i = null) => {
		let { el: a, type: c, transition: l, children: u, shapeFlag: d } = e;
		if (d & 6) {
			he(e.component.subTree, t, n, r);
			return;
		}
		if (d & 128) {
			e.suspense.move(t, n, r);
			return;
		}
		if (d & 64) {
			c.move(e, t, n, xe);
			return;
		}
		if (c === B) {
			o(a, t, n);
			for (let e = 0; e < u.length; e++) he(u[e], t, n, r);
			o(e.anchor, t, n);
			return;
		}
		if (c === ya) {
			S(e, t, n);
			return;
		}
		if (r !== 2 && d & 1 && l) if (r === 0) l.persisted && !a[lr] ? o(a, t, n) : (l.beforeEnter(a), o(a, t, n), ia(() => l.enter(a), i));
		else {
			let { leave: r, delayLeave: i, afterLeave: c } = l, u = () => {
				e.ctx.isUnmounted ? s(a) : o(a, t, n);
			}, d = () => {
				let e = a._isLeaving || !!a[lr];
				a._isLeaving && a[lr](!0), l.persisted && !e ? u() : r(a, () => {
					u(), c && c();
				});
			};
			i ? i(a, u, d) : d();
		}
		else o(a, t, n);
	}, ge = (e, t, n, r = !1, i = !1) => {
		let { type: a, props: o, ref: s, children: c, dynamicChildren: l, shapeFlag: u, patchFlag: d, dirs: f, cacheIndex: p, memo: m } = e;
		if (d === -2 && (i = !1), s != null && (Ge(), Dr(s, null, n, e, !0), Ke()), p != null && (t.renderCache[p] = void 0), u & 256) {
			t.ctx.deactivate(e);
			return;
		}
		let h = u & 1 && f, g = !kr(e), _;
		if (g && (_ = o && o.onVnodeBeforeUnmount) && za(_, t, e), u & 6) ve(e.component, n, r);
		else {
			if (u & 128) {
				e.suspense.unmount(n, r);
				return;
			}
			h && Rn(e, null, t, "beforeUnmount"), u & 64 ? e.type.remove(e, t, n, xe, r) : l && !l.hasOnce && (a !== B || d > 0 && d & 64) ? k(l, t, n, !1, !0) : (a === B && d & 384 || !i && u & 16) && k(c, t, n), r && O(e);
		}
		let v = m != null && p == null;
		(g && (_ = o && o.onVnodeUnmounted) || h || v) && ia(() => {
			_ && za(_, t, e), h && Rn(e, null, t, "unmounted"), v && (e.el = null);
		}, n);
	}, O = (e) => {
		let { type: t, el: n, anchor: r, transition: i } = e;
		if (t === B) {
			_e(n, r);
			return;
		}
		if (t === ya) {
			C(e);
			return;
		}
		let a = () => {
			s(n), i && !i.persisted && i.afterLeave && i.afterLeave();
		};
		if (e.shapeFlag & 1 && i && !i.persisted) {
			let { leave: t, delayLeave: r } = i, o = () => t(n, a);
			r ? r(e.el, a, o) : o();
		} else a();
	}, _e = (e, t) => {
		let n;
		for (; e !== t;) n = h(e), s(e), e = n;
		s(t);
	}, ve = (e, t, n) => {
		let { bum: r, scope: i, job: a, subTree: o, um: s, m: c, a: l } = e;
		pa(c), pa(l), r && ce(r), i.stop(), a && (a.flags |= 8, ge(o, e, t, n)), s && ia(s, t), ia(() => {
			e.isUnmounted = !0;
		}, t);
	}, k = (e, t, n, r = !1, i = !1, a = 0) => {
		for (let o = a; o < e.length; o++) ge(e[o], t, n, r, i);
	}, ye = (e) => {
		if (e.shapeFlag & 6) return ye(e.component.subTree);
		if (e.shapeFlag & 128) return e.suspense.next();
		let t = h(e.anchor || e.el), n = t && t[Xn];
		return n ? h(n) : t;
	}, A = !1, be = (e, t, n) => {
		let r;
		e == null ? t._vnode && (ge(t._vnode, null, null, !0), r = t._vnode.component) : v(t._vnode || null, e, t, null, null, null, n), t._vnode = e, A ||= (A = !0, An(r), jn(), !1);
	}, xe = {
		p: v,
		um: ge,
		m: he,
		r: O,
		mt: le,
		mc: T,
		pc: D,
		pbc: ie,
		n: ye,
		o: e
	}, j, Se;
	return i && ([j, Se] = i(xe)), {
		render: be,
		hydrate: j,
		createApp: Ti(be, j)
	};
}
function sa({ type: e, props: t }, n) {
	return n === "svg" && e === "foreignObject" || n === "mathml" && e === "annotation-xml" && t && t.encoding && t.encoding.includes("html") ? void 0 : n;
}
function ca({ effect: e, job: t }, n) {
	n ? (e.flags |= 32, t.flags |= 4) : (e.flags &= -33, t.flags &= -5);
}
function la(e, t) {
	return (!e || e && !e.pendingBranch) && t && !t.persisted;
}
function ua(e, t, n = !1) {
	let r = e.children, i = t.children;
	if (d(r) && d(i)) for (let e = 0; e < r.length; e++) {
		let t = r[e], a = i[e];
		a.shapeFlag & 1 && !a.dynamicChildren && ((a.patchFlag <= 0 || a.patchFlag === 32) && (a = i[e] = Ia(i[e]), a.el = t.el), !n && a.patchFlag !== -2 && ua(t, a)), a.type === _a && (a.patchFlag === -1 && (a = i[e] = Ia(a)), a.el = t.el), a.type === va && !a.el && (a.el = t.el);
	}
}
function da(e) {
	let t = e.slice(), n = [0], r, i, a, o, s, c = e.length;
	for (r = 0; r < c; r++) {
		let c = e[r];
		if (c !== 0) {
			if (i = n[n.length - 1], e[i] < c) {
				t[r] = i, n.push(r);
				continue;
			}
			for (a = 0, o = n.length - 1; a < o;) s = a + o >> 1, e[n[s]] < c ? a = s + 1 : o = s;
			c < e[n[a]] && (a > 0 && (t[r] = n[a - 1]), n[a] = r);
		}
	}
	for (a = n.length, o = n[a - 1]; a-- > 0;) n[a] = o, o = t[o];
	return n;
}
function fa(e) {
	let t = e.subTree.component;
	if (t) return t.asyncDep && !t.asyncResolved ? t : fa(t);
}
function pa(e) {
	if (e) for (let t = 0; t < e.length; t++) e[t].flags |= 8;
}
function ma(e) {
	if (e.placeholder) return e.placeholder;
	let t = e.component;
	return t ? ma(t.subTree) : null;
}
var ha = (e) => e.__isSuspense;
function ga(e, t) {
	t && t.pendingBranch ? d(e) ? t.effects.push(...e) : t.effects.push(e) : kn(e);
}
var B = /* @__PURE__ */ Symbol.for("v-fgt"), _a = /* @__PURE__ */ Symbol.for("v-txt"), va = /* @__PURE__ */ Symbol.for("v-cmt"), ya = /* @__PURE__ */ Symbol.for("v-stc"), ba = [], xa = null;
function V(e = !1) {
	ba.push(xa = e ? null : []);
}
function Sa() {
	ba.pop(), xa = ba[ba.length - 1] || null;
}
var Ca = 1;
function wa(e, t = !1) {
	Ca += e, e < 0 && xa && t && (xa.hasOnce = !0);
}
function Ta(e) {
	return e.dynamicChildren = Ca > 0 ? xa || n : null, Sa(), Ca > 0 && xa && xa.push(e), e;
}
function H(e, t, n, r, i, a) {
	return Ta(W(e, t, n, r, i, a, !0));
}
function U(e, t, n, r, i) {
	return Ta(G(e, t, n, r, i, !0));
}
function Ea(e) {
	return e ? e.__v_isVNode === !0 : !1;
}
function Da(e, t) {
	return e.type === t.type && e.key === t.key;
}
var Oa = ({ key: e }) => e ?? null, ka = ({ ref: e, ref_key: t, ref_for: n }) => (typeof e == "number" && (e = "" + e), e == null ? null : g(e) || /* @__PURE__ */ Jt(e) || h(e) ? {
	i: Pn,
	r: e,
	k: t,
	f: !!n
} : e);
function W(e, t = null, n = null, r = 0, i = null, a = e === B ? 0 : 1, o = !1, s = !1) {
	let c = {
		__v_isVNode: !0,
		__v_skip: !0,
		type: e,
		props: t,
		key: t && Oa(t),
		ref: t && ka(t),
		scopeId: Fn,
		slotScopeIds: null,
		children: n,
		component: null,
		suspense: null,
		ssContent: null,
		ssFallback: null,
		dirs: null,
		transition: null,
		el: null,
		anchor: null,
		target: null,
		targetStart: null,
		targetAnchor: null,
		staticCount: 0,
		shapeFlag: a,
		patchFlag: r,
		dynamicProps: i,
		dynamicChildren: null,
		appContext: null,
		ctx: Pn
	};
	return s ? (La(c, n), a & 128 && e.normalize(c)) : n && (c.shapeFlag |= g(n) ? 8 : 16), Ca > 0 && !o && xa && (c.patchFlag > 0 || a & 6) && c.patchFlag !== 32 && xa.push(c), c;
}
var G = Aa;
function Aa(e, t = null, n = null, r = 0, i = null, a = !1) {
	if ((!e || e === Yr) && (e = va), Ea(e)) {
		let r = Ma(e, t, !0);
		return n && La(r, n), Ca > 0 && !a && xa && (r.shapeFlag & 6 ? xa[xa.indexOf(e)] = r : xa.push(r)), r.patchFlag = -2, r;
	}
	if (so(e) && (e = e.__vccOpts), t) {
		t = ja(t);
		let { class: e, style: n } = t;
		e && !g(e) && (t.class = O(e)), v(n) && (/* @__PURE__ */ Wt(n) && !d(n) && (n = s({}, n)), t.style = D(n));
	}
	let o = g(e) ? 1 : ha(e) ? 128 : Zn(e) ? 64 : v(e) ? 4 : h(e) ? 2 : 0;
	return W(e, t, n, r, i, o, a, !0);
}
function ja(e) {
	return e ? /* @__PURE__ */ Wt(e) || Hi(e) ? s({}, e) : e : null;
}
function Ma(e, t, n = !1, r = !1) {
	let { props: i, ref: a, patchFlag: o, children: s, transition: c } = e, l = t ? Ra(i || {}, t) : i, u = {
		__v_isVNode: !0,
		__v_skip: !0,
		type: e.type,
		props: l,
		key: l && Oa(l),
		ref: t && t.ref ? n && a ? d(a) ? a.concat(ka(t)) : [a, ka(t)] : ka(t) : a,
		scopeId: e.scopeId,
		slotScopeIds: e.slotScopeIds,
		children: s,
		target: e.target,
		targetStart: e.targetStart,
		targetAnchor: e.targetAnchor,
		staticCount: e.staticCount,
		shapeFlag: e.shapeFlag,
		patchFlag: t && e.type !== B ? o === -1 ? 16 : o | 16 : o,
		dynamicProps: e.dynamicProps,
		dynamicChildren: e.dynamicChildren,
		appContext: e.appContext,
		dirs: e.dirs,
		transition: c,
		component: e.component,
		suspense: e.suspense,
		ssContent: e.ssContent && Ma(e.ssContent),
		ssFallback: e.ssFallback && Ma(e.ssFallback),
		placeholder: e.placeholder,
		el: e.el,
		anchor: e.anchor,
		ctx: e.ctx,
		ce: e.ce
	};
	return c && r && Sr(u, c.clone(u)), u;
}
function Na(e = " ", t = 0) {
	return G(_a, null, e, t);
}
function Pa(e, t) {
	let n = G(ya, null, e);
	return n.staticCount = t, n;
}
function K(e = "", t = !1) {
	return t ? (V(), U(va, null, e)) : G(va, null, e);
}
function Fa(e) {
	return e == null || typeof e == "boolean" ? G(va) : d(e) ? G(B, null, e.slice()) : Ea(e) ? Ia(e) : G(_a, null, String(e));
}
function Ia(e) {
	return e.el === null && e.patchFlag !== -1 || e.memo ? e : Ma(e);
}
function La(e, t) {
	let n = 0, { shapeFlag: r } = e;
	if (t == null) t = null;
	else if (d(t)) n = 16;
	else if (typeof t == "object") if (r & 65) {
		let n = t.default;
		n && (n._c && (n._d = !1), La(e, n()), n._c && (n._d = !0));
		return;
	} else {
		n = 32;
		let r = t._;
		!r && !Hi(t) ? t._ctx = Pn : r === 3 && Pn && (Pn.slots._ === 1 ? t._ = 1 : (t._ = 2, e.patchFlag |= 1024));
	}
	else h(t) ? (t = {
		default: t,
		_ctx: Pn
	}, n = 32) : (t = String(t), r & 64 ? (n = 16, t = [Na(t)]) : n = 8);
	e.children = t, e.shapeFlag |= n;
}
function Ra(...e) {
	let t = {};
	for (let n = 0; n < e.length; n++) {
		let r = e[n];
		for (let e in r) if (e === "class") t.class !== r.class && (t.class = O([t.class, r.class]));
		else if (e === "style") t.style = D([t.style, r.style]);
		else if (a(e)) {
			let n = t[e], i = r[e];
			i && n !== i && !(d(n) && n.includes(i)) ? t[e] = n ? [].concat(n, i) : i : i == null && n == null && !o(e) && (t[e] = i);
		} else e !== "" && (t[e] = r[e]);
	}
	return t;
}
function za(e, t, n, r = null) {
	hn(e, t, 7, [n, r]);
}
var Ba = Ci(), Va = 0;
function Ha(e, n, r) {
	let i = e.type, a = (n ? n.appContext : e.appContext) || Ba, o = {
		uid: Va++,
		vnode: e,
		type: i,
		parent: n,
		appContext: a,
		root: null,
		next: null,
		subTree: null,
		effect: null,
		update: null,
		job: null,
		scope: new Te(!0),
		render: null,
		proxy: null,
		exposed: null,
		exposeProxy: null,
		withProxy: null,
		provides: n ? n.provides : Object.create(a.provides),
		ids: n ? n.ids : [
			"",
			0,
			0
		],
		accessCache: null,
		renderCache: [],
		components: null,
		directives: null,
		propsOptions: Ji(i, a),
		emitsOptions: ji(i, a),
		emit: null,
		emitted: null,
		propsDefaults: t,
		inheritAttrs: i.inheritAttrs,
		ctx: t,
		data: t,
		props: t,
		attrs: t,
		slots: t,
		refs: t,
		setupState: t,
		setupContext: null,
		suspense: r,
		suspenseId: r ? r.pendingId : 0,
		asyncDep: null,
		asyncResolved: !1,
		isMounted: !1,
		isUnmounted: !1,
		isDeactivated: !1,
		bc: null,
		c: null,
		bm: null,
		m: null,
		bu: null,
		u: null,
		um: null,
		bum: null,
		da: null,
		a: null,
		rtg: null,
		rtc: null,
		ec: null,
		sp: null
	};
	return o.ctx = { _: o }, o.root = n ? n.root : o, o.emit = ki.bind(null, o), e.ce && e.ce(o), o;
}
var Ua = null, Wa = () => Ua || Pn, Ga, Ka;
{
	let e = fe(), t = (t, n) => {
		let r;
		return (r = e[t]) || (r = e[t] = []), r.push(n), (e) => {
			r.length > 1 ? r.forEach((t) => t(e)) : r[0](e);
		};
	};
	Ga = t("__VUE_INSTANCE_SETTERS__", (e) => Ua = e), Ka = t("__VUE_SSR_SETTERS__", (e) => Xa = e);
}
var qa = (e) => {
	let t = Ua;
	return Ga(e), e.scope.on(), () => {
		e.scope.off(), Ga(t);
	};
}, Ja = () => {
	Ua && Ua.scope.off(), Ga(null);
};
function Ya(e) {
	return e.vnode.shapeFlag & 4;
}
var Xa = !1;
function Za(e, t = !1, n = !1) {
	t && Ka(t);
	let { props: r, children: i } = e.vnode, a = Ya(e);
	Ui(e, r, a, t), na(e, i, n || t);
	let o = a ? Qa(e, t) : void 0;
	return t && Ka(!1), o;
}
function Qa(e, t) {
	let n = e.type;
	e.accessCache = /* @__PURE__ */ Object.create(null), e.proxy = new Proxy(e.ctx, ai);
	let { setup: r } = n;
	if (r) {
		Ge();
		let n = e.setupContext = r.length > 1 ? io(e) : null, i = qa(e), a = mn(r, e, 0, [e.props, n]), o = y(a);
		if (Ke(), i(), (o || e.sp) && !kr(e) && wr(e), o) {
			if (a.then(Ja, Ja), t) return a.then((n) => {
				$a(e, n, t);
			}).catch((t) => {
				gn(t, e, 0);
			});
			e.asyncDep = a;
		} else $a(e, a, t);
	} else no(e, t);
}
function $a(e, t, n) {
	h(t) ? e.type.__ssrInlineRender ? e.ssrRender = t : e.render = t : v(t) && (e.setupState = Qt(t)), no(e, n);
}
var eo, to;
function no(e, t, n) {
	let i = e.type;
	if (!e.render) {
		if (!t && eo && !i.render) {
			let t = i.template || pi(e).template;
			if (t) {
				let { isCustomElement: n, compilerOptions: r } = e.appContext.config, { delimiters: a, compilerOptions: o } = i;
				i.render = eo(t, s(s({
					isCustomElement: n,
					delimiters: a
				}, r), o));
			}
		}
		e.render = i.render || r, to && to(e);
	}
	{
		let t = qa(e);
		Ge();
		try {
			li(e);
		} finally {
			Ke(), t();
		}
	}
}
var ro = { get(e, t) {
	return nt(e, "get", ""), e[t];
} };
function io(e) {
	return {
		attrs: new Proxy(e.attrs, ro),
		slots: e.slots,
		emit: e.emit,
		expose: (t) => {
			e.exposed = t || {};
		}
	};
}
function ao(e) {
	return e.exposed ? e.exposeProxy ||= new Proxy(Qt(Gt(e.exposed)), {
		get(t, n) {
			if (n in t) return t[n];
			if (n in ri) return ri[n](e);
		},
		has(e, t) {
			return t in e || t in ri;
		}
	}) : e.proxy;
}
function oo(e, t = !0) {
	return h(e) ? e.displayName || e.name : e.name || t && e.__name;
}
function so(e) {
	return h(e) && "__vccOpts" in e;
}
var q = (e, t) => /* @__PURE__ */ sn(e, t, Xa);
function co(e, t, n) {
	try {
		wa(-1);
		let r = arguments.length;
		return r === 2 ? v(t) && !d(t) ? Ea(t) ? G(e, null, [t]) : G(e, t) : G(e, null, t) : (r > 3 ? n = Array.prototype.slice.call(arguments, 2) : r === 3 && Ea(n) && (n = [n]), G(e, t, n));
	} finally {
		wa(1);
	}
}
var lo = "3.5.35", uo = void 0, fo = typeof window < "u" && window.trustedTypes;
if (fo) try {
	uo = /* @__PURE__ */ fo.createPolicy("vue", { createHTML: (e) => e });
} catch {}
var po = uo ? (e) => uo.createHTML(e) : (e) => e, mo = "http://www.w3.org/2000/svg", ho = "http://www.w3.org/1998/Math/MathML", go = typeof document < "u" ? document : null, _o = go && /* @__PURE__ */ go.createElement("template"), vo = {
	insert: (e, t, n) => {
		t.insertBefore(e, n || null);
	},
	remove: (e) => {
		let t = e.parentNode;
		t && t.removeChild(e);
	},
	createElement: (e, t, n, r) => {
		let i = t === "svg" ? go.createElementNS(mo, e) : t === "mathml" ? go.createElementNS(ho, e) : n ? go.createElement(e, { is: n }) : go.createElement(e);
		return e === "select" && r && r.multiple != null && i.setAttribute("multiple", r.multiple), i;
	},
	createText: (e) => go.createTextNode(e),
	createComment: (e) => go.createComment(e),
	setText: (e, t) => {
		e.nodeValue = t;
	},
	setElementText: (e, t) => {
		e.textContent = t;
	},
	parentNode: (e) => e.parentNode,
	nextSibling: (e) => e.nextSibling,
	querySelector: (e) => go.querySelector(e),
	setScopeId(e, t) {
		e.setAttribute(t, "");
	},
	insertStaticContent(e, t, n, r, i, a) {
		let o = n ? n.previousSibling : t.lastChild;
		if (i && (i === a || i.nextSibling)) for (; t.insertBefore(i.cloneNode(!0), n), !(i === a || !(i = i.nextSibling)););
		else {
			_o.innerHTML = po(r === "svg" ? `<svg>${e}</svg>` : r === "mathml" ? `<math>${e}</math>` : e);
			let i = _o.content;
			if (r === "svg" || r === "mathml") {
				let e = i.firstChild;
				for (; e.firstChild;) i.appendChild(e.firstChild);
				i.removeChild(e);
			}
			t.insertBefore(i, n);
		}
		return [o ? o.nextSibling : t.firstChild, n ? n.previousSibling : t.lastChild];
	}
}, yo = "transition", bo = "animation", xo = /* @__PURE__ */ Symbol("_vtc"), So = {
	name: String,
	type: String,
	css: {
		type: Boolean,
		default: !0
	},
	duration: [
		String,
		Number,
		Object
	],
	enterFromClass: String,
	enterActiveClass: String,
	enterToClass: String,
	appearFromClass: String,
	appearActiveClass: String,
	appearToClass: String,
	leaveFromClass: String,
	leaveActiveClass: String,
	leaveToClass: String
}, Co = /* @__PURE__ */ s({}, pr, So), wo = /* @__PURE__ */ ((e) => (e.displayName = "Transition", e.props = Co, e))((e, { slots: t }) => co(_r, Do(e), t)), To = (e, t = []) => {
	d(e) ? e.forEach((e) => e(...t)) : e && e(...t);
}, Eo = (e) => e ? d(e) ? e.some((e) => e.length > 1) : e.length > 1 : !1;
function Do(e) {
	let t = {};
	for (let n in e) n in So || (t[n] = e[n]);
	if (e.css === !1) return t;
	let { name: n = "v", type: r, duration: i, enterFromClass: a = `${n}-enter-from`, enterActiveClass: o = `${n}-enter-active`, enterToClass: c = `${n}-enter-to`, appearFromClass: l = a, appearActiveClass: u = o, appearToClass: d = c, leaveFromClass: f = `${n}-leave-from`, leaveActiveClass: p = `${n}-leave-active`, leaveToClass: m = `${n}-leave-to` } = e, h = Oo(i), g = h && h[0], _ = h && h[1], { onBeforeEnter: v, onEnter: y, onEnterCancelled: b, onLeave: x, onLeaveCancelled: S, onBeforeAppear: C = v, onAppear: w = y, onAppearCancelled: ee = b } = t, te = (e, t, n, r) => {
		e._enterCancelled = r, jo(e, t ? d : c), jo(e, t ? u : o), n && n();
	}, ne = (e, t) => {
		e._isLeaving = !1, jo(e, f), jo(e, m), jo(e, p), t && t();
	}, T = (e) => (t, n) => {
		let i = e ? w : y, o = () => te(t, e, n);
		To(i, [t, o]), Mo(() => {
			jo(t, e ? l : a), Ao(t, e ? d : c), Eo(i) || Po(t, r, g, o);
		});
	};
	return s(t, {
		onBeforeEnter(e) {
			To(v, [e]), Ao(e, a), Ao(e, o);
		},
		onBeforeAppear(e) {
			To(C, [e]), Ao(e, l), Ao(e, u);
		},
		onEnter: T(!1),
		onAppear: T(!0),
		onLeave(e, t) {
			e._isLeaving = !0;
			let n = () => ne(e, t);
			Ao(e, f), e._enterCancelled ? (Ao(e, p), Ro(e)) : (Ro(e), Ao(e, p)), Mo(() => {
				e._isLeaving && (jo(e, f), Ao(e, m), Eo(x) || Po(e, r, _, n));
			}), To(x, [e, n]);
		},
		onEnterCancelled(e) {
			te(e, !1, void 0, !0), To(b, [e]);
		},
		onAppearCancelled(e) {
			te(e, !0, void 0, !0), To(ee, [e]);
		},
		onLeaveCancelled(e) {
			ne(e), To(S, [e]);
		}
	});
}
function Oo(e) {
	if (e == null) return null;
	if (v(e)) return [ko(e.enter), ko(e.leave)];
	{
		let t = ko(e);
		return [t, t];
	}
}
function ko(e) {
	return ue(e);
}
function Ao(e, t) {
	t.split(/\s+/).forEach((t) => t && e.classList.add(t)), (e[xo] || (e[xo] = /* @__PURE__ */ new Set())).add(t);
}
function jo(e, t) {
	t.split(/\s+/).forEach((t) => t && e.classList.remove(t));
	let n = e[xo];
	n && (n.delete(t), n.size || (e[xo] = void 0));
}
function Mo(e) {
	requestAnimationFrame(() => {
		requestAnimationFrame(e);
	});
}
var No = 0;
function Po(e, t, n, r) {
	let i = e._endId = ++No, a = () => {
		i === e._endId && r();
	};
	if (n != null) return setTimeout(a, n);
	let { type: o, timeout: s, propCount: c } = Fo(e, t);
	if (!o) return r();
	let l = o + "end", u = 0, d = () => {
		e.removeEventListener(l, f), a();
	}, f = (t) => {
		t.target === e && ++u >= c && d();
	};
	setTimeout(() => {
		u < c && d();
	}, s + 1), e.addEventListener(l, f);
}
function Fo(e, t) {
	let n = window.getComputedStyle(e), r = (e) => (n[e] || "").split(", "), i = r(`${yo}Delay`), a = r(`${yo}Duration`), o = Io(i, a), s = r(`${bo}Delay`), c = r(`${bo}Duration`), l = Io(s, c), u = null, d = 0, f = 0;
	t === yo ? o > 0 && (u = yo, d = o, f = a.length) : t === bo ? l > 0 && (u = bo, d = l, f = c.length) : (d = Math.max(o, l), u = d > 0 ? o > l ? yo : bo : null, f = u ? u === yo ? a.length : c.length : 0);
	let p = u === yo && /\b(?:transform|all)(?:,|$)/.test(r(`${yo}Property`).toString());
	return {
		type: u,
		timeout: d,
		propCount: f,
		hasTransform: p
	};
}
function Io(e, t) {
	for (; e.length < t.length;) e = e.concat(e);
	return Math.max(...t.map((t, n) => Lo(t) + Lo(e[n])));
}
function Lo(e) {
	return e === "auto" ? 0 : Number(e.slice(0, -1).replace(",", ".")) * 1e3;
}
function Ro(e) {
	return (e ? e.ownerDocument : document).body.offsetHeight;
}
function zo(e, t, n) {
	let r = e[xo];
	r && (t = (t ? [t, ...r] : [...r]).join(" ")), t == null ? e.removeAttribute("class") : n ? e.setAttribute("class", t) : e.className = t;
}
var Bo = /* @__PURE__ */ Symbol("_vod"), Vo = /* @__PURE__ */ Symbol("_vsh"), Ho = /* @__PURE__ */ Symbol(""), Uo = /(?:^|;)\s*display\s*:/;
function Wo(e, t, n) {
	let r = e.style, i = g(n), a = !1;
	if (n && !i) {
		if (t) if (g(t)) for (let e of t.split(";")) {
			let t = e.slice(0, e.indexOf(":")).trim();
			n[t] ?? Ko(r, t, "");
		}
		else for (let e in t) n[e] ?? Ko(r, e, "");
		for (let i in n) {
			i === "display" && (a = !0);
			let o = n[i];
			o == null ? Ko(r, i, "") : Xo(e, i, !g(t) && t ? t[i] : void 0, o) || Ko(r, i, o);
		}
	} else if (i) {
		if (t !== n) {
			let e = r[Ho];
			e && (n += ";" + e), r.cssText = n, a = Uo.test(n);
		}
	} else t && e.removeAttribute("style");
	Bo in e && (e[Bo] = a ? r.display : "", e[Vo] && (r.display = "none"));
}
var Go = /\s*!important$/;
function Ko(e, t, n) {
	if (d(n)) n.forEach((n) => Ko(e, t, n));
	else if (n ??= "", t.startsWith("--")) e.setProperty(t, n);
	else {
		let r = Yo(e, t);
		Go.test(n) ? e.setProperty(ie(r), n.replace(Go, ""), "important") : e[r] = n;
	}
}
var qo = [
	"Webkit",
	"Moz",
	"ms"
], Jo = {};
function Yo(e, t) {
	let n = Jo[t];
	if (n) return n;
	let r = T(t);
	if (r !== "filter" && r in e) return Jo[t] = r;
	r = ae(r);
	for (let n = 0; n < qo.length; n++) {
		let i = qo[n] + r;
		if (i in e) return Jo[t] = i;
	}
	return t;
}
function Xo(e, t, n, r) {
	return e.tagName === "TEXTAREA" && (t === "width" || t === "height") && g(r) && n === r;
}
var Zo = "http://www.w3.org/1999/xlink";
function Qo(e, t, n, r, i, a = ve(t)) {
	r && t.startsWith("xlink:") ? n == null ? e.removeAttributeNS(Zo, t.slice(6, t.length)) : e.setAttributeNS(Zo, t, n) : n == null || a && !k(n) ? e.removeAttribute(t) : e.setAttribute(t, a ? "" : _(n) ? String(n) : n);
}
function $o(e, t, n, r, i) {
	if (t === "innerHTML" || t === "textContent") {
		n != null && (e[t] = t === "innerHTML" ? po(n) : n);
		return;
	}
	let a = e.tagName;
	if (t === "value" && a !== "PROGRESS" && !a.includes("-")) {
		let r = a === "OPTION" ? e.getAttribute("value") || "" : e.value, i = n == null ? e.type === "checkbox" ? "on" : "" : String(n);
		(r !== i || !("_value" in e)) && (e.value = i), n ?? e.removeAttribute(t), e._value = n;
		return;
	}
	let o = !1;
	if (n === "" || n == null) {
		let r = typeof e[t];
		r === "boolean" ? n = k(n) : n == null && r === "string" ? (n = "", o = !0) : r === "number" && (n = 0, o = !0);
	}
	try {
		e[t] = n;
	} catch {}
	o && e.removeAttribute(i || t);
}
function es(e, t, n, r) {
	e.addEventListener(t, n, r);
}
function ts(e, t, n, r) {
	e.removeEventListener(t, n, r);
}
var ns = /* @__PURE__ */ Symbol("_vei");
function rs(e, t, n, r, i = null) {
	let a = e[ns] || (e[ns] = {}), o = a[t];
	if (r && o) o.value = r;
	else {
		let [n, s] = as(t);
		r ? es(e, n, a[t] = ls(r, i), s) : o && (ts(e, n, o, s), a[t] = void 0);
	}
}
var is = /(?:Once|Passive|Capture)$/;
function as(e) {
	let t;
	if (is.test(e)) {
		t = {};
		let n;
		for (; n = e.match(is);) e = e.slice(0, e.length - n[0].length), t[n[0].toLowerCase()] = !0;
	}
	return [e[2] === ":" ? e.slice(3) : ie(e.slice(2)), t];
}
var os = 0, ss = /* @__PURE__ */ Promise.resolve(), cs = () => os ||= (ss.then(() => os = 0), Date.now());
function ls(e, t) {
	let n = (e) => {
		if (!e._vts) e._vts = Date.now();
		else if (e._vts <= n.attached) return;
		let r = n.value;
		if (d(r)) {
			let n = e.stopImmediatePropagation;
			e.stopImmediatePropagation = () => {
				n.call(e), e._stopped = !0;
			};
			let i = r.slice(), a = [e];
			for (let n = 0; n < i.length && !e._stopped; n++) {
				let e = i[n];
				e && hn(e, t, 5, a);
			}
		} else hn(r, t, 5, [e]);
	};
	return n.value = e, n.attached = cs(), n;
}
var us = (e) => e.charCodeAt(0) === 111 && e.charCodeAt(1) === 110 && e.charCodeAt(2) > 96 && e.charCodeAt(2) < 123, ds = (e, t, n, r, i, s) => {
	let c = i === "svg";
	t === "class" ? zo(e, r, c) : t === "style" ? Wo(e, n, r) : a(t) ? o(t) || rs(e, t, n, r, s) : (t[0] === "." ? (t = t.slice(1), !0) : t[0] === "^" ? (t = t.slice(1), !1) : fs(e, t, r, c)) ? ($o(e, t, r), !e.tagName.includes("-") && (t === "value" || t === "checked" || t === "selected") && Qo(e, t, r, c, s, t !== "value")) : e._isVueCE && (ps(e, t) || e._def.__asyncLoader && (/[A-Z]/.test(t) || !g(r))) ? $o(e, T(t), r, s, t) : (t === "true-value" ? e._trueValue = r : t === "false-value" && (e._falseValue = r), Qo(e, t, r, c));
};
function fs(e, t, n, r) {
	if (r) return !!(t === "innerHTML" || t === "textContent" || t in e && us(t) && h(n));
	if (t === "spellcheck" || t === "draggable" || t === "translate" || t === "autocorrect" || t === "sandbox" && e.tagName === "IFRAME" || t === "form" || t === "list" && e.tagName === "INPUT" || t === "type" && e.tagName === "TEXTAREA") return !1;
	if (t === "width" || t === "height") {
		let t = e.tagName;
		if (t === "IMG" || t === "VIDEO" || t === "CANVAS" || t === "SOURCE") return !1;
	}
	return us(t) && g(n) ? !1 : t in e;
}
function ps(e, t) {
	let n = e._def.props;
	if (!n) return !1;
	let r = T(t);
	return Array.isArray(n) ? n.some((e) => T(e) === r) : Object.keys(n).some((e) => T(e) === r);
}
var ms = /* @__PURE__ */ new WeakMap(), hs = /* @__PURE__ */ new WeakMap(), gs = /* @__PURE__ */ Symbol("_moveCb"), _s = /* @__PURE__ */ Symbol("_enterCb"), vs = /* @__PURE__ */ ((e) => (delete e.props.mode, e))({
	name: "TransitionGroup",
	props: /* @__PURE__ */ s({}, Co, {
		tag: String,
		moveClass: String
	}),
	setup(e, { slots: t }) {
		let n = Wa(), r = dr(), i, a;
		return Br(() => {
			if (!i.length) return;
			let t = e.moveClass || `${e.name || "v"}-move`;
			if (!Cs(i[0].el, n.vnode.el, t)) {
				i = [];
				return;
			}
			i.forEach(ys), i.forEach(bs);
			let r = i.filter(xs);
			Ro(n.vnode.el), r.forEach((e) => {
				let n = e.el, r = n.style;
				Ao(n, t), r.transform = r.webkitTransform = r.transitionDuration = "";
				let i = n[gs] = (e) => {
					e && e.target !== n || (!e || e.propertyName.endsWith("transform")) && (n.removeEventListener("transitionend", i), n[gs] = null, jo(n, t));
				};
				n.addEventListener("transitionend", i);
			}), i = [];
		}), () => {
			let o = /* @__PURE__ */ P(e), s = Do(o), c = o.tag || B;
			if (i = [], a) for (let e = 0; e < a.length; e++) {
				let t = a[e];
				t.el && t.el instanceof Element && (i.push(t), Sr(t, yr(t, s, r, n)), ms.set(t, Ss(t.el)));
			}
			a = t.default ? Cr(t.default()) : [];
			for (let e = 0; e < a.length; e++) {
				let t = a[e];
				t.key != null && Sr(t, yr(t, s, r, n));
			}
			return G(c, null, a);
		};
	}
});
function ys(e) {
	let t = e.el;
	t[gs] && t[gs](), t[_s] && t[_s]();
}
function bs(e) {
	hs.set(e, Ss(e.el));
}
function xs(e) {
	let t = ms.get(e), n = hs.get(e), r = t.left - n.left, i = t.top - n.top;
	if (r || i) {
		let t = e.el, n = t.style, a = t.getBoundingClientRect(), o = 1, s = 1;
		return t.offsetWidth && (o = a.width / t.offsetWidth), t.offsetHeight && (s = a.height / t.offsetHeight), (!Number.isFinite(o) || o === 0) && (o = 1), (!Number.isFinite(s) || s === 0) && (s = 1), Math.abs(o - 1) < .01 && (o = 1), Math.abs(s - 1) < .01 && (s = 1), n.transform = n.webkitTransform = `translate(${r / o}px,${i / s}px)`, n.transitionDuration = "0s", e;
	}
}
function Ss(e) {
	let t = e.getBoundingClientRect();
	return {
		left: t.left,
		top: t.top
	};
}
function Cs(e, t, n) {
	let r = e.cloneNode(), i = e[xo];
	i && i.forEach((e) => {
		e.split(/\s+/).forEach((e) => e && r.classList.remove(e));
	}), n.split(/\s+/).forEach((e) => e && r.classList.add(e)), r.style.display = "none";
	let a = t.nodeType === 1 ? t : t.parentNode;
	a.appendChild(r);
	let { hasTransform: o } = Fo(r);
	return a.removeChild(r), o;
}
var ws = (e) => {
	let t = e.props["onUpdate:modelValue"] || !1;
	return d(t) ? (e) => ce(t, e) : t;
};
function Ts(e) {
	e.target.composing = !0;
}
function Es(e) {
	let t = e.target;
	t.composing && (t.composing = !1, t.dispatchEvent(new Event("input")));
}
var Ds = /* @__PURE__ */ Symbol("_assign");
function Os(e, t, n) {
	return t && (e = e.trim()), n && (e = E(e)), e;
}
var ks = {
	created(e, { modifiers: { lazy: t, trim: n, number: r } }, i) {
		e[Ds] = ws(i);
		let a = r || i.props && i.props.type === "number";
		es(e, t ? "change" : "input", (t) => {
			t.target.composing || e[Ds](Os(e.value, n, a));
		}), (n || a) && es(e, "change", () => {
			e.value = Os(e.value, n, a);
		}), t || (es(e, "compositionstart", Ts), es(e, "compositionend", Es), es(e, "change", Es));
	},
	mounted(e, { value: t }) {
		e.value = t ?? "";
	},
	beforeUpdate(e, { value: t, oldValue: n, modifiers: { lazy: r, trim: i, number: a } }, o) {
		if (e[Ds] = ws(o), e.composing) return;
		let s = (a || e.type === "number") && !/^0\d/.test(e.value) ? E(e.value) : e.value, c = t ?? "";
		if (s === c) return;
		let l = e.getRootNode();
		(l instanceof Document || l instanceof ShadowRoot) && l.activeElement === e && e.type !== "range" && (r && t === n || i && e.value.trim() === c) || (e.value = c);
	}
}, As = {
	deep: !0,
	created(e, t, n) {
		e[Ds] = ws(n), es(e, "change", () => {
			let t = e._modelValue, n = Fs(e), r = e.checked, i = e[Ds];
			if (d(t)) {
				let e = be(t, n), a = e !== -1;
				if (r && !a) i(t.concat(n));
				else if (!r && a) {
					let n = [...t];
					n.splice(e, 1), i(n);
				}
			} else if (p(t)) {
				let e = new Set(t);
				r ? e.add(n) : e.delete(n), i(e);
			} else i(Is(e, r));
		});
	},
	mounted: js,
	beforeUpdate(e, t, n) {
		e[Ds] = ws(n), js(e, t, n);
	}
};
function js(e, { value: t, oldValue: n }, r) {
	e._modelValue = t;
	let i;
	if (d(t)) i = be(t, r.props.value) > -1;
	else if (p(t)) i = t.has(r.props.value);
	else {
		if (t === n) return;
		i = A(t, Is(e, !0));
	}
	e.checked !== i && (e.checked = i);
}
var Ms = {
	created(e, { value: t }, n) {
		e.checked = A(t, n.props.value), e[Ds] = ws(n), es(e, "change", () => {
			e[Ds](Fs(e));
		});
	},
	beforeUpdate(e, { value: t, oldValue: n }, r) {
		e[Ds] = ws(r), t !== n && (e.checked = A(t, r.props.value));
	}
}, Ns = {
	deep: !0,
	created(e, { value: t, modifiers: { number: n } }, r) {
		let i = p(t);
		es(e, "change", () => {
			let t = Array.prototype.filter.call(e.options, (e) => e.selected).map((e) => n ? E(Fs(e)) : Fs(e));
			e[Ds](e.multiple ? i ? new Set(t) : t : t[0]), e._assigning = !0, Tn(() => {
				e._assigning = !1;
			});
		}), e[Ds] = ws(r);
	},
	mounted(e, { value: t }) {
		Ps(e, t);
	},
	beforeUpdate(e, t, n) {
		e[Ds] = ws(n);
	},
	updated(e, { value: t }) {
		e._assigning || Ps(e, t);
	}
};
function Ps(e, t) {
	let n = e.multiple, r = d(t);
	if (!(n && !r && !p(t))) {
		for (let i = 0, a = e.options.length; i < a; i++) {
			let a = e.options[i], o = Fs(a);
			if (n) if (r) {
				let e = typeof o;
				e === "string" || e === "number" ? a.selected = t.some((e) => String(e) === String(o)) : a.selected = be(t, o) > -1;
			} else a.selected = t.has(o);
			else if (A(Fs(a), t)) {
				e.selectedIndex !== i && (e.selectedIndex = i);
				return;
			}
		}
		!n && e.selectedIndex !== -1 && (e.selectedIndex = -1);
	}
}
function Fs(e) {
	return "_value" in e ? e._value : e.value;
}
function Is(e, t) {
	let n = t ? "_trueValue" : "_falseValue";
	return n in e ? e[n] : t;
}
var Ls = {
	created(e, t, n) {
		zs(e, t, n, null, "created");
	},
	mounted(e, t, n) {
		zs(e, t, n, null, "mounted");
	},
	beforeUpdate(e, t, n, r) {
		zs(e, t, n, r, "beforeUpdate");
	},
	updated(e, t, n, r) {
		zs(e, t, n, r, "updated");
	}
};
function Rs(e, t) {
	switch (e) {
		case "SELECT": return Ns;
		case "TEXTAREA": return ks;
		default: switch (t) {
			case "checkbox": return As;
			case "radio": return Ms;
			default: return ks;
		}
	}
}
function zs(e, t, n, r, i) {
	let a = Rs(e.tagName, n.props && n.props.type)[i];
	a && a(e, t, n, r);
}
var Bs = [
	"ctrl",
	"shift",
	"alt",
	"meta"
], Vs = {
	stop: (e) => e.stopPropagation(),
	prevent: (e) => e.preventDefault(),
	self: (e) => e.target !== e.currentTarget,
	ctrl: (e) => !e.ctrlKey,
	shift: (e) => !e.shiftKey,
	alt: (e) => !e.altKey,
	meta: (e) => !e.metaKey,
	left: (e) => "button" in e && e.button !== 0,
	middle: (e) => "button" in e && e.button !== 1,
	right: (e) => "button" in e && e.button !== 2,
	exact: (e, t) => Bs.some((n) => e[`${n}Key`] && !t.includes(n))
}, J = (e, t) => {
	if (!e) return e;
	let n = e._withMods ||= {}, r = t.join(".");
	return n[r] || (n[r] = ((n, ...r) => {
		for (let e = 0; e < t.length; e++) {
			let r = Vs[t[e]];
			if (r && r(n, t)) return;
		}
		return e(n, ...r);
	}));
}, Hs = {
	esc: "escape",
	space: " ",
	up: "arrow-up",
	left: "arrow-left",
	right: "arrow-right",
	down: "arrow-down",
	delete: "backspace"
}, Us = (e, t) => {
	let n = e._withKeys ||= {}, r = t.join(".");
	return n[r] || (n[r] = ((n) => {
		if (!("key" in n)) return;
		let r = ie(n.key);
		if (t.some((e) => e === r || Hs[e] === r)) return e(n);
	}));
}, Ws = /* @__PURE__ */ s({ patchProp: ds }, vo), Gs;
function Ks() {
	return Gs ||= aa(Ws);
}
var qs = ((...e) => {
	let t = Ks().createApp(...e), { mount: n } = t;
	return t.mount = (e) => {
		let r = Ys(e);
		if (!r) return;
		let i = t._component;
		!h(i) && !i.render && !i.template && (i.template = r.innerHTML), r.nodeType === 1 && (r.textContent = "");
		let a = n(r, !1, Js(r));
		return r instanceof Element && (r.removeAttribute("v-cloak"), r.setAttribute("data-v-app", "")), a;
	}, t;
});
function Js(e) {
	if (e instanceof SVGElement) return "svg";
	if (typeof MathMLElement == "function" && e instanceof MathMLElement) return "mathml";
}
function Ys(e) {
	return g(e) ? document.querySelector(e) : e;
}
//#endregion
//#region node_modules/pinia/dist/pinia.mjs
var Xs = typeof window < "u", Zs, Qs = (e) => Zs = e, $s = Symbol();
function ec(e) {
	return e && typeof e == "object" && Object.prototype.toString.call(e) === "[object Object]" && typeof e.toJSON != "function";
}
var tc;
(function(e) {
	e.direct = "direct", e.patchObject = "patch object", e.patchFunction = "patch function";
})(tc ||= {});
var nc = typeof window == "object" && window.window === window ? window : typeof self == "object" && self.self === self ? self : typeof global == "object" && global.global === global ? global : typeof globalThis == "object" ? globalThis : { HTMLElement: null };
function rc(e, { autoBom: t = !1 } = {}) {
	return t && /^\s*(?:text\/\S*|application\/xml|\S*\/\S*\+xml)\s*;.*charset\s*=\s*utf-8/i.test(e.type) ? new Blob(["﻿", e], { type: e.type }) : e;
}
function ic(e, t, n) {
	let r = new XMLHttpRequest();
	r.open("GET", e), r.responseType = "blob", r.onload = function() {
		lc(r.response, t, n);
	}, r.onerror = function() {
		console.error("could not download file");
	}, r.send();
}
function ac(e) {
	let t = new XMLHttpRequest();
	t.open("HEAD", e, !1);
	try {
		t.send();
	} catch {}
	return t.status >= 200 && t.status <= 299;
}
function oc(e) {
	try {
		e.dispatchEvent(new MouseEvent("click"));
	} catch {
		let t = new MouseEvent("click", {
			bubbles: !0,
			cancelable: !0,
			view: window,
			detail: 0,
			screenX: 80,
			screenY: 20,
			clientX: 80,
			clientY: 20,
			ctrlKey: !1,
			altKey: !1,
			shiftKey: !1,
			metaKey: !1,
			button: 0,
			relatedTarget: null
		});
		e.dispatchEvent(t);
	}
}
var sc = typeof navigator == "object" ? navigator : { userAgent: "" }, cc = /Macintosh/.test(sc.userAgent) && /AppleWebKit/.test(sc.userAgent) && !/Safari/.test(sc.userAgent), lc = Xs ? typeof HTMLAnchorElement < "u" && "download" in HTMLAnchorElement.prototype && !cc ? uc : "msSaveOrOpenBlob" in sc ? dc : fc : () => {};
function uc(e, t = "download", n) {
	let r = document.createElement("a");
	r.download = t, r.rel = "noopener", typeof e == "string" ? (r.href = e, r.origin === location.origin ? oc(r) : ac(r.href) ? ic(e, t, n) : (r.target = "_blank", oc(r))) : (r.href = URL.createObjectURL(e), setTimeout(function() {
		URL.revokeObjectURL(r.href);
	}, 4e4), setTimeout(function() {
		oc(r);
	}, 0));
}
function dc(e, t = "download", n) {
	if (typeof e == "string") if (ac(e)) ic(e, t, n);
	else {
		let t = document.createElement("a");
		t.href = e, t.target = "_blank", setTimeout(function() {
			oc(t);
		});
	}
	else navigator.msSaveOrOpenBlob(rc(e, n), t);
}
function fc(e, t, n, r) {
	if (r ||= open("", "_blank"), r && (r.document.title = r.document.body.innerText = "downloading..."), typeof e == "string") return ic(e, t, n);
	let i = e.type === "application/octet-stream", a = /constructor/i.test(String(nc.HTMLElement)) || "safari" in nc, o = /CriOS\/[\d]+/.test(navigator.userAgent);
	if ((o || i && a || cc) && typeof FileReader < "u") {
		let t = new FileReader();
		t.onloadend = function() {
			let e = t.result;
			if (typeof e != "string") throw r = null, Error("Wrong reader.result type");
			e = o ? e : e.replace(/^data:[^;]*;/, "data:attachment/file;"), r ? r.location.href = e : location.assign(e), r = null;
		}, t.readAsDataURL(e);
	} else {
		let t = URL.createObjectURL(e);
		r ? r.location.assign(t) : location.href = t, r = null, setTimeout(function() {
			URL.revokeObjectURL(t);
		}, 4e4);
	}
}
var { assign: pc } = Object;
function mc() {
	let e = Ee(!0), t = e.run(() => /* @__PURE__ */ F({})), n = [], r = [], i = Gt({
		install(e) {
			Qs(i), i._a = e, e.provide($s, i), e.config.globalProperties.$pinia = i, r.forEach((e) => n.push(e)), r = [];
		},
		use(e) {
			return this._a ? n.push(e) : r.push(e), this;
		},
		_p: n,
		_a: null,
		_e: e,
		_s: /* @__PURE__ */ new Map(),
		state: t
	});
	return i;
}
var hc = () => {};
function gc(e, t, n, r = hc) {
	e.add(t);
	let i = () => {
		e.delete(t) && r();
	};
	return !n && De() && Oe(i), i;
}
function _c(e, ...t) {
	e.forEach((e) => {
		e(...t);
	});
}
var vc = (e) => e(), yc = Symbol(), bc = Symbol();
function xc(e, t) {
	e instanceof Map && t instanceof Map ? t.forEach((t, n) => e.set(n, t)) : e instanceof Set && t instanceof Set && t.forEach(e.add, e);
	for (let n in t) {
		if (!t.hasOwnProperty(n)) continue;
		let r = t[n], i = e[n];
		ec(i) && ec(r) && e.hasOwnProperty(n) && !/* @__PURE__ */ Jt(r) && !/* @__PURE__ */ Vt(r) ? e[n] = xc(i, r) : e[n] = r;
	}
	return e;
}
var Sc = Symbol();
function Cc(e) {
	return !ec(e) || !Object.prototype.hasOwnProperty.call(e, Sc);
}
var { assign: wc } = Object;
function Tc(e) {
	return !!(/* @__PURE__ */ Jt(e) && e.effect);
}
function Ec(e, t, n, r) {
	let { state: i, actions: a, getters: o } = t, s = n.state.value[e], c;
	function l() {
		return s || (n.state.value[e] = i ? i() : {}), wc(/* @__PURE__ */ tn(n.state.value[e]), a, Object.keys(o || {}).reduce((t, r) => (t[r] = Gt(q(() => {
			Qs(n);
			let t = n._s.get(e);
			return o[r].call(t, t);
		})), t), {}));
	}
	return c = Dc(e, l, t, n, r, !0), c;
}
function Dc(e, t, n = {}, r, i, a) {
	let o, s = wc({ actions: {} }, n), c = { deep: !0 }, l, u, d = /* @__PURE__ */ new Set(), f = /* @__PURE__ */ new Set(), p = r.state.value[e];
	!a && !p && (r.state.value[e] = {});
	let m;
	function h(t) {
		let n;
		l = u = !1, typeof t == "function" ? (t(r.state.value[e]), n = {
			type: tc.patchFunction,
			storeId: e,
			events: void 0
		}) : (xc(r.state.value[e], t), n = {
			type: tc.patchObject,
			payload: t,
			storeId: e,
			events: void 0
		});
		let i = m = Symbol();
		Tn().then(() => {
			m === i && (l = !0);
		}), u = !0, _c(d, n, r.state.value[e]);
	}
	let g = a ? function() {
		let { state: e } = n, t = e ? e() : {};
		this.$patch((e) => {
			wc(e, t);
		});
	} : hc;
	function _() {
		o.stop(), d.clear(), f.clear(), r._s.delete(e);
	}
	let v = (t, n = "") => {
		if (yc in t) return t[bc] = n, t;
		let i = function() {
			Qs(r);
			let n = Array.from(arguments), a = /* @__PURE__ */ new Set(), o = /* @__PURE__ */ new Set();
			function s(e) {
				a.add(e);
			}
			function c(e) {
				o.add(e);
			}
			_c(f, {
				args: n,
				name: i[bc],
				store: y,
				after: s,
				onError: c
			});
			let l;
			try {
				l = t.apply(this && this.$id === e ? this : y, n);
			} catch (e) {
				throw _c(o, e), e;
			}
			return l instanceof Promise ? l.then((e) => (_c(a, e), e)).catch((e) => (_c(o, e), Promise.reject(e))) : (_c(a, l), l);
		};
		return i[yc] = !0, i[bc] = n, i;
	}, y = /* @__PURE__ */ Lt({
		_p: r,
		$id: e,
		$onAction: gc.bind(null, f),
		$patch: h,
		$reset: g,
		$subscribe(t, n = {}) {
			let i = gc(d, t, n.detached, () => a()), a = o.run(() => Gn(() => r.state.value[e], (r) => {
				(n.flush === "sync" ? u : l) && t({
					storeId: e,
					type: tc.direct,
					events: void 0
				}, r);
			}, wc({}, c, n)));
			return i;
		},
		$dispose: _
	});
	r._s.set(e, y);
	let b = (r._a && r._a.runWithContext || vc)(() => r._e.run(() => (o = Ee()).run(() => t({ action: v }))));
	for (let t in b) {
		let n = b[t];
		/* @__PURE__ */ Jt(n) && !Tc(n) || /* @__PURE__ */ Vt(n) ? a || (p && Cc(n) && (/* @__PURE__ */ Jt(n) ? n.value = p[t] : xc(n, p[t])), r.state.value[e][t] = n) : typeof n == "function" && (b[t] = v(n, t), s.actions[t] = n);
	}
	return wc(y, b), wc(/* @__PURE__ */ P(y), b), Object.defineProperty(y, "$state", {
		get: () => r.state.value[e],
		set: (e) => {
			h((t) => {
				wc(t, e);
			});
		}
	}), r._p.forEach((e) => {
		wc(y, o.run(() => e({
			store: y,
			app: r._a,
			pinia: r,
			options: s
		})));
	}), p && a && n.hydrate && n.hydrate(y.$state, p), l = !0, u = !0, y;
}
function Oc(e, t, n) {
	let r, i = typeof t == "function";
	r = i ? n : t;
	function a(n, a) {
		let o = Vn();
		return n ||= o ? Bn($s, null) : null, n && Qs(n), n = Zs, n._s.has(e) || (i ? Dc(e, t, r, n) : Ec(e, r, n)), n._s.get(e);
	}
	return a.$id = e, a;
}
//#endregion
//#region src/utils/storage.ts
var kc = "__moment_notes_", Ac = () => typeof window < "u" && window.__TOOLKIT_CTX__ ? window.__TOOLKIT_CTX__ : null, jc = () => Ac() !== null, Mc = /* @__PURE__ */ new Map(), Nc = async (e) => {
	let t = e || Ac();
	if (t?.storage) try {
		let e = await t.storage.keys() || [];
		if (e.length > 0) {
			let n = await Promise.all(e.map((e) => t.storage.get(e)));
			e.forEach((e, t) => {
				let r = n[t];
				r != null && Mc.set(e, typeof r == "string" ? r : JSON.stringify(r));
			});
		}
	} catch (e) {
		console.warn("[Storage] Failed to preload from ctx.storage:", e);
	}
}, Y = {
	getItem(e) {
		if (typeof localStorage < "u") {
			let t = e.startsWith(kc) ? e : `${kc}${e}`, n = localStorage.getItem(e) ?? localStorage.getItem(t);
			if (n !== null) return Mc.set(e, n), n;
		}
		return Mc.has(e) && Mc.get(e) || null;
	},
	setItem(e, t) {
		if (Mc.set(e, t), typeof localStorage < "u") try {
			localStorage.setItem(e, t), e.startsWith(kc) || localStorage.setItem(`${kc}${e}`, t);
		} catch (e) {
			console.warn("[Storage] localStorage.setItem failed:", e);
		}
		let n = Ac();
		if (n?.storage) {
			let r = t;
			try {
				r = JSON.parse(t);
			} catch {}
			n.storage.set(e, r).catch((t) => {
				console.warn(`[Storage] ctx.storage.set('${e}') failed:`, t);
			});
		}
	},
	removeItem(e) {
		Mc.delete(e), typeof localStorage < "u" && (localStorage.removeItem(e), e.startsWith(kc) || localStorage.removeItem(`${kc}${e}`));
		let t = Ac();
		t?.storage && t.storage.remove(e).catch((t) => {
			console.warn(`[Storage] ctx.storage.remove('${e}') failed:`, t);
		});
	}
}, Pc = async (e) => {
	try {
		if (navigator?.clipboard?.writeText) return await navigator.clipboard.writeText(e), !1;
	} catch (e) {
		console.warn("Clipboard copy failed, fallback to textarea:", e);
	}
	if (typeof document < "u") try {
		let t = document.createElement("textarea");
		t.value = e, t.style.position = "fixed", t.style.opacity = "0", document.body.appendChild(t), t.select(), document.execCommand("copy"), document.body.removeChild(t);
	} catch (e) {
		console.error("execCommand copy failed:", e);
	}
	return !1;
}, Fc = (e, t, n = "text/plain") => {
	if (typeof document > "u") return "fallback";
	try {
		let r = new Blob([e], { type: n }), i = URL.createObjectURL(r), a = document.createElement("a");
		return a.href = i, a.download = t, document.body.appendChild(a), a.click(), document.body.removeChild(a), URL.revokeObjectURL(i), "success";
	} catch (e) {
		return console.error("Browser download fallback failed:", e), "fallback";
	}
}, Ic = class {
	getDraft() {
		let e = Y.getItem("sticky_notes_draft_buffer");
		if (!e) return null;
		try {
			let t = JSON.parse(e);
			return t && Array.isArray(t.notes) ? t : null;
		} catch {
			return null;
		}
	}
	saveDraft(e, t) {
		let n = {
			notes: e,
			categories: t,
			timestamp: Date.now(),
			dirty: !0
		};
		Y.setItem("sticky_notes_draft_buffer", JSON.stringify(n));
	}
	markSynced() {
		let e = this.getDraft();
		e && (e.dirty = !1, Y.setItem("sticky_notes_draft_buffer", JSON.stringify(e)));
	}
	clearDraft() {
		Y.removeItem("sticky_notes_draft_buffer");
	}
	hasUnsyncedChanges() {
		let e = this.getDraft();
		return !!(e && e.dirty);
	}
}, Lc = class {
	getAll() {
		let e = Bc.getDraft();
		if (e && e.notes && e.notes.length > 0) return e.notes;
		let t = Y.getItem("sticky_notes_notes");
		if (!t) return [];
		try {
			let e = JSON.parse(t);
			return Array.isArray(e) ? e : [];
		} catch {
			return [];
		}
	}
	saveAll(e, t) {
		Y.setItem("sticky_notes_notes", JSON.stringify(e)), t && Bc.saveDraft(e, t);
	}
}, Rc = class {
	getAll() {
		let e = Bc.getDraft();
		if (e && e.categories && e.categories.length > 0) return e.categories;
		let t = Y.getItem("sticky_notes_categories");
		if (!t) return [];
		try {
			let e = JSON.parse(t);
			return Array.isArray(e) ? e : [];
		} catch {
			return [];
		}
	}
	saveAll(e, t) {
		Y.setItem("sticky_notes_categories", JSON.stringify(e)), t && Bc.saveDraft(t, e);
	}
	getOrder() {
		let e = Y.getItem("sticky_notes_category_order");
		if (!e) return [];
		try {
			let t = JSON.parse(e);
			return Array.isArray(t) ? t : [];
		} catch {
			return [];
		}
	}
	saveOrder(e) {
		Y.setItem("sticky_notes_category_order", JSON.stringify(e));
	}
	getCollapsed() {
		let e = Y.getItem("sticky_notes_collapsed_categories");
		if (!e) return [];
		try {
			let t = JSON.parse(e);
			return Array.isArray(t) ? t : [];
		} catch {
			return [];
		}
	}
	saveCollapsed(e) {
		Y.setItem("sticky_notes_collapsed_categories", JSON.stringify(e));
	}
}, zc = class {
	static encode(e, t, n) {
		return {
			version: "2.0.0",
			timestamp: Date.now(),
			categories: e,
			notes: t,
			settings: n
		};
	}
	static decode(e) {
		try {
			let t = JSON.parse(e);
			return !t || typeof t != "object" || !Array.isArray(t.categories) || !Array.isArray(t.notes) ? null : t;
		} catch {
			return null;
		}
	}
}, Bc = new Ic(), Vc = new Lc(), Hc = new Rc(), Uc = new class {
	handlers = /* @__PURE__ */ new Map();
	subscribe(e, t) {
		this.handlers.has(e) || this.handlers.set(e, /* @__PURE__ */ new Set());
		let n = this.handlers.get(e);
		return n.add(t), () => {
			n.delete(t);
		};
	}
	emit(e, t) {
		let n = {
			type: e,
			payload: t,
			timestamp: Date.now()
		}, r = this.handlers.get(e);
		r && r.forEach((t) => {
			try {
				t(n);
			} catch (t) {
				console.error(`Error handling event ${e}:`, t);
			}
		});
	}
	requestToast(e, t = "success", n = "top") {
		this.emit("TOAST_REQUESTED", {
			message: e,
			type: t,
			position: n
		});
	}
	clearAll() {
		this.handlers.clear();
	}
}(), Wc = Oc("categoryStore", () => {
	let e = /* @__PURE__ */ F([]), t = /* @__PURE__ */ F([]), n = /* @__PURE__ */ F([]), r = /* @__PURE__ */ F(null), i = /* @__PURE__ */ F(""), a = () => {
		Hc.saveAll(e.value);
	}, o = () => {
		Hc.saveOrder(t.value);
	}, s = () => {
		Hc.saveCollapsed(n.value);
	}, c = (e) => {
		let t = n.value.indexOf(e);
		t === -1 ? n.value.push(e) : n.value.splice(t, 1), s();
	}, l = (e) => n.value.includes(e), u = (t) => {
		let n = /* @__PURE__ */ new Set(), r = /* @__PURE__ */ new Map();
		e.value.filter((e) => !e.isDeleted).forEach((e) => {
			e.parentId && (r.has(e.parentId) || r.set(e.parentId, []), r.get(e.parentId).push(e.id));
		});
		let i = [t], a = 0;
		for (; a < i.length;) {
			let e = i[a++];
			(r.get(e) || []).forEach((e) => {
				n.has(e) || (n.add(e), i.push(e));
			});
		}
		return n;
	}, d = q(() => {
		let i = e.value.filter((e) => !e.isDeleted), a = new Map(i.map((e) => [e.id, e])), o = /* @__PURE__ */ new Map(), s = [];
		i.forEach((e) => {
			e.parentId && a.has(e.parentId) ? (o.has(e.parentId) || o.set(e.parentId, []), o.get(e.parentId).push(e)) : s.push(e);
		});
		let c = (e) => {
			let n = t.value.indexOf(e);
			return n === -1 ? Infinity : n;
		}, l = (e, t) => c(e.id) - c(t.id);
		s.sort(l), o.forEach((e) => e.sort(l));
		let u = [];
		u.push({
			id: "all",
			name: "全部便签",
			createdAt: 0,
			isSystem: !0,
			level: 0,
			hasChildren: !1,
			isCollapsed: !1
		});
		let d = (e, t) => {
			let i = o.get(e.id) || [], a = i.length > 0, s = n.value.includes(e.id);
			u.push({
				...e,
				isSystem: !1,
				level: t,
				hasChildren: a,
				isCollapsed: s
			}), r.value === e.id && !s && u.push({
				id: `sub-add-${e.id}`,
				name: "",
				createdAt: Date.now(),
				parentId: e.id,
				isSystem: !1,
				level: t + 1,
				hasChildren: !1,
				isCollapsed: !1,
				isVirtualAdd: !0
			}), a && !s && i.forEach((e) => {
				d(e, t + 1);
			});
		};
		return s.forEach((e) => {
			d(e, 0);
		}), u;
	});
	return {
		categories: e,
		categoryOrder: t,
		collapsedCategoryIds: n,
		addingSubParentId: r,
		newSubCategoryName: i,
		saveCategories: a,
		saveCategoryOrder: o,
		saveCollapsedCategories: s,
		toggleCategoryCollapse: c,
		isCategoryCollapsed: l,
		getCategoryDescendants: u,
		orderedCategories: d,
		reorderCategories: (e, n) => {
			let r = d.value[e], i = d.value[n];
			if (!r || !i) return;
			let a = r.id, s = i.id, c = [...t.value], l = c.indexOf(a), u = c.indexOf(s);
			if (l !== -1 && u !== -1) {
				let [e] = c.splice(l, 1);
				c.splice(u, 0, e), t.value = c, o();
			}
		},
		moveCategory: (r, i, c, l) => {
			let d = e.value.find((e) => e.id === r);
			if (!d && r !== "all") return;
			if (r === "all") {
				if (i !== void 0) {
					Uc.requestToast("“全部便签”只能作为一级分类排序", "error");
					return;
				}
			} else {
				if (i === r) return;
				let e = u(r);
				if (i && e.has(i)) {
					Uc.requestToast("无法将分类移动到其子分类下", "error");
					return;
				}
				d.parentId = i, a();
			}
			let f = [...t.value];
			f.includes("all") || f.unshift("all");
			let p = f.indexOf(r);
			if (p !== -1 && f.splice(p, 1), l === "inside") {
				let e = f.indexOf(i || "");
				e === -1 ? f.push(r) : f.splice(e + 1, 0, r), i && n.value.includes(i) && (n.value = n.value.filter((e) => e !== i), s());
			} else {
				let e = f.indexOf(c || "");
				if (e !== -1) {
					let t = l === "before" ? e : e + 1;
					f.splice(t, 0, r);
				} else f.push(r);
			}
			t.value = f, o();
		},
		addCategory: (n, r) => {
			if (!n.trim()) return;
			let i = Date.now(), s = {
				id: `${i}_${Math.random().toString(36).slice(2, 7)}`,
				name: n.trim(),
				createdAt: i,
				updatedAt: i,
				isDeleted: !1,
				parentId: r
			};
			return e.value.push(s), a(), t.value.push(s.id), o(), Uc.emit("CATEGORY_CREATED", s), s;
		},
		deleteCategory: (n) => {
			let r = Date.now(), i;
			e.value.forEach((e) => {
				e.id === n && (e.isDeleted = !0, e.deletedAt = r, e.updatedAt = r, e.parentId !== void 0 && (i = e.parentId));
			}), e.value.forEach((e) => {
				e.parentId === n && (e.parentId = i, e.updatedAt = r);
			}), a(), t.value = t.value.filter((e) => e !== n), o(), Uc.emit("CATEGORY_DELETED", n);
		},
		updateCategory: (t, n) => {
			if (!n.trim()) return;
			let r = e.value.find((e) => e.id === t);
			r && (r.name = n.trim(), r.updatedAt = Date.now(), a(), Uc.emit("CATEGORY_UPDATED", r));
		},
		categoryOptions: q(() => {
			let n = [];
			n.push({
				label: "全部便签",
				value: "all"
			});
			let r = e.value.filter((e) => !e.isDeleted), i = (e) => {
				let t = [], n = r.find((t) => t.id === e);
				for (; n;) {
					t.unshift(n.name);
					let e = n.parentId;
					n = e ? r.find((t) => t.id === e) : void 0;
				}
				return t.join(" / ");
			}, a = (e) => {
				let n = t.value.indexOf(e);
				return n === -1 ? Infinity : n;
			}, o = (e, t) => a(e.id) - a(t.id), s = new Map(r.map((e) => [e.id, {
				...e,
				children: []
			}])), c = [];
			r.forEach((e) => {
				let t = s.get(e.id);
				t && (e.parentId && s.has(e.parentId) ? s.get(e.parentId).children.push(t) : c.push(t));
			}), c.sort(o), s.forEach((e) => e.children.sort(o));
			let l = [], u = (e) => {
				e.forEach((e) => {
					l.push(e), e.children && e.children.length > 0 && u(e.children);
				});
			};
			return u(c), l.forEach((e) => {
				n.push({
					label: i(e.id),
					value: e.id
				});
			}), n.push({
				label: "最近使用",
				value: "recent"
			}), n.push({
				label: "最近删除",
				value: "trash"
			}), n;
		})
	};
}), Gc = [
	{
		id: "copyAndPaste",
		label: "双击复制并粘贴到光标处",
		execute: (e) => e.copyAndPaste()
	},
	{
		id: "fullscreen",
		label: "全屏查看便签",
		execute: (e) => e.openFullscreen()
	},
	{
		id: "delete",
		label: "删除便签(移入\"最近删除\")",
		tooltip: "如果双击的是\"最近删除\"的便签就直接删除",
		execute: (e) => e.deleteNote()
	},
	{
		id: "none",
		label: "不执行任何操作",
		tooltip: "双击便签卡片时不触发任何操作",
		execute: () => void 0
	}
], Kc = new Set(Gc.map((e) => e.id)), qc = new Map(Gc.map((e) => [e.id, e])), Jc = (e) => typeof e == "string" && Kc.has(e), Yc = {
	key: "doubleClickNoteAction",
	storageKey: "sticky_notes_double_click_note_action",
	defaultValue: "copyAndPaste",
	codec: {
		decode: (e) => Jc(e) ? e : void 0,
		encode: (e) => e
	}
}, Xc = (e, t) => qc.get(e)?.execute(t), Zc = (e, t) => e.codec.decode(t), Qc = (e, t) => Zc(e, t) ?? e.defaultValue, $c = new class {
	adapter;
	constructor(e = Y) {
		this.adapter = e;
	}
	get(e) {
		let t = this.adapter.getItem(e.storageKey), n = Zc(e, t);
		return n === void 0 ? (t !== null && this.adapter.setItem(e.storageKey, e.codec.encode(e.defaultValue)), e.defaultValue) : n;
	}
	set(e, t) {
		let n = Qc(e, t);
		return this.adapter.setItem(e.storageKey, e.codec.encode(n)), n;
	}
}(), el = Oc("uiStore", () => {
	let e = /* @__PURE__ */ F({
		show: !1,
		title: "",
		message: ""
	}), t = null, n = (n, r) => (e.value = {
		show: !0,
		title: n,
		message: r
	}, new Promise((e) => {
		t = e;
	})), r = (n) => {
		e.value.show = !1, t &&= (t(n), null);
	}, i = /* @__PURE__ */ F(""), a = /* @__PURE__ */ F("success"), o = /* @__PURE__ */ F("top"), s = null, c = (e, t = "success", n = "top") => {
		i.value = e, a.value = t, o.value = n, s && clearTimeout(s), s = setTimeout(() => {
			i.value = "";
		}, 2500);
	};
	Uc.subscribe("TOAST_REQUESTED", (e) => {
		e.payload && c(e.payload.message, e.payload.type, e.payload.position);
	});
	let l = /* @__PURE__ */ F("auto"), u = /* @__PURE__ */ F(260), d = /* @__PURE__ */ F(300), f = /* @__PURE__ */ F(!1), p = /* @__PURE__ */ F({}), m = (e) => {
		f.value = e, Y.setItem("sticky_notes_category_independent_toolbar", e ? "true" : "false");
	}, h = () => {
		Y.setItem("sticky_notes_category_view_settings", JSON.stringify(p.value));
	}, g = (e, t) => {
		p.value[e] || (p.value[e] = {}), Object.assign(p.value[e], t), h();
	}, _ = (e, t) => {
		l.value = e, Y.setItem("sticky_notes_grid_columns", e.toString()), f.value && t && g(t, { gridColumns: e });
	}, v = (e) => {
		u.value = Number(e) || 260, Y.setItem("sticky_notes_min_note_width", u.value.toString());
	}, y = (e) => {
		d.value = Number(e) || 320, Y.setItem("sticky_notes_note_max_height", d.value.toString());
	}, b = /* @__PURE__ */ F(!1), x = () => {
		b.value = !0;
	}, S = () => {
		b.value = !1;
	}, C = /* @__PURE__ */ F(!1), w = (e) => {
		let t = document.documentElement;
		e ? (t.classList.remove("light-theme"), t.classList.add("dark-theme"), t.dataset.theme = "dark", t.style.colorScheme = "dark") : (t.classList.remove("dark-theme"), t.classList.add("light-theme"), t.dataset.theme = "light", t.style.colorScheme = "light");
	}, ee = () => {
		let e = Y.getItem("sticky_notes_theme");
		e ? C.value = e === "dark" : typeof document < "u" && document.documentElement.dataset.theme ? C.value = document.documentElement.dataset.theme === "dark" : C.value = typeof window < "u" && window.matchMedia("(prefers-color-scheme: dark)").matches, w(C.value);
	}, te = () => {
		C.value = !C.value, w(C.value), Y.setItem("sticky_notes_theme", C.value ? "dark" : "light");
	}, ne = /* @__PURE__ */ F([
		"theme-toggle",
		"sort-select",
		"columns-select",
		"clear-notes"
	]), T = (e) => {
		ne.value = e, Y.setItem("sticky_notes_enabled_action_bar_buttons", JSON.stringify(e));
	}, re = /* @__PURE__ */ F("YYYY.MM.DD HH:mm"), ie = (e) => {
		re.value = e || "YYYY.MM.DD HH:mm", Y.setItem("sticky_notes_date_format", re.value);
	}, ae = /* @__PURE__ */ F("random"), oe = (e) => {
		ae.value = e || "random", Y.setItem("sticky_notes_default_note_color", ae.value);
	}, se = /* @__PURE__ */ F("text"), ce = (e) => {
		se.value = e || "text", Y.setItem("sticky_notes_default_note_type", se.value);
	}, le = /* @__PURE__ */ F("inline"), E = (e) => {
		le.value = e || "inline", Y.setItem("sticky_notes_default_edit_mode", le.value);
	}, ue = /* @__PURE__ */ F($c.get(Yc)), de = (e) => {
		ue.value = $c.set(Yc, e);
	}, fe = /* @__PURE__ */ F("all"), D = (e) => {
		fe.value = e || "all", Y.setItem("sticky_notes_super_panel_default_category", fe.value);
	}, pe = /* @__PURE__ */ F("last"), me = (e) => {
		pe.value = e || "last", Y.setItem("sticky_notes_start_page_mode", pe.value);
	}, he = /* @__PURE__ */ F(!0), ge = (e) => {
		he.value = e, Y.setItem("sticky_notes_enable_hover_animation", e ? "true" : "false");
	}, O = /* @__PURE__ */ F(!0), _e = (e) => {
		O.value = e, Y.setItem("sticky_notes_enable_auto_copy_selection", e ? "true" : "false");
	}, ve = /* @__PURE__ */ F(!0), k = (e) => {
		ve.value = e, Y.setItem("sticky_notes_show_note_count", e ? "true" : "false");
	}, ye = /* @__PURE__ */ F(!0), A = (e) => {
		ye.value = e, Y.setItem("sticky_notes_prefix_tag_with_hash", e ? "true" : "false");
	}, be = /* @__PURE__ */ F(!1), xe = (e) => {
		be.value = e, Y.setItem("sticky_notes_skip_delete_confirm", e ? "true" : "false");
	}, j = /* @__PURE__ */ F(!1), Se = (e) => {
		j.value = e, Y.setItem("sticky_notes_enable_immersive_fullscreen", e ? "true" : "false");
	}, Ce = /* @__PURE__ */ F(!1), we = () => {
		Ce.value = !0;
	}, Te = () => {
		Ce.value = !1;
	}, Ee = () => {
		Ce.value = !Ce.value;
	}, De = /* @__PURE__ */ F(null), Oe = /* @__PURE__ */ F(null), M = (e) => {
		De.value = e;
	}, ke = () => {
		De.value = null, Oe.value = null;
	}, Ae = (e) => {
		De.value === e ? ke() : M(e);
	}, je = /* @__PURE__ */ F(!1), Me = () => {
		je.value = !0;
	}, Ne = () => {
		je.value = !1;
	}, Pe = /* @__PURE__ */ F(!1), Fe = /* @__PURE__ */ F(null);
	return {
		confirmState: e,
		askConfirm: n,
		handleConfirmResult: r,
		toastMessage: i,
		toastType: a,
		toastPosition: o,
		showToast: c,
		gridColumns: l,
		minNoteWidth: u,
		setGridColumns: _,
		setMinNoteWidth: v,
		showSettings: b,
		openSettings: x,
		closeSettings: S,
		isDark: C,
		initTheme: ee,
		toggleTheme: te,
		enabledActionBarButtons: ne,
		setEnabledActionBarButtons: T,
		dateFormat: re,
		setDateFormat: ie,
		defaultNoteColor: ae,
		setDefaultNoteColor: oe,
		defaultNoteType: se,
		setDefaultNoteType: ce,
		defaultEditMode: le,
		setDefaultEditMode: E,
		doubleClickNoteAction: ue,
		setDoubleClickNoteAction: de,
		superPanelDefaultCategory: fe,
		setSuperPanelDefaultCategory: D,
		startPageMode: pe,
		setStartPageMode: me,
		noteMaxHeight: d,
		setNoteMaxHeight: y,
		enableHoverAnimation: he,
		setEnableHoverAnimation: ge,
		enableAutoCopySelection: O,
		setEnableAutoCopySelection: _e,
		showNoteCount: ve,
		setShowNoteCount: k,
		prefixTagWithHash: ye,
		setPrefixTagWithHash: A,
		skipDeleteConfirm: be,
		setSkipDeleteConfirm: xe,
		enableImmersiveFullscreen: j,
		setEnableImmersiveFullscreen: Se,
		categoryIndependentToolbar: f,
		setCategoryIndependentToolbar: m,
		categoryViewSettings: p,
		updateCategoryViewSetting: g,
		saveCategoryViewSettings: h,
		previewNoteId: De,
		openedFullscreenForEditNoteId: Oe,
		openNotePreview: M,
		closeNotePreview: ke,
		toggleNotePreview: Ae,
		isMobileSidebarOpen: Ce,
		openMobileSidebar: we,
		closeMobileSidebar: Te,
		toggleMobileSidebar: Ee,
		showExportModal: je,
		openExportModal: Me,
		closeExportModal: Ne,
		showImportModal: Pe,
		pendingImportData: Fe,
		openImportModal: (e) => {
			Fe.value = e, Pe.value = !0;
		},
		closeImportModal: () => {
			Pe.value = !1, Fe.value = null;
		}
	};
}), tl = {
	yellow: {
		name: "暖阳黄",
		lightBg: "#FFF6D1",
		darkBg: "#343020",
		lightBorder: "hsl(48, 100%, 75%)",
		darkBorder: "hsl(48, 40%, 30%)",
		lightText: "hsl(48, 80%, 15%)",
		darkText: "hsl(48, 100%, 85%)",
		lightBtnHoverBg: "hsl(48, 100%, 79%)",
		lightBtnHoverColor: "hsl(48, 90%, 12%)",
		darkBtnHoverBg: "hsla(48, 60%, 55%, 0.13)",
		darkBtnHoverColor: "hsl(48, 100%, 88%)"
	},
	green: {
		name: "薄荷绿",
		lightBg: "#DEFADE",
		darkBg: "#182C1F",
		lightBorder: "hsl(120, 75%, 80%)",
		darkBorder: "hsl(120, 30%, 28%)",
		lightText: "hsl(120, 70%, 15%)",
		darkText: "hsl(120, 85%, 85%)",
		lightBtnHoverBg: "hsl(120, 75%, 84%)",
		lightBtnHoverColor: "hsl(120, 75%, 12%)",
		darkBtnHoverBg: "hsla(120, 50%, 50%, 0.13)",
		darkBtnHoverColor: "hsl(120, 85%, 88%)"
	},
	blue: {
		name: "晴空蓝",
		lightBg: "#DBF2FD",
		darkBg: "#172A38",
		lightBorder: "hsl(200, 90%, 80%)",
		darkBorder: "hsl(200, 40%, 30%)",
		lightText: "hsl(200, 75%, 15%)",
		darkText: "hsl(200, 90%, 85%)",
		lightBtnHoverBg: "hsl(200, 90%, 84%)",
		lightBtnHoverColor: "hsl(200, 80%, 12%)",
		darkBtnHoverBg: "hsla(200, 60%, 55%, 0.13)",
		darkBtnHoverColor: "hsl(200, 90%, 88%)"
	},
	pink: {
		name: "蔷薇粉",
		lightBg: "#FDDFE9",
		darkBg: "#331A28",
		lightBorder: "hsl(340, 85%, 82%)",
		darkBorder: "hsl(340, 40%, 30%)",
		lightText: "hsl(340, 75%, 15%)",
		darkText: "hsl(340, 90%, 85%)",
		lightBtnHoverBg: "hsl(340, 85%, 84%)",
		lightBtnHoverColor: "hsl(340, 80%, 12%)",
		darkBtnHoverBg: "hsla(340, 60%, 55%, 0.13)",
		darkBtnHoverColor: "hsl(340, 90%, 88%)"
	},
	purple: {
		name: "熏衣紫",
		lightBg: "#F0E4FC",
		darkBg: "#261B38",
		lightBorder: "hsl(270, 80%, 83%)",
		darkBorder: "hsl(270, 35%, 30%)",
		lightText: "hsl(270, 70%, 15%)",
		darkText: "hsl(270, 90%, 85%)",
		lightBtnHoverBg: "hsl(270, 80%, 86%)",
		lightBtnHoverColor: "hsl(270, 75%, 12%)",
		darkBtnHoverBg: "hsla(270, 55%, 58%, 0.13)",
		darkBtnHoverColor: "hsl(270, 90%, 88%)"
	},
	gray: {
		name: "极简灰",
		lightBg: "#F2F2F2",
		darkBg: "#25272C",
		lightBorder: "hsl(0, 0%, 82%)",
		darkBorder: "hsl(0, 0%, 30%)",
		lightText: "hsl(0, 0%, 15%)",
		darkText: "hsl(0, 0%, 85%)",
		lightBtnHoverBg: "hsl(0, 0%, 84%)",
		lightBtnHoverColor: "hsl(0, 0%, 10%)",
		darkBtnHoverBg: "hsla(0, 0%, 70%, 0.1)",
		darkBtnHoverColor: "hsl(0, 0%, 92%)"
	}
}, nl = "moment_notes_assets", rl = 1, il = "images", al = class e {
	static instance;
	dbPromise = null;
	memoryUrlCache = /* @__PURE__ */ new Map();
	memoryMetaCache = /* @__PURE__ */ new Map();
	fallbackStore = /* @__PURE__ */ new Map();
	static getInstance() {
		return e.instance ||= new e(), e.instance;
	}
	normalizeId(e) {
		return e ? e.replace(/^attachment:\/\//, "").replace(/^attachments\//, "").replace(/^images\//, "").replace(/^\/+/, "") : "";
	}
	toRelativePath(e) {
		let t = this.normalizeId(e);
		return t.startsWith("img_") || /\.(?:png|jpe?g|webp|gif|svg|bmp|ico)$/i.test(t) ? `images/${t}` : `attachments/${t}`;
	}
	getDB() {
		return typeof indexedDB > "u" ? Promise.resolve(null) : (this.dbPromise ||= new Promise((e) => {
			try {
				let t = indexedDB.open(nl, rl);
				t.onupgradeneeded = (e) => {
					let t = e.target.result;
					t.objectStoreNames.contains(il) || t.createObjectStore(il, { keyPath: "id" });
				}, t.onsuccess = () => {
					e(t.result);
				}, t.onerror = (t) => {
					console.warn("[ImageRepository] IndexedDB open error, fallback to memory:", t), e(null);
				};
			} catch (t) {
				console.warn("[ImageRepository] IndexedDB exception, fallback to memory:", t), e(null);
			}
		}), this.dbPromise);
	}
	generateAssetId(e = "image", t = "bin") {
		let n = Date.now(), r = Math.random().toString(16).substring(2, 10);
		return `${e === "audio" ? "audio" : e === "video" ? "video" : e === "file" ? "file" : "img"}_${n}_${r}.${t}`;
	}
	generateImageId(e = "png") {
		return this.generateAssetId("image", e);
	}
	detectType(e, t) {
		let n = (e || "").toLowerCase(), r = (t || "").toLowerCase();
		return n.startsWith("image/") || [
			"png",
			"jpg",
			"jpeg",
			"webp",
			"gif",
			"svg",
			"ico",
			"bmp"
		].includes(r) ? "image" : n.startsWith("audio/") || [
			"mp3",
			"wav",
			"m4a",
			"ogg",
			"aac",
			"flac",
			"webm",
			"wma"
		].includes(r) ? "audio" : n.startsWith("video/") || [
			"mp4",
			"webm",
			"mov",
			"mkv",
			"avi",
			"flv"
		].includes(r) ? "video" : "file";
	}
	getDefaultExt(e, t) {
		let n = (e || "").toLowerCase();
		return n === "image/jpeg" ? "jpg" : n === "image/png" ? "png" : n === "image/webp" ? "webp" : n === "image/gif" ? "gif" : n === "image/svg+xml" ? "svg" : n === "audio/mpeg" || n === "audio/mp3" ? "mp3" : n === "audio/wav" ? "wav" : n === "audio/ogg" ? "ogg" : n === "audio/aac" ? "aac" : n === "video/mp4" ? "mp4" : n === "video/webm" ? "webm" : n === "application/pdf" ? "pdf" : n === "application/zip" ? "zip" : t === "audio" ? "mp3" : t === "video" ? "mp4" : t === "image" ? "png" : "bin";
	}
	async compressImageIfNeeded(e, t = 5) {
		if (!(e.type === "image/jpeg" || e.type === "image/png" || e.type === "image/webp") || e.size < t * 1024 * 1024 || typeof document > "u" || typeof Image > "u") return e;
		try {
			let t = await new Promise((t, n) => {
				let r = new FileReader();
				r.onload = () => t(r.result), r.onerror = n, r.readAsDataURL(e);
			}), n = await new Promise((e, n) => {
				let r = new Image();
				r.onload = () => e(r), r.onerror = n, r.src = t;
			}), r = 1920, i = n.width, a = n.height;
			(i > r || a > r) && (i > a ? (a = Math.round(a * r / i), i = r) : (i = Math.round(i * r / a), a = r));
			let o = document.createElement("canvas");
			o.width = i, o.height = a;
			let s = o.getContext("2d");
			if (!s) return e;
			s.drawImage(n, 0, 0, i, a);
			let c = e.type === "image/jpeg" ? "image/jpeg" : e.type, l = await new Promise((e) => {
				o.toBlob((t) => e(t), c, .85);
			});
			return l && l.size < e.size ? l : e;
		} catch (t) {
			return console.warn("[ImageRepository] Image compression failed, using original:", t), e;
		}
	}
	async saveImage(e, t) {
		let n = t?.originalName || ("name" in e ? e.name : void 0), r = t?.ext;
		if (!r && n) {
			let e = n.split(".");
			e.length > 1 && (r = e.pop()?.toLowerCase());
		}
		let i = t?.type || this.detectType(e.type, r);
		r ||= this.getDefaultExt(e.type, i);
		let a = e;
		i === "image" && t?.autoCompress !== !1 && (a = await this.compressImageIfNeeded(e, t?.maxSizeMB || 5));
		let o = t?.customId ? this.normalizeId(t.customId) : this.generateAssetId(i, r), s = this.toRelativePath(o), c = {
			id: o,
			path: s,
			size: a.size,
			mimeType: a.type || (i === "image" ? "image/png" : "application/octet-stream"),
			createdAt: Date.now(),
			uploadStatus: t?.uploadStatus || "pending",
			type: i,
			originalName: n
		}, l = {
			id: o,
			blob: a,
			meta: c
		}, u = this.createBlobUrl(a);
		this.memoryUrlCache.set(o, u), this.memoryUrlCache.set(s, u), this.memoryMetaCache.set(o, c), this.memoryMetaCache.set(s, c);
		let d = await this.getDB();
		return d ? await new Promise((e, t) => {
			try {
				let n = d.transaction(il, "readwrite");
				n.objectStore(il).put(l), n.oncomplete = () => e(), n.onerror = () => t(n.error);
			} catch (e) {
				t(e);
			}
		}) : this.fallbackStore.set(o, l), {
			id: o,
			path: s,
			url: u,
			meta: c
		};
	}
	saveAttachment = this.saveImage.bind(this);
	getMetaSync(e) {
		let t = this.normalizeId(e);
		return this.memoryMetaCache.get(t) || null;
	}
	async getMeta(e) {
		let t = this.normalizeId(e), n = this.getMetaSync(t);
		if (n) return n;
		let r = await this.getDB();
		if (r) return new Promise((e) => {
			try {
				let n = r.transaction(il, "readonly").objectStore(il).get(t);
				n.onsuccess = () => {
					let r = n.result;
					r && r.meta ? (this.memoryMetaCache.set(t, r.meta), e(r.meta)) : e(null);
				}, n.onerror = () => e(null);
			} catch {
				e(null);
			}
		});
		{
			let e = this.fallbackStore.get(t);
			return e?.meta ? (this.memoryMetaCache.set(t, e.meta), e.meta) : null;
		}
	}
	createBlobUrl(e) {
		if (typeof URL < "u" && typeof URL.createObjectURL == "function") try {
			return URL.createObjectURL(e);
		} catch {}
		return `data:${e.type || "image/png"};base64,mock`;
	}
	getImageUrlSync(e) {
		let t = this.normalizeId(e), n = this.toRelativePath(t);
		return this.memoryUrlCache.get(t) || this.memoryUrlCache.get(n) || null;
	}
	async getImageBlob(e) {
		let t = this.normalizeId(e);
		if (!t) return null;
		let n = await this.getDB();
		if (n) return new Promise((e) => {
			try {
				let r = n.transaction(il, "readonly").objectStore(il).get(t);
				r.onsuccess = () => {
					let t = r.result;
					e(t ? t.blob : null);
				}, r.onerror = () => e(null);
			} catch {
				e(null);
			}
		});
		let r = this.fallbackStore.get(t);
		return r ? r.blob : null;
	}
	async getImageUrl(e) {
		let t = this.getImageUrlSync(e);
		if (t) return t;
		let n = await this.getImageBlob(e);
		if (!n) return null;
		let r = this.normalizeId(e), i = this.toRelativePath(r), a = this.createBlobUrl(n);
		return this.memoryUrlCache.set(r, a), this.memoryUrlCache.set(i, a), a;
	}
	async listImages() {
		let e = await this.getDB();
		return e ? new Promise((t) => {
			try {
				let n = e.transaction(il, "readonly").objectStore(il).getAll();
				n.onsuccess = () => {
					t((n.result || []).map((e) => e.meta));
				}, n.onerror = () => t([]);
			} catch {
				t([]);
			}
		}) : Array.from(this.fallbackStore.values()).map((e) => e.meta);
	}
	async getPendingUploads() {
		let e = await this.getDB();
		return e ? new Promise((t) => {
			try {
				let n = e.transaction(il, "readonly").objectStore(il).getAll();
				n.onsuccess = () => {
					t((n.result || []).filter((e) => e.meta.uploadStatus === "pending" || e.meta.uploadStatus === "failed").map((e) => ({
						id: e.id,
						path: e.meta.path,
						blob: e.blob,
						meta: e.meta
					})));
				}, n.onerror = () => t([]);
			} catch {
				t([]);
			}
		}) : Array.from(this.fallbackStore.values()).filter((e) => e.meta.uploadStatus === "pending" || e.meta.uploadStatus === "failed").map((e) => ({
			id: e.id,
			path: e.meta.path,
			blob: e.blob,
			meta: e.meta
		}));
	}
	async markUploadStatus(e, t) {
		let n = this.normalizeId(e), r = await this.getDB();
		if (r) await new Promise((e) => {
			try {
				let i = r.transaction(il, "readwrite").objectStore(il), a = i.get(n);
				a.onsuccess = () => {
					let n = a.result;
					n && (n.meta.uploadStatus = t, i.put(n)), e();
				}, a.onerror = () => e();
			} catch {
				e();
			}
		});
		else {
			let e = this.fallbackStore.get(n);
			e && (e.meta.uploadStatus = t);
		}
	}
	async deleteImage(e) {
		let t = this.normalizeId(e), n = this.toRelativePath(t), r = this.memoryUrlCache.get(t);
		if (r && typeof URL < "u" && typeof URL.revokeObjectURL == "function") try {
			URL.revokeObjectURL(r);
		} catch {}
		this.memoryUrlCache.delete(t), this.memoryUrlCache.delete(n);
		let i = await this.getDB();
		return i ? new Promise((e) => {
			try {
				let n = i.transaction(il, "readwrite");
				n.objectStore(il).delete(t), n.oncomplete = () => e(!0), n.onerror = () => e(!1);
			} catch {
				e(!1);
			}
		}) : (this.fallbackStore.delete(t), !0);
	}
	async clearAll() {
		for (let e of this.memoryUrlCache.values()) if (typeof URL < "u" && typeof URL.revokeObjectURL == "function") try {
			URL.revokeObjectURL(e);
		} catch {}
		this.memoryUrlCache.clear(), this.fallbackStore.clear();
		let e = await this.getDB();
		e && await new Promise((t) => {
			try {
				let n = e.transaction(il, "readwrite");
				n.objectStore(il).clear(), n.oncomplete = () => t(), n.onerror = () => t();
			} catch {
				t();
			}
		});
	}
}.getInstance(), ol = 10080 * 60 * 1e3, sl = class e {
	static instance;
	static getInstance() {
		return e.instance ||= new e(), e.instance;
	}
	extractImageIdsFromNote(e) {
		let t = /* @__PURE__ */ new Set();
		if (!e) return t;
		if (e.images && Array.isArray(e.images) && e.images.forEach((e) => {
			let n = al.normalizeId(e);
			n && t.add(n);
		}), e.content) {
			let n = /(?:!\[.*?\]|\[.*?\])\((?:attachment:\/\/)?(?:attachments\/|images\/)?([a-zA-Z0-9_\-\.]+\.[a-zA-Z0-9]+)\)/gi, r;
			for (; (r = n.exec(e.content)) !== null;) if (r[1]) {
				let e = al.normalizeId(r[1]);
				e && t.add(e);
			}
			let i = /src=["'](?:attachment:\/\/)?(?:attachments\/|images\/)?([a-zA-Z0-9_\-\.]+\.[a-zA-Z0-9]+)["']/gi, a;
			for (; (a = i.exec(e.content)) !== null;) if (a[1]) {
				let e = al.normalizeId(a[1]);
				e && t.add(e);
			}
		}
		return t;
	}
	collectActiveImageIds(e) {
		let t = /* @__PURE__ */ new Set();
		for (let n of e) n && !n.isPurged && this.extractImageIdsFromNote(n).forEach((e) => t.add(e));
		return t;
	}
	findOrphanImages(e, t, n = ol) {
		let r = Date.now();
		return e.filter((e) => !(t.has(e.id) || r - e.createdAt < n));
	}
	async performImageGC(e, t, n) {
		let r = this.collectActiveImageIds(e), i = await al.listImages(), a = (n?.gracePeriodDays ?? 7) * 24 * 60 * 60 * 1e3, o = this.findOrphanImages(i, r, a), s = 0, c = 0, l = [], u = (n?.remoteDir || "/toolkit/moment_notes_images").replace(/\/+$/, "");
		for (let e of o) {
			try {
				await al.deleteImage(e.id) && s++;
			} catch (t) {
				l.push(`本地删除 ${e.id} 失败: ${t.message}`);
			}
			if (t) try {
				let n = `${u}/${e.id}`;
				(await t.deleteFile(n)).success && c++;
			} catch (t) {
				l.push(`远端删除 ${e.id} 失败: ${t.message}`);
			}
		}
		return {
			activeCount: r.size,
			cleanedLocal: s,
			cleanedRemote: c,
			errors: l
		};
	}
}.getInstance(), cl = "sticky_notes_webdav_config", ll = {
	enabled: !1,
	serverUrl: "",
	username: "",
	password: "",
	remotePath: "/toolkit/moment_notes.json",
	autoSync: !0,
	syncIntervalMinutes: 5,
	lastSyncStatus: "idle",
	lastSyncTime: void 0,
	lastSyncMessage: "",
	syncImages: !0,
	imagesRemoteDir: "/toolkit/moment_notes_images",
	autoCompressImages: !0,
	maxImageSizeMB: 10
}, ul = class {
	config;
	constructor(e) {
		this.config = e;
	}
	getAuthHeader() {
		let e = this.config.username || "", t = this.config.password || "";
		try {
			return `Basic ${btoa(unescape(encodeURIComponent(`${e}:${t}`)))}`;
		} catch {
			return `Basic ${btoa(`${e}:${t}`)}`;
		}
	}
	getFullUrl(e) {
		let t = (this.config.serverUrl || "").trim();
		!t.startsWith("http://") && !t.startsWith("https://") && (t = `https://${t}`), t = t.replace(/\/+$/, "");
		let n = e.startsWith("/") ? e : `/${e}`;
		return `${t}${n}`;
	}
	async testConnection() {
		if (!this.config.serverUrl) return {
			success: !1,
			message: "请输入 WebDAV 服务器地址"
		};
		let e = this.getFullUrl("/");
		try {
			let t = await fetch(e, {
				method: "PROPFIND",
				headers: {
					Authorization: this.getAuthHeader(),
					Depth: "0"
				}
			}).catch(async () => await fetch(e, {
				method: "OPTIONS",
				headers: { Authorization: this.getAuthHeader() }
			}));
			return t.status === 401 || t.status === 403 ? {
				success: !1,
				message: "认证失败：用户名或应用密码错误 (HTTP " + t.status + ")"
			} : t.status >= 200 && t.status < 400 ? {
				success: !0,
				message: "WebDAV 服务器连接成功！"
			} : {
				success: !1,
				message: `服务器响应异常 (HTTP ${t.status}: ${t.statusText})`
			};
		} catch (e) {
			return {
				success: !1,
				message: `网络连接失败: ${e.message || "请检查服务器地址与网络"}`
			};
		}
	}
	async ensureDirectory(e) {
		let t = e.split("/").filter(Boolean), n = "";
		for (let e of t) {
			n += `/${e}`;
			let t = this.getFullUrl(n);
			try {
				(await fetch(t, {
					method: "PROPFIND",
					headers: {
						Authorization: this.getAuthHeader(),
						Depth: "0"
					}
				})).status === 404 && await fetch(t, {
					method: "MKCOL",
					headers: { Authorization: this.getAuthHeader() }
				});
			} catch {}
		}
		return !0;
	}
	async getFileMeta(e) {
		let t = this.getFullUrl(e);
		try {
			let e = await fetch(t, {
				method: "HEAD",
				headers: {
					Authorization: this.getAuthHeader(),
					"Cache-Control": "no-cache"
				}
			});
			if (e.status === 404 || !e.ok) return { exists: !1 };
			let n = e.headers.get("ETag") || void 0, r = n?.replace(/^W\//, "").replace(/"/g, "").trim(), i = e.headers.get("Last-Modified"), a = i ? new Date(i).getTime() : void 0, o = e.headers.get("Content-Length") ? Number(e.headers.get("Content-Length")) : void 0;
			return {
				exists: !0,
				etag: r || n,
				lastModified: a,
				contentLength: o
			};
		} catch {
			return { exists: !1 };
		}
	}
	async downloadJson(e) {
		let t = this.getFullUrl(e);
		try {
			let e = await fetch(t, {
				method: "GET",
				headers: {
					Authorization: this.getAuthHeader(),
					"Cache-Control": "no-cache"
				}
			});
			if (e.status === 404) return {
				exists: !1,
				data: null
			};
			if (!e.ok) throw Error(`下载失败 HTTP ${e.status}: ${e.statusText}`);
			let n = e.headers.get("ETag") || void 0, r = await e.text();
			return {
				exists: !0,
				data: JSON.parse(r),
				etag: n
			};
		} catch (e) {
			if (e.message && e.message.includes("404")) return {
				exists: !1,
				data: null
			};
			throw e;
		}
	}
	async uploadJson(e, t, n) {
		let r = e.lastIndexOf("/");
		if (r > 0) {
			let t = e.substring(0, r);
			await this.ensureDirectory(t);
		}
		let i = this.getFullUrl(e), a = typeof t == "string" ? t : JSON.stringify(t, null, 2), o = {
			Authorization: this.getAuthHeader(),
			"Content-Type": "application/json; charset=utf-8"
		};
		n && (o["If-Match"] = n);
		let s = await fetch(i, {
			method: "PUT",
			headers: o,
			body: a
		});
		if (s.status === 412) {
			let e = /* @__PURE__ */ Error("412 Precondition Failed: 远端文件在此期间已被其他设备更新");
			throw e.status = 412, e.isPreconditionFailed = !0, e;
		}
		if (!s.ok && s.status !== 201 && s.status !== 204) throw Error(`上传失败 HTTP ${s.status}: ${s.statusText}`);
		let c = s.headers.get("ETag") || void 0;
		return {
			success: !0,
			etag: c?.replace(/^W\//, "").replace(/"/g, "").trim() || c
		};
	}
	async uploadBinary(e, t, n = "image/png") {
		let r = e.lastIndexOf("/");
		if (r > 0) {
			let t = e.substring(0, r);
			await this.ensureDirectory(t);
		}
		let i = this.getFullUrl(e), a = {
			Authorization: this.getAuthHeader(),
			"Content-Type": n
		}, o = await fetch(i, {
			method: "PUT",
			headers: a,
			body: t
		});
		if (!o.ok && o.status !== 201 && o.status !== 204) throw Error(`二进制上传失败 HTTP ${o.status}: ${o.statusText}`);
		return {
			success: !0,
			etag: o.headers.get("ETag") || void 0
		};
	}
	async downloadBinary(e) {
		let t = this.getFullUrl(e);
		try {
			let e = await fetch(t, {
				method: "GET",
				headers: {
					Authorization: this.getAuthHeader(),
					"Cache-Control": "no-cache"
				}
			});
			if (e.status === 404) return {
				exists: !1,
				data: null
			};
			if (!e.ok) throw Error(`二进制下载失败 HTTP ${e.status}: ${e.statusText}`);
			let n = e.headers.get("ETag") || void 0;
			return {
				exists: !0,
				data: await e.blob(),
				etag: n
			};
		} catch (e) {
			if (e.message && e.message.includes("404")) return {
				exists: !1,
				data: null
			};
			throw e;
		}
	}
	async deleteFile(e) {
		let t = this.getFullUrl(e);
		try {
			let e = await fetch(t, {
				method: "DELETE",
				headers: { Authorization: this.getAuthHeader() }
			});
			return e.status === 404 || e.ok || e.status === 204 ? { success: !0 } : { success: !1 };
		} catch {
			return { success: !1 };
		}
	}
	async checkFileExists(e) {
		let t = this.getFullUrl(e);
		try {
			let e = await fetch(t, {
				method: "HEAD",
				headers: { Authorization: this.getAuthHeader() }
			}).catch(async () => await fetch(t, {
				method: "PROPFIND",
				headers: {
					Authorization: this.getAuthHeader(),
					Depth: "0"
				}
			}));
			return e.status >= 200 && e.status < 300;
		} catch {
			return !1;
		}
	}
}, dl = class e {
	static instance;
	config = /* @__PURE__ */ F(this.loadConfig());
	syncState = /* @__PURE__ */ F("idle");
	syncMessage = /* @__PURE__ */ F("");
	isSyncing = /* @__PURE__ */ F(!1);
	debounceTimer = null;
	pollingTimer = null;
	dataGetter = null;
	dataApplier = null;
	static getInstance() {
		return e.instance ||= new e(), e.instance;
	}
	loadConfig() {
		let e = Y.getItem(cl);
		if (!e) return { ...ll };
		try {
			let t = JSON.parse(e);
			return t.remotePath === "/ScriptKit/moment_notes.json" && (t.remotePath = "/toolkit/moment_notes.json"), {
				...ll,
				...t
			};
		} catch {
			return { ...ll };
		}
	}
	saveConfig(e) {
		this.config.value = {
			...this.config.value,
			...e
		}, Y.setItem(cl, JSON.stringify(this.config.value)), this.restartPolling();
	}
	initScheduler(e, t) {
		this.dataGetter = e, this.dataApplier = t, this.restartPolling();
	}
	startPolling() {
		this.stopPolling();
		let e = this.config.value;
		if (!e.enabled || !e.autoSync || !this.dataGetter || !this.dataApplier) return;
		let t = Math.max(1, e.syncIntervalMinutes || 5);
		this.pollingTimer = setInterval(() => {
			this.config.value.enabled && this.config.value.autoSync && this.performSync(this.dataGetter, this.dataApplier, { silent: !0 }).catch(() => {});
		}, t * 60 * 1e3);
	}
	stopPolling() {
		this.pollingTimer &&= (clearInterval(this.pollingTimer), null);
	}
	restartPolling() {
		this.stopPolling(), this.startPolling();
	}
	lastTriggerTime = 0;
	async triggerSyncCheck(e) {
		if (!this.config.value.enabled) return {
			success: !1,
			message: "WebDAV 未启用"
		};
		let t = e?.minIntervalMs ?? 1e4, n = Date.now();
		return n - this.lastTriggerTime < t ? {
			success: !0,
			message: "同步检查冷却中，已跳过",
			throttled: !0
		} : (this.lastTriggerTime = n, !this.dataGetter || !this.dataApplier ? {
			success: !1,
			message: "调度器未准备就绪"
		} : this.performSync(this.dataGetter, this.dataApplier, { silent: e?.silent ?? !0 }));
	}
	hasLocalChangesSince(e, t) {
		if (!t || t <= 0) return !0;
		for (let n of e.notes || []) if (Math.max(n.updatedAt || 0, n.deletedAt || 0, n.purgedAt || 0, n.createdAt || 0) > t) return !0;
		for (let n of e.categories || []) if (Math.max(n.updatedAt || 0, n.deletedAt || 0, n.purgedAt || 0, n.createdAt || 0) > t) return !0;
		return !1;
	}
	mergeBackupData(e, t, n) {
		let r = Date.now(), i = 720 * 60 * 60 * 1e3, a = n === void 0 ? this.config.value?.lastSyncTime || 0 : n, o = /* @__PURE__ */ new Map(), s = /* @__PURE__ */ new Set();
		for (let t of e.notes || []) t && t.id && s.add(t.id);
		for (let e of t.notes || []) e && e.id && s.add(e.id);
		let c = new Map((e.notes || []).map((e) => [e.id, e])), l = new Map((t.notes || []).map((e) => [e.id, e]));
		for (let e of s) {
			let t = c.get(e), n = l.get(e);
			if (t && !n) o.set(e, t);
			else if (!t && n) o.set(e, n);
			else if (t && n) {
				let i = !!t.isPurged, s = !!n.isPurged, c = t.purgedAt || 0, l = n.purgedAt || 0, u = Math.max(c, l), d = Math.max(t.updatedAt || 0, t.createdAt || 0), f = Math.max(n.updatedAt || 0, n.createdAt || 0);
				if ((i || s) && u >= Math.max(d, f)) {
					o.set(e, {
						...i ? t : n,
						isDeleted: !0,
						isPurged: !0,
						purgedAt: u
					});
					continue;
				}
				let p = !t.isDeleted && !n.isDeleted && !i && !s, m = t.content !== n.content || (t.title || "") !== (n.title || ""), h = Math.max(t.updatedAt || 0, t.deletedAt || 0, t.createdAt || 0), g = Math.max(n.updatedAt || 0, n.deletedAt || 0, n.createdAt || 0);
				if (p && m && (a > 0 && h > a && g > a || h === g)) {
					let i = h >= g ? t : n, a = h >= g ? n : t;
					o.set(e, i);
					let s = `${e}_conflict_${Math.min(h, g)}`;
					if (!o.has(s)) {
						let e = {
							...a,
							id: s,
							title: `[冲突副本] ${a.title || "便签"}`,
							createdAt: r,
							updatedAt: r
						};
						o.set(s, e);
					}
				} else h >= g ? o.set(e, t) : o.set(e, n);
			}
		}
		let u = Array.from(o.values()).filter((e) => !(e.isPurged && e.purgedAt && r - e.purgedAt > i || e.isDeleted && e.deletedAt && r - e.deletedAt > i)), d = /* @__PURE__ */ new Map(), f = /* @__PURE__ */ new Set();
		for (let t of e.categories || []) t && t.id && f.add(t.id);
		for (let e of t.categories || []) e && e.id && f.add(e.id);
		let p = new Map((e.categories || []).map((e) => [e.id, e])), m = new Map((t.categories || []).map((e) => [e.id, e]));
		for (let e of f) {
			let t = p.get(e), n = m.get(e);
			t && !n ? d.set(e, t) : !t && n ? d.set(e, n) : t && n && (Math.max(t.updatedAt || 0, t.deletedAt || 0, t.createdAt || 0) >= Math.max(n.updatedAt || 0, n.deletedAt || 0, n.createdAt || 0) ? d.set(e, t) : d.set(e, n));
		}
		let h = Array.from(d.values()).filter((e) => !(e.isDeleted && e.deletedAt && r - e.deletedAt > i)), g = e.categoryOrder || [], _ = t.categoryOrder || [], v = /* @__PURE__ */ new Set(), y = [];
		for (let e of g) v.has(e) || (v.add(e), y.push(e));
		for (let e of _) v.has(e) || (v.add(e), y.push(e));
		for (let e of h) v.has(e.id) || (v.add(e.id), y.push(e.id));
		let b = e.settings || {}, x = t.settings || {};
		return {
			version: "1.7.0",
			timestamp: r,
			categories: h,
			notes: u,
			categoryOrder: y,
			settings: {
				...x,
				...b,
				categoryViewSettings: {
					...x.categoryViewSettings || {},
					...b.categoryViewSettings || {}
				},
				shortcuts: b.shortcuts || x.shortcuts
			}
		};
	}
	async performSync(e, t, n) {
		let r = this.config.value;
		if (!r.enabled || !r.serverUrl || !r.remotePath) return {
			success: !1,
			message: "WebDAV 未启用或配置不完整"
		};
		if (this.isSyncing.value) return {
			success: !1,
			message: "同步任务正在进行中，已自动跳过重叠请求"
		};
		this.isSyncing.value = !0, this.syncState.value = "syncing", this.syncMessage.value = "正在同步中...";
		let i = new ul(r);
		try {
			let a = 0;
			for (; a <= 2;) {
				let o = e(), s = o;
				if (n?.forcePull) {
					let e = await i.downloadJson(r.remotePath);
					if (!e.exists || !e.data) throw Error("远端未发现有效的备份文件");
					let n = zc.decode(JSON.stringify(e.data));
					if (!n) throw Error("远端备份数据解析失败");
					return t(n), this.syncState.value = "success", this.syncMessage.value = `已强制从云端拉取覆盖本地 (${(/* @__PURE__ */ new Date()).toLocaleTimeString()})`, this.saveConfig({
						lastSyncTime: Date.now(),
						lastSyncStatus: "success",
						lastSyncMessage: this.syncMessage.value,
						lastEtag: e.etag
					}), {
						success: !0,
						message: "已从云端拉取覆盖本地",
						mergedNotesCount: n.notes.length
					};
				}
				let c;
				if (!n?.forcePush) {
					if (r.lastSyncTime && r.lastSyncTime > 0) try {
						let e = await i.getFileMeta(r.remotePath);
						if (e.exists) {
							let t = e.etag?.replace(/^W\//, "").replace(/"/g, "").trim(), n = r.lastEtag?.replace(/^W\//, "").replace(/"/g, "").trim(), i = !1;
							t && n ? i = t === n : e.lastModified && (i = e.lastModified <= r.lastSyncTime + 1e3);
							let a = !Bc.hasUnsyncedChanges() && !this.hasLocalChangesSince(o, r.lastSyncTime);
							if (i && a) return this.syncState.value = "success", this.syncMessage.value = `已是最新 (${(/* @__PURE__ */ new Date()).toLocaleTimeString()})`, {
								success: !0,
								message: "数据已是最新，无须网络下载",
								mergedNotesCount: o.notes.length
							};
						}
					} catch (e) {
						console.warn("[WebdavSync] getFileMeta probe failed, fallback to full sync:", e);
					}
					let n = await i.downloadJson(r.remotePath);
					if (c = n.etag, n.exists && n.data) {
						let i = zc.decode(JSON.stringify(n.data));
						if (i) {
							let n = (!o.notes || o.notes.length === 0) && (o.categories || []).every((e) => [
								"1",
								"2",
								"3"
							].includes(e.id)), a = i.notes.length > 0 || (i.categories || []).some((e) => ![
								"1",
								"2",
								"3"
							].includes(e.id));
							if (n && a) s = i, t(s);
							else {
								let n = e();
								s = this.mergeBackupData(n, i, r.lastSyncTime || 0), t(s);
							}
						}
					}
				}
				try {
					let e = await i.uploadJson(r.remotePath, s, n?.forcePush ? void 0 : c);
					Bc.clearDraft(), r.syncImages !== !1 && this.syncPendingImages().catch((e) => {
						console.warn("[WebdavSync] syncPendingImages error:", e);
					});
					let t = e.etag, a = Date.now();
					if (!t) try {
						let e = await i.getFileMeta(r.remotePath);
						e.exists && (e.etag && (t = e.etag), e.lastModified && (a = Math.max(a, e.lastModified)));
					} catch (e) {
						console.warn("[WebdavSync] post-upload meta probe failed:", e);
					}
					let o = (e) => e?.replace(/^W\//, "").replace(/"/g, "").trim();
					return this.syncState.value = "success", this.syncMessage.value = `同步成功 (${new Date(a).toLocaleTimeString()})`, this.saveConfig({
						lastSyncTime: a,
						lastSyncStatus: "success",
						lastSyncMessage: this.syncMessage.value,
						lastEtag: o(t || e.etag || c)
					}), {
						success: !0,
						message: "WebDAV 同步成功！",
						mergedNotesCount: s.notes.length
					};
				} catch (e) {
					if (e.isPreconditionFailed && a < 2) {
						a++;
						continue;
					}
					throw e;
				}
			}
			throw Error("同步并发重试次数超限，请稍后重试");
		} catch (e) {
			return this.syncState.value = "error", this.syncMessage.value = `同步失败: ${e.message || "网络异常"}`, this.saveConfig({
				lastSyncStatus: "error",
				lastSyncMessage: this.syncMessage.value
			}), {
				success: !1,
				message: this.syncMessage.value
			};
		} finally {
			this.isSyncing.value = !1;
		}
	}
	async syncPendingImages() {
		let e = this.config.value;
		if (!e.enabled || e.syncImages === !1 || !e.serverUrl) return {
			uploaded: 0,
			failed: 0
		};
		let t = await al.getPendingUploads();
		if (t.length === 0) return {
			uploaded: 0,
			failed: 0
		};
		let n = new ul(e), r = (e.imagesRemoteDir || "/toolkit/moment_notes_images").replace(/\/+$/, "");
		await n.ensureDirectory(r);
		let i = 0, a = 0;
		for (let e of t) try {
			let t = `${r}/${e.id}`;
			await n.uploadBinary(t, e.blob, e.meta.mimeType), await al.markUploadStatus(e.id, "uploaded"), i++;
		} catch (t) {
			console.warn(`[WebdavSync] Upload image ${e.id} failed:`, t), await al.markUploadStatus(e.id, "failed"), a++;
		}
		return {
			uploaded: i,
			failed: a
		};
	}
	async downloadImageIfMissing(e) {
		let t = al.normalizeId(e);
		if (!t) return null;
		let n = await al.getImageBlob(t);
		if (n) return n;
		let r = this.config.value;
		if (!r.enabled || r.syncImages === !1 || !r.serverUrl) return null;
		let i = new ul(r), a = `${(r.imagesRemoteDir || "/toolkit/moment_notes_images").replace(/\/+$/, "")}/${t}`;
		try {
			let e = await i.downloadBinary(a);
			if (e.exists && e.data) return await al.saveImage(e.data, {
				customId: t,
				uploadStatus: "uploaded",
				autoCompress: !1
			}), e.data;
		} catch (e) {
			console.warn(`[WebdavSync] Failed to lazy download image ${t}:`, e);
		}
		return null;
	}
	triggerDebouncedPush(e, t, n = 3e3) {
		!this.config.value.enabled || !this.config.value.autoSync || (this.debounceTimer && clearTimeout(this.debounceTimer), this.debounceTimer = setTimeout(() => {
			this.performSync(e, t, { silent: !0 });
		}, n));
	}
}.getInstance(), fl = Oc("noteStore", () => {
	let e = /* @__PURE__ */ F([]), t = /* @__PURE__ */ F([]), n = /* @__PURE__ */ F("all"), r = /* @__PURE__ */ F(""), i = /* @__PURE__ */ F(["all"]), a = /* @__PURE__ */ F("date"), o = /* @__PURE__ */ F("desc"), s = /* @__PURE__ */ F(null), c = /* @__PURE__ */ F(null), l = /* @__PURE__ */ F(!1), u = () => {
		let r = n.value, i = e.value, a = Wc(), o = i;
		if (r === "trash") o = o.filter((e) => e.isDeleted === !0 && !e.isPurged);
		else if (r === "recent") o = o.filter((e) => e.isDeleted !== !0 && !e.isPurged && e.lastUsedAt !== void 0);
		else if (o = o.filter((e) => e.isDeleted !== !0 && !e.isPurged), r !== "all") {
			let e = a.getCategoryDescendants(r);
			o = o.filter((t) => t.categoryId === r || e.has(t.categoryId));
		}
		t.value = o;
	}, d = (e = !0) => {
		u(), l.value = !1;
	}, f = (e) => {
		let t = el();
		if (!t.categoryIndependentToolbar) return;
		let n = t.categoryViewSettings[e];
		n && (n.sortMode && (a.value = n.sortMode), n.sortOrder && (o.value = n.sortOrder), n.gridColumns && (t.gridColumns = n.gridColumns));
	};
	Gn(n, (e) => {
		e && (Y.setItem("sticky_notes_last_category_id", e), f(e), d());
	}), Gn(o, (e) => {
		let t = el();
		t.categoryIndependentToolbar && n.value && t.updateCategoryViewSetting(n.value, { sortOrder: e });
	}), Gn(a, (e) => {
		let t = el();
		t.categoryIndependentToolbar && n.value && t.updateCategoryViewSetting(n.value, { sortMode: e });
	});
	let p = () => {
		Vc.saveAll(e.value);
	}, m = "", h = (t, n = "", r = "", i, a) => {
		let o = el(), s = i || o.defaultNoteColor || "random";
		if (s === "random") {
			let e = Object.keys(tl), t = e.length > 1 ? e.filter((e) => e !== m) : e;
			s = t[Math.floor(Math.random() * t.length)], m = s;
		}
		let l = a || o.defaultNoteType || "text", d = {
			id: `${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
			categoryId: t,
			title: r.trim(),
			content: n,
			type: l,
			color: s,
			isPinned: !1,
			createdAt: Date.now(),
			updatedAt: Date.now(),
			tags: []
		};
		return e.value.unshift(d), p(), u(), c.value = d.id, Uc.emit("NOTE_CREATED", d), d;
	}, g = (t) => {
		let n = e.value.find((e) => e.id === t);
		n && (n.isDeleted ? (n.isPurged = !0, n.purgedAt = Date.now(), Uc.requestToast("已彻底删除便签", "success")) : (n.isDeleted = !0, n.deletedAt = Date.now(), n.isPinned = !1, Uc.requestToast("已将便签移至最近删除", "success")), p(), u(), Uc.emit("NOTE_DELETED", t));
	}, _ = (t) => {
		let n = e.value.find((e) => e.id === t);
		n && (n.isDeleted = !1, n.isPurged = !1, delete n.deletedAt, delete n.purgedAt, n.updatedAt = Date.now(), p(), u(), Uc.requestToast("已成功恢复便签", "success"), Uc.emit("NOTE_RESTORED", t));
	}, v = () => {
		let t = Date.now();
		e.value.forEach((e) => {
			e.isDeleted && !e.isPurged && (e.isPurged = !0, e.purgedAt = t);
		}), p(), u(), Uc.requestToast("已清空最近删除的所有便签", "success");
		let n = dl.config.value, r = n.enabled ? new ul(n) : void 0;
		sl.performImageGC(e.value, r, {
			gracePeriodDays: 7,
			remoteDir: n.imagesRemoteDir || "/toolkit/moment_notes_images"
		}).catch((e) => console.warn("[NoteStore] Image GC error:", e));
	}, y = /* @__PURE__ */ F(0);
	return Gn(() => e.value, (e) => {
		y.value = e.filter((e) => e.isDeleted === !0 && !e.isPurged).length;
	}, {
		deep: !0,
		immediate: !0
	}), {
		allNotes: e,
		notes: t,
		currentCategoryId: n,
		searchQuery: r,
		searchTarget: i,
		sortMode: a,
		sortOrder: o,
		draggedNoteId: s,
		editingNoteId: c,
		isLoadingNotes: l,
		saveNotes: p,
		addNote: h,
		deleteNote: g,
		restoreNote: _,
		clearTrash: v,
		trashNotesCount: y,
		updateNote: (t, n, r = !0) => {
			let i = e.value.find((e) => e.id === t);
			i && (Object.assign(i, n), r && (i.updatedAt = Date.now()), p(), u(), Uc.emit("NOTE_UPDATED", i));
		},
		clearNotes: (t, n) => {
			if (t === "all") e.value.forEach((e) => {
				!e.isDeleted && !e.isPurged && (e.isDeleted = !0, e.deletedAt = Date.now(), e.isPinned = !1);
			});
			else if (t === "trash") {
				v();
				return;
			} else e.value.forEach((e) => {
				(e.categoryId === t || n && n.has(e.categoryId)) && !e.isDeleted && !e.isPurged && (e.isDeleted = !0, e.deletedAt = Date.now(), e.isPinned = !1);
			});
			p(), u(), Uc.requestToast("已清空当前分类下的便签", "success");
		},
		setSortMode: (e) => {
			e === a.value ? e !== "custom" && (o.value = o.value === "asc" ? "desc" : "asc") : (a.value = e, e === "date" ? o.value = "desc" : e === "title" || e === "tag" ? o.value = "asc" : e === "useCount" && (o.value = "desc")), Y.setItem("sticky_notes_sort_mode", a.value), Y.setItem("sticky_notes_sort_order", o.value);
		},
		moveNote: (r, i) => {
			let a = t.value.findIndex((e) => e.id === r), o = t.value.findIndex((e) => e.id === i);
			if (a !== -1 && o !== -1) {
				let s = t.value[a], c = t.value[o];
				if (s.isPinned === c.isPinned) {
					if (n.value !== "all" && n.value !== "trash" && s.categoryId !== c.categoryId) {
						s.categoryId = c.categoryId, s.updatedAt = Date.now();
						let t = e.value.find((e) => e.id === r);
						t && (t.categoryId = c.categoryId, t.updatedAt = Date.now());
					}
					let [l] = t.value.splice(a, 1);
					t.value.splice(o, 0, l);
					let u = e.value.findIndex((e) => e.id === r), d = e.value.findIndex((e) => e.id === i);
					if (u !== -1 && d !== -1) {
						let [t] = e.value.splice(u, 1);
						e.value.splice(d, 0, t);
					}
					p();
				}
			}
		},
		updateNoteLastUsed: (t) => {
			let n = e.value.find((e) => e.id === t);
			n && (n.lastUsedAt = Date.now(), n.useCount = (n.useCount || 0) + 1, p(), u());
		},
		loadNotesForCurrentCategory: d,
		syncCurrentCategoryNotes: u,
		applyCategoryViewSettings: f
	};
}), pl = () => [
	{
		id: "1",
		name: "常用模版",
		createdAt: Date.now()
	},
	{
		id: "2",
		name: "工作备忘",
		createdAt: Date.now() - 1e3
	},
	{
		id: "3",
		name: "灵感想法",
		createdAt: Date.now() - 2e3
	}
], ml = () => [];
Date.now() - 1e3, Date.now() - 1e3, Date.now() - 2e3, Date.now() - 2e3, Date.now() - 3e3, Date.now() - 3e3, Date.now() - 4e3, Date.now() - 4e3;
//#endregion
//#region src/stores/stickyNotesHelpers.ts
var hl = (e, t, n, r) => ({
	version: r || "1.7.0",
	timestamp: Date.now(),
	categories: e,
	notes: t,
	...n ? { settings: n } : {}
}), gl = (e, t, n) => {
	let r = "1.7.0", i = Y.getItem("sticky_notes_app_version");
	if (i && i !== r) try {
		let a = hl(e, t, n, i);
		Y.setItem("sticky_notes_pre_update_backup", JSON.stringify(a)), console.log(`[AutoBackup] 检测到版本更新 (${i} -> ${r})，已保存更新前数据备份至 sticky_notes_pre_update_backup`);
	} catch (e) {
		console.error("[AutoBackup] 自动备份更新前数据失败:", e);
	}
	Y.setItem("sticky_notes_app_version", r);
}, _l = (e, t, n, r) => {
	let i = hl(e, t, n), a = JSON.stringify(i, null, 2), o = (e) => String(e).padStart(2, "0"), s = /* @__PURE__ */ new Date(), c = Fc(a, `moment-notes-backup-${`${s.getFullYear()}.${o(s.getMonth() + 1)}.${o(s.getDate())} ${o(s.getHours())}.${o(s.getMinutes())}.${o(s.getSeconds())}`}.json`, "application/json");
	c === "success" ? r("备份已成功导出", "success") : c === "canceled" ? r("已取消备份导出", "info") : r("备份已导出为 JSON 文件下载", "success");
}, vl = (e, t, n, r, i) => {
	let a = new Set(r.categoryIds), o = hl(e.filter((e) => a.has(e.id)), t.filter((e) => {
		if (e.isDeleted && !r.includeTrash) return !1;
		let t = e.categoryId || "all";
		return t === "all" ? a.has("all") || a.has("uncategorized") : a.has(t);
	}), r.includeSettings ? n : void 0), s = JSON.stringify(o, null, 2), c = (e) => String(e).padStart(2, "0"), l = /* @__PURE__ */ new Date(), u = Fc(s, `moment-notes-backup-${`${l.getFullYear()}.${c(l.getMonth() + 1)}.${c(l.getDate())} ${c(l.getHours())}.${c(l.getMinutes())}.${c(l.getSeconds())}`}.json`, "application/json");
	u === "success" ? i("所选数据已成功导出", "success") : u === "canceled" ? i("已取消备份导出", "info") : i("所选数据已导出为 JSON 文件下载", "success");
}, yl = (e, t, n, r, i, a, o, s, c) => {
	try {
		let l = JSON.parse(e);
		if (!l || typeof l != "object") return !1;
		let u = Array.isArray(l.categories), d = Array.isArray(l.notes), f = !!(l.settings && typeof l.settings == "object");
		if (!u && !d && !f) return s("导入失败：备份文件不包含有效的数据", "error"), !1;
		let p = u ? l.categories.filter((e) => e && typeof e.id == "string" && typeof e.name == "string") : [], m = d ? l.notes.filter((e) => e && typeof e.id == "string" && typeof e.categoryId == "string" && typeof e.content == "string" && typeof e.color == "string") : [];
		if (p.length === 0 && m.length === 0 && !f) return s("导入失败：备份文件不包含有效的分类、便签或设置数据", "error"), !1;
		if (p.length > 0) {
			let e = new Map(t.value.map((e) => [e.id, e]));
			p.forEach((t) => {
				e.set(t.id, {
					id: t.id,
					name: t.name,
					createdAt: t.createdAt || Date.now(),
					parentId: typeof t.parentId == "string" ? t.parentId : void 0
				});
			}), t.value = Array.from(e.values()), i();
		}
		if (m.length > 0) {
			let e = new Map(n.value.map((e) => [e.id, e]));
			m.forEach((t) => {
				e.set(t.id, {
					id: t.id,
					categoryId: t.categoryId,
					title: t.title || "",
					content: t.content,
					color: t.color,
					isPinned: !!t.isPinned,
					createdAt: t.createdAt || Date.now(),
					updatedAt: t.updatedAt || Date.now(),
					tags: Array.isArray(t.tags) ? t.tags.filter((e) => typeof e == "string") : [],
					type: t.type || "text",
					images: Array.isArray(t.images) ? t.images : void 0,
					isDeleted: !!t.isDeleted,
					deletedAt: t.deletedAt,
					lastUsedAt: t.lastUsedAt,
					useCount: t.useCount
				});
			}), n.value = Array.from(e.values()), a();
		}
		if (p.length > 0) {
			let e = new Set(t.value.map((e) => e.id));
			e.add("all");
			let n = r.value.filter((t) => e.has(t));
			t.value.forEach((e) => {
				n.includes(e.id) || n.push(e.id);
			}), n.includes("all") || n.unshift("all"), r.value = n, o();
		}
		f && c && c(l.settings);
		let h = `成功导入 ${p.length} 个分类和 ${m.length} 张便签！`;
		return f && (h = `成功导入 ${p.length} 个分类、${m.length} 张便签及系统设置！`), s(h, "success"), !0;
	} catch (e) {
		return console.error("Import backup failed:", e), s("导入失败：JSON 文件解析错误", "error"), !1;
	}
}, bl = (e, t, n, r, i, a, o, s, c, l) => {
	try {
		if (!e || typeof e != "object") return !1;
		let u = new Set(t.categoryIds), d = Array.isArray(e.categories) ? e.categories : [], f = Array.isArray(e.notes) ? e.notes : [], p = d.filter((e) => e && typeof e.id == "string" && typeof e.name == "string" && u.has(e.id)), m = f.filter((e) => {
			if (!e || typeof e.id != "string" || typeof e.content != "string" || typeof e.color != "string") return !1;
			let n = e.categoryId || "all";
			return !!(n !== "all" && u.has(n) || (n === "all" || !n) && t.importUncategorized);
		}), h = p.length > 0, g = m.length > 0, _ = t.importSettings && !!(e.settings && typeof e.settings == "object");
		if (!h && !g && !_) return c("未选择任何有效的数据项进行导入", "warning"), !1;
		if (t.mode === "overwrite") u.size > 0 ? n.value = p.map((e) => ({
			id: e.id,
			name: e.name,
			createdAt: e.createdAt || Date.now(),
			parentId: typeof e.parentId == "string" ? e.parentId : void 0
		})) : n.value = [], r.value = m.map((e) => ({
			id: e.id,
			categoryId: e.categoryId || "all",
			title: e.title || "",
			content: e.content,
			color: e.color,
			isPinned: !!e.isPinned,
			createdAt: e.createdAt || Date.now(),
			updatedAt: e.updatedAt || Date.now(),
			tags: Array.isArray(e.tags) ? e.tags.filter((e) => typeof e == "string") : [],
			type: e.type || "text",
			images: Array.isArray(e.images) ? e.images : void 0,
			isDeleted: !!e.isDeleted,
			deletedAt: e.deletedAt,
			lastUsedAt: e.lastUsedAt,
			useCount: e.useCount
		}));
		else {
			if (h) {
				let e = new Map(n.value.map((e) => [e.id, e]));
				p.forEach((t) => {
					e.set(t.id, {
						id: t.id,
						name: t.name,
						createdAt: t.createdAt || Date.now(),
						parentId: typeof t.parentId == "string" ? t.parentId : void 0
					});
				}), n.value = Array.from(e.values());
			}
			if (g) {
				let e = new Map(r.value.map((e) => [e.id, e]));
				m.forEach((t) => {
					e.set(t.id, {
						id: t.id,
						categoryId: t.categoryId || "all",
						title: t.title || "",
						content: t.content,
						color: t.color,
						isPinned: !!t.isPinned,
						createdAt: t.createdAt || Date.now(),
						updatedAt: t.updatedAt || Date.now(),
						tags: Array.isArray(t.tags) ? t.tags.filter((e) => typeof e == "string") : [],
						type: t.type || "text",
						images: Array.isArray(t.images) ? t.images : void 0,
						isDeleted: !!t.isDeleted,
						deletedAt: t.deletedAt,
						lastUsedAt: t.lastUsedAt,
						useCount: t.useCount
					});
				}), r.value = Array.from(e.values());
			}
		}
		a(), o();
		let v = new Set(n.value.map((e) => e.id));
		v.add("all");
		let y = i.value.filter((e) => v.has(e));
		n.value.forEach((e) => {
			y.includes(e.id) || y.push(e.id);
		}), y.includes("all") || y.unshift("all"), i.value = y, s(), _ && l && e.settings && l(e.settings);
		let b = t.mode === "overwrite" ? "覆盖" : "增量", x = `成功以【${b}】模式导入 ${p.length} 个分类和 ${m.length} 张便签！`;
		return _ && (x = `成功以【${b}】模式导入 ${p.length} 个分类、${m.length} 张便签及系统设置！`), c(x, "success"), !0;
	} catch (e) {
		return console.error("Import selected backup failed:", e), c("导入失败：处理备份数据时发生错误", "error"), !1;
	}
}, xl = (e, t, n = !0) => {
	let r = e.title || "无标题便签", i = e.tags && e.tags.length > 0 ? `标签: ${e.tags.map((e) => n ? `#${e}` : e).join(" ")}\n` : "", a = Fc(`${r}\n创建时间: ${new Date(e.createdAt).toLocaleString()}\n${i}---------------------------\n\n${e.content}`, `${r.replace(/[\\/:*?"<>|]/g, "_")}.txt`, "text/plain;charset=utf-8");
	a === "success" ? t("便签已成功导出", "success") : a === "canceled" ? t("已取消导出", "info") : t("便签已导出为 TXT 文本下载", "success");
}, Sl = (e, t, n) => {
	e.value = ml(), t(), n("已重置所有便签(Notes)", "success");
}, Cl = (e, t, n) => {
	e.value = e.value.map((e) => ({
		...e,
		tags: []
	})), t(), n("已重置所有便签的标签(Tags)", "success");
}, wl = (e, t, n) => {
	Y.removeItem("sticky_notes_categories"), Y.removeItem("sticky_notes_category_order"), Y.removeItem("sticky_notes_notes"), Y.removeItem("sticky_notes_grid_columns"), t.value = "auto", e(), n("已重置所有数据(便签和分类)", "success");
}, Tl = (e, t) => {
	if (e.length !== t.length) return !1;
	let n = new Map(e.map((e) => [e.id, e]));
	for (let e of t) {
		let t = n.get(e.id);
		if (!t || e.updatedAt !== t.updatedAt || e.title !== t.title || e.content !== t.content || e.categoryId !== t.categoryId || e.color !== t.color || e.type !== t.type || !!e.isPinned != !!t.isPinned || !!e.isDeleted != !!t.isDeleted || !!e.isPurged != !!t.isPurged || (e.deletedAt || 0) !== (t.deletedAt || 0) || (e.purgedAt || 0) !== (t.purgedAt || 0)) return !1;
		let r = e.tags || [], i = t.tags || [];
		if (r.length !== i.length) return !1;
		for (let e = 0; e < r.length; e++) if (r[e] !== i[e]) return !1;
		let a = e.images || [], o = t.images || [];
		if (a.length !== o.length) return !1;
		for (let e = 0; e < a.length; e++) if (a[e] !== o[e]) return !1;
	}
	return !0;
}, El = (e, t) => {
	if (e.length !== t.length) return !1;
	let n = new Map(e.map((e) => [e.id, e]));
	for (let e of t) {
		let t = n.get(e.id);
		if (!t || e.name !== t.name || e.parentId !== t.parentId || e.updatedAt !== t.updatedAt || !!e.isDeleted != !!t.isDeleted || !!e.isPurged != !!t.isPurged) return !1;
	}
	return !0;
}, Dl = (e, t) => {
	if (e.length !== t.length) return !1;
	for (let n = 0; n < e.length; n++) if (e[n] !== t[n]) return !1;
	return !0;
}, Ol = (e, t) => {
	if (!e && !t) return !0;
	if (!e || !t) return !1;
	try {
		return JSON.stringify(e) === JSON.stringify(t);
	} catch {
		return !1;
	}
}, kl = new class {
	commands = /* @__PURE__ */ new Map();
	register(e) {
		return this.commands.has(e.id) && console.warn(`[CommandRegistry] Warning: Command with ID "${e.id}" is already registered and will be overwritten.`), this.commands.set(e.id, e), () => {
			this.commands.delete(e.id);
		};
	}
	registerHandler(e, t, n, r) {
		return this.register({
			id: e,
			name: t,
			handler: n,
			description: r
		});
	}
	execute(e, t) {
		let n = this.commands.get(e);
		if (n) try {
			return n.handler({ payload: t }), !0;
		} catch (t) {
			return console.error(`Failed to execute command ${e}:`, t), !1;
		}
		return !1;
	}
	has(e) {
		return this.commands.has(e);
	}
	get(e) {
		return this.commands.get(e);
	}
	clear() {
		this.commands.clear();
	}
}();
//#endregion
//#region src/domain/shortcuts/KeyCombo.ts
function Al(e) {
	if (!e) return "";
	let t = e.toLowerCase();
	return [
		"control",
		"shift",
		"alt",
		"meta"
	].includes(t) ? "" : t === " " || t === "space" ? "Space" : t === "arrowleft" || t === "left" ? "Left" : t === "arrowright" || t === "right" ? "Right" : t === "arrowup" || t === "up" ? "Up" : t === "arrowdown" || t === "down" ? "Down" : t === "enter" ? "Enter" : t === "escape" || t === "esc" ? "Escape" : t === "tab" ? "Tab" : t === "backspace" ? "Backspace" : t === "delete" ? "Delete" : e.length === 1 ? e.toUpperCase() : e.charAt(0).toUpperCase() + e.slice(1);
}
function jl(e) {
	let t = Al(e.key);
	if (!t) return null;
	let n = !!(e.ctrlKey || e.metaKey), r = !!e.altKey, i = !!e.shiftKey, a = !!e.metaKey, o = [];
	return n && o.push("Ctrl"), r && o.push("Alt"), i && o.push("Shift"), o.push(t), {
		ctrl: n,
		alt: r,
		shift: i,
		meta: a,
		key: t,
		rawString: o.join("+")
	};
}
function Ml(e) {
	if (!e || !e.trim()) return "";
	let t = e.split("+").map((e) => e.trim()).filter(Boolean), n = !1, r = !1, i = !1, a = "";
	for (let e of t) {
		let t = e.toLowerCase();
		t === "ctrl" || t === "control" || t === "meta" || t === "cmd" ? n = !0 : t === "alt" ? r = !0 : t === "shift" ? i = !0 : a = Al(e);
	}
	if (!a) return "";
	let o = [];
	return n && o.push("Ctrl"), r && o.push("Alt"), i && o.push("Shift"), o.push(a), o.join("+");
}
var Nl = new class {
	activeContexts = new Set(["global"]);
	setContext(e, t) {
		t ? this.activeContexts.add(e) : this.activeContexts.delete(e);
	}
	hasContext(e) {
		return this.activeContexts.has(e);
	}
	evaluate(e) {
		return !e || !e.trim() ? !0 : e.split("||").map((e) => e.trim()).some((e) => e.split("&&").map((e) => e.trim()).every((e) => {
			if (e.startsWith("!")) {
				let t = e.substring(1).trim();
				return !this.activeContexts.has(t);
			}
			return this.activeContexts.has(e);
		}));
	}
	reset() {
		this.activeContexts.clear(), this.activeContexts.add("global");
	}
}(), Pl = new class {
	bindings = /* @__PURE__ */ new Map();
	constructor() {
		this.registerDefaults();
	}
	registerDefaults() {
		for (let e of [
			{
				id: "addNote",
				name: "新建便签",
				commandId: "addNote",
				defaultKey: "Ctrl+Alt+N",
				currentKey: "Ctrl+Alt+N",
				description: "在当前所在分类下极速新建一个空白便签",
				when: "!inEditor && !modalOpen",
				priority: 10
			},
			{
				id: "focusSearch",
				name: "聚焦搜索",
				commandId: "focusSearch",
				defaultKey: "Ctrl+F",
				currentKey: "Ctrl+F",
				description: "一键将输入光标聚焦到顶部的搜索框中",
				when: "!inEditor && !modalOpen",
				priority: 10
			},
			{
				id: "saveEdit",
				name: "保存编辑",
				commandId: "saveEdit",
				defaultKey: "Ctrl+Enter",
				currentKey: "Ctrl+Enter",
				description: "在编辑便签内容时，快捷保存并结束编辑状态",
				when: "inEditor",
				priority: 20
			},
			{
				id: "cancelEdit",
				name: "取消编辑",
				commandId: "cancelEdit",
				defaultKey: "Escape",
				currentKey: "Escape",
				description: "在编辑便签内容时取消修改并退出编辑状态",
				when: "inEditor",
				priority: 20
			}
		]) this.bindings.set(e.id, { ...e });
	}
	register(e) {
		let t = Ml(e.currentKey), n = Ml(e.defaultKey), r = {
			...e,
			currentKey: t,
			defaultKey: n
		};
		return this.bindings.set(r.id, r), () => {
			this.bindings.delete(r.id);
		};
	}
	get(e) {
		return this.bindings.get(e);
	}
	getAll() {
		return Array.from(this.bindings.values());
	}
	match(e, t = Nl) {
		let n = Ml(e);
		if (!n) return null;
		let r = [];
		for (let e of this.bindings.values()) e.currentKey && e.currentKey === n && t.evaluate(e.when) && r.push(e);
		return r.length === 0 ? null : (r.sort((e, t) => (t.priority || 0) - (e.priority || 0)), r[0]);
	}
	updateKeybinding(e, t) {
		let n = Ml(t), r = this.bindings.get(e);
		if (!r) return {
			success: !1,
			message: `未找到 ID 为 "${e}" 的快捷键`
		};
		if (!n) return r.currentKey = "", { success: !0 };
		for (let t of this.bindings.values()) if (t.id !== e && t.currentKey && t.currentKey.toLowerCase() === n.toLowerCase()) return {
			success: !1,
			message: `与 [${t.name}] 快捷键冲突`
		};
		return r.currentKey = n, { success: !0 };
	}
	resetKeybinding(e) {
		let t = this.bindings.get(e);
		t && (t.currentKey = t.defaultKey);
	}
	clearKeybinding(e) {
		let t = this.bindings.get(e);
		t && (t.currentKey = "");
	}
}(), Fl = class {
	registry;
	contextService;
	isRecordingGetter;
	onExecuteCommand;
	constructor(e = {}) {
		this.registry = e.keybindingRegistry || Pl, this.contextService = e.contextService || Nl, this.isRecordingGetter = e.isRecordingGetter, this.onExecuteCommand = e.onExecuteCommand;
	}
	handleEvent(e) {
		if (this.isRecordingGetter && this.isRecordingGetter()) return {
			handled: !1,
			matchedBinding: null
		};
		let t = jl(e);
		if (!t) return {
			handled: !1,
			matchedBinding: null
		};
		let n = this.registry.match(t.rawString, this.contextService);
		return n ? (e.preventDefault(), e.stopPropagation(), this.onExecuteCommand ? this.onExecuteCommand(n.commandId, n) : kl.has(n.commandId) && kl.execute(n.commandId), {
			handled: !0,
			matchedBinding: n
		}) : {
			handled: !1,
			matchedBinding: null
		};
	}
}, Il = Oc("shortcutStore", () => {
	let e = /* @__PURE__ */ F(!1), t = /* @__PURE__ */ F(Pl.getAll()), n = new Fl({
		keybindingRegistry: Pl,
		contextService: Nl,
		isRecordingGetter: () => e.value,
		onExecuteCommand: (e) => {
			u(e);
		}
	}), r = () => {
		t.value = Pl.getAll().map((e) => ({
			id: e.id,
			name: e.name,
			defaultKey: e.defaultKey,
			currentKey: e.currentKey,
			description: e.description
		}));
	}, i = () => {
		let e = Y.getItem("sticky_notes_shortcuts");
		if (e) try {
			let t = JSON.parse(e);
			Array.isArray(t) && t.forEach((e) => {
				e.id && e.currentKey !== void 0 && Pl.updateKeybinding(e.id, e.currentKey);
			});
		} catch (e) {
			console.error("Failed to parse stored shortcuts:", e);
		}
		r();
	}, a = () => {
		let e = t.value.map((e) => ({
			id: e.id,
			currentKey: e.currentKey
		}));
		Y.setItem("sticky_notes_shortcuts", JSON.stringify(e));
	}, o = (e, t) => {
		let n = Pl.updateKeybinding(e, t);
		return n.success && (r(), a()), n;
	}, s = (e) => {
		Pl.resetKeybinding(e), r(), a();
	}, c = (e) => {
		Pl.clearKeybinding(e), r(), a();
	}, l = (e) => {
		let t = jl(e);
		return t ? t.rawString : null;
	}, u = (e) => {
		if (kl.has(e)) {
			kl.execute(e);
			return;
		}
		if (e === "focusSearch") {
			let e = document.activeElement;
			if (!(e && (e.tagName === "INPUT" || e.tagName === "TEXTAREA"))) {
				let e = document.querySelector(".search-input");
				e && (e.focus(), e.select());
			}
		}
	};
	return {
		isRecording: e,
		shortcuts: t,
		loadShortcuts: i,
		saveShortcuts: a,
		updateShortcut: o,
		resetShortcut: s,
		clearShortcut: c,
		getEventKeyString: l,
		triggerShortcut: u,
		setContext: (e, t) => {
			Nl.setContext(e, t);
		},
		handleKeyDown: (e) => n.handleEvent(e)
	};
}), Ll = (e, t, n, r) => ({
	theme: e.isDark ? "dark" : "light",
	gridColumns: e.gridColumns,
	minNoteWidth: e.minNoteWidth,
	noteMaxHeight: e.noteMaxHeight,
	enabledActionBarButtons: e.enabledActionBarButtons,
	dateFormat: e.dateFormat,
	defaultNoteColor: e.defaultNoteColor,
	defaultNoteType: e.defaultNoteType,
	defaultEditMode: e.defaultEditMode,
	doubleClickNoteAction: e.doubleClickNoteAction,
	superPanelDefaultCategory: e.superPanelDefaultCategory,
	startPageMode: e.startPageMode,
	enableHoverAnimation: e.enableHoverAnimation,
	enableAutoCopySelection: e.enableAutoCopySelection,
	showNoteCount: e.showNoteCount,
	prefixTagWithHash: e.prefixTagWithHash,
	skipDeleteConfirm: e.skipDeleteConfirm,
	enableImmersiveFullscreen: e.enableImmersiveFullscreen,
	sortMode: t.sortMode,
	sortOrder: t.sortOrder,
	categoryIndependentToolbar: e.categoryIndependentToolbar,
	categoryViewSettings: e.categoryViewSettings,
	shortcuts: n.shortcuts.map((e) => ({
		id: e.id,
		currentKey: e.currentKey
	})),
	collapsedCategoryIds: r.collapsedCategoryIds
}), Rl = (e, t, n, r, i) => {
	if (!e || typeof e != "object") return;
	(e.theme === "dark" || e.theme === "light") && e.theme === "dark" !== t.isDark && t.toggleTheme(), e.gridColumns && [
		"auto",
		1,
		2,
		3,
		4
	].includes(e.gridColumns) && t.setGridColumns(e.gridColumns), typeof e.minNoteWidth == "number" && !isNaN(e.minNoteWidth) && t.setMinNoteWidth(e.minNoteWidth), typeof e.noteMaxHeight == "number" && !isNaN(e.noteMaxHeight) && t.setNoteMaxHeight(e.noteMaxHeight), Array.isArray(e.enabledActionBarButtons) && t.setEnabledActionBarButtons(e.enabledActionBarButtons), typeof e.dateFormat == "string" && t.setDateFormat(e.dateFormat), typeof e.defaultNoteColor == "string" && t.setDefaultNoteColor(e.defaultNoteColor), e.defaultNoteType && ["text", "markdown"].includes(e.defaultNoteType) && t.setDefaultNoteType(e.defaultNoteType), e.defaultEditMode && ["inline", "fullscreen"].includes(e.defaultEditMode) && t.setDefaultEditMode(e.defaultEditMode);
	let a = Zc(Yc, e.doubleClickNoteAction);
	a && t.setDoubleClickNoteAction(a), typeof e.superPanelDefaultCategory == "string" && t.setSuperPanelDefaultCategory(e.superPanelDefaultCategory), e.startPageMode && ["last", "default"].includes(e.startPageMode) && t.setStartPageMode(e.startPageMode), typeof e.enableHoverAnimation == "boolean" && t.setEnableHoverAnimation(e.enableHoverAnimation), typeof e.enableAutoCopySelection == "boolean" && t.setEnableAutoCopySelection(e.enableAutoCopySelection), typeof e.showNoteCount == "boolean" && t.setShowNoteCount(e.showNoteCount), typeof e.prefixTagWithHash == "boolean" && t.setPrefixTagWithHash(e.prefixTagWithHash), typeof e.skipDeleteConfirm == "boolean" && t.setSkipDeleteConfirm(e.skipDeleteConfirm), typeof e.enableImmersiveFullscreen == "boolean" && t.setEnableImmersiveFullscreen(e.enableImmersiveFullscreen), typeof e.categoryIndependentToolbar == "boolean" && t.setCategoryIndependentToolbar(e.categoryIndependentToolbar), e.categoryViewSettings && typeof e.categoryViewSettings == "object" && (t.categoryViewSettings = e.categoryViewSettings, t.saveCategoryViewSettings()), e.sortMode && [
		"date",
		"title",
		"tag",
		"custom",
		"useCount"
	].includes(e.sortMode) && n.setSortMode(e.sortMode), e.sortOrder && ["asc", "desc"].includes(e.sortOrder) && (n.sortOrder = e.sortOrder, Y.setItem("sticky_notes_sort_order", e.sortOrder)), Array.isArray(e.shortcuts) && e.shortcuts.forEach((e) => {
		e && typeof e.id == "string" && typeof e.currentKey == "string" && r.updateShortcut(e.id, e.currentKey);
	}), Array.isArray(e.collapsedCategoryIds) && (i.collapsedCategoryIds = e.collapsedCategoryIds, Y.setItem("sticky_notes_collapsed_categories", JSON.stringify(e.collapsedCategoryIds))), typeof n.applyCategoryViewSettings == "function" && n.currentCategoryId && n.applyCategoryViewSettings(n.currentCategoryId);
};
//#endregion
//#region src/stores/stickyNotesAlgorithms.ts
function zl(e) {
	let t = /* @__PURE__ */ new Map();
	if (!e || e.length === 0) return t;
	let n = new Map(e.map((e) => [e.id, e]));
	return e.forEach((e) => {
		let r = [], i = e;
		for (; i;) r.unshift(i.name), i = i.parentId ? n.get(i.parentId) : void 0;
		t.set(e.id, r.join(" / "));
	}), t;
}
function Bl(e, t, n = ["all"], r = []) {
	let i = t.trim().toLowerCase();
	if (!i) return e;
	let a = i.split(/\s+/).filter((e) => e.length > 0);
	if (a.length === 0) return e;
	let o = zl(r);
	return e.filter((e) => a.every((t) => {
		let r = t.toLowerCase(), i = (e.title || "").toLowerCase(), a = (e.content || "").toLowerCase(), s = i.includes(r), c = a.includes(r), l = Array.isArray(e.tags) ? e.tags.some((e) => typeof e == "string" && e.toLowerCase().includes(r)) : !1, u = e.categoryId && o.has(e.categoryId) ? o.get(e.categoryId) : e.categoryId === "uncategorized" ? "未分类" : "", d = u ? u.toLowerCase().includes(r) : !1;
		if (n.includes("all")) return s || c || l || d;
		let f = !1;
		return n.includes("title") && s && (f = !0), n.includes("content") && c && (f = !0), n.includes("tag") && l && (f = !0), n.includes("category") && d && (f = !0), f;
	}));
}
function Vl(e, t = "date", n = "desc", r = "all") {
	if (e.length <= 1) return [...e];
	let i = t === "custom" ? new Map(e.map((e, t) => [e.id, t])) : null, a = t === "tag" ? new Map(e.map((e) => [e.id, Array.isArray(e.tags) && e.tags.length > 0 ? [...e.tags].sort((e, t) => e.localeCompare(t, "zh")) : []])) : null;
	return [...e].sort((e, o) => {
		if (e.isPinned && !o.isPinned) return -1;
		if (!e.isPinned && o.isPinned) return 1;
		if (r === "recent") {
			let t = e.lastUsedAt || 0;
			return (o.lastUsedAt || 0) - t;
		}
		if (t === "title") {
			let t = e.title || "", r = o.title || "";
			if (!t && r) return 1;
			if (t && !r) return -1;
			if (!t && !r) return n === "asc" ? (e.updatedAt || 0) - (o.updatedAt || 0) : (o.updatedAt || 0) - (e.updatedAt || 0);
			let i = t.localeCompare(r, "zh");
			return i === 0 ? n === "asc" ? (e.updatedAt || 0) - (o.updatedAt || 0) : (o.updatedAt || 0) - (e.updatedAt || 0) : n === "asc" ? i : -i;
		} else if (t === "tag") {
			let t = a?.get(e.id) || [], r = a?.get(o.id) || [];
			if (t.length === 0 && r.length > 0) return 1;
			if (t.length > 0 && r.length === 0) return -1;
			if (t.length === 0 && r.length === 0) return (o.updatedAt || 0) - (e.updatedAt || 0);
			let i = t[0], s = r[0], c = i.localeCompare(s, "zh");
			if (c !== 0) return n === "asc" ? c : -c;
			if (t.length !== r.length) return r.length - t.length;
			for (let e = 1; e < t.length; e++) {
				let i = t[e].localeCompare(r[e], "zh");
				if (i !== 0) return n === "asc" ? i : -i;
			}
			return n === "asc" ? (e.updatedAt || 0) - (o.updatedAt || 0) : (o.updatedAt || 0) - (e.updatedAt || 0);
		} else if (t === "useCount") {
			let t = e.useCount || 0, r = o.useCount || 0;
			return t === r ? n === "asc" ? (e.updatedAt || 0) - (o.updatedAt || 0) : (o.updatedAt || 0) - (e.updatedAt || 0) : n === "asc" ? t - r : r - t;
		} else if (t === "custom") {
			if (r !== "all" && r !== "trash") {
				let t = e.categoryId === r, n = o.categoryId === r;
				if (t && !n) return -1;
				if (!t && n) return 1;
			}
			return (i?.get(e.id) ?? 0) - (i?.get(o.id) ?? 0);
		} else return n === "desc" ? (o.updatedAt || 0) - (e.updatedAt || 0) : (e.updatedAt || 0) - (o.updatedAt || 0);
	});
}
function Hl(e, t, n = ["all"], r = "date", i = "desc", a = "all", o = []) {
	let s = Vl(Bl(e, t, n, o), r, i, a);
	return a === "recent" ? s.slice(0, 30) : s;
}
function Ul(e, t) {
	let n = new Set(t.map((e) => e.id));
	n.add("all");
	let r = e.filter((e) => n.has(e));
	return t.forEach((e) => {
		r.includes(e.id) || r.push(e.id);
	}), r.includes("all") || r.unshift("all"), r;
}
//#endregion
//#region src/stores/stickyNotes.ts
var Wl = Oc("stickyNotes", () => {
	let e = Wc(), t = fl(), n = el(), r = /* @__PURE__ */ L(e, "categories"), i = /* @__PURE__ */ L(t, "notes"), a = /* @__PURE__ */ L(e, "categoryOrder"), o = /* @__PURE__ */ L(n, "gridColumns"), s = /* @__PURE__ */ F(!1);
	kl.registerHandler("addNote", "新建便签", () => {
		let e = t.currentCategoryId;
		(e === "all" || e === "trash" || e === "recent") && (e = "uncategorized"), t.addNote(e, "", ""), n.showToast("已快捷新建空便签，可以直接编辑");
	});
	let c = () => {
		try {
			Il().loadShortcuts();
			let r = Hc.getAll();
			r && r.length > 0 ? e.categories = r : (e.categories = pl(), e.saveCategories()), e.collapsedCategoryIds = Hc.getCollapsed();
			let i = Hc.getOrder();
			e.categoryOrder = Ul(i, e.categories), i.length === 0 && e.saveCategoryOrder();
			let a = Y.getItem("sticky_notes_sort_mode");
			a && [
				"date",
				"title",
				"tag",
				"custom",
				"useCount"
			].includes(a) && (t.sortMode = a);
			let o = Y.getItem("sticky_notes_sort_order");
			o && ["asc", "desc"].includes(o) && (t.sortOrder = o);
			let c = Y.getItem("sticky_notes_grid_columns");
			if (c) if (c === "auto") n.gridColumns = "auto";
			else {
				let e = parseInt(c, 10);
				[
					1,
					2,
					3,
					4
				].includes(e) && (n.gridColumns = e);
			}
			let l = Y.getItem("sticky_notes_min_note_width");
			if (l) {
				let e = parseInt(l, 10);
				isNaN(e) || (n.minNoteWidth = e);
			}
			let m = Y.getItem("sticky_notes_note_max_height");
			if (m) {
				let e = parseInt(m, 10);
				isNaN(e) || (n.noteMaxHeight = e);
			}
			let h = Y.getItem("sticky_notes_enabled_action_bar_buttons");
			if (h) try {
				n.enabledActionBarButtons = JSON.parse(h);
			} catch (e) {
				console.error("Failed to parse enabled action bar buttons:", e);
			}
			let g = Y.getItem("sticky_notes_date_format");
			g && (n.dateFormat = g);
			let _ = Y.getItem("sticky_notes_default_note_color");
			_ && (n.defaultNoteColor = _);
			let v = Y.getItem("sticky_notes_default_note_type");
			v && ["text", "markdown"].includes(v) && (n.defaultNoteType = v);
			let y = Y.getItem("sticky_notes_default_edit_mode");
			y && ["inline", "fullscreen"].includes(y) && (n.defaultEditMode = y);
			let b = Y.getItem("sticky_notes_super_panel_default_category");
			b && (n.superPanelDefaultCategory = b);
			let x = Y.getItem("sticky_notes_start_page_mode");
			x && ["last", "default"].includes(x) && (n.startPageMode = x);
			let S = Y.getItem("sticky_notes_enable_hover_animation");
			S !== null && (n.enableHoverAnimation = S === "true");
			let C = Y.getItem("sticky_notes_enable_auto_copy_selection");
			C !== null && (n.enableAutoCopySelection = C === "true");
			let w = Y.getItem("sticky_notes_show_note_count");
			w !== null && (n.showNoteCount = w === "true");
			let ee = Y.getItem("sticky_notes_prefix_tag_with_hash");
			ee !== null && (n.prefixTagWithHash = ee === "true");
			let te = Y.getItem("sticky_notes_skip_delete_confirm");
			te !== null && (n.skipDeleteConfirm = te === "true");
			let ne = Y.getItem("sticky_notes_enable_immersive_fullscreen");
			ne !== null && (n.enableImmersiveFullscreen = ne === "true");
			let T = Y.getItem("sticky_notes_category_independent_toolbar");
			T !== null && (n.categoryIndependentToolbar = T === "true");
			let re = Y.getItem("sticky_notes_category_view_settings");
			if (re) try {
				n.categoryViewSettings = JSON.parse(re);
			} catch (e) {
				console.error("Failed to parse category view settings:", e);
			}
			let ie = Vc.getAll();
			if (ie && ie.length > 0 ? t.allNotes = ie : (t.allNotes = ml(), t.saveNotes()), n.startPageMode === "default") {
				let r = n.superPanelDefaultCategory || "all";
				t.currentCategoryId = [
					"all",
					"recent",
					"trash"
				].includes(r) || e.categories.some((e) => e.id === r && !e.isDeleted) ? r : "all";
			} else {
				let n = Y.getItem("sticky_notes_last_category_id") || "all";
				t.currentCategoryId = [
					"all",
					"recent",
					"trash"
				].includes(n) || e.categories.some((e) => e.id === n && !e.isDeleted) ? n : "all";
			}
			t.loadNotesForCurrentCategory(!0), s.value = !0, gl(e.categories, t.allNotes, Ll(n, t, Il(), e)), dl.initScheduler(d, f), u(), dl.config.value.enabled && dl.config.value.autoSync && p({ silent: !1 }).catch(() => {});
		} catch (e) {
			console.error("Failed to load sticky notes data:", e);
		}
	}, l = !1, u = () => {
		if (l) return;
		l = !0;
		let e = () => {
			dl.triggerDebouncedPush(d, f, 3e3);
		};
		[
			"NOTE_UPDATED",
			"NOTE_DELETED",
			"NOTE_RESTORED",
			"CATEGORY_CREATED",
			"CATEGORY_UPDATED",
			"CATEGORY_DELETED"
		].forEach((t) => Uc.subscribe(t, e));
	}, d = () => {
		let r = Ll(n, t, Il(), e);
		return {
			version: "1.7.0",
			timestamp: Date.now(),
			categories: e.categories,
			notes: t.allNotes,
			categoryOrder: e.categoryOrder,
			settings: r
		};
	}, f = (r) => {
		if (r.categories && r.categories.length > 0 && (El(e.categories, r.categories) || (e.categories = r.categories, e.saveCategories())), r.categoryOrder && Array.isArray(r.categoryOrder) && r.categoryOrder.length > 0 && (Dl(e.categoryOrder, r.categoryOrder) || (e.categoryOrder = r.categoryOrder, e.saveCategoryOrder())), r.notes && (Tl(t.allNotes, r.notes) || (t.allNotes = r.notes, t.saveNotes(), t.loadNotesForCurrentCategory())), r.settings) {
			let i = Il();
			Ol(Ll(n, t, i, e), r.settings) || Rl(r.settings, n, t, i, e);
		}
	}, p = async (e) => {
		let t = typeof e == "boolean" ? { forcePush: e } : e || {};
		return await dl.performSync(d, f, t);
	}, m = () => {
		t.allNotes = Vc.getAll(), t.syncCurrentCategoryNotes();
	}, h = (n, r) => {
		let i = e.addCategory(n, r);
		return i && (t.currentCategoryId = i.id), i;
	}, g = (n) => {
		e.deleteCategory(n), t.allNotes = t.allNotes.map((e) => e.categoryId === n ? {
			...e,
			isDeleted: !0,
			deletedAt: Date.now(),
			isPinned: !1
		} : e), t.saveNotes(), t.syncCurrentCategoryNotes(), t.currentCategoryId === n && (t.currentCategoryId = "all");
	}, _ = (e, n = "", r = "", i, a) => {
		let o = e;
		return (e === "all" || e === "trash" || e === "recent") && (o = "uncategorized"), t.addNote(o, n, r, i, a);
	}, v = (n) => {
		let r = e.getCategoryDescendants(n);
		t.clearNotes(n, r);
	}, y = q(() => Hl(t.notes, t.searchQuery, t.searchTarget, t.sortMode, t.sortOrder, t.currentCategoryId, e.categories));
	return {
		categories: r,
		categoryOrder: a,
		collapsedCategoryIds: /* @__PURE__ */ L(e, "collapsedCategoryIds"),
		addingSubParentId: /* @__PURE__ */ L(e, "addingSubParentId"),
		newSubCategoryName: /* @__PURE__ */ L(e, "newSubCategoryName"),
		orderedCategories: q(() => e.orderedCategories),
		categoryOptions: q(() => e.categoryOptions),
		toggleCategoryCollapse: e.toggleCategoryCollapse,
		isCategoryCollapsed: e.isCategoryCollapsed,
		getCategoryDescendants: e.getCategoryDescendants,
		saveCategoryOrder: e.saveCategoryOrder,
		reorderCategories: e.reorderCategories,
		moveCategory: e.moveCategory,
		addCategory: h,
		deleteCategory: g,
		updateCategory: e.updateCategory,
		allNotes: /* @__PURE__ */ L(t, "allNotes"),
		notes: i,
		isLoadingNotes: /* @__PURE__ */ L(t, "isLoadingNotes"),
		currentCategoryId: /* @__PURE__ */ L(t, "currentCategoryId"),
		searchQuery: /* @__PURE__ */ L(t, "searchQuery"),
		searchTarget: /* @__PURE__ */ L(t, "searchTarget"),
		sortMode: /* @__PURE__ */ L(t, "sortMode"),
		sortOrder: /* @__PURE__ */ L(t, "sortOrder"),
		draggedNoteId: /* @__PURE__ */ L(t, "draggedNoteId"),
		editingNoteId: /* @__PURE__ */ L(t, "editingNoteId"),
		filteredNotes: y,
		recentNotesCount: q(() => t.allNotes.filter((e) => e.isDeleted !== !0 && e.lastUsedAt !== void 0).length),
		trashNotesCount: q(() => t.trashNotesCount),
		addNote: _,
		deleteNote: t.deleteNote,
		restoreNote: t.restoreNote,
		clearTrash: t.clearTrash,
		updateNote: t.updateNote,
		clearNotes: v,
		setSortMode: t.setSortMode,
		moveNote: t.moveNote,
		updateNoteLastUsed: t.updateNoteLastUsed,
		toastMessage: /* @__PURE__ */ L(n, "toastMessage"),
		toastType: /* @__PURE__ */ L(n, "toastType"),
		toastPosition: /* @__PURE__ */ L(n, "toastPosition"),
		showToast: n.showToast,
		confirmState: /* @__PURE__ */ L(n, "confirmState"),
		askConfirm: n.askConfirm,
		handleConfirmResult: n.handleConfirmResult,
		gridColumns: o,
		minNoteWidth: /* @__PURE__ */ L(n, "minNoteWidth"),
		noteMaxHeight: /* @__PURE__ */ L(n, "noteMaxHeight"),
		setGridColumns: (e) => n.setGridColumns(e, t.currentCategoryId),
		setMinNoteWidth: n.setMinNoteWidth,
		setNoteMaxHeight: n.setNoteMaxHeight,
		categoryIndependentToolbar: /* @__PURE__ */ L(n, "categoryIndependentToolbar"),
		setCategoryIndependentToolbar: n.setCategoryIndependentToolbar,
		categoryViewSettings: /* @__PURE__ */ L(n, "categoryViewSettings"),
		showSettings: /* @__PURE__ */ L(n, "showSettings"),
		openSettings: n.openSettings,
		closeSettings: n.closeSettings,
		isDark: /* @__PURE__ */ L(n, "isDark"),
		initTheme: n.initTheme,
		toggleTheme: n.toggleTheme,
		enabledActionBarButtons: /* @__PURE__ */ L(n, "enabledActionBarButtons"),
		setEnabledActionBarButtons: n.setEnabledActionBarButtons,
		dateFormat: /* @__PURE__ */ L(n, "dateFormat"),
		setDateFormat: n.setDateFormat,
		defaultNoteColor: /* @__PURE__ */ L(n, "defaultNoteColor"),
		setDefaultNoteColor: n.setDefaultNoteColor,
		defaultNoteType: /* @__PURE__ */ L(n, "defaultNoteType"),
		setDefaultNoteType: n.setDefaultNoteType,
		defaultEditMode: /* @__PURE__ */ L(n, "defaultEditMode"),
		setDefaultEditMode: n.setDefaultEditMode,
		doubleClickNoteAction: /* @__PURE__ */ L(n, "doubleClickNoteAction"),
		setDoubleClickNoteAction: n.setDoubleClickNoteAction,
		superPanelDefaultCategory: /* @__PURE__ */ L(n, "superPanelDefaultCategory"),
		setSuperPanelDefaultCategory: n.setSuperPanelDefaultCategory,
		startPageMode: /* @__PURE__ */ L(n, "startPageMode"),
		setStartPageMode: n.setStartPageMode,
		enableHoverAnimation: /* @__PURE__ */ L(n, "enableHoverAnimation"),
		setEnableHoverAnimation: n.setEnableHoverAnimation,
		enableAutoCopySelection: /* @__PURE__ */ L(n, "enableAutoCopySelection"),
		setEnableAutoCopySelection: n.setEnableAutoCopySelection,
		showNoteCount: /* @__PURE__ */ L(n, "showNoteCount"),
		setShowNoteCount: n.setShowNoteCount,
		prefixTagWithHash: /* @__PURE__ */ L(n, "prefixTagWithHash"),
		setPrefixTagWithHash: n.setPrefixTagWithHash,
		skipDeleteConfirm: /* @__PURE__ */ L(n, "skipDeleteConfirm"),
		setSkipDeleteConfirm: n.setSkipDeleteConfirm,
		enableImmersiveFullscreen: /* @__PURE__ */ L(n, "enableImmersiveFullscreen"),
		setEnableImmersiveFullscreen: n.setEnableImmersiveFullscreen,
		previewNoteId: /* @__PURE__ */ L(n, "previewNoteId"),
		openedFullscreenForEditNoteId: /* @__PURE__ */ L(n, "openedFullscreenForEditNoteId"),
		openNotePreview: n.openNotePreview,
		closeNotePreview: n.closeNotePreview,
		toggleNotePreview: n.toggleNotePreview,
		isMobileSidebarOpen: /* @__PURE__ */ L(n, "isMobileSidebarOpen"),
		openMobileSidebar: n.openMobileSidebar,
		closeMobileSidebar: n.closeMobileSidebar,
		toggleMobileSidebar: n.toggleMobileSidebar,
		showExportModal: /* @__PURE__ */ L(n, "showExportModal"),
		openExportModal: n.openExportModal,
		closeExportModal: n.closeExportModal,
		showImportModal: /* @__PURE__ */ L(n, "showImportModal"),
		pendingImportData: /* @__PURE__ */ L(n, "pendingImportData"),
		openImportModal: n.openImportModal,
		closeImportModal: n.closeImportModal,
		syncWithWebdav: p,
		getCurrentBackupData: d,
		applyMergedBackupData: f,
		isInitialized: /* @__PURE__ */ zt(s),
		loadData: c,
		reloadNotes: m,
		exportBackup: () => {
			let r = Ll(n, t, Il(), e);
			_l(e.categories, t.allNotes, r, n.showToast);
		},
		exportSelectedBackup: (r) => {
			let i = Ll(n, t, Il(), e);
			vl(e.categories, t.allNotes, i, r, n.showToast);
		},
		importBackup: (i) => {
			let o = Il(), s = yl(i, r, /* @__PURE__ */ L(t, "allNotes"), a, e.saveCategories, t.saveNotes, e.saveCategoryOrder, n.showToast, (r) => Rl(r, n, t, o, e));
			return s && t.loadNotesForCurrentCategory(), s;
		},
		importSelectedBackup: (i) => {
			if (!n.pendingImportData) return n.showToast("导入失败：找不到解析的备份数据", "error"), !1;
			let o = Il(), s = bl(n.pendingImportData, i, r, /* @__PURE__ */ L(t, "allNotes"), a, e.saveCategories, t.saveNotes, e.saveCategoryOrder, n.showToast, (r) => Rl(r, n, t, o, e));
			return s && (t.loadNotesForCurrentCategory(), n.closeImportModal()), s;
		},
		prepareImportFile: (e) => {
			let t = new FileReader();
			t.onload = (e) => {
				let t = e.target?.result;
				if (t) try {
					let e = JSON.parse(t);
					if (!e || typeof e != "object") {
						n.showToast("导入失败：无效的 JSON 备份格式", "error");
						return;
					}
					n.openImportModal(e);
				} catch (e) {
					console.error("Failed to parse backup JSON file:", e), n.showToast("导入失败：JSON 文件解析失败", "error");
				}
			}, t.readAsText(e);
		},
		exportSingleNoteAsTxt: (e) => {
			xl(e, n.showToast, n.prefixTagWithHash);
		},
		handlePasteNote: async (e, r) => {
			if (!e.trim()) return n.showToast("便签内容为空，无法复制粘贴", "warning"), {
				success: !1,
				isNative: !1
			};
			let i = await Pc(e);
			return i ? n.showToast("已隐藏并粘贴到目标光标处！", "success") : n.showToast("已复制到剪贴板，请到目标位置粘贴", "info"), r && t.updateNoteLastUsed(r), {
				success: !0,
				isNative: i
			};
		},
		devResetNotes: () => {
			Sl(/* @__PURE__ */ L(t, "allNotes"), t.saveNotes, n.showToast), t.loadNotesForCurrentCategory();
		},
		devResetTags: () => {
			Cl(/* @__PURE__ */ L(t, "allNotes"), t.saveNotes, n.showToast), t.loadNotesForCurrentCategory();
		},
		devResetAllData: () => wl(c, o, n.showToast)
	};
}), Gl = (e) => e === "", Kl = (...e) => e.filter((e, t, n) => !!e && e.trim() !== "" && n.indexOf(e) === t).join(" ").trim(), ql = (e) => e.replace(/([a-z0-9])([A-Z])/g, "$1-$2").toLowerCase(), Jl = (e) => e.replace(/^([A-Z])|[\s-_]+(\w)/g, (e, t, n) => n ? n.toUpperCase() : t.toLowerCase()), Yl = (e) => {
	let t = Jl(e);
	return t.charAt(0).toUpperCase() + t.slice(1);
}, Xl = {
	xmlns: "http://www.w3.org/2000/svg",
	width: 24,
	height: 24,
	viewBox: "0 0 24 24",
	fill: "none",
	stroke: "currentColor",
	"stroke-width": 2,
	"stroke-linecap": "round",
	"stroke-linejoin": "round"
}, Zl = /* @__PURE__ */ Symbol("lucide-icons");
function Ql() {
	return Bn(Zl, {});
}
//#endregion
//#region node_modules/@lucide/vue/dist/esm/Icon.mjs
var $l = ({ name: e, iconNode: t, "icon-node": n, absoluteStrokeWidth: r, "absolute-stroke-width": i, strokeWidth: a, "stroke-width": o, size: s, color: c, ...l }, { slots: u }) => {
	let { size: d, color: f, strokeWidth: p = 2, absoluteStrokeWidth: m = !1, class: h = "" } = Ql(), g = q(() => {
		let e = Gl(r) || Gl(i) || r === !0 || i === !0 || m === !0, t = a || o || p || Xl["stroke-width"];
		return e ? Number(t) * 24 / Number(s ?? d ?? Xl.width) : t;
	});
	return co("svg", {
		...Xl,
		...l,
		width: s ?? d ?? Xl.width,
		height: s ?? d ?? Xl.height,
		stroke: c ?? f ?? Xl.stroke,
		"stroke-width": g.value,
		class: Kl("lucide", h, ...e ? [`lucide-${ql(Yl(e))}-icon`, `lucide-${ql(e)}`] : ["lucide-icon"])
	}, [...(t ?? n ?? []).map((e) => co(...e)), ...u.default ? [u.default()] : []]);
}, X = (e, t) => (n, { slots: r, attrs: i }) => co($l, {
	...i,
	...n,
	iconNode: t,
	name: e
}, r.default ? { default: r.default } : void 0), eu = X("arrow-up-down", [
	["path", {
		d: "m21 16-4 4-4-4",
		key: "f6ql7i"
	}],
	["path", {
		d: "M17 20V4",
		key: "1ejh1v"
	}],
	["path", {
		d: "m3 8 4-4 4 4",
		key: "11wl7u"
	}],
	["path", {
		d: "M7 4v16",
		key: "1glfcx"
	}]
]), tu = X("calendar", [
	["path", {
		d: "M8 2v4",
		key: "1cmpym"
	}],
	["path", {
		d: "M16 2v4",
		key: "4m81vk"
	}],
	["rect", {
		width: "18",
		height: "18",
		x: "3",
		y: "4",
		rx: "2",
		key: "1hopcy"
	}],
	["path", {
		d: "M3 10h18",
		key: "8toen8"
	}]
]), nu = X("check", [["path", {
	d: "M20 6 9 17l-5-5",
	key: "1gmf2c"
}]]), ru = X("chevron-down", [["path", {
	d: "m6 9 6 6 6-6",
	key: "qrunsl"
}]]), iu = X("chevron-left", [["path", {
	d: "m15 18-6-6 6-6",
	key: "1wnfg3"
}]]), au = X("chevron-right", [["path", {
	d: "m9 18 6-6-6-6",
	key: "mthhwq"
}]]), ou = X("circle-alert", [
	["circle", {
		cx: "12",
		cy: "12",
		r: "10",
		key: "1mglay"
	}],
	["line", {
		x1: "12",
		x2: "12",
		y1: "8",
		y2: "12",
		key: "1pkeuh"
	}],
	["line", {
		x1: "12",
		x2: "12.01",
		y1: "16",
		y2: "16",
		key: "4dfq90"
	}]
]), su = X("circle-arrow-down", [
	["circle", {
		cx: "12",
		cy: "12",
		r: "10",
		key: "1mglay"
	}],
	["path", {
		d: "M12 8v8",
		key: "napkw2"
	}],
	["path", {
		d: "m8 12 4 4 4-4",
		key: "k98ssh"
	}]
]), cu = X("circle-arrow-up", [
	["circle", {
		cx: "12",
		cy: "12",
		r: "10",
		key: "1mglay"
	}],
	["path", {
		d: "m16 12-4-4-4 4",
		key: "177agl"
	}],
	["path", {
		d: "M12 16V8",
		key: "1sbj14"
	}]
]), lu = X("circle-check", [["circle", {
	cx: "12",
	cy: "12",
	r: "10",
	key: "1mglay"
}], ["path", {
	d: "m9 12 2 2 4-4",
	key: "dzmm74"
}]]), uu = X("circle-x", [
	["circle", {
		cx: "12",
		cy: "12",
		r: "10",
		key: "1mglay"
	}],
	["path", {
		d: "m15 9-6 6",
		key: "1uzhvr"
	}],
	["path", {
		d: "m9 9 6 6",
		key: "z0biqf"
	}]
]), du = X("cloud", [["path", {
	d: "M17.5 19H9a7 7 0 1 1 6.71-9h1.79a4.5 4.5 0 1 1 0 9Z",
	key: "p7xjir"
}]]), fu = X("columns-2", [["rect", {
	width: "18",
	height: "18",
	x: "3",
	y: "3",
	rx: "2",
	key: "afitv7"
}], ["path", {
	d: "M12 3v18",
	key: "108xh3"
}]]), pu = X("copy", [["rect", {
	width: "14",
	height: "14",
	x: "8",
	y: "8",
	rx: "2",
	ry: "2",
	key: "17jyea"
}], ["path", {
	d: "M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2",
	key: "zix9uf"
}]]), mu = X("database", [
	["ellipse", {
		cx: "12",
		cy: "5",
		rx: "9",
		ry: "3",
		key: "msslwz"
	}],
	["path", {
		d: "M3 5V19A9 3 0 0 0 21 19V5",
		key: "1wlel7"
	}],
	["path", {
		d: "M3 12A9 3 0 0 0 21 12",
		key: "mv7ke4"
	}]
]), hu = X("download", [
	["path", {
		d: "M12 15V3",
		key: "m9g1x1"
	}],
	["path", {
		d: "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4",
		key: "ih7n3h"
	}],
	["path", {
		d: "m7 10 5 5 5-5",
		key: "brsn70"
	}]
]), gu = X("external-link", [
	["path", {
		d: "M15 3h6v6",
		key: "1q9fwt"
	}],
	["path", {
		d: "M10 14 21 3",
		key: "gplh6r"
	}],
	["path", {
		d: "M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6",
		key: "a6xqqp"
	}]
]), _u = X("eye-off", [
	["path", {
		d: "M10.733 5.076a10.744 10.744 0 0 1 11.205 6.575 1 1 0 0 1 0 .696 10.747 10.747 0 0 1-1.444 2.49",
		key: "ct8e1f"
	}],
	["path", {
		d: "M14.084 14.158a3 3 0 0 1-4.242-4.242",
		key: "151rxh"
	}],
	["path", {
		d: "M17.479 17.499a10.75 10.75 0 0 1-15.417-5.151 1 1 0 0 1 0-.696 10.75 10.75 0 0 1 4.446-5.143",
		key: "13bj9a"
	}],
	["path", {
		d: "m2 2 20 20",
		key: "1ooewy"
	}]
]), vu = X("eye", [["path", {
	d: "M2.062 12.348a1 1 0 0 1 0-.696 10.75 10.75 0 0 1 19.876 0 1 1 0 0 1 0 .696 10.75 10.75 0 0 1-19.876 0",
	key: "1nclc0"
}], ["circle", {
	cx: "12",
	cy: "12",
	r: "3",
	key: "1v7zrd"
}]]), yu = X("file-code", [
	["path", {
		d: "M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z",
		key: "1oefj6"
	}],
	["path", {
		d: "M14 2v5a1 1 0 0 0 1 1h5",
		key: "wfsgrz"
	}],
	["path", {
		d: "M10 12.5 8 15l2 2.5",
		key: "1tg20x"
	}],
	["path", {
		d: "m14 12.5 2 2.5-2 2.5",
		key: "yinavb"
	}]
]), bu = X("file-text", [
	["path", {
		d: "M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z",
		key: "1oefj6"
	}],
	["path", {
		d: "M14 2v5a1 1 0 0 0 1 1h5",
		key: "wfsgrz"
	}],
	["path", {
		d: "M10 9H8",
		key: "b1mrlr"
	}],
	["path", {
		d: "M16 13H8",
		key: "t4e002"
	}],
	["path", {
		d: "M16 17H8",
		key: "z1uh3a"
	}]
]), xu = X("folder-input", [
	["path", {
		d: "M2 9V5a2 2 0 0 1 2-2h3.9a2 2 0 0 1 1.69.9l.81 1.2a2 2 0 0 0 1.67.9H20a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2v-1",
		key: "fm4g5t"
	}],
	["path", {
		d: "M2 13h10",
		key: "pgb2dq"
	}],
	["path", {
		d: "m9 16 3-3-3-3",
		key: "6m91ic"
	}]
]), Su = X("folder", [["path", {
	d: "M20 20a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L9.6 3.9A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2Z",
	key: "1kt360"
}]]), Cu = X("git-merge", [
	["circle", {
		cx: "18",
		cy: "18",
		r: "3",
		key: "1xkwt0"
	}],
	["circle", {
		cx: "6",
		cy: "6",
		r: "3",
		key: "1lh9wr"
	}],
	["path", {
		d: "M6 21V9a9 9 0 0 0 9 9",
		key: "7kw0sc"
	}]
]), wu = X("history", [
	["path", {
		d: "M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8",
		key: "1357e3"
	}],
	["path", {
		d: "M3 3v5h5",
		key: "1xhq8a"
	}],
	["path", {
		d: "M12 7v5l4 2",
		key: "1fdv2h"
	}]
]), Tu = X("info", [
	["circle", {
		cx: "12",
		cy: "12",
		r: "10",
		key: "1mglay"
	}],
	["path", {
		d: "M12 16v-4",
		key: "1dtifu"
	}],
	["path", {
		d: "M12 8h.01",
		key: "e9boi3"
	}]
]), Eu = X("keyboard", [
	["path", {
		d: "M10 8h.01",
		key: "1r9ogq"
	}],
	["path", {
		d: "M12 12h.01",
		key: "1mp3jc"
	}],
	["path", {
		d: "M14 8h.01",
		key: "1primd"
	}],
	["path", {
		d: "M16 12h.01",
		key: "1l6xoz"
	}],
	["path", {
		d: "M18 8h.01",
		key: "emo2bl"
	}],
	["path", {
		d: "M6 8h.01",
		key: "x9i8wu"
	}],
	["path", {
		d: "M7 16h10",
		key: "wp8him"
	}],
	["path", {
		d: "M8 12h.01",
		key: "czm47f"
	}],
	["rect", {
		width: "20",
		height: "16",
		x: "2",
		y: "4",
		rx: "2",
		key: "18n3k1"
	}]
]), Du = X("layout-grid", [
	["rect", {
		width: "7",
		height: "7",
		x: "3",
		y: "3",
		rx: "1",
		key: "1g98yp"
	}],
	["rect", {
		width: "7",
		height: "7",
		x: "14",
		y: "3",
		rx: "1",
		key: "6d4xhi"
	}],
	["rect", {
		width: "7",
		height: "7",
		x: "14",
		y: "14",
		rx: "1",
		key: "nxv5o0"
	}],
	["rect", {
		width: "7",
		height: "7",
		x: "3",
		y: "14",
		rx: "1",
		key: "1bb6yr"
	}]
]), Ou = X("maximize-2", [
	["path", {
		d: "M15 3h6v6",
		key: "1q9fwt"
	}],
	["path", {
		d: "m21 3-7 7",
		key: "1l2asr"
	}],
	["path", {
		d: "m3 21 7-7",
		key: "tjx5ai"
	}],
	["path", {
		d: "M9 21H3v-6",
		key: "wtvkvv"
	}]
]), ku = X("menu", [
	["path", {
		d: "M4 5h16",
		key: "1tepv9"
	}],
	["path", {
		d: "M4 12h16",
		key: "1lakjw"
	}],
	["path", {
		d: "M4 19h16",
		key: "1djgab"
	}]
]), Au = X("minimize-2", [
	["path", {
		d: "m14 10 7-7",
		key: "oa77jy"
	}],
	["path", {
		d: "M20 10h-6V4",
		key: "mjg0md"
	}],
	["path", {
		d: "m3 21 7-7",
		key: "tjx5ai"
	}],
	["path", {
		d: "M4 14h6v6",
		key: "rmj7iw"
	}]
]), ju = X("moon", [["path", {
	d: "M20.985 12.486a9 9 0 1 1-9.473-9.472c.405-.022.617.46.402.803a6 6 0 0 0 8.268 8.268c.344-.215.825-.004.803.401",
	key: "kfwtm"
}]]), Mu = X("palette", [
	["path", {
		d: "M12 22a1 1 0 0 1 0-20 10 9 0 0 1 10 9 5 5 0 0 1-5 5h-2.25a1.75 1.75 0 0 0-1.4 2.8l.3.4a1.75 1.75 0 0 1-1.4 2.8z",
		key: "e79jfc"
	}],
	["circle", {
		cx: "13.5",
		cy: "6.5",
		r: ".5",
		fill: "currentColor",
		key: "1okk4w"
	}],
	["circle", {
		cx: "17.5",
		cy: "10.5",
		r: ".5",
		fill: "currentColor",
		key: "f64h9f"
	}],
	["circle", {
		cx: "6.5",
		cy: "12.5",
		r: ".5",
		fill: "currentColor",
		key: "qy21gx"
	}],
	["circle", {
		cx: "8.5",
		cy: "7.5",
		r: ".5",
		fill: "currentColor",
		key: "fotxhn"
	}]
]), Nu = X("paperclip", [["path", {
	d: "m16 6-8.414 8.586a2 2 0 0 0 2.829 2.829l8.414-8.586a4 4 0 1 0-5.657-5.657l-8.379 8.551a6 6 0 1 0 8.485 8.485l8.379-8.551",
	key: "1miecu"
}]]), Pu = X("pen-line", [["path", {
	d: "M13 21h8",
	key: "1jsn5i"
}], ["path", {
	d: "M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z",
	key: "1a8usu"
}]]), Fu = X("pen", [["path", {
	d: "M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z",
	key: "1a8usu"
}]]), Iu = X("pin-off", [
	["path", {
		d: "M12 17v5",
		key: "bb1du9"
	}],
	["path", {
		d: "M15 9.34V7a1 1 0 0 1 1-1 2 2 0 0 0 0-4H7.89",
		key: "znwnzq"
	}],
	["path", {
		d: "m2 2 20 20",
		key: "1ooewy"
	}],
	["path", {
		d: "M9 9v1.76a2 2 0 0 1-1.11 1.79l-1.78.9A2 2 0 0 0 5 15.24V16a1 1 0 0 0 1 1h11",
		key: "c9qhm2"
	}]
]), Lu = X("pin", [["path", {
	d: "M12 17v5",
	key: "bb1du9"
}], ["path", {
	d: "M9 10.76a2 2 0 0 1-1.11 1.79l-1.78.9A2 2 0 0 0 5 15.24V16a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-.76a2 2 0 0 0-1.11-1.79l-1.78-.9A2 2 0 0 1 15 10.76V7a1 1 0 0 1 1-1 2 2 0 0 0 0-4H8a2 2 0 0 0 0 4 1 1 0 0 1 1 1z",
	key: "1nkz8b"
}]]), Ru = X("plug", [
	["path", {
		d: "M12 22v-5",
		key: "1ega77"
	}],
	["path", {
		d: "M15 8V2",
		key: "18g5xt"
	}],
	["path", {
		d: "M17 8a1 1 0 0 1 1 1v4a4 4 0 0 1-4 4h-4a4 4 0 0 1-4-4V9a1 1 0 0 1 1-1z",
		key: "1xoxul"
	}],
	["path", {
		d: "M9 8V2",
		key: "14iosj"
	}]
]), zu = X("plus", [["path", {
	d: "M5 12h14",
	key: "1ays0h"
}], ["path", {
	d: "M12 5v14",
	key: "s699le"
}]]), Bu = X("redo-2", [["path", {
	d: "m15 14 5-5-5-5",
	key: "12vg1m"
}], ["path", {
	d: "M20 9H9.5A5.5 5.5 0 0 0 4 14.5A5.5 5.5 0 0 0 9.5 20H13",
	key: "6uklza"
}]]), Vu = X("refresh-cw", [
	["path", {
		d: "M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8",
		key: "v9h5vc"
	}],
	["path", {
		d: "M21 3v5h-5",
		key: "1q7to0"
	}],
	["path", {
		d: "M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16",
		key: "3uifl3"
	}],
	["path", {
		d: "M8 16H3v5",
		key: "1cv678"
	}]
]), Hu = X("rotate-ccw", [["path", {
	d: "M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8",
	key: "1357e3"
}], ["path", {
	d: "M3 3v5h5",
	key: "1xhq8a"
}]]), Uu = X("search-x", [
	["path", {
		d: "m13.5 8.5-5 5",
		key: "1cs55j"
	}],
	["path", {
		d: "m8.5 8.5 5 5",
		key: "a8mexj"
	}],
	["circle", {
		cx: "11",
		cy: "11",
		r: "8",
		key: "4ej97u"
	}],
	["path", {
		d: "m21 21-4.3-4.3",
		key: "1qie3q"
	}]
]), Wu = X("search", [["path", {
	d: "m21 21-4.34-4.34",
	key: "14j7rj"
}], ["circle", {
	cx: "11",
	cy: "11",
	r: "8",
	key: "4ej97u"
}]]), Gu = X("settings", [["path", {
	d: "M9.671 4.136a2.34 2.34 0 0 1 4.659 0 2.34 2.34 0 0 0 3.319 1.915 2.34 2.34 0 0 1 2.33 4.033 2.34 2.34 0 0 0 0 3.831 2.34 2.34 0 0 1-2.33 4.033 2.34 2.34 0 0 0-3.319 1.915 2.34 2.34 0 0 1-4.659 0 2.34 2.34 0 0 0-3.32-1.915 2.34 2.34 0 0 1-2.33-4.033 2.34 2.34 0 0 0 0-3.831A2.34 2.34 0 0 1 6.35 6.051a2.34 2.34 0 0 0 3.319-1.915",
	key: "1i5ecw"
}], ["circle", {
	cx: "12",
	cy: "12",
	r: "3",
	key: "1v7zrd"
}]]), Ku = X("shield-check", [["path", {
	d: "M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",
	key: "oel41y"
}], ["path", {
	d: "m9 12 2 2 4-4",
	key: "dzmm74"
}]]), qu = X("square-check-big", [["path", {
	d: "M21 10.656V19a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h12.344",
	key: "2acyp4"
}], ["path", {
	d: "m9 11 3 3L22 4",
	key: "1pflzl"
}]]), Ju = X("square", [["rect", {
	width: "18",
	height: "18",
	x: "3",
	y: "3",
	rx: "2",
	key: "afitv7"
}]]), Yu = X("sticky-note", [["path", {
	d: "M21 9a2.4 2.4 0 0 0-.706-1.706l-3.588-3.588A2.4 2.4 0 0 0 15 3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2z",
	key: "1dfntj"
}], ["path", {
	d: "M15 3v5a1 1 0 0 0 1 1h5",
	key: "6s6qgf"
}]]), Xu = X("sun", [
	["circle", {
		cx: "12",
		cy: "12",
		r: "4",
		key: "4exip2"
	}],
	["path", {
		d: "M12 2v2",
		key: "tus03m"
	}],
	["path", {
		d: "M12 20v2",
		key: "1lh1kg"
	}],
	["path", {
		d: "m4.93 4.93 1.41 1.41",
		key: "149t6j"
	}],
	["path", {
		d: "m17.66 17.66 1.41 1.41",
		key: "ptbguv"
	}],
	["path", {
		d: "M2 12h2",
		key: "1t8f8n"
	}],
	["path", {
		d: "M20 12h2",
		key: "1q8mjw"
	}],
	["path", {
		d: "m6.34 17.66-1.41 1.41",
		key: "1m8zz5"
	}],
	["path", {
		d: "m19.07 4.93-1.41 1.41",
		key: "1shlcs"
	}]
]), Zu = X("trash-2", [
	["path", {
		d: "M10 11v6",
		key: "nco0om"
	}],
	["path", {
		d: "M14 11v6",
		key: "outv1u"
	}],
	["path", {
		d: "M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6",
		key: "miytrc"
	}],
	["path", {
		d: "M3 6h18",
		key: "d0wm0j"
	}],
	["path", {
		d: "M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2",
		key: "e791ji"
	}]
]), Qu = X("triangle-alert", [
	["path", {
		d: "m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3",
		key: "wmoenq"
	}],
	["path", {
		d: "M12 9v4",
		key: "juzpu7"
	}],
	["path", {
		d: "M12 17h.01",
		key: "p32p05"
	}]
]), $u = X("undo-2", [["path", {
	d: "M9 14 4 9l5-5",
	key: "102s5s"
}], ["path", {
	d: "M4 9h10.5a5.5 5.5 0 0 1 5.5 5.5a5.5 5.5 0 0 1-5.5 5.5H11",
	key: "f3b9sd"
}]]), ed = X("upload", [
	["path", {
		d: "M12 3v12",
		key: "1x0j5s"
	}],
	["path", {
		d: "m17 8-5-5-5 5",
		key: "7q97r8"
	}],
	["path", {
		d: "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4",
		key: "ih7n3h"
	}]
]), td = X("x", [["path", {
	d: "M18 6 6 18",
	key: "1bl5f8"
}], ["path", {
	d: "m6 6 12 12",
	key: "d8bk6v"
}]]), nd = X("zoom-out", [
	["circle", {
		cx: "11",
		cy: "11",
		r: "8",
		key: "4ej97u"
	}],
	["line", {
		x1: "21",
		x2: "16.65",
		y1: "21",
		y2: "16.65",
		key: "13gj7c"
	}],
	["line", {
		x1: "8",
		x2: "14",
		y1: "11",
		y2: "11",
		key: "durymu"
	}]
]), rd = X("zoom-in", [
	["circle", {
		cx: "11",
		cy: "11",
		r: "8",
		key: "4ej97u"
	}],
	["line", {
		x1: "21",
		x2: "16.65",
		y1: "21",
		y2: "16.65",
		key: "13gj7c"
	}],
	["line", {
		x1: "11",
		x2: "11",
		y1: "8",
		y2: "14",
		key: "1vmskp"
	}],
	["line", {
		x1: "8",
		x2: "14",
		y1: "11",
		y2: "11",
		key: "durymu"
	}]
]), id = "moment_notes_window_pinned", ad = /* @__PURE__ */ F(typeof window < "u" ? localStorage.getItem(id) === "true" : !1), od = () => typeof window > "u" ? !1 : !!window.bridge || window.location.pathname.includes("pluginwin.html") || window.location.search.includes("mode=pluginwin"), sd = (e) => {
	if (typeof window > "u" || e && e.buttons !== 1) return;
	let t = window.bridge;
	if (t?.drag) try {
		t.drag();
	} catch (e) {
		console.warn("[WindowControl] bridge.drag() failed:", e);
	}
}, cd = async (e) => {
	if (typeof window > "u") return;
	let t = window.bridge, n = t?.label;
	if (t?.bus && n) try {
		await t.bus.publish("moment-notes:control-window", {
			label: n,
			op: "alwaysOnTop",
			value: e
		});
	} catch (e) {
		console.warn("[WindowControl] setWindowAlwaysOnTop failed:", e);
	}
}, ld = async () => {
	ad.value = !ad.value, typeof window < "u" && localStorage.setItem(id, String(ad.value)), await cd(ad.value);
}, ud = async () => {
	if (typeof window > "u") return;
	let e = window.bridge, t = e?.label;
	if (e?.bus && t) try {
		await e.bus.publish("moment-notes:control-window", {
			label: t,
			op: "hide"
		});
	} catch (e) {
		console.warn("[WindowControl] hideCurrentWindow failed:", e);
	}
}, dd = async () => {
	if (typeof window > "u") return;
	let e = window.bridge, t = e?.label;
	try {
		if (e?.close) {
			let t = e.close();
			t && typeof t.then == "function" && await t;
			return;
		}
	} catch (e) {
		console.warn("[WindowControl] bridge.close() failed, falling back to bus:", e);
	}
	try {
		if (e?.bus && t) {
			await e.bus.publish("moment-notes:close-window", { label: t });
			return;
		}
	} catch (e) {
		console.warn("[WindowControl] bus publish close-window failed:", e);
	}
	try {
		window.close();
	} catch (e) {
		console.warn("[WindowControl] window.close() failed:", e);
	}
};
//#endregion
//#region src/utils/useSidebarResize.ts
function fd(e = {}) {
	let { defaultWidth: t = 220, minWidth: n = 160, storageKey: r = "sidebar-width" } = e, i = /* @__PURE__ */ F(t), a = /* @__PURE__ */ F(!1);
	if (typeof localStorage < "u") {
		let e = localStorage.getItem(r);
		if (e) {
			let t = parseInt(e, 10);
			!isNaN(t) && t >= n && (i.value = t);
		}
	}
	let o = (e) => {
		if (!a.value) return;
		let t = e.clientX;
		if (t < n && (t = n), typeof window < "u") {
			let e = window.innerWidth * .5;
			t > e && (t = e);
		}
		i.value = t;
	}, s = () => {
		a.value && (a.value = !1, typeof document < "u" && (document.body.style.cursor = "", document.body.style.userSelect = ""), typeof localStorage < "u" && localStorage.setItem(r, i.value.toString()), typeof window < "u" && (window.removeEventListener("mousemove", o), window.removeEventListener("mouseup", s)));
	};
	return Wa() && typeof window < "u" && Hr(() => {
		window.removeEventListener("mousemove", o), window.removeEventListener("mouseup", s);
	}), {
		sidebarWidth: i,
		isResizing: a,
		startResize: (e) => {
			e.preventDefault(), a.value = !0, typeof document < "u" && (document.body.style.cursor = "col-resize", document.body.style.userSelect = "none"), typeof window < "u" && (window.addEventListener("mousemove", o), window.addEventListener("mouseup", s));
		}
	};
}
//#endregion
//#region src/assets/logo.png
var pd = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAQAAAAEACAYAAABccqhmAAAAAXNSR0IArs4c6QAAIABJREFUeF7EvWmsJVuWHrQiznCnzHwvh5dvrHpD2z1XgY1bqLElhBAIMxkwQgKBQFgWo5BAYCYL/MeAAYGEzCRkC4SFJcQ8CISFEBKYHyAste3qqq5qt1Grcbfr5XQz73CmCPStb629144TcSLOzSxxq1/nHeJE7Nh7r299a9yV/P/01bbtPRH5WEQ+FJHHIvK+iNwXkXMRWYrIrG3bP4DhVVW1N8q2bfX3/u/U14if88/4/fk3feLU26Xn47M+1vg9fnfsGLufyWPGXPB+cV740/Co+8aT3z19N/md+y4s1gPvbGsWZxLjxM/+76EHDs0ZX51rP/Wru+ZxveOaDd2zb69159THUvy+fFHs5Z2IrEXkWkRei8hLEXkmIr8hIn+hqqo3U9/pXV03fRbfwRPbtv1xEflNIvKliHxDRD41AHjSAYATAMChjXbX4fgClcIft+bdAOCu4+l+rrvx43gdnFoToWMXr1+oInz493cDhbuCcpyDPsHK4+b4AALHAkB8xvBn81y8DUgd2AsAgFUHAL42APg1EflVEfkVEflBVVW/9K721KH7HLuHjh5T27YQ9m+JyM+IyE+IyG82AID2v/PXlAUa21j8e3fTHw8AJZjcTeNHDTK+QfMYx7R/dw4O3xt3q++8Jofe4Rjt3wv80PqBP0xhVfGaoe/LZx0HAFMn6oi9+hcMAL4vIt8TkT8rIn+6qiqAwo/k60cGAG3b/hYR+W0i8ltF5Nsi8rMi8uCYtxiiWS62PvgjJrjn8W+3NbvUPwrYsePqZyfDM3Z33tK9ZxxpBMTh7fE2Y3UzoAu1w3OZOc/YnE4CBnv9KoH/NDEo2dj4Z8bG2gt02Qy9FJE/IyK/ICL/t4j8X1VV/alj5GfKteNvMeUu4RoT/N8uIj8vIj9HjX+Mnupgstn6fVs2/u74F+kuz9sBQb/WMrv8LjuhuGE5tj7S3n3/KYLAR3TvdvxMHnz3uDcm+AD6xl3qZfUAHPTSjL37IYjTmW7hw+DACx+G+V709yM+iGkw2scW+zZL+32R6v8Ukf9DRP73dwkE72a16ej6SkT+KhH5K0XkdxjNF2A3EZ+PemcPnOhMOhK/3uld31ru0+B5J85lOYNv+4y8PvEJ4RlHPCAJavjM+MfHr9g30952F91dIZVL4rPX3ddvc/99RRR8Pr/SiPxvtcj/KiL/S1VVf+74/V1+4m1nEoKPe/x1IvLXiMhfbXQ/6Za3fsDQGxpK3+3+mGT8N2zvTtmWbzv50z/vAJA32tTxTaOtPxoW4O93eKzxr0NXvo1ADfGTt1FHfezRnzNk4Exf7UNX2pNhFvzPIvInROR/rCpwlrt93U1+7Flt234uIn+DiPxOEflrLXy3N5KpdOjYV3i7bdEYH9mfgre7b/9bTBXYw3NQ3qVvnGP0t3t/3sNZmgPM3bdFdydODfsdu/Z3uz5q1+kA0BuZKDjtj2qHlyHTzh5COPF/EpH/QUT++6qq/p+7zMmdV7pt259rmuZ31XX9N0WtHwdx7KY/5PQ7QAT2zIppDqqOMHlegT3onTgY7RFZyPqne7rQkgxCTAvbVGU4b8Iyr2F8icfEYiiOPrYmTl0PiVpe84NXhUf1APaAn2h/fPs78qCjuZPbkebVQDOPuKv1D6uQrrNT71P4FPqBfmCGfqFpmv+2ruv/uqrUT3DU1/ju6Lld27bQ9n9b27Z/a1VVT6fovCFt5S+/H0OO23L6MKcJ//gcFcQ0JB35J8ecQGmPHBh6X8y//755NHEe94hoEITpoOJv1A/Xd57Pntt1gaTc+IfW+7CGvdsYh9XT3e7XVX0U177wY5oHd4oOKJ/xXZqciH9RRP5LEfkvqqoCK5j8NV2y7JZt2/4tTdP8HXVd/+1t2y6Gkeuw/h/foNMBYPxek+cjXXgovNd3t+mj3ff87oPf9PHehTVNv/t+1uHQZ4d03tDa3HXNDgnUMe819dq3md8+gD9KgUwYZBjfRkT+MxH5T6uq+q8mfFQvOQoA2rb93W3b/p0i8rsPa8Bx8t9F2VIbTBv+EFK/zaLhyX1ju+vC9W30QwJ/jGC8q3F2hSq+69vOpc/nXdK2e4E2mDp32TOHdtaQwE5iez037lvnQ/M5LjWT9uZ/LiJ/vKoq/Dv6NRkAoPlF5O+G8I/e9cAFfQh+1/sNCcBdF+zQhrvrPeMYuznodwUV/1zfhr3rOLvA1zfWt7l3BIKh8d91H7zN5w5S9E7NxTHP6TLIdwFWfQpvQGFA+P/YFCYwCQDM5v/7RATaf/BrSNsd+syxm6pvYuP9XdMcO+GHBHXqGLt+g6H3HnPSDY1lCEC6z5k83gHfRtRcU0Gq8E10HJLd9+n7+dCY+8bTN7dT37sLdkPzdywbi3tvaE9Onc/4+UNM78A+/+Mi8h+O+QRGAcC8/b+nqqq/X0TU5h+eGIrAEKXsm5RjqeEY7e1SrKmLeMdJ7pXxsXt152FMs0wVgGPve0gQumAzVbimvPu7XPNjwe8QGHWF81jzZ8q7TwWAY9Z8YG3gE/ijIvJHDkUHDgKAxfl/r4jgvwFv/9j2LZ1eQyxh6gYbf9rbFeNMuf/YNVM2zjHA1BWYuDnuMm9Tnz32nsf+fcq8TL3nu36HdzW2d3Wf7jzc8X0RHfgP8N9QnsAgAFiG3z/Utu0/EOP8UzbcO0CvvX0wds+7UP8xxD72nkNj7LvP1I1y6L0jMIxtkO7fx5iUs4O30dZjlLhvL/WB29BYjx3bVFp9zH3H9mXU+GNr1B3f0PwdeU9kDf77IvLv9mUMHgKA39m27T8sIn+j2xlTXyBe17d43YUfu+/Y/fpo1RjTiALYt4hjdnqfpuq+a3zPPYFnUbve5hAYdAWie+3Y3Pk4u3M4ZXMNaeNDYNIFpUNmSd+79c1737zG340ppb45GzJHpzKQPjA5BvCG9ufQXj40rrH3F5H/TkT+naqqkDVYfPUCgBX2/KMi8o8MpfceO1GHBDJtBErDXqVV3+YdE5whNB1zNjnYHft+Qxui+L39MOp4seuGhHuq0E8VYJv21GlnaL6n3O8QmE3pBdQF40PK4m3nge8T/Va6+pM6OI0qmG6MfUqMr6MMjn2/A/tl3bbtv13X9R/uFhANAcDvadv2H6sq1PH7hHBypn71af4+dOsTEH/SoXvsIdlYeWYnfjzlPSYgK7fQMfeuuom85Uj62EjfWKeObQgID73/Mfcee/eSThdxkj04HNP0ccxTW7eNjS/fE4pnWjOUCHJj909zeSQADK/5oVzQ/lW1Mf5CVVX/VlVVf6SYx+5HUM/fNM0/Xtf13xMnh98fBwDH2FJ9Q++jmsdszilC/qO45pAWHNsHP0qtryt4RC+9qXNziM6Wz4spveV+6poD/uxhTXu3/dgHiMf2q+jbl2PK7dBcjmv6rtDvqb+DS+X3b5rmP67r+t+M/QT2JLptW1D/f0IErbym13L1IWG05+66+fY3xpgIDaPgkDPubYQivvfYfcZGPkYrpwrkEJjGTTq+6Q4/rbsufVpxfz66ALAPAqWWJ/t8W+HyvdcFZrphhpKYD++jCFDdMR+zTvtj2gdJYnY32fxwfcTA+H6lqqp/o6qqP5zmtIOIaOP1T4rI31U+cBhthzbCVIEfeo2+hefvCEpjwtZdhEP08th7dbVI3GAHfQwjHGoKnTwsuCXEdIWyz0n1tu/eBdVD7Kdck37BK+dgaK3HoHRfBA+PaxoIDN1j+juPQ0PfPuWnIgC4PPbPg96D7aP1k3GN2rb9T+q6/tedBRQMoG3b3yvS/lMilbXxYtc0///jw89XpEH0bnoO7G5dgvJL930Xp+oYQe1ap8f2i4uIW3j/dUC+EL6MmHb0I9i3OTOgpiCB3bp82wjJvfPQ2RvTNX63T8IRwhYu7fvU0HoN76uhZx8W2OF33b9fFl7O6L7+Hdv1YSwhsjP2qaG/j499/917Z8Neted+aDj6r1VVhfyAbNRb997fJ9L+g0nkj1n7gbzpoY3QS0E6DrV+7ZQhKb9Az1MOCMAhYehO5vQp6EPoLhxFESjbe+UxxS2YuxLwk/uwdFgUOoDc4wPYf9pxM5AAK7Qr64Jp3Ox9RmVcj1KbDr1d2RxtECb2IkpxjWwuXVke0a9waIx9KzcGBNNMp2md6vTtIgj39knABe2/J1L/q+g2nBhA27Z/s4j80yLyVwwRjrGX6fv7vlgc7hI4rqnyHbMIjW+IsfvmO+Q+b0Mg1dX2vHdXJ0fSFhtaT53FOHP4vg5sbL8x5l02H9c5t9vmd8cBQIAY+3Zfi/rMlOI3ZR7yWPL75R6TlkVxlHM6OvyG3nQ66Luk5PW46zocmo2pIN+9R/+ex4o3f7KS2R+qquq/iQDwz4rIP4PW3ZyAKKj9XVh0YcfCb93OqunnvhaXY2m8il5Gnb07ThbTrC/34xVjANB1sqTeO33tYafs3YJMxq3a2dQAD06k3jWDiYuNU3L+HHsCdQXqbhulC6jvZgv33WWaYPXBxP4n82+m3ZVLdvy76ScOVgWGWdehTBvP+H4sN9nx4NmVpbg72kuR6l+pqupfpn+RJ/b8cyLy92bt7wLaL6iTZGCQuQy/zvjExA0bm2QebhV9eLz5Xfn+4V4dqRp2+MSFL4W8pL2HN8i+KRABLzOJfb6x34J8unOqv9XYUOLOmJ3ad7fu7EwPKOcdmYV42qf3x9kPkXE3xnlNT+5kbfaxPZ19vS76eYZ33eF9vg9vdwGA/qenHsP/kYj8Sw4Af72I/PNO//s+OC6YPZ8K/dWznu4gm63JISLRXbZ+UZsKSfvXTcPsY+7PEXednFOeU87zvtj0b+GBpT7gl4mfGBOnKUDib2zndu31LTx29go217bWp99NlHLE0/dmXhcHZS4UHQFj85DfoVSODholJz3mfp2CuU7790O8Zfq7h9FzX/zJqqr+oAMAUn4BAAeP67rLww4tvN4vIUOkwNOXYuj+vml1cd4y+aV7r3c1D13n1/A4j9Of/fctoePQpurO6RQAOEbAx64detshAD1urUsfz9hOG7Kjywbt44eV+DvHsQ7vzXIGgpT0NsCdtr/3VAeOIfuDlZ3S+/vNAbi3Nj4Bd9kE+hqJBdhL9XRanSJQx4kAX2N0zKpZ9pE6vvO7iJ3rluv4EtIzTAMdXsS4ePtiMG2NSu2XNmSPC607b6PzOCbRnb+/LaB290tXqA6Dfkmvu6LbN7aso/rgAveLa0Ju4QeYHje2vCqZPQ6vdx+oHFYizlX4yaZp/hAAAId1/gvW7ist1ZAQHJPem7YtQMAbWoeGIt1nDAltH/JnDUbhahVpOPy+jL++PZo2UpCvvgXrfnYa4pafItvRQgDzKfGhOXgwzIDGvDBRQPuFdcAk2aO+3LiHN/yR0m6X92m+Ic19COz79kzcN+PCH4SgoxT7mNMU5ZQKikIosRS1/XqRoT3Ed48rPg74cUWO2ZtN0/wxAACO8QIA4GSfAgCGNv60SSnvVSTH9GQoHTPwtEdHinA0GcodemkeD5FfFwAIagaUIBIqsf200ZfOQChFUSx3cW+sNqDB4qCOGIBBdDzMFKBoLXeF198V/yLpqGczxU1rJlmcoQQGPS9e3M1/6EHrPoA6LKjDIDOkUYfAZApcHQL9Y/alP6uI1PS0XZvy7r1Kr2e/T1V2AwrwTwAAfpeI/IsigjTgPQDo5vNPGfwxQNK93xi4pMXyVMfozSk8O5YNmZOHOSyfRJUnl2afbmbn8ZKuGPg1GRw4Nxk0kFeeFy5nUe6vm6cyd4XXwnw+rtazBXl9Fvju2Ow9UkixfFXXRolzeP57RwPmFIDK8K8PCqJPBe/ukQkzp3QMpsE6/Q6GFMoxQtqXenwXIU3COqGS85j7D4Fd3ztOuW+XlfTN4ZjMdD8TxvinAAAI/QEAvhxDwmMfRHnr30R33QwunKX2YfilI/9Mhy5sXBPYjt7ULQx/QJEIY5/16E5Ordah51BQlKL9d7XIUIYT9Tk4aAzVNHTfJCKzQ1NO2tF3TFGozCzKOe7TKXjtHKT0wpiEkV1w5Zv3gCPACQvQSKVMo7H7ltd2/SlTBOAYQZ2qnKbsyaj4po4zmic+lrv5APYV8bsQ/B7F/CsAAFT/AQCejE3MVPu/a4ceQsWp9yw3AjZzSJAJ8VdKWkcQdR+WxD3+lPS2fzYb5vbYqNfdn1HG5N3YSE9OBRk2niRnWeA4znzKqUEDn5nGbNdHJDHmwcs8OSizCX6XLUm8Hzdn1wyIoBDmzBClhMvAgHTuMwgSMDgfVZ1TbPuMpanC1LNZ+5Ro8bup956i6PzG7+KecZBT7zf0/lFejjF7uuBk9/8aAPD72rYFAJwPzfAU2jUGHt1JGHQADfoHqDXbdpduRQ3fUPsn2jygpEa3z8AFvYoTv6Smy9Jafj5/rCtkWVApcvx7BiQXu875f7mD2MGB5iCXORUDGFI7G+jYE7tWQN/NOcKeKx2bisNFsSjhHXSRzBwyk6BvE7uDtAT60qE7ZQkHnWsHmGiXmXSfc0hox/Z9370PMaGx+x2S0T7QGHm3awDA72/b9g+IyKwPqboDmopgYyirW783USVsNKXlTm8h/Q2tS91fsaceQKCrkdNWytpQlW0WNYqDbW/30rtQ2mUezuHdbGz4WxP9B9G/Fm2F7C9Ib1WMPdsXeb4qzwoOTCbc08fvuJJu3EUqe7NQ7JLpe9bmXAJSd4+k6BrrJfEh++aTg58zjgxnwTegU2BVjzp2zluEt+JRtmxTBKHrn3obQT1G6LuC1ucn6xPUKbIzoKkHsW/qPXGDnnHuAADQ/gCAQiC79v5U+3/qwo3fj7SV44KmZWSUiEYgyDKZdWkhqPrWvqNKZpBgwLVYMldt08fPFZ6EIGilHZEWqRDFdN8wDgyq7o7fQoQ+ZKPVHL9LeQCaQiFnMyLiV2H1ZCTNm8nGFk2G9EfX1g6SXaBJzj8HaAKXrqtKOH4OFSVtbcCGfw0IOkuTILuHBQ4J1Pg+sh0xwCz7FNzYPePf38V+7zORhzR3H+gNjbdPwXYBpmqahlutKEbJO3tsMroLc8jej88ZgjRuIFJ7FXK1XfNux9/996DhsDnrNFwChfsH8qeiRstBmjiGQt4LypudbsSTUqKzsDuXQNUeNKpHAboIYP6I9E55FHxzd6RloXZ4i90Z9qS4GFfWyTkuUSYm50gz55jMKHg89QFDrCqDkln+CYvVGahbqpG2qhNoqxGhQA5gIAhoBKGTpdk1DbubuLu/pmjAqNx8D05hqIf2aPc+UwT2GPMkXts31qnvHd89ml7+bgkAhibmLg8amrj00NHUXHiRXZBJ9wEH3GX0nNd1Jc3uRrbrF7LbvBFptyLtThr1CSA5yMpnncamODpuEhtxRE2cN3bxDgVd4DVk8tj+WcBLVs4QXgiSEZzcKkgfMzeeCWClNodTaBN9aNMUT056MiIHmU4cZ7J5AwC5+ZH5k7J8/VgKDYKdmHnjLo69kKi5GBuYVJ5pMZNqdiKz5XsyWzyUanYuuwZglh6QvA46e8oIangNc2i2n6YSilIY9G6p3W8j8H37eYrmn77ffWsHpmcfPuQvGJOzsTHi3jAB9p86ducDf48UYyp4lJQKoo6N41+NtKZRVPDqmUhzJbevf1W2m1cym89lNj8Vmc1USPJG9hk0f4HyYVLTMjjoYmu7PUkxf9btXdDwIFBO05OA+GeMtajt69PrUQtIDQWO/3iCjzkV9ZdN8C/22RDODnCxpZ3aaMnD8R+do8l6KZKG+GZpntuVSHNT2kuFCYLrzf/SiaboY7E+Sl5aaZpKmupcZiefyPLBj4nUZ9I2Cb49VmCggw/hvc1kMDN06r4Z26ZDbGGf1UYex7umJc8bsXhcH73eR+SxEb7d3wtT84hbBfeZFAzAkfaIe/Veepiy9A3bSW6rm4XxZCoG9fLr/tqqstiufl2uX/15WZ7el5PzxwoIqrzanbQQnKILSkzMMertNm1MhqEKVABR2dHcfQqJeyFpmhjA2N8cS/R9A6XXp7pcGwBwH5F4cwZoypStQjB+AoFrzmIugwbPmsE1rAu7JfHoQyxiEtgGh2OmlWDOoIFvRHYvzAQI4b3k9PQEpUwyINLKbzBnvqQKAkikqmSzamTTnMvJ+z8j89NPBZamD4OGAb/0LmYS+HTHTdUPBsNbvyvcQ/ot0+HiaYW3x2YqjNbGfMBHwfGWPRxKhdMvXYfGeUges5m7f9X+Pc00DCZ1YgCHEW0cEkotzmENL17C2CBjDYoTkr2vjr7kD9hKXbeyvvrzsnrza3Lx6Jsym59Lu71Vwc+OviAMyXnlwhgFLy4QNxMRfx8AdNOaMHMDMxrBKIRPf/w3b27/LitNBwAATPhM7OGYUo2NkZgJk+fCQnLm1lCOEuRBr0tsB3Z4yGo2CaycUekAAQDXIrvnlgHJi1IadaekOxd3OblxkAxO1mouVX0izbaVm+udLN/7tiwuvjQm552NzGmozxepazIBj7rs78dIVAfU8sA27foVSk3te9FhOVhSPQgw7JPwu3YZ27Sxjtv5x+v7fgaUKC73PZyA75Jy9TkaynXpYJb9qJre7HdQfgAANWwjVd3K9vb/letXf04ePPmKEtncWjgJGypPjqfjuhYvp80dXln/GHfN/i/FhjozAN3xnmlomwQsRXbBmnAGU7Lu+BTdS+pja4Lwh9QfayuGOwHs0obwkJwDTpDAFLbTe5vgJzkxjWu/dxKuXgvFllbaGkxjJm1zLbJ9zjCgfUVmEmY3mRwE+PyGymW0KCuYQfWJVO2JXF/eysmj3yb16ScEgWpmYVt7igLgTP/bp+dRCg/pu2EN2L8n+++199uj5M6rAIe4QwkGfebyYbByHsl3nQIt/eZOWOW39QHEl+jV+jaBQ0tHRkqBMv1qQuI0eaca6vXXf1ruPf5UapmrvaoZZ/phpzV8KWrosBn8+RA8uzz+WZ/rTjc49Uxd07llHV6M49YafnQzw6MRcRnsziks4cDgFJraOpsDtlEscaZy4UnUwfrWW5ptZhJU/ykfwpRxbenMeWdwToE8Glsw4kPY2ZkxMpNGbqTdPlPfn06XJu44MidbxuY1zneogwg7kkDiL3EispvJ9W0l5x/8vLT1PZEWKSd0oGr+gQE4ACB/rpsPMWW7B93e49oqFV1M4nKtXaY7Dcn+kG9hH4LGfzOu+YfvUery/usyAJS7PkFABIB4SSQyx019qV0PCr7bwprdx93ZWIxft0WzkdmsluuX35Vq1srZvafSwuMfPMvFa+ugyxclpXRhzVor6Wz8DfZpg3Ci5bGn+5t33PPlG4CR3cPvqTJsVQROsRM9537W4GTbyAzJQ+ZHyNDgwmwhTKPc7FOAq+zKBAqhO05sqGLwF/VCCpeqWYD7zzKoefGA0m74AJ4xdJnYjj0w9nOwqR1mjAYcvg7w3Det1LMzWV+vpJl/LqeP/hJpdhDuuWd2SK35AkwYUhDQR/f1QjTzZILu62cSWTOn9TddWpbgjgtueUVezWjvT5GbY0zvPhGe2IIw9JIs9eNbRQEOeVOHpnAPtdpGmnZH7aPhPo/lI6wHunwjr599R+4/+VyqHbTWJrnVHK+pGfvKd305TJ+lSjXjrxUiDHgGNRG3FwTMsw1NV7eNQPsnZgFN7eXCYZVjpJHORPuCUKl/gyEvsgtXmeZTSNW+nCFCFgHAE2qccyf/QWAKffOtXn5Qbr2Ndy4uuLuaO21zJe3uOWl5ANAM3u4/sXfqbTddEAS+neFXq4xoKTdvRM4++O0i9X1LPJ3p0Ai8+LLQYAitusgmP437Ogc22GGBKlVczgjJjKdMwJ4KBPtsqci6GKISU2/fua6rqI+7TfnpAgCGtHV8wDCydofhG5m/7yHKVhVH258Vcoz38/uNiuT6+ldlu34mFw+/Ie32KpW9Jeu5uLHZzp4WHENheIZtNFfoqCuoQyw/RQCSnY2nwBlJQVIB33P88f0iZVY5t8AZNK+mwqbJBdvJAsU/7PStMRZnCMw0du0Pu92SdQzsevKIwjMse1Kf7Vva1XciFRR+fQYA4GWi/q5n/c18rp2TuMslTX3uhxk0TWQQjUh9Kqs3W5nd/5Yszr+g1VctLMyKa50JITcApkBuzZqjJcmi2dtTGWvLCsthCuxw79AS4SDv5en73aFqv2qC7CbmTNjMDgDpIYGOCrQrV1OBIOLRXiKQvkaXBtqdj6ErWfemDxsSRImFVoWm559U+FVD7kSarcxmjVy/+J5Ui7mcnj8Ugdff42vJNR/Q11mAMwKDk2zh2XOwGjsTfvNkNW7zZ0k1zWlpyEWtPwU+UmZfDMyR+ijdOw8PN4PkydHogoVd4brP78dEJjcrDERjE5IhbZJ2hpkIzU6dfcZhKLMeUTALXLWUJu69Edm9VADS2SwStULOAW8S9lkOY8bvkuWitwfI7ETqE9ncNNIuviEn739LWkW4eSpBAThTBJ0FcGZ0RB1yd4zTet+pltWcfueMJ5lcJXE/Zs9HxzOnseNT6JinQ9m3Q4Ls/q30/kcwi6jc4/eDJsDgPgsx0P2BThlRjK0DANz5h8/6fztpd2upZzu5fv6Lsjh7IMuTc2mbNTeM0e9Uv+4Ia58nanfGYj+CfoP2U9uSd6uWT3o5FbMhROI+tJzR5nDepal6KzoItpoBV8nMN64594r5Unbi+QYsUnIWlIr2zBdRILahGUHatWwevTr34NPg7nb0pcgn29qSb1TewLreSLW7TIeP2GON2VBIvNgyc7lOeaI5ShM+6LszI1PhsF5Is6pk2z6R08e/RZoGmn5OFmJZgYlp1ACGAABprrtQXu7Aadr60B4t/3aM8AfOcNA/f7d7FphritTqLt4iQ5JbueOGnDaJU8lG33WeOAJ707zqSrMp/MwX34g0O6nrrVw//44sLx7KAtl+sk2Tm+3o6Pfzz3Pjp/CP60HdP+bFxwYShArLAAAgAElEQVQLggkQ8JnVZKTUXafMLXDtbSTJmWtqfqpMYmeFSxBpS07ymCE+p5FwjTy43qykRXEQM58sBt/3XBNqFzYXcQsVwoFKk8Nbm3jikgGF+jbwXJgkRvRruCcuRXZvsonEjZErJ/E9psvLerN3g9zGHIpqbDhAQsB9teBrqRey28xkt3tfTh8BAGYi9Vxa0H0AQM2YAEWQAJAzMEutPKghA6V+V/v48H2iLu1Rhx2KPxzi63+jKer0bSRR12dqGHA03DdhJJyAXDWmtNgq/ajRoJ1hEkDQtzKrt3L17LuyvPdIFvMTAoDR43ySTi4XdhBxzUcAcIGCHW8fTw48pwUULK9m8zH57xLkZp0YmIE77PA2fIbTet22KnAGG8oSmN9A4TfNr8KWYnQp74CPy9d5RMPlz00QLeRpd8nplv0UmQUoM+CAOHZKtP7XNK+l2l1pToCCcJK3wL0L5dvPrny+A3WwRKNKqnoh220l2+0DOXv0l0qDUCAiAW4GoKgLXAzRGGR3ur8m6NM+7Rl/d1ftGoV8upAeFv5e1Rf6A041Y6LcdT8zfazDwjlsAtxhsIcwIC+Oa2xMoGXUOQPQTbZRAGjbrdTVRq5efE9O7j2R+Wypf/P4P/eo7Uq1YxGi80XJf6MdBp9C9ja7d93H6/tdNb86JNlfgLZnZhPBr2+YwGug9fF+UOLJ840rNNEGYzPgU79BqAmwAbjApS0VIwxKBJKLMfgdaL4oadBne36CPjgpYqKepx0H80ZFnX9rdgCAWxW6tOF8CjWFF0zG3e82Sk9Qcmm3/gj+61QE5R+sT6XZ1LLZ3pOzR9+Spl2QAahJt2BOgH4YwMTEoNJ1XO6urkKKf50qXP6ZDgne28bH3K8rlN17H3WvgRnoe/foT9ClGy24MyU0hQEcQqEJir+4JKOtedfN+88tjt+tGbNGFKDaytXL78ry4gNZzJcaGTC1mRpK+OfKuDGpPvcetVjthjXoqJahZruZl5E+k4OHWJPbslEr6gXmQMOY1eaGF98bY4Lypu2V0ob1FgGj1B8Rzg/in3K4LuNAzHVM/IYeD0Qy7NwBmhv0aqf74n1TDMY1twMvfQDt9qVUDeaW0Qp3j7BPoothKBVWO8b9DwRJOhAV7uwDuBfNKtYnAQAWstmcydmjb0sDwa+XVgswNzOADIT03wBgAg9+l/uTpKtjQk4QprjJu4yiK5yTBbTDfrpOw3fx3kUtQC4wKcU6/n4KsnQnox8kcj49hE+LS7BZdxtmBbZbmclGrl59X4t+5gsCgL90HJM3DEmxYiuIa+AJdy98ir1HKTQvrdn8lB63k0NRTKpJ8JRgeqxTam9DfeehHq8RoAebvg1KQk6sV+FP1COGrtxe8H9j8lI2WRgsbaRGclJiQp6/YDOeIhfpQcnR6s1AlR3tXpnZZXZ4qpgMlYZRCILnnE/ysxmY+JNaDxp80PI4ld12JpvNuZw9+llpBAwAYUAkJzEa4P0EERuZaVpwWQY8RdlM2Z+H2EPfM465ZwSQ7r2m3Kf7mTF2MhVMhtiOAkCfHeUfOAQKQwsybYKD/W/OP9LjnWYAggnMq528eflLcnLxRH0ACgBFJIrClex8167ers/Sf1Ufqo0NKzOqYPNQK/V34S/gq7h3ZL16F2UNBjsW541VgQQANyeiedKiaM6Sc0rPNucuh6couuwPkKkJNb+7zXT9anr+PSkqRf+9RiC9ljlczR/QoqZii8NiqXmDF1LHAfMluuDSfkggYX+1Ggqv58BAONf08kPYmy1MgAs5ffjT0qoJAACYS1UtrD7Aw4ZgaAAGZib27cGh342BxNjePPq+jskxgWokvj8GBIfkcej9ptyz9936TIA+p0h8QPx7n7YfskdKNLP8f6PYuqE1Mw8bGyCwkrraybUCwAeBAQSbWFm4U3qOxHMJ1PTVhhPePqzcyCkorwIa88JdY5d2QDIYzLGoc+COei+Cidk5KjixJt/7+lmxDD2AlOnicx77jmE+07MudBizpiXDuZY9/bzdEGcOTMRAUGdEC4He8Ddqfmdxz+vlvpbseUnekdAazBulxlCgmyMtfADbuWw3p3LyPgBgLjI7MQBYMgyqoVCAUMwI3A93DSmnMSHoasEus+1zqg3t9SFN3RWyKXLTJ0PxHYdYxV3e1+/ln93rB3AIQYdMgSk0pbyvaW54puFESwlACP8hCoBowK1GAa6f/0CW95/IXH0A65AfRs1ocafk6AIFnaUYP0DA6uBCKiy1qecgpOTCvPXdPxC1jxnwXlVXG+2nXg+CrpzMU39LNuEjdk97JOb+cE3djSo33YKUX6MCeg19JlxIg6cUm+TP0ReQqitVq9p4AWa7KxHPsNxb/BIEUyagsRJN8knmgL44x5LGgapKoBL6DsAHMJft9lROwABA++tTmgD1MjUG0fdRR2DRo3ZMsR90eg3tzz7hjr/z/T4kaMfve75G93530fh9E9IFm9FJw1jeZTlwHyr2Oy6oP1TrKwDQ894izKfefHjt1xoFuH7xAzm5RwbQNPBU08DPfvGcK88EH8SUKWrxmlzSq4FvdsPx0Fsx8H0NSmdbw0bA6nHPEetUO5Du4bX+bve7EPHn5Jg0eWHyD69xJyH78+XwH51xeC6BpWANMSEovXFIo401ACa4/obqw9heSqWl1Tkn0bZputrj+zqfgbmwcjKn0DKpKjg69c9mj1Un6gPYbk7k9BEYwFLACpgMBB8A/jXQUmZDEyBqrCgoUzZ3Ab89Mfk+Qezu10PPOcSU+8BhDFCOHe8xczDIbrwpaPdmQ9p+bEL870O+A9cT3DgMu+ng1ICF4O/o7W/XMhNEAX4gS4QB4QT0jZocaxYKs7TbSrPLEO+zUFsKrTsYWKssmBne+SdtfI7cxJT0Omn9FDIxtp7/lmvojY1YwZFJqckScv3DV7Lxo06NwOOgQXZErer+ho7JYLeNgULOsfcUcMdlyHpVQa4VeBEBqNW3Ulj6RZIhqymd/rvPJdvn7oeJa58nE5qciUDtBk7AEzl9/6ekqZbKACo5kRY+AGsIQrDBumYG0EfVk6DaQ3tJk89NER4+tIOxrvQVJWbZc3mXORxiAlNpuj9mCqtI+RzHIIBFN7pzOWgCTAWALrIM0Znyfr456XzDZ5jnjPz8rTSylXa3kpn6AL4vy/sfyHy+UL8A7UPLD3fb2VJfSQ4so9yd6GYX67hUFiCM/KPbqntORPOm6Zg9O1Epv1PvFOUOVYEmpK61+ASGFmFqm60fLGwS9wIZwm62qkH02dPnKpjlcadQZvc9UzFVzv3PAurMgj34Ggi+FgH5ILKt3xWoxBo6Rpgum4f69DZ2pTMF1eYY/Ik0m5lstwtZvv8z0moUAAwA9v/S/DWBAQyaAPYOtnhDHo+uNi3wN6TPch+Upk5pg5VPmCagfo7jtHj8ccLfd+/+WZg01uNTgeNmKSGoj2b0g5QBgOXDI4XVE3AqSwJSJ6Ds5BphwHtPZLZYKCioUIUkHTrinG4HTR+jbir87DlQomdn43cGy/J9s7mTBgxxde+5l6ztvHVS1p41OE82fnhGkn1LFIJO1t+lDcoqRAe8QknbmmcCTh9BKp7xWggXSqPnqsmtHXfT3oogCSgcwJJdrAYBho6Fv8IYhr/toFNYr/MeC0uNAuw2SwWARk60i7BUyPCMUYB9BpCFdH83De/Gw+oxK6ouNet+LgtX1wQZc5YfqaD38g8OvXe+9zR57LuXjt9NAPzAvmxjX/sPnEKB8mQ5ybYQGYiozrEl4mgIEM5AJAJt5Orl9+X03iOZLRgGVK0MKd6ZcGiJvYXwHApSPAzbFh5zz+5LWKvfkNju+81dCJldKOpUVCKO6r3GkmyQQBP8DOzG45kbnjTjjGFoTqP6d1VudFtzGCw/IGYGJi9/97M5+Sf5V5Il4Qk9rL8nFWIfgBrNQFyLuzPRnudA2z/6bKYM6B+bDFsD+ADWItvtUk7e/7a0EPzqVEOB6BWgyKwWnZ8iZGFAG+8+lY6QNGwA+L7r7lHX+oULRZ81xH2CyHUShfwvx9L9qPmj76E73zkFI895UDV2eTnuPrDqA4G9RKAx8Z/y9yTsSbPEwXG78Iw/fA8A4LZE51+tA2iQCkwGcPXyewwDLuEpZhQAhAECR9uUnW/5BKbA6s+WIov6gZyeaoFyS93trrWDgRb0pIo6s31DjJ1hQ0/ycYEKjkl/TPCIZ2c5HRPm3kpONDc3vF+feyN07PZh5DI4FnAx7ark6MtdSNTrr+n+yIh0qLM6DPWVIAPwEh0X2BlYcyH2LV+ulrOBtGU54+7LGMqUS13RYQadSLOu1Al48vDb0sqJmQDQ/sgHsDMU9F74b0gZec0GVz3S9+Rk8/dwMyEJrO+U2Lsv/852TmeLD9Prrte9BAAH9FjL7asamWIEchuBMcD++/EaVo/uf/UD3fB1A7UAnZfun4MpWGCC4gZ3flkOlCBAALC4uToAN5oMVMtaGcDJvacyXy6k0f71SLnVshFtakmJD/f1rbPXuTcON7KQkPFnWl7zakhLbLLNs+/FbgowHvrLiT4+FC/syaaJVdfp5+iUS5o4aXR7j529i/kMApqlXcO58666UWeZpk/FBZxXApYBlGp7zB+AFiXAKLBCRZ5dm+p/8vbKYBXnsLP9jHV5P8BsVbMWo4Ktv65lvTmTk4ffUp8AegRA+7f13LIBncUQAHSLh85KMb8g1yZkHPIV888RVGnG2VWdEJyvgoG8r4Vd3rftI6M4rPFtPhmy2ZOVIZHq3t/UZfj8MNvpE8gh88yvHQGAaZJ/2AbsahWb9AAAmj7q2Xpa879lIhBSgTUM+FjmJyfSNCursef2SqfSWM45d4uFwIoEH0NN3wwBlPPWAKpaK3J1+IVtb+cUGK0wmuqOS75PqiPQpCA3SQhr7NhrR2WZ3yOfoJv1riYO6Wk7/J1usMR06XtgXkNGf4JB3OCYAvPQU0VbarXvQw/lrUWaNzn8F6wVHa+aOqRSOgTX9rpS9nwHGjXbYbLYAaM+olBWoc6+VSWb3T1ZPPxZqZAJWJ0m4VcWwqoGqwS0NbD3J9txJhLCkfTs5tSDPJ1B2L32w1/E94OvXZ7nvR0ffjFd+KNSchOzFGVOZ1ZcOrKg+dOzCvjw66eBwJjw64j6i4GiWEx72BAdiHfK089Nyxx+mgCcJpoA7Q6hQEQBEAZkKvD8ZCmyvaGDrMxXCywD30KI3aQsJzi63XXyrQ1uyunXvAS8rxelmEaFs081I0tWNRyvxX5bo2Jw81tjk+TWN2YQavk4k0a1PYPOC3j0c8kYt4gFqR7Dpa7D3BaxPIFYsGOOPz9tiJGVZNgYyBqF3r1ha3V9I+vJrwLGNmJp3bhLQkMUKyNOyOQZjiZUydkYNLMuCM4JmMtue08W7/0UPf/KAGYaIuSY4QbF51AhGPoJKDOjKcIVTSiZdasGNghArs+zGWX3GjBVil1yhzZdvZo3/TKOp1SG053mBJQs/sP5nkNyOPT7Sf0ApvGA/kfEyU1Q4vXv+sddAgAkAlWaCdjIDtpe1nLzAmHAJ/QB6IZ1ALDTg4y2U34IKIneJA1oGsIVSByqahZo3tBXX0/upUdde2paUQqfAQDYWtqs38gcmh660wsBCCZcuImdBkxr3LSB2+4W4qPABsKoDk92FyosBdfG2lAlf+UogAm0a8+kFS3aAtDZveTZBup087i7ndNHx0MJSKmMOZP77JCw3yW2Yg+0pC12FDqRZncm2+2FzO//uAJCjSiA1gkwDKiiovcAyDjLcacgHQpdty2ECAfKYKGo8dhcxJEhvUpKNS61c/yp5AfHilJp3xf7vuNpnCZP3atiLsbxYxsCqcGmoEOD7HoXpwxlj7johFBTOwBoQ5wKws9+AM1urQzg+sUvEQAsESiHlYKg6GAtzOc2rAlttraz/kj2oycjqdD55mcmImXMT7o1kdWuNRhejSCFZS0zoYnNN/FdOI5LladLYTgfzzPolHa7RuUsqaZzkyYjZjHNRt1USBsFCHITNwd0JHa4SSyJJsNgnYU6AJUF2QGdsY2Jhk2JC3RZMOEqf7l3zy4yk4UXm6byZqQpLRsx/xPZ3J5KvfjQin+sKUhrDUAU8KwXQNLWLswcDEEy7856NpP52anM751JdbKQdov3I7ujPzEzWP0UDpZNfgXP5+CbvR3XHQYABfWjbt6VGNsbaYxH3WxPRBO765oA8bHTUGpY/KMN45Nres9eww/ZMBNANw+ED2FA+AAIAFcvfok+AAWAlXfWyg46zQKEwMaCnqCZ7dv40vqeTrnDyWIEEWpzCpn/uJOqrqVZz2V9WUmzPpWqPpfaNFeaBRMAajx81kHF9IwPwuRJx2FhL+aiuBbLoU2qeC9vzNSXvg5vrxZ7C4a8hdCUknYLmUm7upLm9toafeA0YFZJEqvsIAP9DmZM9MY7aDuo5efyQFNrAKoUHWE8/6qknc+lXpzI7tVGmmvkY+CQVzokNSSJ5+CwF6PyXhrshhfHbvOCbFE/Y8EasmyXtSyfPJSLLz+VxYMzaXYEYg+AKitIi5pzSaJkRrGKiu4uSs+ZRSRF08V2T2UmRze30PQ7JUlIYai4KoM+AH4sgsBdJ6EfIihZek9opITqsP23UrUbzVJDQxAwgJP7j2UxxxFWK1JDO/rbhdWi9HuiHt85AYDtAzYAcQ1gCTQOItofgGnDGBuaiayeVbK5vifLs8eyODljCFIzj3P4zFzOdOAlb7ovptN7bkkLBtgcMzOPnw8mjJ8URMRSoDPLP4c2U7gTF1mYELezV/DEJ2o/AkBz81rqLbz/NsisEjt60MZeDta8lJ3Th83fkPWggYmF9VowjdMTaV9upXqxk2rOhqA8JgzCjwYhpP576thNHou+GnUsVC5cMDe3K7nebeX0q4/l/m/6VI8nR74IM3vRagxAw8kHE+jz4ncdZ8fs+ylKc2qYbli17v9lzNkXP9Ed47APwLvbuFi9RYuwEk19I5oTsN1Z8248CKEpsIC1NDgVqN7JNXwA9x7JfAGNYanABh7UWp4mW1K4BCrpjADyME/tZQahNwYNgKRdsvyUYlL469+opdo+kvP3H5t5Qj8Ft3iSdN2XbsezHCHf12m0ib8JetE9MAFAOiIs8nC39hOSuTWcuQ18KFowRIgx+gLh8jMFkEC1kfaa2X9aX5B0i3mh7a28w3G2uZMuNVvbVQSbo6T76PNp1pBQUKi199/JqexerKX+eiPVEuE/VAKyOSj+TU3SPTXXAbrwR6Tkh9IVPKulPj0RmdVy+eJStg8v5OG3f4whZh0cBd46jhFQNcpSRlSiJ94Zx5QEn0JZBolLDKDj8U/caM828FqErgrON+0Dqe64uzAROUWUx0lOwL2bHeEpLVmEv5T9q5Oyta3NPACU/MLAJgMgAJzceyizBc4EXJmt7sdne8ca24Jp87vd6r0CnCPQfjR/XDgM0yry9AAQOvn0KC+ZydWvwzJ5KufvvyfN5sa84dg0ZnMnLzw3ZjqiXOlt7tDjHoJkI3sswwHK7HM6H1MGQTgh2bWxA10WXc6xZTt28h+ScKqTfSa71a1UK7yHsw2PJpiwJv+DbV1Sh0IpZ3eUe6YjjJjmN3tbIVK9+7VUy1PZvVxJ/RwMAHkAtbSzuVQzMgACsiOSh3TtNCUFq9Cb0DZlyqAzzd7MK5ldnMvl1y9lc/9MHv1lPyE7PVHKQpSYbzN5VAVY9mtXM8c9PwUA9vRy1/E3GQC6ULJP97vRgyksJcN3VlK6UkMNQfSPnaKJt5mUPGhfYTIAbFwtB1agBuWmd60RVAMiFRh5AA9lPp9Lq40rCR6FT8rmzFuDcdyl9cVYvFNzN8I9VGec3JxfsB+hm1fPW2nePJbzR09ku36jR1jpvdU0Ng9ZerZjLEzthi3zlHS404p/10eY0KdEF2/nbS+lImkAstdhKBhmOqd2f+ZAZpDgaUPOmekmVE1880bDlz4YFSrbnJy3ciun3+0xc3sfLz5ygTQJ1vk3DcsVm6sJsH2xkfr5VlO7GwjfbK5dgOlrIFtAJqb2W/B7mO3PXAoDd9PsOXKQk6y0vdz9e/L8134o8y8/lvs/8ZnstrkHgrYgN/8IziXsxt+7wnwnAOjc5G2pf8xB2AObDhj2/z0DSwEgDgB9SQ59qDhGNeLDI1XZnwCj2bBJnUqnfgBgAGupZSvXDgAz+ABu0xmChSNE96I3o8yb2JgfE3x2EEo/oou00NtdJRqv2t+cZetG3vz6qdx//E1pNtcEqBTypnTrxtBn80gzFXj3+CbmSbubX5bplminpURrq3BSZ1XgqZAne9VJyT0Dwv0IrBdQQwJDyjzcnABsIKL/w7tvNyK31+rTYEdgCJmxMYcPA04XkDF3E9c4g0E2xOi49DnT/v+n5+oErJ9tpZqf6iHBFQ4BQVdgRXYAgs0R0pU149MRKcVjkxPZaUmy693vgSXE4+cL+Ys/fC6Pf8e3pbpAzQEcnjx8FIKfmE3wB/QJ6hQN27fv38af0L3fECh12cC+8EdE52rGcZVhwAGa4jeNjGAKKh6kVaxG15CXCqKGs+AEZENQzfqrUAvwfTm5AAOAxMIE8ChQjlUnLaYMMofDaPP72X7U3owWeGpNYBMQFO0sToG6/SGE7TM5OT+Rdo3og6ep5i44HAs1byEo+ivtRmrblxDnrIBCgve2EJ557NQIUjBgGqx3AErhcTeWPN/BE56St9NzFqzM2pOMDFTa2yuptqiNsI0QjA2WF2c2sLeRCjMgEkq7UgHKodwq+qztOLfgggDwci0VHIHo8QgqXs2lnqEhiJlViARgPsEArE15yu4sJtnCgimKGmoZPJpyupTXL95I89FDefCtL2SHw2aqORu74IkwPYzp9r17d49PcbYd2vNRjoa0uP9+yn3iPYblMTPPtO5BzntPBvJJORb59l7KtUsnxZEb2tJuETnXAUEYEP6DOeAMAD4ARAFwMAguWSeKmhfM22jHQ0Bo5yjpsWO6ODYWxujyx0nQ6B/6EeL3Oz3Z5+o3zuT84ZeafYh7JFtaFTG1J+LNzDyDTqX6JRxkQOD3/P+e2cvEI6tjcIeXuQU5PAKEroP7NWzcNJt4BkJKj03FQNkMIDVmgowi0XYlAACyBQeAmFZjDslggu5pMFvgMrmV8Je8LJ43YDCbxqgM4J5sX95qFKBGh6eqlhrVgGqT438zFU5o9LrxdmL5LIPEuoy06PbyFAUtLgtghIStupJdVcmL2xt5/PPflgbZxxpy5Byo/W/0yeNBd3YCdpRnH1MuaPxAMU9X8x8EZV+Pg0kG0afADxSsIbYEGzMDxrR+10457ENwE8CYgG54an/1AbQbmenBIIwCLOd18gFwrolsLnZMELJYtmoO3AcO8BlNAAUdExD7PDWNZZbib3qkF8JklaxePZHzhx9Ku7qmWCswBbvXEo3c6+8bHfYrLtezB1OL8RwpYHyuzFlgvz7zlifPvPk5vLW3RiUp/DRZso+DxUfBAnBbwM0QsI3VlVTr9X7Jt/LwPJ/ldxYyMwrCrURo5XwniSvCh2l5dApYC6EmyMmF7C7hA1hrTgAAwCMAys7aDABgADqHnq6dTK6QlGRznDa1zo+vkbGh06U8e/ZKHvzcT8rsPRwvB2CwpqPqEOQ76POTXuCbju33rrD6z31MufCzJCCNdyi/P2Q+x+cM3yEL+xCT0WdEH4BPRB8QjD2o7+9DjgsOCBqXffncFmdPQDsZaIfafwDAL8np/ccynyEMiFoAtwHKJ6oAeQKONc+kDWkWugFANpMBCg1zj1TtAAC4gTY4Km/1qZy99560t9fcNFqwFNOMbYIDzXULXdVK9jlZr0NnAmzkSSwxW9w5vqVIq0MvCbiJpCcnWdZhcvh5AZMCTy7GoVlOYUFlZXNzJbXlLNiO7wixv4/NaxHpcdEnUY8Mp/xU5ujlhgcSwQl4JttXyANYS40mr2AF9VxqzQUgAPAkdTcB7KiyFPDr8Ui4/wEmTDKNAu09X8rLZ69l+dOfy+lHD6n9QP1V4C3qYIecxLzAqcJ/0Mzt7TyUZ6zPvzJF8F1Oj5HJPllU0Os2BZ1i54w9eIrp4IVAGgVI4Ts2BYUJsCuagj6U2byWasdMwCL4lFJ+jTS7XW0Zdq4dGaOzjDeVTqPhcPyp8w8hQALA+mUlzfYzObt/X5rbG3P2gQWwFTcd6k72GWPXebP/aQ2A+gAwUjIRetvAIszTTW+fyaLlM6jGdvvaqLras8x0TOBlFjNv7MaOAwXfk19mqqyvRdY8+iv7LbzqLq6m8W9vk16wx5JK7hPLBEnBH2J+DH3NhcjZqWxfraWCE3CBJiBIAWYOABe2VtquRovnabh308M+KbWaQp6+ErmjY5QspJHq7FRevbqS+Vcfy/lnT9XlzLAj5wjOQE4XxT8K/lRZ6CrMKft/SIaOdRze5VmFE9ABYAjJpiKhv9CY8yLbRqEaUFNA4BPoZALKWq5f/LKc3Htf5goAaAhiC592oOeKs6gIvQKSpDi1LTkpuwLjbzuEw6CtkSCD9FJS7PUrhBw/lbP7DwgA6jOwxiNm91O4WS+gG8dJsFXSUQqUXtjmIiXQQzKikHtSU0yvV1OGFYgx0UhvaUDiAm5k1aIQRs2tLoE5CY3a/pWmxjqEuO6JOigkxCRzKfsK3NJ3Q6rsCOy37h7iYb4PJWdzqc7OCQAvNjKbMQyo3X+1K7AVMFl4lXWXsQjKfBmFj8Xh0t+M2Ztuqul+OF/K68trqT7/SM4/faLB0RoOZU08smiAM4BkS/ebAEPCOaYQXWM7ZPVp/qnycxftr1hYhHozeA4cD05EfNuvPp8A72naU22QnezUkQYNjKQgdAaGDwAe/43cvPxlObkAACAKsE4mAJNCbEO7fazrFvVkfpomABkgqN40Z58rSoQJ9UjytpHVS2zGbwxiIukAACAASURBVMrpPTIASi6KBnLAUu38MEfcMsmhEMKEFhs0sNBa/eiPcCehGaBOsbUy0kN8NmNpRQwcdOzujETugSfKeLkshg3Nv2EVZfIadEOaNmcUOJ6i5CXCvloEAEfd/r1BnPU27TkSwnvMpDq7J9tXK5Hna5nPT9UHkADADgXRp9BCZH5AHkC5HW0IhcJRi8dTzHl5db6Uy8srmX3jQzn/xhNND65nSEBCFqIxJS8c0uk0gA7Msk8Ohvf2sNRMBYCutz77+LoAHlnQ/pocYjD+twOZgL7YfWRvOjT0UxQHAAqMIrXqsOgExMlAG7l6Dgbwniy9FiA+WotHLMZv1Nx98HE6VA95CzEz9yvQ+Xw6mdrJkCsA0u0rA4CL+9Le3igt1WO9PbtLQ2bZH6COdvfOp/GZE1A3ZHBNFUrX5tY9+nofP+XYPet2+Ide6qE2LrwGLBXN8pHjDq4ENmj/awW12EIqbxuv+jOTpRMdcF6TyozTu0UHYJZRmheeL2HfWNcmHAVWnZ/J5tVW6mfZCaj2v/oBmAik7hi8mYUBiUkeonT/Cd8getrp0NKXNv8KPaDVOUyAS5l99qFcfPYBAWAx0wxEhmVwlqGdSJxMgLxIvUKrLhqLfRyRFTsmNRHMyihCOQpf/eiz6CrsPl/CPpu3pqB9fzD8TN72qYyg+xL5peNLOADklmDMZOOx4EgF1lOCUQz0HHkA78tigSQZ+AAs581P1rUDQIuqNXWIhQw3rTVmaE7FVo8fw7/M6mNIDo1IwEJ2snoFzfMNObsAA7jlBrHPJxqt9Nrsb7fnvbjGQ3aWHMTdaqHBNA3coLq5U/UgDjZhqNITdHLmG+6RWYhScaYVsqGq0zxNZCKjbpHyi8NWLWEpMQDX1DqunMVAQm3NUGhvhACBmxBZIOOGjmqiZALWFl0AABeaByAKAKwFqMEMNA8AAICIDeeUh69YE1Oz8sygCFvKTmO233A+nKkw0au+OJHLV6+l/uypnH/2gTRYY9SVQKF4+NH6B2QfQI82devL52xyau+Y2Jd/H6TqRagvy1J2yA6wsoMAFaIA3BOOrD6oSKenmwTDWt9mL5kABgDmYefZgNYPQJuCbuTmxQ9kCQBY1oK2stBkDLWx7FWPpVbN6KWxecwcsTnCbAFZPMRYv8qn1sS0UqkJwOPC1q8gXN+Us4t70q48Ccg1PsHL9R6df3G+PNOqTExhUlKG0eTLMGFkV2T9gaaEWhu+8820MD8BQ48puyCbVN7IVD3/WxHk/btKtiHq7PgUxU2cNphr9yzw2fPv282jK6Va4Lq7T4Zrrb/T9ZmJnF/I9sVaKjcB1AeA/+AQxGUzzeDDZ5QBwE63UCYrMy0EiLGmLO683jQJzZEK9uMA8PJKAeDss8dcayiTud1f+wOYMafOXYWBQakdUnD7dDvS833TqY+ed4WfY8n6nt93ZdL3X78JoPPRk+DlSv9OxUARLLozdTgjKbyQV9NpNaALl3cEBghA8DZy8/yXZXHxniyWUFUbaSyEWCt28KVps/rS+/Jhsqyu38Nu+nhQf5oEOuEeAQAA4D8AwEtonm/K2b170t7i2CzPqXcDwzUvboj7WZ69O/R0MK7hrRlQ8mdZZV7KSeC9VUYMhFMkIN3HDzgtsMfemAKjGYThNCNZXZuT0zaG5dDvaep8FwvxFTzBWICn4TpbsEKd0G8gfqrkep6wNBc5P5fdi5VUzzcygw/AnYDaGpyZgI1lAmoikAuAsjkDQV1m9howdcU3sAHQUmKlo9YUnC3l8uU1AeBTAEAj1XImgtRyaP661kiA53HQT3RY2XXp9bQ9X96z6yyPdv9eMtIeHO0bJlPUcx/oBACI6NIZbKG5xqbHNn8USM+DCVSO3JsLpRpNtTrLgbUi0BgAmoIqAzihCaBPV8YQHH6qlF2w6IxTITLqG3is9Qw05qCNJewEb20rRQekRgHAAAAAqxv1TbDM1ptWuu3sHY39nTPq6yIGppDVv21d02ig/ClBKS0050WBR08VsnfW23uUg1ECpfC5bxmFGDkUCP0FJaQbrJNeQL9j1E4Oo3nHFcJsbMJxqZCTqJgMyFotu3SwXGgUYPNyIzMkAs2X0mg5MI4Hx3/UvAoAngnoTslU4eiOTKxtPDzUQrM+bDMF1HdxcSKvX1xJ9ckTZQB6rupiJpWaAHYGoQEAycsUUYoSmTU0p4Dzeexd4tKzYnT/HvtiP0hURv+QVj1XA0bKMgwAo3emTrbLhu7jIUBq6ewEZB4A6Gvb3uZioIv3ZL60TEBt1JGzweig2tc/ySdoI2EKbfqBFFtpopkA2jyCZxOu4AQEANyHE9AYQGrGYRrCwcyAh+0so+B4nD9KoX3WTylSOzd+DiN0tuGFQKDzAfAYv8z0OrQv1y46eI8VHH8IcYbCqOTg66B5GjKzGLpqIDKG4gXNf8G1NqdD4gsAcdfKvENjPgCEAWdfr6QGA4AnXiMBlguA67R3QCv1zmoBNPfC5jBGeFKxlSf1BM1t7FLX/PxEXr98I9XHT+QcAIDRLObJBNAyZGcAAJ6jRTevb06J9pm6Gwy4+Hfn/l0BQLxPxwQoH9G3+HuDOtILys9TM1D7WPxeG3CC+iORY6cnAfN0YKQCvy/LRS0NEoESwOAuxFxqe6PS9neW9OTQFTckNKnl9WvTD+snYPY/uhGDPiIRiCYAAODabGY/xJTjLxJGuqRRpzEcIZbEylmPZxW6yAXgSJrf1oIxy0C78u/91ykxCvX16xupNsii5D0z7XPWkmdQLyiEqvTuD21fzqW7+/mupqxLReZ4qwRmLvX5Pe0HUD1fST07YyhO03EdABAFoN9AyYO2DbM+B6ZWnGjkmgk3S8xk0EHTQatl2QCAF2+k/vgDOfvGY4VOJJW1C1QeEnxUY7teKfT3VJHrXjcuR+XalGo1ylgfCByClUOhv1JBcUsN+gCiJng7PMu0KN9nHwBImAEALAbagQG0O7l5jmKgBzJHNdDu1g618Oy3SAkZo/ciGTrg/RQZLogDQJqIHYDG0nzVB7BVkr8CACgDuCfNDWoBrHTWiAfDir7xrBjJMxRt7dPC2SlEunGt2SjFLPf3L0DRc4gtglA18EdYbb9eaA5AYwU0Nezd4CQFADAjoCOMkVb6E0m7zeMY9kcOMEVulWL8hjx6lTlk037RFw3lQub7aNEj8ALFQCgHXslshjMBkPnHakA+kQCgIVsVeDuwxAt9aPclnpLnzecgJfbTJMR8n53I5YvXMvuEPoBmVkk9q6SZI/oAwfeWZNnn6s5LZnv6HEUw9amKgu6jKXlAMX8dRXEwTm+PmMIh+iIHYwl8aeT95wKY9rABDyFSv+czYXRhCOxjYtkVmM1AkPzCxqBIBFIAUAZwX2ZYMPcBmINNUdTYhE5UShM1LUCxt6sMBJRZE0DanZ1MjNAQCoFgAiAR6BV27edyeu+eNLdsBJKjCV4xErLeLAGlqwUZJiRdR4ahN89Kp/EmWu5pvj5Lbj64Ggedt3wCc/a5INAzbgeGoNGnHyZqy5DnPYsLV7dva/EaF3+bMbvaIgCu/QMXSyzMNb7F7bk+zFFoFADuy+7lRuTrW5kv3AmIhiDUwmoq2Jywa5OFARHRSJKUj2b3zxShMAMJfTaiPUgEAgP45AO5+Oyx7LQN4VzaBbMBNQqhjV5sVlKquQm+Z3J6/khiTPvzx/kyaUkmUClLpa4f/inDtyV/DiBBf8Tt8FPKe3fdkQOfHQpbjCFN/+2sIzCD8vQBqOPDzwYMDUH0XAAwAPTlMycgtoqGi8zLnybezcV8oi4dgdmGVsDwk4islzyqAOtdI+2G/Qg2ryCqX8jZvXMFADyMtzF73TP5YsGOKwpj2qnWIdFZsp6smJPb32g4k5oYigyUX1fLSL56sBi5yB1KLMyDngWa2gzxtTZrpAbBY26bM5REU2GzMYg7sIp4pT7eXFKWM0A2k238CBQOIVwSu6gCHXcAQC3ArfoA2AyU9J/7yEwAdQLiTTwTMJf6ch/uAxjdBM74LHCJa8+W8ur5Zc4ExLvOa6nVCchGpDRncjJQsWfDlDkv4XOyuVQI1AHZ64YQp9L1Q+LcJ77HyOTRYUDOc2kDT0W1fB2FwVuCoR8ATQArBtKegOvUFXh5cZ9NQbeMyZf58LGlld83HgXlPkluRp0wT5YxJlChXdS20Z7yYCLIA2iqLxMAeDier04hzpvQ9I9LhdvwtiuYy++bNoxF97CNVw/nNIDw8GCgE3qr1D+g4xPAhkann/XaGmua0yz7Sff3szvmOwsXmZ7/KWFRknpu/GxQuP515uefdJXKnxuZayIQWoIBANASjF2AGQnIdbl0p2oxkLstwjhLJsmR8Mv7BWb/OQ4MQRjwJUyAz5gKjHvPlnM9/KmqFyzkgtMxNQwlT3OIiVqdGD9MyvvmrysbfbH+Egi6d5ly1+MlMK3SkAnggzpEEKYizf4L2hZSm5jOGtqhPJRDk4FQDVgzE3B5757MLBGI1XR+srBtRj9vLxH+7AuImoE7l3n96Yg+XAD7HwAADdoCAJCR9oWcX1xIs3qdqwGdkcddqIVF3Px+PiA3Su6WS83vOfYOUsG+crDwQzWSLNnnHBtiWFEBlA1P2g0iJol8Wj9EspVM5zvE3jMAzXWSN4SVEEe2Eh2FbhO7dOYPZvZrBU/6RM3CxOoiE/C+bF+upX52I7MFGQBr860lmGZ5umkVjZRsVkZ4wb5K4lHIJcOm6kw8O5GXz99I/dkHcvHNJ0qeZgs0IanUH4AvNAbxcwhyWhdRPvYXwMM0SpB8A3nSkzfKIhbdfP4+Ee3G/vvFuASAPhah6+w2zJFYMNgUdL8gYb9d1DEPLZGP3nAFBrX92RLM24FpXn6DVGBWAy7vXcgMi6XpwV4j7kjv0YQcE3AqWDohGFfHkvMYP9uYKDpBv8CmlQa98hUAsBE/l9OLC1bS2fke5NKWquuV8UrLszMyfWfXuiZhmrOtjh8TplrOG9kRFJOYOiVP7diNBbi209z3rch6VZgM/LwLsZtE3Oi6mbuKOg+QV4Qef7r9QwguZTb4nrT3SakEafS5pRmfCUa1kPoMALCSSgEA5wKSAegpRpoPwP4I3h3YzQkdQxh3lPVkDdnsEYi5vnpA0OlSXoEBfPNDOf/8KffanM1I9bO1sVlLC06rkHwO1qHIOA+VSEJsM+uwbqUDcoocHis/3Yy+vp+L50bsCN9H5X60CcD3n2YCDHonFbnd1kX6L+4KAWUmIAQdDKCqt3KltQAwAQAAqGqLFWLMgyeQ2FpoFx77wbY9VZNl/+m5eEgjrtmKDAAARIAPAE5BTQTCfb+U04szLQZiL1EzHfSeBJKwR5JLLNuDDkgWMSi69rBdufaq1/cO9N+zG10YDcU02ceEWL/DdUj2sboG/2tpHxs4gmarEMXQXTSNuG10j6QX8DMT7FnJb2DXuS80fRKc2tucsbAnfwQAUEsdTQAtxmE7cCT1wN4nAHg1oQblyWHSmBwFLPvDKvcokCwnZtm2pYUjjnACAHgj9RcfmQnAVOB0JJoOlSHlJJDmY6Cz1sDTFzsserHPLCrkjCGaCimzz+f4jtp6zF03FVAKFgETYOzGh+hL/NuQo7AfDb0Uj4nA3KAbem6RD6AAsKEJcHFPnYApE7CgtmUCjvPQpCUsTOXFOOqcw3873M8EETUFO5xHiFXcyfoFnYDnF+fSrN4IMtp0QZMH3O36nIaUdSw2TQ5JJtFy6TLAUjrp2YJJowCAklJhppprHITWQGsdfLZraS3eT0CwzaoyYkUyJiC5fZdbtyYwxoKUMBg7yO3U86EprMZz34NDnwMi2q+hSCm5ya2Zp5XWWgbiDgBwdqFhwPb5rczV7gdoeD8Ak2EXxORkoz+nUbA0ZqMKJPzsUOwZkXoGAMFofrKQ15dXUn3xkYYBUz8A7QpkR5KpkwfmSBkbYUv3TPkzIJCRqDkQ/TtGU7whiXYeHvAZdNN9+2TkWLk8BABDJv2kcwGKpJeJ2r8LDHsvqJNrDStcO5kTsN1ZKjBOBlIAOGc1YLsy9sVFKcy+PW6btWpOGrEEEa8F0B+ZHFRvG54n1zayeVlL03wu5/fPZIcwoNeNm5CkRp2BFpZjSUY7x0sJ5XFiynx8NjJfYNzaQ6P2dxU60HC8u9e6w1+xknbDY9LS782N6r5p9Ut4aqsJYTDS+dmUSsUx8jJu+qSkogxgjC4kqetOts/JxPzcPdr/LEOuZYec+9N7srvcSfvDazYDhQipE9DCcH4kuB7h5QVHlnKpE+wdnUxhJNpiHE+bMGUgBB4sTk/k9esbqb/4UM4+hQ+glXpRSYVaABxYosTBeg92xDWuaX7LzJZoaXDN3OjRxKY0rzQNMjbuc8YhwR+i+3eVxaic9xiA0/p+TZ1/ewzFiC+wP2jSaJp2O6XiJH/oCgwGAEHfYNvwcNCLM1ksZtoq3AI8UUJIjUsJNIvQzYycmEKBZC8ALwRSk2DXym7HJhzrF1jYL+Ts/hlLamsfqwlykWfsQszcAn6ZkLP9LFuRKf1mPN9ZszcnV0UMM8QE1SMN/CxahTOLYDefSzNbaHtrdlK299Zef/Rms7SYz03swT2E/ITNOwVF4y9WfozPev4iE4xsUi0WHpCLQ6ME2F0JVviEJvO4j1PlF6tby+z0VLZXO9m8uNHcCgU2awGmbMA6+XIx/eguNzkso8heGuwtB06ieWRcDODTtgoAN6+u5fbxhbRPHzBxHN2lkAQE8wPmHSoC3f/CtAr6bTldXdxU5nZS1XJvsZD78zmOPNH1cFcFZo4Vxvbh9M94o9Fjtb5L55hs9pnj+npoCTYm+JxzdxDlfyNwdBHr8D2pFtVLm5qCMnNLjwTTE4LZD+DmGRjAqWYC4mAQjcmbHyIYhyFA44LhnvcoFHbohzIPAoDa/hYJaBAGbEXWLwMArNERiGFKwgg+a/au2Zpaw64JOlklobQ1SYbV7LMDqV3jVF2FP59GrEht7Brfb9qZbM7ek+bBQ5HFSbZTVfPwPVxr032Q7Vbu3n3dBQFVTaljYX8FPXUnKc/SkmXzi4IvGPOIsYcAfBaSc0x2exgZf8CqzS3zFRgDooan6WH9+ZS94Gc6BfUazw5MtJpOPs+U1pfgGfOW288krMVsLlcvr+Xrai2r95baJlwrAOtaZloMxKf4CUHqPHQAcPwLTI87gB2k4Tw+lVY+PjuTj8/PZW6OR5WXtpWZm44KuqxZUYZg2uo4k/mwRPUBwBDtj3faawrafcxUh18EAweMviGnbeRJNdoHEF1ZIERgADwdGNmAaAkGJ+Dy3qkyAD0XIOznvN/DpkdoMdEBd0qZo1x3uBfSwOlHEED2HAqBFACaRlaX0E5fyDkSgdZXdqBH7tST8+f9RCDuRFqlOS5OrW+puzBvVN5ck3kUwgujrO23khYUPjVyM1vK9snHMjt7X2YokEIexNZ6F9oBpjQpwBLMg5fUVoQCt895foGeMawdYcsYvjcCczZB36kf2Z3Ji5or6pzzMlqQHKbwuv/BTQp9fa2xRfLNUs/p291s1etPM8V0r9oudOSxd39OvlJ/adpMBhqOX4ZaOlTzmei7WZOVxXIhr5+9ka/PRNqPzsk4ZjOpcS3Sgu2UoEzOc/8jPjNmBeRxAN7xmc1mI1dXV7LcbuWn339f3gdLU5OASs7ci6ageNw6jzzrF+jCQ9+htcfI4iG4iPeZxADG6EVX+McYBW0i06Z2NJgm26rzb6uC3yIPoEUx0A9keX7KakBEBxwAjGBxHq3Jp026merp/B/VQEqTnaZTINSppgCAZkQ7zQOAV15rAXZfytkDOAGvNUaMtGSjDdQ6uskshKc+hbCoatoYtbYON8lRZs4jvL92Q1aZsfbk+J1WJe/kenEmzUdf6pmI9c211BvUR5CtePmvvk3Q5GYJG3XHO4aDRhUgKLSUGc6c+x81C8+oa14/P2MxhzpV9Fsm66jStQVJChhj8rCoEi5qV934y4U0m0Z2t1um4+p1OAsAmliJM8XKtbw5UDyb00UqD9zg1rSCmx6smOZ7wgl4+exKfnjRSvPROe89r6VBNiDWVSmAPdPyseirAahmo66U1xz2XVSVnFW13K5WcvXyUn7m/Qfy4clJ6nStFd3JxUBFpeaPTf5xzNlI5RFRhMLe72lTvncuwCHtPSbY/ve+hxZ+AG2P7ZPL48FBSXkqLxkAhF1PB372XVlenMl8ibMBYRZ0odPMCU0iwmQbLbbLWFLvGyV0lfF2YEoKdtIiEUjZB5yAM2l3X8jpgzNp19fcJNDAFUilHecF4NC+W45IFGZ9rGssC0lyPvL5gApZltOvs7Bjhxu1I3eNXNdz2X7ylSxnc5lfXcl2u5FmB3aUQYNg5tWNTvWzIy/5Vc27ookxGm6LFErVc7Lnafs6QBir8n58KvgGGoEMOAujlZNBUFfFwEmvgcZdLjXSsrvesB7fowAaCkzexdzHwXRomtdk7nCSneyUhVnuUOQgcar0q+dv5NmDWtqPz+3MwFpBYAZHIN355oikecu2ZFzEBAE6ofn9GZGw8yXbVi5gUux28uLrF/LtR+/Le4uF3kuzVqwUHSYHowbmMgwO9UOaf6rcDbH3aP93r1EA6HoIp2j8sUEdeii1iB+31TkXQPMAAARoCrqTq+ffkxP1ATgAmIPG9hobidLmUjG34DMdW6EOwLW/5+8nTWp+AAUBB4BamhYMAHkAV+b/gJMOj6qtFZlRW+Om+mz9nsUvNFtDHz3v66/Exz5kNFabhlqYb7Vr5PbpN2V5fk9mr19rctJut1EHJQgHD1FxGx0A5A5Ka43mQuMZfinTDxMGd5WT6ey0KuJfqa25g6avtDsVbazJOU9bnCLp4MLzE7MiYAdnOORgAqyvVjKbL6S1Y8FcI9JUcBByYfMj1t156U5BEmyfC58RZTnmxVPv/GIhl19fystHM9l9fKEAgKagOISUzUB5hFg6J9CEPns88pFzDjuJNRlg8nGtXFS17NYbuX51Kb/1g8eySJ2o6XNJwSRmPSQR6lL7Id/A28hlV8Zd0ScfwCH7Ittfg6aLsbJgqQWnoa2qvTA3iR/lzWiAf84YgDYFRd4/woDfkxM1AdAfDhWCPP6LHmo08XRdQPVLs9W0cejX5wuqV6d2YIxEIgsQvQCa7UZmbSurV7AYvpRzlAOvXltCCgVXzx3g2/L/nGnojJZhPjrpQmGP0T7vaIQ/oZk3vPxKObc7uTp/T2ZPvyGLq0tpVivZbjAXHJ8yBLM9aUblQ8GTZZQex8nQ+LnH1PU5uU2ahlKV3Vj+u0Vmoa2VtptnOzE7e20Px3kkgJo+a17SW0wHIxh6q7qS2elCduudbK+sKehskVJwubnZHoVT6h1/vPTazRWO2RmGfi7F2fx98PAZG4DO53L5/FIun8yl+eSCTATsAyYAsksRCgRo6OMs19En2Vw4Gd6ySUDEy/4cp/JgAs9evJKPZzP5zQ/u6Qaj54WTq+eRGuvy5iNRWZZy6APZV7cuMQOuhL0P7D/DILtVgzJtnzT9+4/cF+O+axKV8c1uEYQsCBRcDogCk7v18HBQEWQCIuTHfgDL86UsTuEYW5uCMKdbmgU/GtyFP2j/ROc8e9GEAJ53K0HQBqEAgJ2fCwCt9pU6Adv1azqkNO++WHN7fcu5T9mC5tGOPew869HMBSoM06QaQuKGXu1ENh99IWdwJL2+lC00v9J/go9SU6iwtO9CtpzNJvui5BAetJz55gqwYn6LJ9OklAwrtrJsT5dwP3tA9S0P1Gy0jsMP7zBQ1AILS4Nyr74NVuX0jD6AzRsAwILdgGu2Aqd/gslDHn4kaOeELZpXnimYU7/TNlAVC2exN3uBc3kmr19cyuXTpbSfXuhzUAnY4JwJrQXgv/RH6DlVnmIUyZIhWg4nU/7LBipuysKRfP3spfzlH34gi2YnMyRB6b13qvlnnr9hocI+tkyLIyAREWdfsINaHZLZBODJ5MjwUTVtzv2KfuNjEWb/IQ4YTll5R6eJkQGoCOmGspN0WpwCjK7AjTKA5dlC5qcWBbCUXvoQzLpnuNwiQfREU8iIbdk375rO+gCoZrXuwjABtC04nIBwxn0lZw9QC/A6T7tlhbFuwe1dvpfbu66jmUXm+QAMRZJKmI9Ch4lMBzuwvG3lenYm9cdfysnqWrY3N7LZrGS3xSEpMUnH4uX6bqZZzOmmHg7V5nGmTZNbWi09+Ca4iUIjL4LnCmKrpjJr03D+Gh7GUg6h4EEBoGBC2+NtLHchaWYm52iF39lSms1WNldbmc0h/HN65d1J6A6UUEjF3enKwhxqnHE7b4GAoX4aZ4YKAI0gwl3PZvLmxZVcPl3I7tNzVdrOANTxiM/YWYH+Ll3SlgTLqE2SjTRe2+uwJttGTutaXj5/JT9zcS5PT5Z0RpqSxZ7WsYYSa/quzOTZyyy0pwcfxJigj/09wkpPS7Ds6EgT0rnjZNphC+UCmLdl7gcAYdJyYEU75OQjLLiSCnkACgC/KMuLhcySCeBP56ZwjeOOIo/FG5kzx6AtUNpMdMyoprD24HpQyIbnAty+hJh+JRf3DAAK72kmTNlBZBpT5UGNfD5X/8m9CVTDWA8/on4l24ZNMJptI1f3H8oJwn5Xr2W73sh2fasA4O3N+BY5wJRy5M3m1b9paYHRfu24bBTZ7NUM8kpZPKqdvO8sWaBwqUClFgjuLPRYe6boAdYT2yA1N0vJQoFqAigAoCvwUjvzKu3GtVaZRwXhXnKbThXsbF7mvCaIE4Q/W9TwkXCOAQAoNZjJ1cvXCgDtxxcKOGAAgsxSLQVmOJCvm3so0lnXo3E929GiHVE0cA/s5ZO6kqvXV/KRVPLj9+/Jtm1koSySigDOQGXKnhdQyNe+wR2VcTQKDinpfpPelJWpNOU/fYUA3QcmlHcwGjUUTOASADibp9m6uwAAIABJREFU8vBJNAHcO+5pwXDEsRgIgHD9/LtyogAA3glQ4K5imI1Hi9PeJMlK2SzYr2EuqYNIM9X9qAY4w28aD4dJsN2qtlq9BA59KRf3WQ6M+yNk5GG7xA11f5jA27i4sHa6bXIoOZ0jNrjTTC0Pc1RuVrdy8+hTOXv8odSvL2Wz3cgOoT87s5BPslOHQevjWhj90VnRqjZOQyEyhQYhKOjZAWq7J16W0oAZccCNkKpr/g3NtWfzDlOGIWXYTCv3gKqJwYarepu6lvnpUgFt+2Yj9RzanwVAtMGzsGEt9TOps5CBfeIbWEHUEuD/LHRoTljdEfryLAmW+VyuX7yWV0/n0n5yoebcXH0AdP4RfGyzuEPH91ShlY1iHrCWmXpUKQCsr2/lbLOWn33vPWmanQIAVgZdoD3qSE7oMuE3jgrOF9lCysn5y99PVcQZX0oA0HvcqRIoINaw08KwKkJWAnTPe/cyYBciSAc0HgGAJgAYwFIWC6AmQIH4n4ghJBhIX/gxXDDzZOb9D8bBqIFSRC0EggWyU2HDEdpoCrprDQBuLr39EAtxLEyGxCV2rvRYvCUUGcHW35tda8ni1Exqy3MioP2RArzbrmWzWsvth1/JycMPZPbmtdr+uy3+Zhl/XpobBCx7PV0r06vt/ha4nxISpP2rHjnrPmTOO4CG03STGx2naihEDvIYigxHnWZe52ADoMS4lNUFbMQZAIuzJRnAm7VUs4UyADgb0QrcHWp0pmVPZzp81Xorptrsam6hOueXHAGSnAhO9Nsg4+/qxRt5+XQhzSdnNPmRVQrAUY8c3AaYD4qUt2srNG1Olhiuu7fP4/nLqpLtza0sVmv52fffU0WDfAFPN4apC78ABZB7lKBKxXbM1yHn/dh9GI3LLvix64u/Dz+4JCaR0PgNuF08EmAtwbTOHhqc5cCaCiyN3DwDAMxkoanASASiamEmmpfOZa5aJlawkiwLP3ekAoC6HVADYE01zAcAAEAikDsBm9vX5h32/v0mvZblp34DS/zJxhOvyW4qZh1DG4JhKKnXhJ9Gtpu1Cgsyyq4//FLO3/9QZm/IABAVwDW4F7Wxdb0x2z1peiU3TKbxhpx8wZyHlhcPPFXvaIdjmtfCY/zJ8890WfxVi/08p81pvfofGMqlfHgCj3fycRcemVMzq2V5Ch/ATtav19qaW30YKvyZjhPIzYCzaA71PLUgfQLWQszYHFdzx0wL7STMsBuZRyU3L67k5dO57D4+V1MDJ01jPBr+c1+F+QNcs0b2SJzbNwmK35ncYp2WdSWb21tZ3K7kp99/TxmmHkjMkatdNVeHpYGkg/odtPrbAACffwcAGNX6PVBSmBW6Y8y41FRgvDkEDCEvHhCqmYCCjkBIBJrJbDGTGsDgXXNaUCo647Lg8cF9r6QJQkbZ0QlYtZoBgLYKh9No12gyB2oBdg2iAOgKfGmb1NuCGx3VVzB32oCDJtmtHp5ExiCotT4LTsedHlYJAFivt3Lz0Zdy79GHUl2+ku12LTvtT0AB03slikrNQZqMucPpNjN2VtK4JisInSQGch3yBryBRQAAy2VXH4JW5Hl5sjELWgIF96Q5lXPcaVpprbP9ntfjYzOYAJudbF/7wSDwiDMTUEuuLU3WHbru2nB25/6MSnBwi9NZJlVRewcmoVneyOuv5PbltVw+mcnmk3ONOswgjYgEIBdAp88ZQH4199FQO3demrvMQK/c7BgJ6P7u5kZmtyv5qYfvKcsEj1IQ0DUkANBcdAfgsbo/P7cb4nNGMUWjjwJAFPYoWMNJCVHn99MZeuchdDwenNVrmDrQ+Q0yrKVp1jLTTMBflMVFLfMTdAXG37jpdSKdmqWwGJ+dC5ccuT2gS81CxxZbgVXIwlNBcxMAAACnnOUBIAoAQTCvPtePoaLk80sdgcKiGCkG1pjvn8mAADc0H1Vnp8gGx6OjQGa9lauPPpf7Dz+S6s1L2W7QnwDsyNHDxmxTxTCiZ7CFxBsFSLU2TVLV/55YDIuWPAJt9NPMC5go9CFA82vlfKLSOegRnKDWwMNTjPU4Lk+D1nYCVlasEYJWZjABtgwDzmYLpf7wiGsnYMvGo6uGs9tWFlUwfwB86blUjwCoel8br2aQUjCwLD00el+/upJXT+ay++RcmhkiA8gEtLbgEEFtT84twdINC0R6e3NnIu4UjHjg+S4kXPo1ryrZXd/KbHWrAID9tQTwQGEoRvHYU96O7IarezcTIDHrwmlZGDF2SSmPKttdBtCNSXYBYDwbqQQAHcYegLLyj1+5Pbj3BEQeAGL+zAT8RVmeVzI/wbkAMA98cVJmZgIF0/8BAPykXbOvrEGG0mrIlQIAWgxCKyMTENWAjWxetLLbfiUX9+/LdnVpR4FTU9LsLzvTdt8Pc2ZhcEsAoQCgkEf7EVoWIjT8tmllu2tktd3KzYfflPuPPpL6zSsFAGUA5kiL2W1M1/We9kbn0xHktH91ysPAGHal/R8zJhOTUBuD9fk8rg1zEQQu2KZkI5htT9/N/FfHC696qJHXYiXI3BmiADAB4AREJiCZgzoB1RKw1GpL9PHIpXr0GUE35sMGIQg7MjJbc11ScSK1KV5pW4msLq8TAOBCpACr9tdiIJ5H6N5MF5HSbCwrYF3g0k63nApsdMzyCXwAAIDblfzEo/f04NklWJpFANTvmMKAhGs3e+7KA/ZNga7QlT8nOe8DgKxB364PYJeCZFqFdNncCowZ+lqRY7HztZoAs2orV8++K4sLkflyQQbQSaxLixEcNbRH+YxkTwba5u219KDIbabl7WarYUD0A2h2DAPuVpfsIGsWhJnAHfvNt0JwiNG0FUGfQWs0Ainwk7xoBrSyadCHoJH1ditXT78h9x99LDMAAOL/2qmMPgZVcJoubN5xs/fphGPmm7NSzglHqprUA/log63Xhz6EloKsZoQVwLBZXrD78+0YN7f78VANyzMwUqz4qFTX/NtW2wwhBwDAB7B6jaPBltS8ZoO7L4DMhZyJQOXshYJuPMgacVgik9MTy+PXTEb0T2hw1Ewr28trdQLuUAxUNwwD4lQgPRjEehKY9vTTlF2gCnMyRkuMZTgWmjLXJYATcHdzK9X1Sn7iMQEAZsEctQlaGMRwoJ9HQPH3Se5KTWCVHWfkNEY+fD994rFdgccZQP8Dywm1vH2dPaC7n9sHAcRPt2oK1PVOrn74HVkCAE4WPOveQnlJIaVwV6am9Kl4qNEcgbZSVOC2aVH9p5GASouBGrCOdierZwhG/JhcoBrwFj4AJ2nc5V06nK0RAoHmtqv00p+RgqCoosOzNATXqIbf4N8GPoCNXH34DXnw+GMNA2rZ7IYOUppMIA/eqYehO/YRCHF+yxLMAMBjxj08yMFnX4KzC02P1eQUY2Pa78Cz7H1j0nkVuyGm0KiGB+FYsydbGjAhhNQWALA4WyiwrS9vpUZTUBO+dO6COhbtuDAL6Wo5jYKMCb9qWS+/psrXWXeqqYtfa7bdLZyosPBeX8urDxay/RjlwI0eMqM5CHprVgP60eJ+s5yYQwobZyPlCAT6H1kBItZgAPXNWn788QPtGzBXAIDPgwAANpAAIGX9lZmF+lrmfOz3a5npMCVKEcSyAI4IAF367wPQLdCTFHEYW4yQF5qZ9l1qfGeaX+PruuDGAASdbtEPoJHrr78ji3MAwFwZQB9FIl0zb7SmigYzJDmLVPRzOa2+nJ0IhGScLXwCyEHYyuo58OcrudBiIAJA1zojkMBmdqej0V7tM4j74jQbKwzSvHbvYMMNCs2uDACRgFZktVnJzdPP5d6jjywMuGUI0J2AoYpMwcBekXanJQBxoWzirVef/spaikVNnrz93sLLkS07D9O86lx5qqWlXarsMZSqCU6WG8BPGxeHmeLzX7NFN3Ib1m9WUs1OCKwqfFaSa5mF7JVIR6YyAz3tiD0PCHnmQAsHmtAZyjJtjBXWxM2aDtHmzZW8NABgGJDFQPhPw5BeQORTV1TplaYmtabZ+x5y9QWxqdEw4PWtVDABzAnIMKA/1rJPrecBU6CzMEcGnoBlBAjuEg0ofABdOnHIszj1YX2oZbvTIJuJOzw+CrMK+xgRAFB9+ACQU/0dWZ6huysBwDUBVUv0NxgIJOeKV6MxjxZCyZJjK8XF580BqEUrW5gD6AewllswgA0ZAADAy7gUfNzcVceg1QkpftGxBwbDikCrpU9OEDIPBxL1/uuBxGQB681OrmECIBHo8rVs0aRUzyowP4A3EbWQETMMTVDUqQlWEKm9qUUzhlWYzAeSyj/cOWi9EngSj2XFhfP9PAqhn/dGHX6qkgqQsQwInoaWLNdASbxlfYIBXCxkgzyAVxuZLZaagusUnI676KvxI8NZAal+E11v2NIxMcbDkBQiMxx0YW5vd5pyvHuDVOC5bK0hCKIAmv6rUQDmA8QcoGhLqasxKD/dcWrzMxXbPfluMOHvixoAcCNyQxOg3rUdE4AOCu1IZKZW111+SPP3Kd4xBT3ozD/EAOIgxh4QB9UHHolFOF9L7byhGRnr1riyhQCRB8AoABhAI8vlkufeq2awNDN3dKnGj8lFoX0ZaYyxDuYOpPg8tDVCgQAASqPUzUZun9fSrOEEPJNmdWnxcENoxwCnf8im04y63H0oUX6vskv2OkFA3xba030AONEbJsDTT+XBk49FXl9qDgAcZtnmZ2KLakYXdJ10UzsGTrovvUtvij94Ka1VQtKQorBb5iLtGk/v9e3If+GvUIgxJqSgrWsWC3kQe7eSZAMAgglPXFYfwPlctnACAgBOeCoPUnU9CUfLlcGetEkoEn3MtNDoAsCZ/gH6Ni0fxHSAezz0LGFrwX57s9My8ubqSl49XcruozNWJc7YEEQbvXgikpUi5/RqUoqusosqR92pTj3MHwqwQh7A9upGWjCAx+/JzEyABQBSiQftVkQLCCYlA+gy7j4wiPI4xRfQlUn/fNESbEhjdynJEAPofr5MyikgwoxpZgIya8xK8wAAmgm40aPBbmACXDQyXy5FzAeQWISavy74lldgm5uOMQ/tWBWXgg4+zdAR8wCYtqubfLuTmR5IWikAnAcTQP1ijC3ROYXCFz273mv+PVxXshJKDim01/xD0NQEaBocSKRMYLXZys3Tz+Te4w+lev1aM+ZgArBXKM0GP5uQ4W6Mhb/PtJ+hRfyNPoIcWnItzhg98gZw3PrOmnPm6kFfpVy/4Vl++AwdgPoeWkpgYtfA5ebWOIVU94KZZhgq1nh+vlQfwOrVSmYn8AGAqs+0Tx+YAL5vmi07Bmu2orMfLzIK0Q2lX/Z8gKqZCOYSVf/IzaqRxXIu7ZsrefXhUrYfnupn0BUY5cD07Vg/AAMA7g+uYdLK0fx1Z7qDkCVCmSwrW1nOatlckQH8+JMHMjcGMDMfQAQAOkxz6LpPux/6XRcI+hT1kP9A5RhNQfvQpGuTHDOwIXOCs+pYTcHVIkkvBrIkINj/egoQagHUBGhkAY3hDMAMsSj83sbJNZszAveuel5e9oJD8lgHwKIgPxuwldXzmTSbL+X8PZoAZB3wxiNPIbcGS6EjSkPaOHETGVM0beK9CBANYEIQAaCS281GAeD+k4+kfvVauwDRB+COIZoc+j4a5qMGz2lQBkoe/ycpSg4s2Orcu6aqPPDtfb4t7uX7W+17zzOwxU9deDXJhucaMOfesDZ57C0xhzWA+mlkXy6UAWxldbmSxfJEw28QwkbPBjDHprYlQ7QCzMB8DAbkXNNEwQzdmcfveZreKniza+XmppHT87n6AF59cCINGADyAPRkII8C2InE2k8wPSht96Ts0sRkSUhXG42nn7mVuZoAt1IBAB7fNxNgJmiEDuHXqCNMAM2AJAPgGQI5ia1Pecbf3ZWRd5+ROgIl5O/0DYu/9++nMoAh0KDvxDvksiUYX9+85sj4QxhQWrl6/h1ZnG0VAFT4dCFc2+eiIkdt51RaLuxJKZ516D5pNzm0GShQkFQbbbeQrHH7ciG71Rdy8eBUmpuX1gvAEpV0oKZ504SYYzN5hyILyFSV/f2NOqsJgESgSqvFVuut3AIAHsMEeKX0H7XzTPghm6Hzy/lPDrOxNNri/OoQtOtTboDVPaD4Rt0VkFh8H0/isbTUoimGswsrYVYXQ05HTslYyUvvOjMnXtFEobtlflqrCbB5s5J6ccrKPDjpNCUYLILAWFdzTzK2xiBEM0YUndYxzmqHvZnOzs1Dbtc7WW9aOUUF4ptrrQZET0AEOOq5dQAyHwCAiP4cLwpyv5ExAX2/SAkSufTF4PqY7MC9sL5CHsCthQFbbSOuDADYY9EYAIDpwxAG7GGQHUGaKvzDPrgAYmMMIENhnoAeMCwQk4q+P4eA4IErvGrLW4NhE3vYLCcCoRZgfraRxcmStrZ+ZeehOwP1eUbx2R7MhbQURgBPakACrY9DQRo2A0EUgGFAeKu/lIt7S2luXlmIzO+ZCo0zRYzhGicCSRZMFWOzJiuFZcGQ043G+ls1Aa6ffiYPHn2kPgA4AVuEAXGgvcbDcWNnGtlTb/W/tji5zNQXhBWM1G4EXgdGJKemIFqO+1uxEvvWcaVT81J8b/kIFH5ndNmf4IaBO/WYsEOKAAbARKC1VAB02POaCzBP1YDERwKBZyz6+Qn6HgZAGnlIRUgWCzbnHH5/vUJmZysnpzMNA6IhyPYT9ANoZTav6QTUE8J4QGnElVA8YnNkzGufIAQAIDPB/CIMuLq60SjATz5+X8OASARCTwD3AWj4uYgC2K3G5X+gL2bXjZiF/JBp35sJ2EWYPYHvQYA+L+MwUuEGrr0JAIytQiDZElxrAZITcCNo76yHhnpKrttpXiWmQkjtyu1odneaFwoCr7EkIWTmQQ3jPyTs4FASMIBnSFj5Mbm4fyrN9UvLjjPqaSp4iu0VlsCiD2ZrW2suOgHRE4C1AAAAMIDqzWulykhMahtQYWvjZQdsuP5Rp6mCimUdhaiImyHuE0g7OTkNXfsnjpcdWp4EpMviXraKPfWhk/04Q3XyGRhZwg+3hk06fCv4BZxu6NF/PpPdtpX1q7VUOKIbEmhHdNEHwM7EZDxw2PLeEXIp+O4yzv0QM/do1acCBoBHL5eV7F7fyOXTE9l+fKaOP48CMPmIEQE/ZjCROvsmcJqgre23JvBRQQNIEPLbXF0jDik/+QROQEQBKs0DQHhSfQBmApgvU28RfW1DLLskA4dUcefKIrSZC5v2nIDZ35ERZQwA+jyMQ15Hri1VoZ/TZ3VbptnRGhwnAyGLGy3B/owsztYaBhS0BHPpNr8BQ2v08lO8mEXmQMoz5XgQBavjaMsjxNhaFqBmBBobQBjv5hl6130l92ECXDEPIGxrRhXcZgvMMLgBzD41LalGMuPa7LYDZxc71igD0DyAjVx/8Jk8ePyJVG/eaGYgQKkBd05awZJilA7nrkT6Z+t+nGTPmg6oQ1A9+bjKwnimuRkBsMiCDd7LeckU+JlM+0mx2RrNC46sy1JynNGhp6E7bYNPHgGfwfJsps1NVwAAVAPiRGBrzMn59AYfxkzUkslmiqc4a7zI2q3z9HHLDbCkIORWbFg2IouTSraXN/IaUQAAAByPcAKGMKCWBqfMR4sa2dkCXLeslpNUuKPV5in5zFALgGpABYBVAoA9BqCnYVkR1YjW31ekHROzlHWTLT9mPf+boD44NQcOBumOaJheJMTsIEzfwzJfIi32tmBq91kxECn6ylKB4QT8s7JcXsvsBKjJhiDM2jJqnYbq3vkgkVaJk2o5TFliQdGYgecCMCYLAFDV0e7k9uu57NY/JvcenEp7/Ur7ygWfsHvXklwmZhjnIH3C/dLMc6fDs9L0X5xJAABQH4ABwP3Hn0j95o12BFLHnWXy8WHmEDTh14SZJAB5jZhYhfmgze+hRMbPDMxSMpHXLFpM2hx7ACgNNFiSj1JWSgml2R2Avg76RIvrW62Dnr/nJ+1UrSzOaAJs/r/i3jTWsixLD1r33vdeDC/mIcca29VU19CIwZaYJISQEWAGMwgJZATCajFZSCBmEPYfBgMCCZlJlhEIC0vIzCAQFkJIDD/auN1Z1cbu7qpyVVd2VmVkRmREvPkOB33rW2vvtffZZ7gvsiHtroh4795z9tlnr2+t9a3p9SVyu3VAhwIJxByxeA0jWncfRY+Y9kVw0Nsnyyf44poDwPkQ8P2RNamE3NHSAODQAACJQOYCAE+xHyAFdaPCuSocvFqbMvqEtcOtc3liQhSy/gAAF9KdXcjPPb0vB5tODtEPIVoAW+QBkAOoS4/dGmjItf3ID/08s3+MPGy4AHw4/ucbMg4ArTjkuAmTW4JBnai/p7FtKwXWjkCYDbhhHsCN13JwE8U0Vzkpx3Pg01ItiSSZK9Efth/q49AHVr2iUzjML95sla1FCu/lJyvmASAR6PyljrCOAKCIbFqhcH0yGuauOcRjiwKEPAC1AESuwPQLogAbOVUL4B1ZvsYsAKsGVHvXzR7P64dwmuldYTVj9iTXPP0BOfvuCmRrju5Q8n156vReCiAW11LIsIIkFUj9jO1HqJzjV5iRCJ8fsXa9P/bbcOvg1oGsNwCAtSwOD/VdOgBoW279oBFj6iJmdw6gz1FiTBhLfIjm/wMckPVHwb/EMVHw6uTwBgDgTF49PZKdpgKDA1hpwRKCDZoHoEBkkemRijwznBjetNeiFa2+d1bTqv0ATs9kd34h33zywFyADAAKeSgMUg6AeShzGH7KGT7rhG9SPZWCMlXb6GFQg4oBgB+LXJDoQSMngobRqOVrOHj44a/BJGv/zAVgDWDj19oSDH+iFuD82Xfk8OYrObixVBeAB8bOqmk/F85UyMHoVzY4kiNnOfUKANaHwABA83GtWu/ik4XsLr8md+7dYi3A4jDSTQUsZoGqdshTk11rehq+JgIxn0CLVTQjcCFX642cPH1f7j16V5Ynp9oOHMJM7W3x6mRuOhlojxiATfWwpf6qxgzfpSnJjcnRBMsp8CxBgKAlxyjseNt1PXNWmKNulblxZrrTzaDA68ANbwVmNUq4Jxq7osvRJaoBkQkIc9xCYTokRNAhyNZjLoma4Lb7mnFoqMYQJNuekxNgZt16jSYr6MGP6EonN45WstEw4JGFAbMFoMVAsDoQFUig3ld2+o4T2PG+HhgI+K7HUEEHqcCn57JFP4DH9+XQ8gBgAWALwQEkErAQXVpowUJvil0KafupLJMVe/UDY1GDBduCZwH1sgfDmt4CBg988ckMKPnaQROm3n3M/uOwixwFAABgErCmAn/yXTm88UoObwIfci2AgaG+DGoxY+mrBboyc0OXXIClHqvGN2mA+Y904G4n55+Ahvhtcgd5AGgIom2xepGg9MStPUmzCVJqrff/szo31PqjD4BNub282srrt95TDmClFgDagTvJR83Kg5jQLDgZmaxLboGpXe8LkA+Nf9a1iRFhWKcNKfURW1pi69N+dH4A7+1JVt4V2MlVNeW9d6LysYwakB3HqO4VS581Fdh6AhqBqTkBixWdnBB2UzMbYUTjUbxpqXMXOi7NcA2fvbrK3IMm5RwuZX2CYqADtQC07ABRAE0Ews3gAjgAVMrMnjbtecCGmCfj38KyYZug8cf29Fx2RgIeeiagtgRnPQC4Jm8rrluUwLltbdc2eVSpUd02EWPkhwYA+abFQalKb6Y9j/pO0T71w4PzUFkAFgVgOTBYeVgAl7Jc7uT02XfkCC4A2rnBBXDfzBtT+i0bMBZXk4WU47U08cs67uCEqc+LrsCLrVw8W8nu8mfUAtBEoAYApL1QE7SVQhL8U1uI0pT6RaQeMzaPcmD8ebneqgVw/xE4gNfaIIQcAATThFXr5X08mFcGOsHHEBM+yS5J9Kld45cH1sRHDx0tKgKkZfB5xaUCNfxjN/m9bsP8feMTdO+M0FJT3PMFYJKnJJlODm8fyma9k4tXG0YBNJkIjvhS8wQ0EpDClbY2I/sI9Oxd6M+kKVmRkEU05dIGn1pvw6MbK9m8hgWAwSC3dT0r9Cs41BggE3Cwr5ZVqPdpMj75NNH8Tz5D8Xm1ACwVeKck4AMBAIADQB6AdgVqWABjWjpKUUuWxx30YemnQkkOPB87UEI9rZf0uodpRu2DNmalu3g/P+13R0sAlXiaC2CTgTQM+OwDcgC3FrLYrKlN+D9Jwtwfc7M/uy+mr9JSbGosRZAdI8wC0Lp7AEC3k4tPlrK7/KoBAEaDIXXD+7fxoftav965/LnEAaQU2YWa//g/hABx76v1TgEAJCAsgO3VRn8OANCKOzPR1WRNJr8x9dq51ziP0BlHHzv5gR4CNX3hUU2VVnAEVmDjnYZM43JCjxe9MP6HKIaG6JQEY4yfE4boYkXaQjkAC+Ud3TpSDuDiFQaDoBrQFoH9tWaihC5aAfT5LXnCOAb3XZRF8vwrOwrrTSc7mP9GmWj24Y0DBQAUAwEAsD7kAWgBkJUDMyfATPsilOoFV6527K3T6bcXbKfN/um1AOuzC+UAkAegAIBEIIkAYDNJg5Kdm+BT6by0jgjyc6/VJwELtRmKYNPzUpraN4hiEW0JF5lsuNAKIKFDGgzfdQsAvQEv6AI4B3ATFgAAIgsfI8QVMlckjq/Ccw15gCz8pc02OCZchWxNIvLqU1gA6Ap8S7rLk+T7ptceHrOEufwL6ofSZmIY0ATEfH8AAO6NuPXJW+/LfQDAK7oAMJdBalEr+buwLDVLJCIzb4KCE50KpZhARKyw1YQadDxLSvDxEd3WLiw7ubiupyL72HXQpxxxDbJPNaonC5m7o2Y/TRFiAu67Qj+AI80EhAWAyUCsxsP2rgRdg92vV2LOOvwyDZvX8zMH397dECY5UR4vMVrJsj811K4k4IEmAn32ZCW79z0PICcCKaeE3gCeBFhr/xaR5vrHXrcSgVbJiB+xGAgA4GHAnRyn5I3cAAAgAElEQVSJJQIt0dEQlal0kbBedwFK4jyfpZQXYUe9PFXmwg4SB31VFUV8sidgiQelMTIHZVq352H2ODMm33gaKow6JOSwKzDIktNPYAG81NFgYi5AWkXKjS9NkZy8wp8rQZWI7VABp1EAKyeFSb7mnB4FgHOkAsMFwGxA75OXr1fsSzZG0o/d+HZySZ/Y+mXSBbAoAEx8jCS/MhIQYcDXJ2yeab1ECJSR+GSHYWhQ6Eu4E5xCkjMEVSzM93bQzL4m7+lhN8/DQKfiVHBgHYaYVuxv0UuKOcJcfXWv17csQR/l7TuVaqWWOwLAZicXygGwJZiSgGk0F7MPkRuARzLkM2uLat3nI5ZvnJEHmv++VgLUDQUAJAKBA0A1IKIAB0r8aSYgQBkWgYNWUq+ZMHaG3s97cqxsf8uvLjSqyGpApgIzEWglh6zDQkvT3BHIzk471h9d8xiHqp9+7N89uCg+PDAYJGh+Z9uu62j01sbjSFTH/9h4cAWFrexQCKQuAKoBQQJ+Rw6PQAKCWbnMerCIn/pL5585Ccn84SKsyQQkfRzS1iTY0B8QFgCE8dOl7M6+Isf30REITUEtgWZgn8u7Vx9yLWEAQFlm/wFoKGQCOgfw+ul7ch+ZgGoB7FgTFcKN/ipd45AgA6rEl+N/t3ZXGn0wTa1awrr66NcsJ0Crwkxk1RrINQceEuaJYFyfmooamenNnfXVI9xqbYL+3AaY6P5v5fDWDYGZfvnKSUCmApMA9DAiGPxVmtHnhfpKEZtF4elefInUvldXTKwigcgMQdwVALADB/AWwoA3mfN/iIag7GCk+f/JBeAOM0Eq9xzovfZMrYRfmZWlmYAdLQBLBUY58JGstDMw8PLAWoLpiLAeAMTT5L9tE9Ax2a59NEuF3YKQNgBUZs+8tMS5qORCqhMvWSvu1YCa4HFl48GvZKUtwWIUAL/jpiQHI5m8PPgtx4O/sd+7C4B/bsyUBBmoDUI5G/Ac/QDOv8ooABqCaF68m8L95xzD2PwKKOhuUmtLMAYerBZgK6+fvCcPHr8v8vpETWWABITbXQkKHwVPtZJaL9TK3lPBTWUN1Hm8Wg8etZwm5rDMLw0uYTsFO9Wq+dlNKA0VVnFg6FGHp6i0eo2CFwdxX7i9LH3WRCIjywDuBzcPZbNdysWrtdbpqzRopiAq8zzEuLOUYAMky/RUs7+OgITsbABAcrscNDUV+FA2pyeaB9C9e1OxEh2B9H5xOChUs/MZdh89qTMUX/qcgQ74RboAF0oCwgJAlyAnATUMmJLWeTJjiDbTx5UF0Dho0yCQTJrKufH9DVk8RVJLIENaoj3H/E9oGnYx345hvwwAsDTh48MC4HAQ9gT8jiUCQYlgZiBNQYuJpXh2XGM22cyKtH30HAK2mELc3zrNQBI11uS1AEvZXZAEpAWAk2ZZdXajeC5qNye9J9f+ZkXpGHATNC0G2i01/WCLAqTLrdACeF9Wr09kvbapQDbtTKEqlY2alZNGlefEpOQQJwLNptFa95rcyIOaWsm8UAmj8wQg/DyVVo1HZg8g4znzfCT2BVBAtoQW1bwehQh+C9619gO42sklRoNhOjCub9N5mBJsacVG9Joy14GbqpNTlyKf4kvBWa/ZWJXcAXefbh/yAA5lc3Iir99iT0BMdFISEMldykHABWBXI/XLTYmwOtAJp7i//cpAr1CmfYWmoJ2sTy8zAGysKaiFAQ8wA0F9/8zTOIdAEIsZkA6s/ZTeWi5LmawtCQNm56Us72G0KeiQ4F/HIvDvEADwf17IYcVAlqPPKAA5gBQGPHoth7dQI4REIEvFVx/XTTZDM39Pzg0EwtDDb2b762QealAO39AZAdC4SMv9FIMdviJ37mM4qPUETHPq8q5EwY/Glr5EA1ByAP7E+AVfOvz27W4pa3S72e3kYp0tAJCA6w0SWlAMxOdV4ddsOdYu8bomGI5GrnXNzXBLgXuGLy4FxYVqh3hBj26jFfWkugryCxRkdglS4fdQn4b9cLnQTFMBipEBtVIsrJjNgp0c3EZLsJ1cvt5oHoA6xLT9U1IQQYbWAPNFc1m3K5QywLqQq0sW/mRLj29DGXmtBuR04N27x8y8O1yyExEsAEgv8gJ0joHrlkQZJ7hvG+YZMHRvtOyZw0HVAji7kK8/NQ5A2A/AOQBsklYDJhcgmvl9syPo6UIsIz8xVy5T6FQVQOPKUzdThJ1jG9lSy+uxSy/9NPqGDAMqxYMmzsYB0AJQDuDQOIDNlXsA5go02Lc6QOdx6BAv0JfpjUA8b13tcXYKugAHcP4lufMAk4FeW796arw+NmeUKTwuc6N8s12I3Y/GMwNvkAcAAEJPwFdP3pX7j96X5eszswCQGZnNfp5qZ+aNwNR0UquCxJQdm3lAgpCazfCWYTvDTU3vpaSqlqewm0sUioa4bhJzibvx98pZpeaKW5MSv5/PIcj6WFbHK0EkF1GAAxsN5m4AIgGJX7Dhp2Rk+K5cQzqYWuyRtQUbav8UMbA1AD40CnByIi91OjDCgAutBYALoHMJ8NQgIfXvGbjdiuB9snAmIKhrX6x4SKsBlwvZnl7ocBDUAkQSkCMJybkoQAcAqH30ITlsKeYxmayBIV63AIA5N6wZ0aHFZLRufEJ32lSbAoC+ZRv1xc68yAQkB0AX4OgGcOGy55TppfzQ+WHsAah/gL/Q22lLMPj8lgTkbgDyAJ4hFfjLcuf+HekcAPRwWMZYsCyKpws+Wt7LfE8aPxjhxUQoMN06HlwBYC2vnrwn9x7CBTgVdLTZXW1ZPGQ3YQdeZiXagD87nzpnxrgCO1SqWeHVcBIQM/I4M88z29wq4gQgK8dWkcA9rFbApgXF59T4e7I6nNfIhUDunuXN5vte3VppZAMAsEKrLuMyUDSkJrkTjJrGm96UWVAkHkvPdJFCfy4AftjdBYAFsH59qi7A7m3MBmRDELUAEAnAJnlT0ITg2Y3Qv4WipMLqCyDvwoyo7Y0FowCb80v5BjgAuABLRgFiQxAHLXpbZdL9PrLo72ZIKdc8QQEAdUMQv1hpsu+n8Wvhjz65BxW8NXhqCabaiF2B0f0XmYBAytNPf1mjAMjo2m0uidJu/dshrH1u11R5Q8rmjjSBLc3Wu9tqT0D8DA1BVrK7+LLcuQcXwMOArhMCuriPH+mV4EeyHbeRU0hswagsO9cQ5g26ARkZiFqA14/f11RgLQa62mnefI6W4ICgaaYVwyQLzEKB5v3qQA5LCiJvYCa2TephnNxIwNRe26IytrmIWGvLMnRStkag2VrIFEwiZPUekSSlJUF+gT/fLTbaDwB5+swDQPKStefGOjQPgI/H3H5z9QowNzpUgRgDVTHBKSeve8jVeRCs+ejGUrsCay0AOADFmqUsNBmIAIBBocmjjC6+5hvMP/t4E+oCaDXguQ4HAQAcKABwLoD2A9ACK7gA2Wnpg9uYauXv9lXGESASUMIFKBAh1D/7DcbMi6FljiOY8wDkAjQwpQeTHXZ1fq42BEEYEADwUss6ER70rltJ6Xutr75Kb2kdhnekBfJl6yvVcmA2BVUuQrNOrCcgLADNA4AFQADQrjUxo67tCKQ7lYokOwZKAvLVqanuHIBWsK238vLJu/IAAPDqTDYYaoGWYJbwk9uBxcwzE27rBk4+jgKnn9L6AevskwpGEB1gFVoyp5OJwdFgaopr0xSE4xizVgvDWfeUgcfCJjdjtW+A7zKyE6k+uZ7lTg5uigrtxQnbdcMM1zOmYVZONwYA+IhvftNcD12sCYxGQJA7YY1SLPmHM/24HiZ4dnIDAPAa04FvaB6AFuOgDgCtwW0gio4Gw9+DBVdsTs+i7J96cyD0vh4FwIjwb6IhSCwHRkciSzpSWtmUGbHAU8ULZ3IUCeaCQHQDBl2Az0v71ysubug+urbvItbn+nWcWAg5LAB0/0Em4C+xGAjVgBvvB2BayOLR0XdimIwryNlzbjpmX0FzynWijQ0p1VAgCMiOFsD5l+T4wbFyABpCS4fAOtNOA7StwSgr1agmKvDFMRBEOQBmIQIAXj1+V6MAB6/AAaAcGOy2mRne4EMtIFuMNxlBNAWFNDZTj8DmQzJsP5K5CiGFcPpsRreoWIqrmt8GXPq/nXCBwOhBstmDGfFYD8GMRPIUSHxV39lcGHQ1Wt1aah4AwoCIApDrY04+LADlLDw13JqOwjHU6c0W7zf8VM4EeRLpnpF05cvX7xyhDyFmAyoHcEddzQNIqI4I1/rDZAHU9BE3MZba5fPT5wIMeND3QIuBLmRj1YDeEQg1pSwGIgdQWgAGlNVzjCnnmUewJKSrL81qCTZ0o5pcqAGE+1fPVXd0q0hA3Vt3ATaWCbiV00/+tBwdWTkwAMBSLhl6cuHinZMZlfLc64CKbzL6ADIKkCwADAbVIRyWCAQAuH8su4uTMBoM369Txvq7Q44h/NzMSs07cvNbB4N6HgBrAV49ZjXgwesz2cD/R51AmizmutY0hQq4TfxRYQkTgpXV5yZwmKmLMGsa/Adpgo8V9SjhaAk+miGJa6Ciz7S6CjRmHRiTSFfCi4m4roXOQqA1Ro/CkRNhQALAuWUCciQZPnNARr76r9aD+Dd2H3TN1RVbhau212WY7VGRc0dFLcAxXX4dD05bnHMBLCdiRKKy6JtysXt6voODB1ahFsDZhWzOLuVboSWYNwRhV+CchoArhuFz/X1ogMI+JLzLIWUku8Mqm+AA6jvWFx8S9Frga7Rq3VijnKklmKoLa5PFhlA7NfPpAqxWGzn5+E/LESwAuABaDsyDptcmd5WqR/nD4JBH8E5CwFVjZruWv3rWGpqDahSALsD27Et0Aa5ODWX8roxX5zBEAwDqHApDJtVmDMKp+6GTgRUEdrK+ggsAAHhfDk4uZHuJ6cA7HVmWX5CTDhzIoRlxVLysGlRz3ZhtWyLNd68MNHvTGPqFtt42QLGe3+Qt7I7asTeDKNuvefux0JNDgR4Tezi0wyuI+aqMA5CtHCkHsJMzywRkQ1DjD6x1mL4bsOipKs+dCo+/oH8imrjm5BnGL/jyHXx0mZYHQBdgKd37x/r71REzEDUPAHunJKDtm9VPpLOtkp8PFYHdmrTaNjl0+V4eLpEHcCHb80t1AQ52SP9dhI5AYTqw3SjxFwMgdF13vOby4uWVuBwaDjqwjuaPpwjDwv9QfZIrvNTjM/YXZZJIAc6JQGs5+fiX5egmAADUKlwAvCwcNKS3hoB/EMkSrY0kii/RowDmBrA1mOUB7LZy8fxAdmdfNA7gxLoQ5ZbTqRuP7QYJsn6AMLqUamvghOg60CF4p0z/VolAhgE/e/SuPHjyBTmEBbAmCegsvuNebhMO7Qwv0vIYQuy/QME0Q8AE2RoLaAOOVCRkoKqgYYDj5rwlxOC+qnNVe+Un4/AOthhPqYfm26bDohKCPICVrK9YDqw1+SABLQGIqOwWhVYE5Ow4y0/AT2ERIUkq+cxJYEsT2u994+hANugH8NaBdF4NCBvdwoDsCJRdvGTaR2J3ShiC0sFfoavWZ+eyPUMUwMOAsSUYFBBDl7SVko7ha26E2KeU8NgS6yhAAQJDUYCpZ276S8Hkb980JbUSBFRwLG8bjLOGBLeytDAgJgMhD+Dg8IUcaS0ALAAreDFOiG5AJoj0XTgH0KjkcuXGfHVbgw4GYTIQ1oREoO7si+oCoBqQbofjvOubzHrHQ1P6jHEXwQEYQYdKOpsOjEgAhBwcwGeP35P7T96Xw5NzugA6GQimP5uBpqQgM/ndx6afHdcXUnLdFHe6zguEDAC0LbolpGitpbUDd23mKp3OEktalTfRTWaUAWZ/zpkNsOeMus5RRC3AgRbsXJxsNAzHWDx7/aGbj/KW3urM2/Tp5XAv5kSg4YeHKC3HapCSRRTj6IjVgK/fOZDdO8csBoKNznicPvtWQchFsWcQl1alK5pmlSCtMIQBYQGsrSXYwQ7xm4WAA0htwRESzMSSgkGLOL+u5i9O3ogLkQaD9FEn6q9xOJiyAMpv+3VzBiDbR7FLT4e2X/qy0RFoIxfPf1Wk+1Bu3D2SxeYip6a6NewAYLFs15RZEN2EtLZOasExIz9HAahFvTPwJVqCaSIQogAAgMZ0YMu68yAUn7FNF6cnVsOHOfrYM5B8dAFgAezkxSMAwHtyeHIhm6uNrLVVOZn53JufnXaVMEuIQA/Sw6OEKAiUgZS17OYSfaqQPb/un/XUs4w8Wr1eDUf95Nnr9PA5iUd/jrFg/tmovaIrhsk9C7gAR3J2spbNxU6Whxz+qTwGGoFYHwFOLjLewSoN2V0JbhJDk64zs1Zs6W2WIh8dMRPw5duHIkgEso5ACgDak8RKg11p2Ft0KzKFnEuJKsKDBdmM7sfWEmxzcSHfePxADrwfgA0GQTWgGjxB+xda2TTYdbX+kNnfsiwmXAD3rKLnPQwGY6ZGzznXQ4WAj83pUy3Gzr/sC4B04I3szn8ily+/K8dPjmFXMdTXN5oK2XNfuLAGVPB97RYG9H6AmhOAfgAcGnL5KQDgywkAvBceD4X70ZXIpwPvfj5XSpvH/GAFOkut1TAgAQAWwNWmSy7A0gBA8wA0d0DrJG2sF4gPq2K0qEIJO+7LEgBIOjJOCCBx+wVJUIoReCZEIsywYkKLJQHpnzZH0InAtIUGAD4C3MhZFc5kgQV+ZsVU4NNPzlkQtWLUAn/S/2aDD+9krBmMKcTbyQYzFK6QkWjkgPvfg8LC3IZDBYAzAoB2BNrZeHBaABrRACno1/Eck/qYJ7IpIFsADYd/vBICwJn2BPy5x/dtNiCrAcF1akcgswD8dOxL6uWTPKZ6Ju34/mzA/JXaFCqPWcLcZFPnNK3yYcrrUHjdL/e2D3lICAhAzQXw+YDduZx8/H/L8X1YbdY12Eit6CrxLhVXm2roa2smAgCb7e12W1lqQxCQgEvZnX5R7jy8Y1EAdrYsyB4vk3fqKSwmklL59ZTVgNoSDJOBEgm4k5cP35N7T96XFUJIaAmmHIAbFriqhdaUvDRfB8JjvQHIpTifbKSga2prDqpFyHC3bBIwIFjXm3qnmy+tFpXH9Z1g9NRfNgRxAU1AG4qKfMOY2NPJwS1aMRfPORNAhV6JOCKPORTsveCNUw1L0BkJPRN1ZSFjps+6hANvVaZHNw4NAFbSvYe+cnABUAegMUD628qkus/RFpqo3PTv6i31LT48F10AAAA7AmkYUDMB4QIoJZu7AuvtymjVFBhE48q+PmR8TiJAmQpsH3dOdeyqcRFZsfrYr9ocziBQlFloMYs1fnJzdsFMQA3yahfgrVy++r5sr34oxw9vyQ5WgI6RzptPLRdeRtIOIXXUwkQ85wQADYAYEYi/axRAB4MsZHf6Jbn78Fh2ygHAgwsZiG4JpI47tfXv/IB1zrWAFcOA1JzaEKQTucJcAIT71lt58ehduff0i3L46kwnBaEcmKE5Ds/Ef1pSHB43CyKua3X8KVuKVoAfKH4XrpatwWLrJPKsx6BuCaIM9FcZQjQA0LQNZPD5uYrWkC0KiUum0VVOdAlbuXl8Q06fX+qAZ2QBavFNIgC9magHDeDe8NrgatAyHclS9PmDAlHZGRh8YcCjYcBXp/LqbSMBlxgOumLnTmtIwn4EDnzlqddzXuQCjMsUlo1MQE0FvjiXr6sLgHJg8icpD8AyM/kmTE04uDVIwMqANTA0u9rd4RYvkZbbgw2qzM8jCtC2Glwb1ygZLAJNOtERvRzVrSuyVGCEAjEfYIuMwHM5efaB3Li9lqNbB9KhoiTYmSQCyzJNvQvdVYs155miOPCaCUiJTPMBOB6MFsBWAeCOdJcIA6qtyMfUk2tNMaLVobf3PHvbbD3DOUSF8l+3VDQRSDuRwzJASetGXjx6RwEAeQDry41mAno/QICADlR198fYeBBzTiAlwiipZNeuTElmfwBzTPT1aH1xiueRiXHtboJm5BSxEjaIA4oXIJlnBatE0zk5nJRLoCtxeOdANhdbOX+xluURMwBLAEBYzngFMyRVICFIVxvZmBlUO6LjLifWy6nSm9cn2hGoew95AJ2sjqj9dUKwFgMxHOohPq7bTrUJf30v32I/Z7kTUeAAtB+AuwBsCeYuADaIasXeaGhy27crJhU5j+bnAQBEvCBfg9SWyUNiGFta303I7H4nM5p6kIcaJBF8UpVWQLdZADogBNz0lSzWL+Xk0+/K8YMjOUBdwNVFMvjpLhqCF5FBHiqXXXxCCWvrB6ANLa0paIdEIPW5UQ0o0p19Re48vKsWAPLhyTzn+K+n0sanTtCWBN/DWjTxMObLP4M4NkKA6AikKcGbjXz24B25/xTFQGdyBQDQZgG8g6bZRk/GhNmB0JtnsnyXesWj4tr1GMTn6iC1/ubZM6GDH6xfYQlwcrNhBSjTb52PfVR5CHkykccnGOVr0FzZysEdDiU5+emZrA6OqHkBEtC6av5nC0XXbKFAfB1dkVATwRThmAiVDzsPvZ/FMoSG3x1qV2AMB4ULAA5gYZmATAXWeYTWLMUBINoARQh7VMDMAV0stB8AyoGRCuyzAY8W3hEIb4gczoG6YXypnhU4T9T3+RSFue8E2ympLYC2obDPDf2z+cZR6F1g+FuE/aww3TsD6eagMcdam4NoZSCKgFAotHkup8//nNw8XsrR7ZvsG4DAsPvnoVosHYrIJYWTAgFm330DAc0EpH98+QnCgF+R48e0AEiKhZu4dRHT/UKeQdot1YjWn1pLbs2c7jjAEtoW1YBaiQwX4AEsAGQCnjPZZc18ftW+Ltb4u8+yd6Mksyo2UJPkn5ru6lr5VF3PnDKW38J+OphNl5q9arcWFCR0ig3Xr++Pphq1jh0twrf58vjgCm3Aj3SPVfhx2K0VN1P/NSnfUnxVBAhAlniEKkiAYHrwYDj6/g75yi60GgZEOfArRAEONBEIy0Y1oJKPFgbUVGQ7pH171fz9yiyPchLTlPFzkIDb0zOtBkwdgVJTUBgftDwR+vQjNAwAfHAWdV3H1bfv26bls2yxlAgAn5/wZ8AoN8pQMlkNLMXlBlqIR40AkH0AAByAPC0Y1YKL7Su5ePF9kcWphpUOYFKq+Z/pW39kjxgkrzExxmZtQPgVBJgDgHHcsIjRFnx78p4cP7or3eU5jZIU+KJpyfMPDebN9OyZCyDwpickmJAwo4y79rdD40tmvOH2SPz59N5TuffkXc0DQJMLEIUsl8jujbs6kB/zcMxPN19VY+k+aooRg2QJpMk+Jqq2Hz623MXf3RR1jywxiIk59tjJu7OEHVsiZRjDN1eyPFzK5emVXHx6QfCA372yJqA4+Ehi8g5Auj1en8/9gfAnzCXs9LRQj5irPoH3BBIQk4FevX0o2/duq6ZdIREIQq/rgSXgbcG5o7yvWVD+rObSZPUWMiRjMtJiYbUArAYkAGBe4FKOlARk2jLOFMuBc1fgITXrMlTLZytvgADdciJqG8DAvAaAhK4jSn+f+GRatJmR8VXyAXA8mdmFJCB6AdggAADCcmgQakCgVsFGlh3Mq2eyPn8mgvbheqA8RdfOivsyuhkmLZ5kopEGfAAAYPWn8Fs3TAxZP1/JcvdFOX56X7rzMzt7Jm6J+bU4O2dnmTY0LsKKcjge19lDmuVslEmSC76/Cj9IwG0nn9y6L8cPnsjR6aU2uUQIgFjpzTWpflUQ9fksscgPqYOPJ/uY/+rxAO69Cy3N+nTYfeqP8ylW8ae3L6wf9+9N42vdgY4BTk1CNxcbuXx9JZuLTg5V8OF6cRIP+/+BSATXYN14ddYASUH8idJouD+ZmEu2RdrnHNJ1qyRbaQnIlAMACXgmr96GC3DMNuaWCKT5FHAvrLMRaZFwXz58M8szigcVhLsiizAY5EK+jnJgBQDrB2BhQOwpZgO6GmGyWVvDDwHAiIg2ftW++igJGBMKekUEA0zlIIpVzRPytXHI2YBSCfmd9Z/HeHAVfLgJ0AZoFLKWnQ8OhTXQIVvuVHbrc+m2lywm8q5wyWTyuLiVv9pUFmsFbNOBmNDCcdYr2X4ssnh5LDfv3JLtKTmAFHQwcsr9Dk8ESjJiGtiOZU4+cB8eST1IarRJwdqGAH9HHsCTt+X+22/LwcszrQ1AGFAjFZZAREWIF+m1CDlDkSYizQlnysmLulnu0Ou/57+Jk05O+s+cibM+AcHcT9aWNRhNmhIghTFnqF3YLGRxYEKeZn66ic8hJh4qZR8QK8dFd18T/hjVSWclUai2zmRJBtcjnEvnANQFeIcdgeBiIAzonYB1iKpZAGlKXog16A4OnXXfpgINwAEwD4AcAKMAyAJUElCNDbpliQRMpv3+9N8UEToFEpMAMHSBqVhl/b1WtqBbACq41imV3W15NN0K0MoPLRCyBCFtHOohRMaHqeWYyMPvlwU7DBWaNtMBGHSucUl9HwAAzAZcLuXqowvpfryW45sHsjs905g5E1MsVGYWudveBccR/HKswxqQkwS026vvj45AOp0MXRBw8Hfy4t135NGXviAHz19rp5sOIKCGh6G3ugJk310xM+PPzbtMtrqqjLrTP5uN15BU5fk1xvZrqrRxGDX5qKtRU5aWFQlES6eFaa8a1b0ksOxW769Zf0xG8rx/tUmUF1zKpfZAsHkD4QAVUTgL4ybrwEHAoDaeS+0JCAvAagEWSgIiDMj8Ax0OqlEAA/iwj1xX1Y6tOtRKKidOxLLbEQa00WBwAb4eowCWCYhcALxYnQ7s3M4Mhdoy+d8kVVhlskcCBlTlITOPcMYCx7S/CmVNpPiGq59pVoBxArwWtDyEHr40CUEKPsKArNxTywAhRE031eJ6Kg93AWzUVR4xZbH51BTEyluxBisyufrNM5GPNnLn+KYCAGvVTYMm5WvMfuTcvammSgXz3PkfPot0W1aoGfbIFppCmxMDANby7Onb8ujLX5Cjl4gCrJUEZLEmAMvTe7fLRaYAACAASURBVLPpnRJx1HxEezOu0fv+sQMxD7m1zmAXZn8WXZmt0cKVtGTMhvC4u70n791Iss6y55JriW/RzFfB0Eo7S7LBCkLMX+9gI/lc+yPTDxORVSATIccXWQNQqXC9vNXeTwEcBIDUEkwTgcJ0YLdEvCloxtEpxWkA3JcN/MQBYG2JQMwDyNWAnl+R4zWmXAbu2opE1GCwr0J22U61APW9I7K01jX3hkNERXlNvOStagWWr1rHXiVLoENh/kPgEaZTvUlewCIGJLrYVchZ6ZRGqofJEn7sBRsAEySsOBF5CLvNRsVh/ePXsvvoUu7cuSO7s1OGq4z0c5c+rz+rfNeMrKjjaG6Nd+v9Ifwg/nR8ploGoB/QFFT/vNrIx2+9LY+/8r4cvTqXq4uNdJh1x82w8BzZfZ+k5Il3RkN6ZI/7p+t1ltlM/FQSTQlLiXvOMeCHNqnIa6xpOVl6s/nETAwy3bXwFGWDOoClWUsp3KeWk/MVbO/N8CHHZa+3O6vwc5jNpnDhuRoS9OTUeIterF67Ah/K5pW1BX/vpuY9oB+AtyPTc+7zCQoLIL/heNbTevDZNI01pzx7JiASgVAMpD0BdTAIW4KpC4BQJ0qETSHaqzJnzfaxkeA0hEpzZdG/H2UyWQBj5sV1bjAFIL4YTxah6HowCYrchk6q8Ji5D35AMErMpNbcAKg+NelN1vmHigG1r4fRzKRjiqsRYDqfhJYDEm/wm6sfvZTuoyvtCbg7O1NTURHAX3iGGQOXTI8nws1IAWfPdUVINESISFNdc1dgnRK83snHT58oANx4dS5rRAG0YSlNfJ+lqiFAS7RxI0cLhTz7Tmu8LXDgSKCXcGosx4SpBfLvkrvi/fXda0oWFWsDlPIq3FUW9eizaxKB9SW0FFsMxKDVwFfks/+QVqC9EWH2e6iyIsL0mo5UUbvb3xVIQgjTIx5qhWgU4EgtAM0E1MlA7ArsLoDCM7NzzILKaZaqeRVH3RIx4KryAcjK8PnUAlAO4FQ7AiEVWIuBbDKQ3krDf14V4ntCwK4J9iHXuTb9h4j5QtgbFYfNhiBj9k8kA1ufGwvN1EQi99bCLdYplz8jGFDhmDmqfjuSgiikKk2K2MwlUB3nFoC6mIQTXCVRXDZKC40r3LTU5DoNt23oAqAy74cvpPvphdx9eFe25wCAPCrLY7HQzKrTXDiS1xFGSnmBjJvdKphsDoqDj1g3agEQ7kfSy08fP5InsABeX2jvPPgHKBTyg5GYbwvPpb0zdZ6Gcxi5p73uTIiBcRhEwaQdThtWwdI9M17BgtK6w/Zc2lHInoMcgv0i/cxcEstxV5dCE2vcQmCln2ZPhr432Ic1SqK1CUtGk5jU49ubzpmpShdMLi2Ogiv/TgBAJiCKgQ5E3sWEWYQprRmIJXgxOcmEL9O2+bYJAIZCbB7s4VkGAGzNAlAS0AeDIAzofVC1GIjfo8FUlgO3ZKVUmqUdFDmRwmIZsGrStVodgaJgtxY2BhCU2XFnqrQoopGXi4JciztRSKGnzc7kFgq9Ww3U+T63zoeNmh1gHVjTqlwzqnEBgdjCDiUAdCIXP/pU5CcXcvfRXdldnFE7mJBVNFu5FcEfNhIikWHeEBTPo91udvD/YQXApmE58E8ePpQnP/O+3DAAQF5CTgSyrEKq7IQ79s9UnENZ0jrXFP9XufYwn1lHaUSZzWa2L/B51Cw298j9GmOuzcM3v9y1ugs7hJnxfe8KpJyAqkhLuzVrBSQoIh2xA5GbwnRdzJkLglm/AtfOhZvgloHxLTkT8FA6uADoBnaAvATLO8D1na/wew7wVbUroLcygpZuD/+p7Ss1EzA3BIG5f7hbIP+IuQA+FXgCAKZkba51Ppgz8PnWAnC5Y+FD1/r5cyXOu3Dz3HkxjeXr60fpgSYwsFHLqsxUMEK+fE6BMSLO8uDZT4tYDzcChTkQfh8N9hsvZPfRidx7dF86BQCrtzeCjF+lNuVaYoqWm5D5557F5fVO4AGUCwD5h0xAWALrTj56eF8ef/U9uXW6ZkMQ7VFoIOXGhlMOyuBS+yYu1U8hpdgiIm7yR7/aC2jydwn0Bt6WoUaLIhcY+ZARVuvZ/jmXYBEBXEfhMuRf0/JgPQL+Qxk0u/pkSywf5CzOvuJ0eHvmQeGHFGfPz5cCwKtTObVEIPXkEAWwnoBKzhZtwUvmv7ZoY4IQC7EcM/l3fJ5twc+0J+DPPbVqQKQI63RgSwbSpqDRAvB3NhJ2nEKDxu9rWezJ55QF4NecQpoprT+29vjyeR0kyHB4qOfd4OequNUVsOlC3gtfa8mTZFhWITc0hXKMDw/UgBXCs+sOagFgAeD3Vz9+LrufvJZ7T+4rCZgaa1CszBKPDnL2E+msu08cnjoIq3YDAgeAECDqAUACqgVwTx5/+V25fbqWK5QCI6ZuLgC7cJFAUzHSfXJhMUH2ghKz0rMdVpr03tsvak4PtWWCD34+w3z6zJqo5dH7fL38Ewcaa7ZSgJFxEjCN9bm4R9F/0jMQSL78ZMHmSglQIfIZXLB0CRMsWHcHt5AKfCYnbyET8KYCJnoCWlWOJn4hYhHvV+cguNIqXA99x8YRWKSFHhUBAKFH9AT0yUAHsrTRYDobSvGRYMn9dYZmjoyXwbRq5sWE9V1fXzmAls8w5euPLXTQ3OiFEm3bWzZcahbKg06gdS1ihz/a9LTRgwdH2zNpEc/nx8Z7TzurCNSKOwDAFVqRL+T8wxfS/eSl3Ht0T8OAadkpBu+BtJJQM11gW8Pe+xoPMINFSTYIsLoBAAANdJIH2Gzlowf35fFX3pVbp1dyie43AAAlOi1ZxtwcVzteaehTcxUkvTe+ZyMyqT/1n3HSj9rKeBZlzFwmmamorpUlF/F4xkKLIJTaEIQ+NMHWIiDmdSgHY6m+ADntcRiJk/SGuG16diqhzmfNfxGsmfD5yInoJ9EQ5CYsgHM5wXhwAAC4CmsLrt2BtCNQnnG4TyFcUo72DMqvGAmIwSCYDsw8ADL+R9YSTEvLNBPQkYpzAmvCz4GnL2suME3Byfs4ypEY+XvtnoDVqlps5Rw0qx8hm1z5QPAw2sEJBTgq/3rAKWh6cqwSj3BgAqj/sEOsf2WVneYeaCswhgDhc+MQXfwmLIAXCgDdybk9hlsYPQwtf5Bo6VL7q6a0lFHYNsCSK00G4oRg+MM/eXhfHn0FFsBGLi4QBTDrxEg9bb1l+QRk71wgILQmwXp/lyEn7dxWQC5CACVt+Ekd5P348W+rzkgPkPWUQxz3wuE1JyPh2iitNaJW+xiQdMT8PtQ2TFqSZl8VgpiIeT6vs/4OGHxkt0Vy3hQudXiT/QBOMRrsvVucApxSgZnMlBKB7Ilrx6Jm2G0VZmE6eef9Chjz90xApAIfIhNwwXJg7QloSgEAoG/ULIEWgf4mijjvT99KcKU20hNwjviWnxl6gKkrDeGYm6V86QSBdOaDdtfr21tzheACYrkwFApzL3A/DSUiaUhrAcgDdGuOazr/6BPZfvhC7gMATs+N9xpYpVshfXe00GQmMepNwOzncFCtbNA4OBJhPrp/V558BRzARi4uYSrTJXGDxZOBIuWgwhd89QSEpol9ERpzTz/L4MqD4KXOBAzaUSasecPD6G1ABFubEQicfyFA8VBTuNDNB81N8iuKG9Xf03iG6gPsF+EVhqwA+525jGgKquXAGga8pfvPMKBO6GCPSR0OWtAWKeDCB7RdzaZgDj1G18WAiBzAqRYDff3Jw9QTMA0GIZWV3NvyaSynwFyEKdnJtlh5AMfDfzy06oKQA7AU1+m7TX5iKB45+cXqA72DoKhp5nB6/S59ZvqHF6TP5A6BnjNqTLpIViEH7a+4YoU36FazWMjZh89k++Gncv8ROIBzXsmm7fhFkyYzvy/1I7C3qfdOHFHOZlOa0sKCAIA1eiGjN8B2Jx/eO9Y8gJunax17hY5Amvdkh0yfEg00lYAMKcHGb7i7gLW5Ra9dgAanGqdgq8W6LVjgQm8EINu1W8GLWQgk+jgHIP6XE7HwTJ2SmZW8UlcP1tbnC+rfCkHIVpjnV+j97Mdm/CR/Wgm5owNZoxrQpgN3q512BNLcjgAAzBzP7kvKJwgYVUbE+IvgraQBn7AA1mdnOh0YiUBLtQBAAnI2IAeDUNlQbOkCRMCbLy+RT6nexegeG4x2qQLCl7IfIdFaaGEJGIJGYqWlLKceuKEraIKmfgLuyAZuKdmR+BwOotXkW1aNmv946ai606lkW/XLzj78RDYffiz3Hz2Q7uQiKxvDGUdPO58pwsB/e9aRyxQ1tB9mXEyr/0IdwBqcwGYrH96/K4++/L7cBgdwudMSYZaOZ1OfVDOfUUd8JT6e/reTayT6CHT0L7nDagKn71Ooc5w/UfoUBheswKyoI6XXwxOEWgA30y1sB5YfJj/3ylAx6NUsPvnN+95FQaZI8r8MDYmLNzDhb0v3glEQWgAAAPQDuK0NYTgZiPE4FUGEBO0eeamZ7u0zD21Bw7qhTpEKDA4ghgEBCt4RiPH/nBWhTpgprxIYW6e+h6dTotP4fb6ukYD5BbVezNgdak0dP+u3iY/R+lnxnRZquQZPeJlfVxhcZb3b/HeetM87ksENITNVaZZlCGIKWXrbjRq2Zz/+RK4+/FgeIgyoLoAhvS2eWs8IwFg+GgzTRGbZwczJbLQAchQATUHQ9XYrP753L3EAKAZCLQBMaDVTPc3MSL6ci59n/OUMRyzQehCYLaDpw6mrUBaqrX6MZcn6TMr9WaTF3IviTFjSjpKJSfVSm8EyQXwfQ06ANBRk3/dKQEN3pQJQzYdLrLi9e19D1NGlKBQirL/C3t1AQxB1AcgBeDWgDwdlpafXLBQmYwaF/qUHRUKjAAoA7AjkqcDgANwF0Mag1WxAR8pMK5ew04eCa8h9CXPUI2UeQLm9U8inuDvRJqle5hQADO9sjq/nw2DI78JY6IlMCnGdfmV3BUxjqhugnTllt92qTj398TNZ//hjefjwvnRwAWxqrV9hKGQTz0kGAAdXU9zqTWQAWGsoEJ3PdvIbd+/Ko6++L7dOrpQDUF4Cufmat2AgZBV6bpZ4bJ1a3hORLaxl0QZWMrJtmgslSX0WDum6cZ+g8rNpS1eDUQAzU1O0xQhHa7ewXYPLyJUJTpbpn25N9DRdS7octE3vVyajX69MzMkhOZ5JphkzE/BUTpAHgHLgNBiELcnUXfIORWpEGoNa9QWky5NPZ//cM0qC66sLYADwTa0FQPsvRgHU8zAr0V2AaAHwDv09eXMASAJQ8Cf9asDi18nabMrlHOHfd+HjvmE8UtTBfYsl37FFSnIbbHS2pR8vQAbaKC60aTr70cey+fEzeQAS8AwugEsJ7dkcNR5G4QIMkitC8LFpCMwBcJdgvZPfuHdXHn/1fTk+uZSLS6YBs3NxGLVth1ANApc1nEwtpPJwYSaukB/hLcW0A12ycT050KsBtWG41/baM1p0RckiPbZ6OjTmYICi+QGYcYAwqkUpygPcekd+zHFF3rPY4mD0ZyK4NMmjBRYtiAzSBAA0BFm/PpGTd46k08lAW1lgNmBKybM6AEs48Vh/AthSeyRrsPfmDTHxREdaDsx+AN948pDFQKknIPI00ZQ2m/1zAOBa+t5Ql0BZnEi73MRswCRKDSluC2pb3CP21A9CNC9bOw+HiuL1g6Ang7xmF/qfd8pD49WaTZeHguAQHyw6Of3RMwLAY7gABADKzRh5lbHbn4nyws1PXqsWAzFot+6WBACQZbAA7t3RPIDjs41cnDMEqPM7TPO6kFj+YW7e6taB+fOMHHiStKdFE9lRjBQPtxNyuUiYI8I9MSeLnU0OUYk09wKuizUt8eSs8l3n/arPSxnuze8tty23/UznNkuYx/udgkstzc3hUFINkV5UA2I0mLYEO2JDENjeh0tmA/pUYKhlq833RK54TmnNZTcwYGj+mL1nvFcWA4EEPJevP0UUgGFAkIDYOgAArsHyqdgSLNrHBNt9FWiycyc7BPP6zYYghdjMNvHbJgYBNFdYRRHVbxQoNeVSlELf2qJwqwJrHNmdaFIfVisOORYcLQa2m00CgPVvPJOHjxEFuEgEzVQM2x+HCUBcHQ2O8GJt8q12NTAAgKZHb9Mf3j2Wx199V26dbeX8nOXA3B4L9cF4ZBogX14qpAr3st/i8PsSUpYEPq8+frRlbX1wcyynIq+bR5ApwFbfb3HV7ZaDS5MVEsJhuC8r/nwXvOArkF2VpZmfymw0xqbsCg0VYiXA/r2y/QufwC0A5AGcvH0g2/dvMxp0uBRwAD6YlH0BuSf83wGxC7UCxHbfx3Au41yAs3P5hqYCi0YBfDw4XQCSs4RjFmdlxiSv4LoAUBz+xj/8unvNBYia+k0TFCJS+d+Hr1lr8vLATz2sg1ByIHA4tQLQTdCtLNB8Y72VA9nJKUjAP/9TeYhU4PMLm6JTx4KH7tp/ZUn72XnRDEDkASAHAC7BbiebTSc/untHOQAkAp2jI666ANZXQBNqPAXaSn4bS9AUnECwaYq0mQ6MmnjlmaVVu3loQp6pPa8UdKHg4hHag/Br8EUz2TwMF7S4rasA+wD0biExTJqr8DzcmbRt6+Dq+gcsTbuHz0nAPuhcAPQDeOdQdjobsJPF4VJ2B3ADyAFwNAInIcVYg5+bUtgN0z3eolYhEshsDJt1BUYUQMOAVguAwSAHtnY1OAoAcDDJHNycMx0/k/ibApimrzJpAdSXGGP9y8/yJU0h2PyF11qgNvftxVS9B8s12Ugt1Q6W6oqTjEA8clXQEKTbysVPXsj5r38kj54+JAfgTS6m95MonoTMhS82uGSrf7UAdkttB7YBAGx38sM7d+UREoHO13J5ARIQQu/+v4cDve9B1lhqzVgSimKa/oqZk+r/J02Vs9ZShySyganXoOpq1XS5XZWShRqp8GpNCq4DanYvTX8mYbcNszXlbL38OVoxmV9zlyMzB3WZbA3+ds70j5S0zDpRhOSODuTys1dy8sUb0r11izHQw5UsUjUgexekMV/1MQsmZXRjxlTSITiAkzNVHj/39KGswEWgFkCLgXImoNcC4IkUtBrAOefIzeHiemDhdQitasBksGbqvIixzrthGwCiwNcPN8+qaG/T0HVLsz3nqmv2n16KEYCFjiRcyxLm+MsL+ey735MnAICLSx71UFuvhzP00O+BZDB9i423fzDtFhwAScAr7U24JQDAAgAHgLbYSFHGdGA1VNwE9/RmlpBQWKm33eCmmmfSkDfTwO9UpDUyoOo7Hbd49BiFy9fWwiWMKEuC0U8a81i9pwT7nvci6dFYcA/F15HCf8FjilE5o1Oy4EXewKmWIL3mHt06PJTXn72Qi6/dld39QwYyDpayUgBgL8ClWQKu220p+k+9X3CZShBo5cygK7DIFVrJnV0mC0DDgAYAsBWAQ/o+LAMx3SMgy5DybJHb82QnK0k/v20LIAh+PMBzfOD8+WHdX5N+LRNrCvla12gBSv0zjtnmSdTGGFpwDxcAHACmA21ktd7Kx7/0a/Lw7rG6BIjTeSiQ5methWoxLxtT+G/9m1oMBIMDHIBWA7Ic+ft378jjr35B7pzBBUAtAJsVgbdik1MeyODeW59Bs2Y86m5jtrIP7RoX36cWd80beQrqdJqyGoFA1Z4tmoLgzx1PaXaNijce2sBjwX3jOuxisgKi+nVvPAtZAfIm/+4NxKAvvRk+IwZ1fnr6mXTffCpbSKCWAS+UBEQNAN0YTH+z6U/mFs4560V8I9A9GgU4YRTgm7AAvBZAh4FYP1RPlw6uxNCZbym3mDg0T0bb8jjJAdR+fzrMs8nB8rEKBB0119vbUbsgQ9bIkGuhGtNKih0M0AdAuwLhwF+tdWLLZ7/2Y5HPTuTB4weyOz2fHN2UhTITnlHwowCw07eTgKwJwHDQ79+5J09+5gtyfL6RcxQDGQmIa2MmX7IRLZynTH8EaxdWFSibYUi6UC0O7fGhn2efJOKYuRJaEsGCHfYtsLh6ME3rN8K995/WLlk+cOlvMdrjnodxEPyMAycjDf0rZhOCxJlFEQtNbdYPcgDQD/Dliby6t5DuKw/YQPaGjQNH92JtBGJVoyxZtD1ONjDFM5kEfbczQpZTd5oI1ACAQ9tuzQS0WgBcUf8vErPVRo9p/OsozwIw3AUYM81boji1YDdJpjR5Oj4jG1Do1wHrZO4aCQC0Avgn5GGjLoCOGUPuOkzyyyv59Jd/XZ6+/URkfSkrDOqo/NWWQLReiB4SP0TWlgyBB+YB4JacSvS9u3fkyde+JHfP1nKOMCDrn2ippFAfuQCsXTsMB/+ZnoJnAAadqDUQ1rxTv4FMBB1QpRnS2pxEm4+YD+2hSy8MSkRf3xx2DElhzpyan+SpIAMjXujGZGKTv4rTj41lKCuEe9YEDZMAsVj3spNbhyt5/umn0n3jiaxvQuBRCmw9ADUV2BqYxunAnjHqDlUvcalx0qpioSO0lj85lc3ZuXzzrUdlT0AtQeb7ZEOQuOf9a+8jl1NWS9OSGOsIVGvruWjT+l7LTKm1+RhY1Jp+yI0Ysgii5YLwHzaLtekozAAHYBWBSghutGf76x89k8vffCZPvvS2bF+dqCnnmqoFSjQ98wnXf9epwlZXpMy/rNgMBLzDdivfO74jT3/2y3L3fM1y4O0ym+HG9Klfr5rcU4C9ppy9BVyre+Wf5jlo0Q49cv1/OhIBvr2NBXfTwq2BxIXzoIaWfQOvqNwV5yVcu3ECETV2kZ9ZtODKHYNqq6JnjUQfKCTUkK8jMN6+fSQnHz+XS8T/37+no93Q+w/hPxKAzAPQegD1fNyGbz9i7/zFMKYRhd6M1QEAXYG/ZS5ArgWA4NO1itOBkyXW0P7Rv99HZuoz2nIbioYgLbN5SNDmCuuU/zKFWlSeNLTqB4hWRosEaW2Wak4IvOcRwsdGu3GY/6ic00mdWp6nIPDpn/nzsjq/lAfvPpbdyal28GQzUNNO0XQtCK3Mkhepw0uN7rENmKUBIxEIbbK+d+c2LYDzrVycb1QrY6KwrktLiLPJ60SflxzqhFuW/lhNhHVNt6mGak0oqWgtxi1XwS0Iby9mcUICXWDAXb+6lcCIYs7z9y0preXcREQjER7C84RD27vyLGWOhX+LRFswL+x3LjiaBg1kW3Zy++ZNOX/+mZzc2Mnqa49lg0IPbQKC9F8r/jGfHy269Bo+N9Weue8x26IrL6AM3PFfcAEuYQGcX8q3nz5UYhldgZEKjDHobgGoK+BtwdzVGjjrfv7HZKG/j6x9YYpGWYuRrhMbgkyZG3OENQrsGEi0LII5oDJvjW3Cw9eWrqGCxVHNbAyC1mAwvS05aLdVtvb5n/mhdCdn8vjtx/q53RUYQ296kTV+sjKya20/8sIhOn8OADoZGB2BkBew2cr3kQr8tS8QADAXAAOQAA607VVzb31IqatlM/mt7o/8po0DV4HXrkc4tTq9LmnhDF8WXnS5ixS4G9sh6YbsqZcjZ7e5aeanp+dfMpFo/w6aMzjgya1J/nVunGOAoOJAN86LI1Ftd7DCUGI5ef5SLm8LhX+5NcKP2h+Mv84CBBmo0udlwcitMIJUexjaigtKx5+S56u0dFO6haDj2OUJOwJ96ynLgTUPwBqCHNhzp44KxJ9oU3C/RtzdliyOWb8tRa539J6AQ8I9ZhUMCewcjV1r9Ln3j9euN6ikEQaYePf9NSvOZm9DNLQ7MBuEqBXAIn0Nz2Gw4+sffCRnv/lMbt+6Jbfv3NYwkjPIrCW3XDSHdDr+RrK7JmRRD8xvbUFgPQE3u62CwveOb8ujr7wjdy63zAPQCWjQ2qQQ/E93LdS0tunmzPeHtZCFLcG/bnZiCHnUkr9iP6easBJrX/cYJCcbKlzPuA6fnxAe212QzOyF9XidTVKyXszkcm5WgI+P8zZrZhWqu3O1k8uzczm5PJXd01uyfP++TorCe0KTZGX+MZRUq3HYBkw5HR1OEiwVSp49kydDZULUJDOkPgTXwcAIUYBL7Ql4YRYAAQAkoM4g8TBgcLlanFnL9E/qZiZnlpRSw7LQPIShpqBztX08IkPmfl9Q+2zqFJiMHUU/0Mk1bGxOXAN91GC+UsWqhAGttUuwSijHjm3XG53qsj25kJPf/FjWL080sUOn3FpGmSpG7czjDTrd36UwqTmtgkxbE39y3InIVmcPLuSHx7dYDXi+k/OzjWwvN5p5h2acdAMs8c7nhXoBkDPm1vhD98HONJE/E3ypZs4Shzy9KMYXlWT0jkt60zQPrWDmndzMnHmuO2D1nPcoyMNV1dVY5v33RipuIqT3YoKYQo+mkZPlYl2RtcPwdiOXspHN3UORp3dkefuQzhC6o686vicTfA8DQvg1+UbN/5yq7GRtXfGZHZMcIaFFU4GVwNtwEvBCvv0WBoMgFRgWAGkHzQisOgJhLVNaf1/hLy2UZE8VojQ4Gixq6Cnhawn4kPkyB1imzPx6I5z84Z9tcMnXzOYbrqMNQZUhN7Zd0/SQ6sr4v0YG0Ml2zbZWMOPQPHR7eqmTX0Dm8RDnVByCgRm1Rt4Zc2fsPf15BYDFUjYHB7JdLuSHh0u5985bcnC+k5OzK9muGSL09N6cGR/8YhNkZvDFkAD5ZYsZ5J6JCRws/l1sV9bKBDM+lRNksQ12yg+wxqF6XnSHLHfAxj37nEIy9Z4uW5KLibC0+D3WrU1LHBX8GZ3jtJRmBRi087qxErl1qH6+Aghab+v4L8T8AQQs/QXxB1BgEZCFGW2QKZ/Hn99u7VOWSF7QKsgqlX8zyylxEQoA5ABgAfz800daDXi4WGmvCaUgjF/xs+pkqWFeCK2WkrdPss9sMPk8moLWSDNHyKdAxR9g+lom0IEsajEAyQeyXXYyS1+5xdtUgFSzIBIA4QcJh7+zeagW5wAcLIsLPFK0Jqik2IfHSTNm3FKXugAAIABJREFU8Vl/fys33+qMQJHtEvUAqEPS9qTyvV0nt+7flcNNJyfQ/nAR1EsxK8KiDG7NQ7g4sNNHVmVSyfP+VYQt3GQNu3M+gRFzqt/zyeZOBjIsfMEOfZYVh75KPHLKgm1E9J5dsFONfTIhQs+DUuVS1qwvQ0resUw6BXGsWhN7lrIEEWAaf4FoHwp/8FkN/VFoFRxwD/s33Z8cTUzkXjhM/XPlbzmfZlgUYPwvTk6UA/i2A8BypZqf/QBoAdBb5Flhl6WQoDlHQPb+DDc1V0/2GoLsfUW7YPaZWpxBfdWWgA7ducVelqCwz9UyG8pWiDZ114gzIrw65zS5wZgjIgChR0dbVdssItJ1qeNtqbiwJPE9Z1xNRnR15lvbCFN95XDVmQ2IaECnvel/dbOTG/fvytF2IadXBAD2A3C3NJ+QmAFQC2GxI6kXYjxdIaHGeDA1VFzDeTwrvZT+QXd9WRgQoTAoX8v0ZorlI5/CXIq6ZkJJKSP27AIeS1GPwtajfruX5+JSNmzDhVnnJ2qYH34/ST79mYf9fNCL9jgxsAsWcuJX488sdh8bsjpx6a6A2UsGAGfSXVzIt54wCuD9ANByjl2B2UXJrYpWRIsGxnx3eVp6Q5u3lOsx194eufqg72/fKY6Ps8wJboNZVd1jnDuofJqyVW7voq01JkLRhnXShsaYbZufB+EDEWj/1i7CtN1pGntPQTcfVVDdyw4hOwg4zFWYncg/sPlFuJ2OyDIA+H8ur+To3j250S3kdM3JQTF1mYeF/ioPTNywLPb6e8/pt5TYxI8kVyEX0KYcmvSXLN58XT4IxGsg3OrKocJkh4WuQ6VVYNrHTGZaS/lZyiexRpdET+uG5Ihg+fNutWgcn061alEdTYjmmxR45WZt+KfG/L2mw+YX9t9XTJMOq6ozXyu943KKlaP0FyTg7vxc8wA4Hnyp3aYUj4y/0CIkA133JFzoxxh9X1V8/S2YqAnzGEbn3xWIRmIN05DS+0ThDjS/b9ZC8uOucRPXBLQ/TCymr1NaJ1YSoAfctLhT6sy1o9bXQX5g4i1SEJqIcAMT22Z2NMd/O7LrCu3wcFgpB29skK9vZcE6JHOxlF+5uJAbd+/I0fJAzjUPHyBQpeU6m6t38HkAvFvmQGxd5lM7I+gCqZWAVc5C6i6SyYvcXTf5vh4l4A+SoeCxZvtcOpiFz87WYqQMDAzSPuV/J9AwS4of4fvBEA8y95VLZMKvpb5K6qHCz+z51IaXwOAAkIaXVnUKLtdRvv15kltX4oK1QLd5CgvRUeAXp6cMA1pbcFgAikPKI9ECAGAlV2APTR/XM3Tq2wBSW8ufEwBE/zpuUtzMKBBtvVU+yjgCev1Z+Z3az4yoGNGwuL9HBEwbqcbVTEEI/JKhQdf0ZvLrNGI3y9V2ttbbakaXY8oTWusLRrcdZObZeHCdDYDcIgDASr57fqYAcGN1KGeIQCh3kGvqCFU2ICU4jNxnRheSyWzDfnIXP6XWKEo2IyBBn48W1wt5KjGKkGjNsHOw9RT0IUJBZRWZgnoAnAVl3wJqG04B5psLvQUrEi2RcclszC4Wv2echqlOLwZSja/gYBEQjbdZpx/dequmpIpN5c/ckewSefQkndci/ycMJYlmbcpw5FrBAZyfnsnu4kJ+/jFbgh0uV3KIPKVUDmxNQLwmwA7rMJEdLbxhqzmdt2atDh8mvq/FrvPBUlmtFh+YVqzE6KLCjEfL/9cvcV1vJos7rxD936Fr97BupHhJQ36uvVSeLfDuVB6ahsK01eR5XNmE3rrzcF6fEX/GnMdeNk52MYefL4BNQSAWW1mD6V+u5IOTUzm6eyy3DggAGqaC+5FejQWnbECKgpAfaHdDomr2sKQLpT2PrjTJgJ3wSvU57Ohw0KIBRzA8a1Wk13Bhp7amnFBwSDZSl3MPs8lQhA31IwQP/I93LM71/u5O2QIs90JJQn0wtt7yzsmp1t+Wh5CrrsCsvyQ0Jv2DfrcThZ434L38ncizmQloAIooADiAbz9BFKDT0GAmAemilRyAb8aQlOScw/pszxNR2yt73Q4hwQXIAntdQa10eAEAc685h0RsPXBtss29n2sctq9yGLbGFzYON9XLuzmuGOAbanDkqKltxoItbOYqkRf9ACkQ6PQDAhApwVeowluu5Dunr+XozrHcPDqSc0QfHOwMcyi3BoK1b5zk0nW21v5VzLJLfWkrRWWW99ZAwvkOB8NcehDarPsVYrqp5RKkbXLLg9vjA06blq+mKVtubkJ4voXUd8eE3huKaizfCE1yFs4VOAiZ/W1L1VfkFptaIbNPTFPePB8AazxciFyBA3ASEOTuilmKdVdgXIzeyvD9a93fU2755Ka19S3oANym7vQ6u44zX+v/anCvzeZpdvJ6gDKH/Bhaa9LijQ0ZRsm8nUr2mf/vfrOHBtNBSyaufTay50kLp/SabFb5zD1P4vG2YDojEFGAlXzw+iUB4MaRnCEdGf/PBJCa3ggxyzhTTeb0fQo80lT3zD9TokWRkl00565mft2J7YJXYfFwzpbzW3HiEE+Kr68YX2ZgZ4XHFMpIkuZHCvc1w0DZPOYUeLcjt/80t8AxxyIC+n6sqxer7CzTzy1TBRW3KrhiH646aaHOiM+5PKDOEi4ALIBdqAUAB1B0BArkH1MtYlfDcTAqAMDPXEgkaqYJFwKQM0R6swFrTepCNcfMKJFqclvLJQUusv8Afsi4Me5eZNPNzrsr8GTOl6jX3phsuqfrJcrcMvD0vHhzDOohRW4zjXMKELgBZPhFBLIwngkQvq1koKXwIgpwCQtgdSAfvHwpN49vy83bNxUAKFmepWY+fCjNTTus2ovcQtLmCcH9rViWnn3GKgMM8Mwiz1JFVr1bsvbBrZgk+bSls2cRfeOckLQM/mbKhzDfIymdyvzIq83JTiks54ZXkg9X5wqVqVdgys7Tzxlp6PxIOBK0Ns0yCNnP8/Ja8mnPypst38H4oxyYeQAPdQ9BDCKbdIW5BAp8tJaUa/JuTwNCNuTytqJkcxSoO5W6Z9eJAgyZ6a5tqFBqQ6X/dEMBiLnWRQVq2YLX2+dW45PXcxLPNVlgqT3phpd0Yfbny6RbTv1xDezpM7YPxmozcQjx/YVstDVYJ5dwBQ5W8sGLF3Lz9i25dXzbLAC3JDjWjP9R0JWXc/M6bUS554VspTh6NP9zmW4GU4sg6JfzFaJFmOA4mK1ZcEO83i5a67NgKOVEOqJdArGU1mgPmRKbfMhpaskWiFGV9+yjeKjLzyX+DRLW7RY+XWPPYuMSx/L4rEl4YwMTghBiQMj6Uw5AAQDFQEwFhgug3cgtTJsHg1xvNmfi3apA3uR5D4JzLQAYAKrBHxfxyKAch5j5uddvoV3/mq2j2QCj6Lbbr1VYizARj0xO2iAAZCAr1Zne2cxeFyCt2kNdAf4PvQGkk0skGq0O5DvPX8iN2zflxvEtOTcG3iWE3ze/3kznaLkXT2SajyBY5vFlBWhrbeB0ZdiXNfw5xy+ItyX3pGSfuOfUwjFpoYxANkZXG0nJG2R9lQmNQM3rXy0b0r7H+Yfle2cyViCro5UXCGz/nL+3wbzc+ggl6xNTgGgBEAAesxwYJODOhxLTZkSXJw9I7CO09a2H4v1z5GgSAK5rZsSb1wBQZbDoR99kA5L2is030t/nAUB/U3n44rXTOuPhaVg6vKPd19SdXwkvfouJwEgCwt87cABoVrGSD54/lxs3AQC35dyAx4XROWAaIbkdVrQzKGoeoHfxCZV/YUhpkYbrDxnxqzLNfTccWzygF+7SM/rcW/HkpcI/cQsj+fIJdc2ECP5cghoSiYl/DVWENPvdzckPRGPUipIqLW4Hr2DA8jVCNSlf/Lg82e9h0Wk1oDYF9WpA9gMAOeh5STETUKF96vrh7rXiexNFOgkA3L+5k3v6e9QT/oYFkF7XHpvQAhgX0HJD5gPAENhFhiqmbPre6FqiJg0a2H/s550NQWGKwgXw3oA76VYrtQAOb96Qm8fHcopcg6AJo2/vnEM+krxLadzXmt/MTMa+TCuHhSe3zX5XP1Pj+LsJzTh66OFXXytl/GW3pTAKevf2Jqd8IvxvHjJikKNAaH6/oSuPT0lpD7mZdAvCFw1YQ7Ajk6QTsh/xUzMBlwvtCoxMwJ9/8kiTybQaULsCMxsQBWg6cdHwekoB1ryEn/VxVJr+bX824AgZNydEF33FFnjUS2rlQNebMWbitPyg+P28caaXTSP30yLbQFffO288TXnKaO5j5/IV3GfDB5qp3hEY/0IREA4MwoBqAXzyXA5u3ZSbx7fkDLniqXFnNEboJ2c1WIY88lk1yNCSXBtCNQCwdHNCal94psKjT98nF9LX7CauAa3MaUqvPVUYOgglK4t7mfY7xKtLfDCwCyY+z5yBhd4w5E64JRgBui78iVV/CUJCeGeWYnI45GxAtQBQDfjkkTaP8clAOHeanOgAYEVsTYK6smij7NSKyP89BSS1TI6WA4/hx9wbTWMQPzF1vSEkn3P90RjrnpnQNWA17+/aJPxS129yC9Mf/3+LKbKoBnQAeP5CDm7AAgAA0F9MyVTZG+EAW0upZcTPhKcO8ysw4YvwNe0CacqwgUrSgmGxHg1wLavLoFZmog362ue+B6aTi8SewkviqQvpx+bZh9kKbsIzUdHNfM904qW9z4idmJTCXb+DFjeUPhPAYc7ZmXM2PVTpuIeOQFen6Ah0KT//+IFaAAeWCKQTyQxgaTMZf9EgGfc581Py44LfU8AxCtDyJaKGnXX460Nv/56j6adeSEvb1y9ojpXSOjBD6FpbEzGH3llmP5CDm2wZfdoOzAZ34kA7AGAyEDmAF3IADuD2LeUAcplu0OvWGKTwSWnPVo+VuYCsHUxThuS/lFjj+fxB0pIi1yvz+snZMAmn4HpSTdbFVNDRKbHlGRDs5bcOxOFrLbgvENR+/ShwTB1OE2Y89o3lUi5PkQl4Kd9+/FAWm61lApr5jyzH3U57TvoEp7SP1X3GZDKetzkAUJ9PfGfQAmgJ7Cw0TO+5PpDDOzhn8fuiYd/0D+O5BkyrllnV2jQ+iduUVrmmPyvHWPl+YS08w7kACEobAICUYNQCYEjFd55/VgCA7ksSGJfxuK/4fSzsye5AMs+5iFQngG87ieifMas5P5Z3yPV0XXu26B+n8Jnb53FZHg3wC1tX4N4JMHxInv6AoNNryzcoz4vRo7oVFpXBBYF/airl9xLdvhrwo9tQcD6+fwPHl+cyh/HAVRAAzkQQBQAA7EACWjWgjR+AC0AAKC2Afc/5JC4FeWwBZuoK3PJ1o8Dvi45TDzLXZxlaV/3gwyASnT874wOkZosE9PvMef7aQklrCqO6gfha5qslwSQC0RMQAPDdF5/J8uYNuXHbogCWEqtyZEP/qOjNnUiC4VxEuSuFBqcnkMi/nOtv4f6EApHxKjW4Zz2wxZiTcDk7h88f+IoAALnhRi5uivF4PpXdoXplJBk9wpHeiAFuZWjYktMlitbj/GXvPZuQkwtxW4cEY2yeUZ+5eCac+0EIEl2BL07PZGnVgGg2i0zAXJncaU6AamB/nY1MvtZ5bFm41zmb/iy9tuBTgklftp88XLsKQ8hUbtq8ZJ0hMyhq2LkAMGV6jv2+0r3FYarvX78UCgx79yIHgO4AhoNiSOhOFgcr+ZXnn8n28EBu370jp6lhBI+yritkq7nA1D5zCu/ZwaK2d0vCAMCjC54nkB4sZPSlF5gJNX47AgQPsbZZN7+d57ghOE7aha/3odmFs5EY48CXzJAszGNn1h+tzh6NQFC4eQaq0VpQUKjcGeZ/8FmLxCKUAy+XcnZyIjcu1vKNx/dpAYSWYFhLAoCwH8HR67Xx3kcRtWSvBRL6M28JNqSxh3yTFhoOCf18bZ0/WQPF2LXnuBDx+1PWiQPL3OdpaZVBAJROzX4wQdp8GFwAXIDlQr7/+kRebLfy4OEDeW19CilyHuM2prlIuHENWApm7/2kRKeQYltVSGYqobNOOb3QfnXZbCGUeTV9968HkGk9Oc6QD7lHGOhemRVfzIeY0nqpHMJnFPbI3pLh6CmTEXckPbXzICFigaSkm8uVfPL8M3l7uZTfdv+ONo7xTECNAEinfQF5DMxfuQYZPXU+pywIfeY4GmxIkLI5VYacppBm6iVNPUAtWPsK+qAQjpQGz1nTdT+j+ffWBQh7imIejAdDNiBSSD9db+TPfvZK3n37qZzAt1ffMti0tRacsZBay5rHmjLsUr9fn96TggPlIIlK8YccqShILZ0eQN3+Ss8gRwWio+GVx2q0pNYKwVKkpDafPNRAWXFSdkfG4XF8I8efKrg81iMSFsCHH30s3374QJ4eHTAFWDsCoSM55w+gO5BGUwAHKvzWHyDk3dRK603O/5AsFiTgJADYiiY3xD/3BoI2aLLMisn2X+iQRUHtMqE993yO5tr1xVKoUQCkZv1CBw1pLsAaswFWK/nFnz6Tew8fyPLoUEOEKUPM2ww5Gz93Tf6yqvl12TQOe9V4scWPnMwLMt/ThmO5BjHUFcAga/602AL4khszA/Ai3CRbJ2QO6+8TL8AHSS4SfueNR6t79fkdPTiFHYPPINf/8vJKXn76Qv6yd9+Wg91WjtAQ1MKY6AmI+2ufUrNvnCrJ3s2bwFXYgcqqaMl34QIMIkyPlOmbbTVaUa6u/yA12cF/83r9y05D0qBL0eAz9jpnUX6aTDVFTZuB2FQf9AFgpx9EAtgYBMlAaFv9g9NT+dH5hXzpLVoBPDCuZVxsp5+3EKqopFNEwD5RBtd7jz50pxQFSL59di2G9s+v5cvxndFS3mSTxKgFRSRVA+xznpLp75x+dEvyhuxzRhMI+BtNfSidj9jJ7dVKfvCTn8iXb9+Sn7mTzf/DRafvEoDOJCCvKOVupeOd8iC43n3W19r3Qo48duVGpRaUzXGI95SIngbMwD6OHKP3iUcx6q/896ZWs2v2tbJV9hUAUF6rME0LhMuu0JClkl9eAACrRMN4L+0utliq+a/jwZERKDtZL1fyJ3/6TG7dOZaHd+7IWYfKAZiNBAzNHVSB8UhAzaXbgUrrzQVLBp8MYBqT72g6xSCQH08RRWsbHmvY8/sp3pSFP/mznDMQXYomMWyiT/C0wEdwh1L/jhjSTVA74CLYnkSr5XoCZk8IqQWAWuv2OwcreXFyIuevX8lvf/ttwdj5wxX6ACzUMkCnIDwMCsZZ/2/NQKpqhJaQ1EA8dtZrMSrPaAmERRQgaY1qo/aU/zf+eJuJzwsPtkAKHU3pxLwJEY3iUmMTsxZn3H6s2lJporAdTF2D9wMwZp+5ADuOCkdvwK6TV7KQP/XTn8q7T57IrZs35Gy3tihy4+pRu8cXaD9389l97tTdqOfU19KRkNOaiYT0Yz30rqEUFqqFcY8BXHlGQgry9R7C6YAU7kuxRLbs9hZmigNWP8+/p4hoec2MGGUGYmFnBIulsJCCT99fqWVDKnvG59YXupPj1YGcXVzKTz95Jn/pO2/JbX1jKP9FG/CFmvzgAaDqtS14SuemVZBeXYqyTYt4oQYb5n4BrOH1xu8NWgDTt58n57W4DWrVycuVAMBjZ6ZXzk+bvEr/pOS3n595Qh+OJBL1rl80YbQyHu0FSLcAAqL9AW1GAF2BhTzf7uSDnz6Txw/vy6M7x3K1wxAR7UlmE3ZM7DxRyPrSpY+4mRcW5HKl+fiW7BPr4dOZ9Hi8E1IeBvNgd1AiHgQr+uVXaGyetk0NCu189DotBLO3G6oXUyigquDX+9u63MrQnQ0HOMlGfK2ppbH7lAZQoWNRjFxG+UqXXrDO/8ZiIZ+dnsinLz6Tv+itp/LwYKWhUQi8sv9G/nkjEHXr/MyGvUyhR90V44kaRV7xjI3JaZv4y+XVWEUTAHjRqGf3lKvw8dLgKNLF9VPzWYJ4JX7TdIPRYv3cBH2KJlmWn41/i2IwvapICI2ZkH7V+DL5XfYCtPnCCgBQqBBwzQvALILVSl7vRP7sp5+qsD59cF9uHmHmnfMJeZ0xUp/7ExQny/baWnMbXd4UPTPZE8B6qMvKbVWzG6nm47uC/uLqYmtx4xiis+DHQ90aXQSzGdn0wwlS7hqTH1jQxOesLAL7THJRqrOrJ8xLCmJzkXTCQ1jUs/L8RAQgKzIrUwBjIRdXl/Lss8/kcNfJt548ljsGSCj+QeXfAWs6rSU44v+dLH0qkbcuC3tcB14jlvYlYL5cZqAYBYBaMObfoPXJFjpFiyDjYP72lMA6NPEbGfPnr7RcVTZM49+yXhoCqDkhznI3TXDtgONfagWY9teRhIgQ7LYKAlcABTQRXS3lo5Mz+RgtppZLOTo6lKODVfIhW3uQLErzOalwcpYby2jt5hUH4u8ExzaFCFlO5LWJ1nTHOAG270zmsPf/U+2Smqe5r5v3FWtQkTYwcmDz+KLvBzMnSZZaLlSqSvAkbG3WXDWK82PumjsFURIVyxODNYKH8S7Bahh5lacOdCnLLLBO1G6sN1s5v7qSbruVt49vyxfv3pHDLcJ7bAlG4af57xOBtQRYh8O468Lf0Yibto0rw6p35EvXuf50+9uLTnNMuSKKhr/YHOptCcEcAYgrHDNVxoW3Ftjy07q2qZ1pWgKlbaKXCNepgWo+wJSfrBHcY774lPYGNG2qB95ahW8EnAAyBFk7gCxBhARfrTfy6vJSzrcbTSLioJHcBDR62ehXCJIRVXtag5CaZYRuuwEEuBuuR/0cWDNQOxPavdZ9bz8pns8e0DxqSwUBY+wcUHKPv9DDQE+hN/yw8WB2KhUcbCP9kHsWXtIDui7vSRDLs30QKUuv3YZQ/k5zMSwhRzcgnwmPS1Bac4tyxPShwQ9XSzk+PJT7R0dyhG9uN2ruQ/Mj5AfCD7n+avYj+cfmF64wrcieNfv+03bwfPlpndyo/yv5yVEAN6j3McuvKxalxtfjZgjYYuvzI2Vwmin3gymVTVNrAEjmEH1zdoJnDIfbJ+hy9p9qevBqyiY7H4DUILoK3jikw8A7eIdwIawHAQ80rQXauqZVknXkutbfawZ67dGvz+yNRxvgGn7k9pZewcGj14CDb8b7Fnovf75XA5ZQLg0h0LEMViIb25qkY2sVh/ptBwI7AASkPAmJ18ndgajMnYwMTk+V+GR5Ofa0ntpHQPSyXSbvcIXJc+lQ0cE2YGz5vdBUYGp+ZPxlpkqtqKD9FXCL0OawJpsLAG2yuwSYeJeSA3AUnEjm2Ff7DwlHS7CKg9L8YglUM5Q/lUTBBfh28tskkjIhUVyzTqCZm4ATDJO+FcCaADWCwfzrCpeqjaD93RLgMFEOENUyYm0iSq2P53HhdzDkfVKBb6gB6LPp3FqzMJJckCNwqEBfPe9wHCsH9avaYJNC7b48O+zwsKXx4n72YtGkf8zvqy297V040RgEHH8FwKko+Sj3yv2rIwLEtdyzwLVuLEVyAoo5Gdahx/I1DKpSz0c7JXpNCDbGekHI8XPsOAQbA8AxMVrj/fD7Ef4zoNSWrjYLEPue+yeVPRHnKJL4mXbELKrHbNWYjZW+rkDWdd3vF+n+QNb7Iyi0x+GfepCh9IMWqVaiXwYAf0nRBWgRdP1NyjYFr10iZG2QxWvy7E+bbP4K4tXzM7N7rP8OWl592GXoGGSCjhChVg7anEA1WdUZhiXgJq2Ls/e6Nx9fWfRcRJRNc9ah+xwtWCRpuhEEDb9C2WpoikMyLjQBsRB4AiETolQUVA3/oXUd0KAgwLzRCFW8lvG6Q5Jc4zi0kyy/Wxnsm5BFm1/2yimyElmxuKPk9zCLwbsi6dHIFoy7AioslrqrQo/EHk/n0V5/9PfxOQUB7ePMHWf/vyDybqWEqtRxMjlL05A7Pnwux1UkAOBfFJE/EPpOp7vVBz8K9VwhaKFVCxyucz2/zj5g4qLCP4cFef9rtiGviMVWZcgcPETVCG26s7l81PLWPdj64Wm9gEYB/eCytyC+7zRcOtKBuEqvXw+gddaLzT9M0FIkJMSnk0+cLxL8ZKfCyWIlkDZQorbOmqinh6iiE/PkpjquRM6gCFDaUNH8vvhNh5+VWRz5Lsiq5N7iZ8Z7jFgrRIlkklBH2/p5NqHVWfVIt4CKAIKu2X0m/PgoiMDU7Uc7O2XXlUByPa0/dCb95EU3eo6i6rpuCwD4p0Xk94vI7foGLb982ORoC4Cjry+odY99XYr685/HNVtg4i/qTYBvDEi80aXNG5eNM9kLDBGNfj4LhnAe8fNMiFFMeE5tPLb63yCdXMBcCHOgLFpUQWQIiSlv3kz5dLpc9j2fL7Mo6f6miR04YmC2/AyvpVfS25Q2XvDUC4jOcQx69bxCtoI8MJx6JqYhqEELmkmen4KKIBkaqY2aq4iy14IKvw70yJERdU6UHIzRDrZjY/pvNkjY6HWeBTl0JuPP4xndV4l2XXcGAPh9BgBPap986N9TN6q1XkSofTVrCxxa64qo+iYgNQxjdiBmvrwptM734eQdnku0C2cprlnciQ9Igm4aG9d3/zz1//cUYTefgxbNSjyIV1DLpQi6dZQzGUjsVZ3H9Bzb9ZKJb98xDV8Kt5vu0fqKtkFj923hHirTSIFzdB7mNB8QvEMCxxDNihgGQTVsTKGF2KjUgcpYyeSr8/GYM+DaHrcAdUEegD8ngnL4CEHCfCnLj0hbNmJ91rvQkqd9Bb+WCbvmJwCAv88A4KtTh3ZK8IeQaUyo9jGHptZX32dqvfteb45ZFS2eKTDx3/uYLp+ES01PDe7GI2lDuAFxvLMJgwlh4OB46ULV80C6m0BLv9TmWadTqP0z4VtGMdq6CixxiElZN8QG07jFXqS0wdIxSFoYf0nR6dzbMIGN3VfPjnMcqSEJ1+HPGd28lOxtt016WPfF95LgpFRqaLhagAhfjf6HPxibMbdFhZ+kIMbEeSMR36qo+5vvWG8tAAASYUlEQVR810gn4HE56p3+cssr99N++QMAwN8KAOi67i8eDsVl33NKqOYIQI1eYxq7hVzRovD71WufYwXwM9k8rK2I66Js3Pkhv6yP6jxwOPfwL20yoBX/rEhM2YVj4yon1/RJ7JTBoqBmKj3p/BMe0E6zXLKcFkkvdlJdMPpma5Z++sruMnhML6JDJvCy0W4ybi5ADpbZQ9pl+HY8cckIunQ3z/KzTy288oDARj3sGBTaKYX1mi9ibD+ho9hffQyv3eecQbD7JYZ5NiFmQ8ZuRg7f9kw517pHJPt5aP1Zn6f+2W5ZUaWbMWCV/xIA4K8SkX+p67rfOYUwZcZS+9NxcXM07JQFEDdkypKIFkjU1i0wmHvduVo/AtGYK9XD6VgIoooPx9YPDIFXyT87yskM9w8FM9wPrslUYQTQTTBpN1Oh73lHsyFzpMGDTteMx8uFlPZ3/Wk+Cw0ac20S9RcFmqKaRnj5Uo2X4KZkwjEpomR4WHVk0qAOSHzKommyCSJlOzRytfkA2XRyULXF+GtR4tUzGb3NdwyyWbZffnDjaEqhHDvPc2THz2bLTa5loSUPIvInAAA/awDwe4YXVGrJoc/NXXSNaLXw1FpzbKPGrlV/703WN/Wy3nTN9QuLHDgTdixt1tNnvcGnfdFN3roqP+kGe4WeL8Q9p0zVxzKKcFKWTvo7SdhSOknQg/vRhIRsmySsc4MhciCGQTGFIO1TxicCTDA4ck5UtELMbB9Yd4S+XDFJ4PUcAJIP9kmL9Se3IrMhtFiKA8N1jFnY9ftvEdCtsx5lp3Xex67Tdd0fBQDcERGEAv+Z1iEnuhj6zpXEkc+NodWch/kcltAbdVajY+3mTK25te6WJbTPdfX7IZLGNFmXPmitlD5XEHExZZYKl0cRqagMu/EA82CYgLicpBBelloFg4QI+GBm33kl/2VuPe7qtgCfCFQqPCQxewlGhQFhFoFJNNfBNZC/yCvwvaLw8YFiPV2yUhz5vLrZJTVYEiRXjR8JhT8+ypugGMAlvaiQI/I55cwMucBzXPEhWQnn+Q/SWuy6f7Trun9BRN7NiNw38qaEb8r0nTL3Wwg2dc/+etObLHTEPiZ/ec22STt3rfvyCLyuialJEFNv84nlAYy63tbolS/xbCZyimXErsWKAxQyflJWpGE+AcXLa0tpSSlZ7sa4dkz4YZ/3Krzghqf9i1GVYmRX8AGioBtk8PsBwBxgzAfnjrjGjnyo6+zwBj16EJiMVDAV7xP+7nlGxIG2aT9XSPc9m1PXHfD3w1RrfZCPFovFv+wA8DcCABaLxV8xV+Di58ZM63Kx0f6a5w/V1542o94EAOrc7AQFg9syBnrDLK8LudfO5ctfx01JAOHxsZBlV1i8PW3nfrnp8WgxB6sgPnyZHRjWHU3w8IV0f/29A5l9oPoOPpuUvH8xhR4NbvTfToiGMxRyudNlK3M/yWrLDbBahAiAuetQA2sSIGcFsa+Cq2WoRULrSSnKhcvNzYVVpjrabD+hK/Adi8Xi/xSRBAB/gYj88yKCkOC1/muhThupwpttEEZD5nbpiszTyq0HGSMEr/Xg1ZfSGR/sQ+Caa9+7VftWhdL429r3pInOrLxcaZdgbWZOw+RKo2BbqvKUlhp6NwW5Zy7GvGu1gd/vo+fHCI+ocZNCKe3F3r+cDajXzUe3/AMnOvVDNcrsr/Dic89xQ/trK3mH6r3/JyLyr6RVdV33z3Vd98+KyL15Gz6ttaYRsS/IUwCQrNxrHt4hjT1sqYwLbMt8G+ZMohD7IckHo+YNuH/+OX+ZtWourapaDKbMy/qQUUayd92HFNM0VE3pENTayzVOFIWWUZHeh+U8DFl85eFuWZJmIQTOilvXX2NeW0uR5B2kmd9gSXugb/DbO5PzQaA+l2OgO/eqrb20n71aLBb/2mKx+FcjAPwtRgReyw2IC74OWg09cD7ARhmlFc9D1EIDxJDbKEkzd4tbq3bO+nr53kPrrTPqYmKva/8xqBoE1mTdZn9Zhdm02BAATGrw9geKcOAeyXDF1bi2vM/9kzA+0qunKe0H2UMqgSH+fM5+ZGs16dwxeZ78Xf3u5p7OlkKxm8H8/4OLxeK/jQDwVRFBXcA/NLmiwQ/UGm7/Kw0jYX7sIXN3FDWrDKu2lZMP1dyV55dTuzZRHPOBav1tnjBF3d4X9TGnaNCHDDdm2gy4ef43BK+uVdvWXaIF0/fH1tUTxCFfN5GKjILE/oM9myq1NMvx/f67Lu2k5CY1XsTQfgwrOV67/7/zTlR5nuwtFJvY39Gpd4Y7J0XKd/sfiMi/vlgsflC8567rfqET+adEBLkBgy8xHoL+Y/WXM2ZozdyWhoeW77PPIWvfLx+ICC77Xbd3FPVW+RpuVifuuilkLf80rXm/Bc3b2hTK8/e9n2WVbzJ+DD+fpfMeda7D7AetN9IrK5OVP//ZpwAgrul6z159y+sfYsPWCbAe2JdfE5F/Y7FY/OEe0CMdeCfyTy5F/p6xB0jiMkp08QrZVC2PygDJPNHE03HVD1v5CPNfX7k1Ga3d0M4Jq61r1n511jD1qw7pPKa2ou7x1c/R0L7iMTGbowlahyJCaet9zROwePdSp+ozD0hBm0NpGfWeptt/50MC1t/XuPu5jiDF/K/rkzhZmRKJ+6HGuSCA/A40G3Hp4Z85QaMsku59avhV5dfzn4nIv7lYLH6pBwAqsKwO/Cc6EbgEb7QlafFBE8aNaFoGTTMwiyiBI+vp8pXOO6pDn/KDGkMrPZGuwixTkY656xvjTeZcQ3ekAcjjfEwJGX34Ghbc/h624Wfq4O/DF+Us/dITb915Hw0dYiW9x+r532mPm7uVvh9VVEuO5q2vukpQIvGaewD/D0Tk31osFn/IF9qDWrMC/vGFyN97XY2qG2qdToc2Yo9FF5sasTVe+/pr7VsD9Qubr6HjU+VGHcObnRF2ShBqLV0/75SgZV3R3ilen1dJcfRKc0+DSbz2mGe9P1D7+niHnKyb1zruGAxxNbEN6vUF1YuQ3L0LaYYDQYRhUtafo5ac/uquIUP/qYj82679BxV813W/V0T+MRH5C80qKPKY9YuNMFw+hKEra32g7N2nz4aee1OCNqQJ088r62Hqeq1jOKhN3Lwb7eYSxZB/b605rauKS4+JRVzXmLCPcggDhTou+kPA13/f/ees1z60xkjyxu9MhZ7L3axAO4T6fK3zwKpcZWvNw2eo3oNy9+L96/M59tzzgLzx/COVhvbpD0Tk31ksFn+kuH9TCLruZ0Tk9yFFWESOprPv9kf0+I0p7Td59VDVMi4Ak1dqfmDeNacRu35m//fU4R8FhhHm/HpPGxjjQXdnyK7r37E+0PP2cvo6Q3tJALBeB2ouTItUIayzlMj0NWvF6f+OYHodBRWvO8xF9fbvSkT+XRH5Q4vF4vuTAGA3+RtE5B8Rkb/JvzAlqPO2pX/ArnNQi3s11PbUWq9zz/HvjGuEuIf1dd4EAFqC8Hlc77qHs362KUtgzlr3NXU/j3ffev7rXndoL9/kelEp16DS2NP/XkT+vcVi8T/2zt7Qoe5YKvYPi8g/2HWdugLxRq3vTZmm8RrXNQV7B2wg02tqrSPP3XN3CsQczUBsa8YaqevrvclB8OeM+zlHqMbA7HN7Nxn10tlp7cXUenVXR3Lc57+f4af+vJ557HzOkaEpxRTBpF7zwD7C9P8PReTfXyBnufpvlDvruu7Lu93uFxaLxS+IyFtTQjWG9lUhQrGMfbWNfj4JYh4EmTTFRJrwmMDV5mCd4jp+WIchsHXApg7+FEgNHYbhsGT7ikMm8Bio8Dt6IgozO33Hm27EhhuBO9oX9Ib86LFzNSVMxBWemnidnpA0pWRYdFr72V9L7Bw0Z6X8TEvoR+TnYxFBvP8PLxaLH7buMkmed133O3a73e9dLBb/gGAY6p45+EPI2t/kyaU0N6D5UBNtl1uHb2qdcw9aLAaa81r32c85h3UKpOOapp55TLPWezjv0POK7SzC/bXz0Dfm7OncZx8+7o1chYqMHDubc97T3DX6farnxjS5/0hE/shisfjFwb2ac0i7rvvrdrvd379cLv/uOZ9vIVV9mIa0Tuv6cw7XlKYe0jhzN3nOoW2Zt3P2a+rATq0xfn+uNbXPNec8wxCw1Jp1yHcduseYxhsSsKn1zgXSOULq95reT34yYkQzkjbT1YlrG3jnf0xE/uPFYvE/j+3HPLVL0+N3d133exaLxd8xJqRDG1Fr0NaLra8bBao+ODXqTZmUc39f3zOuc0xQ54BU66UNoHfaiusIQH3Aa3CMWvi6QtR6V/G6U/es97J1iIeefchcj2ek/nsNzq31mYgyF8JD+b0S32HNP3T/WvmNRSaG5KKlXEaU0n8hIn90sVj811NgOBsATKtD+GEFNEFg6FD0N6Dve00J19SD1IdvzueHNHbrgE1p6SENOCRgU4C0z/XGNNUcEB3aq7nPPNfymbLS6mceFlJ+cghkhhTUGAC335MzD+NiMqb9S8WnK5gVmjR5GzzGI+8Gwv/HFosF/pz8by8AsEX97t1u93ctl8u/E5zA2B2mtPxcc7UlDG8ipC2hqDd87uH377XM8KEDNwV2Q6Zhvdf7rHFIKGotsg8wTb17JwmHtPu+60/X8RuXHW5GD3v9XLVl13/u+cHHMas3nqu5vTXHFNPIQ8Ln/+Mi8p/P0fxpCychovEBcAIi8reLyN/m0QH/WMtkbpmkc+/bMq3nmI/19ae0VA0ocw9n/WzxvlOm6phQtvazvnb8zNz17nPdfd9RSxBGzNTm5ev33dxDiz649pqTfzLruroiaui5wjq1nxmr5unasT0cev8iArb/vxKR/3LK5+8pkbkvuSFQv0NEMFTkb44pw3OuN+ewjplVrXvMuWZE4/8/1jklDC2wG1pn/1oxxHs9hnrfwzpnP/M6XbiGd372O/cuwTNL1eZcN5+f/UK5U+do7rmcs5ft99N9INL9dyLL/2aM7R88R1MPMPZ75AmIyO8SEWQNwio4epPr/VZ+9/MybRtAODjl5bfyefrXTpHyQT/zt2oP2s8ZTej55nTUqKVQFvov/WOO9o/CNS2Qc6/4/+3bbdwN6b1g+JHd9z8MxfmnVjnPLhm5imUM/vUi8ju7rvtr3RooXlezV1q+dZ3kMeRPqw6xa+XDPO+FzSdq5m3JmEsxfcgGRGZWHHlMkw4L2pQWnLPmFqczxONwf/JgDTLf/S7ItcD379Hviht7FkxBy+hzNyyJ0o4qrz72/Ek7p4nH80vp9zubet4/ENn9LyLLPyEi/1Mrw29K8PN6535y4nMdC4j+mt1u91cvFguMG/tqk8xKLUKGD/KU30+Rjxqv9TjjplwCkjfqeVBuSksY6lXMSZfuE3O8D7GvdeTrvdgvVBWfIq5vHrTm2o7WERl9fvvlkOuTzg8qRg346aFb9h53ZUa5T7u1Nq9StkAZd6SGgTuvNY8JSG9hYiNbHFn/LOnKfiDS/e8iy/9NRP7XurDnOqI8T93tcWX0ExCRv1JE/nIRAU+g7cXqppZzX9zwoaqPagSUcU3YIxE/RxDgo+YpPEXlug/2sYdqnYuWmZ4/N3Y8ryO6FYA12sANnd1hd6KE56Th7S/1gRu6TrSw2tZJFt8hCGgRfyXYOZCU1uibase5wNk82+1mtb8mu90vynL5f4nI/xHr+fcQzeZHP3cASC+cQPDbReQvMbfg22g53j4eeW1DJmWE+XiN9maXP22ZbvFgXncT4nXb1k5+LtVc9VyMsMz6WsXhNT23Ty+8uS7KGGwMARStEe5aKcAZeGuoGobksjo0XnvocEfRr7v51NrUr9cGmnJVY2usn3WMT4nPHtVSAT7TnaVeich3RXYfiCz/lIj8yc9T8N8U5GYDT9d1aC328yLyLRH5eifyswu2G3t3rgasb9Y6XCWG4xP0N6eIrzG0nvru1CYM6eupg9a+rneDa+m7/lPMXXtci1+l/nPqOQN8Vx+dcNR8vtYEm1+vMXYu0nc8YsGNC2ppAVzvvZRPH0OT1xCyj2jmCxp3/jkR+RUR+Q66985/B/t98rrKb7+72Ke7rsMEoq+BHxCRL4rI+yLytog8EZEHInK367rbi8Xihois2lubB1J6TlW90UWxYFXx1Vp4jdgt1J4rUEPXH8v/mjJV4z7UBNjcvLJBUzsseOowTJvlfrEMVlMHZc41+yCVRf765vYQPE+tePj3Y4rJ1rkVkUsROROR113XfbZYLD4RkZ+KyIci8hsGAL++WCx+9formf/N/xdLFCfo0XqBIAAAAABJRU5ErkJggg==", md = { class: "category-node" }, hd = ["data-id", "draggable"], gd = { class: "item-left" }, _d = ["data-tooltip"], vd = {
	key: 0,
	class: "item-badge"
}, yd = {
	key: 1,
	class: "item-actions"
}, bd = { class: "sub-categories-inner" }, xd = /*@__PURE__*/ z({
	__name: "CategoryItem",
	props: {
		cat: {},
		level: {}
	},
	setup(e) {
		let t = e, n = Wl(), r = Bn("categoryContext"), i = q(() => n.collapsedCategoryIds.includes(t.cat.id)), a = q(() => t.cat.children && t.cat.children.length > 0), o = q(() => n.addingSubParentId === t.cat.id), s = (e) => {
			if (e === "all") return n.allNotes.filter((e) => e.isDeleted !== !0).length;
			let t = n.getCategoryDescendants(e);
			return n.allNotes.filter((n) => (n.categoryId === e || t.has(n.categoryId)) && n.isDeleted !== !0).length;
		}, c = { mounted: (e) => {
			setTimeout(() => {
				e.focus(), e.select();
			}, 100);
		} };
		return (t, l) => {
			let u = Jr("CategoryItem", !0);
			return V(), H("div", md, [W("div", {
				class: O(["menu-item", {
					active: I(n).currentCategoryId === e.cat.id,
					"has-actions": !e.cat.isSystem,
					dragging: I(r).draggedCatId.value === e.cat.id,
					"drag-inside": I(r).dragOverCatId.value === e.cat.id && I(r).dragPlacement.value === "inside"
				}]),
				"data-id": e.cat.id,
				draggable: I(r).editingId.value !== e.cat.id,
				style: D({ "--item-level": e.level }),
				onClick: l[13] ||= (t) => I(r).handleCategoryClick(e.cat),
				onDblclick: l[14] ||= (t) => I(r).handleCategoryDblClick(e.cat),
				onDragstart: l[15] ||= (t) => I(r).onDragStart(t, e.cat),
				onDragover: l[16] ||= (t) => I(r).onDragOverItem(t, e.cat),
				onDragend: l[17] ||= (...e) => I(r).onDragEnd && I(r).onDragEnd(...e)
			}, [
				l[25] ||= W("div", { class: "active-indicator" }, null, -1),
				a.value ? (V(), H("span", {
					key: 0,
					class: "collapse-toggle",
					onClick: l[0] ||= J((t) => I(n).toggleCategoryCollapse(e.cat.id), ["stop"]),
					onDblclick: l[1] ||= J(() => {}, ["stop"])
				}, [G(I(au), { class: O(["toggle-icon", { "is-expanded": !i.value }]) }, null, 8, ["class"])], 32)) : K("", !0),
				I(r).editingId.value === e.cat.id ? (V(), H("div", {
					key: 1,
					class: "item-edit-wrapper",
					onClick: l[8] ||= J(() => {}, ["stop"])
				}, [Ln(W("input", {
					"onUpdate:modelValue": l[2] ||= (e) => I(r).editCategoryName.value = e,
					type: "text",
					class: "item-edit-input",
					onKeyup: [l[3] ||= Us((t) => I(r).submitEdit(e.cat.id), ["enter"]), l[4] ||= Us((...e) => I(r).cancelEdit && I(r).cancelEdit(...e), ["esc"])],
					onBlur: l[5] ||= (t) => I(r).submitEdit(e.cat.id)
				}, null, 544), [[ks, I(r).editCategoryName.value], [c]]), W("button", {
					class: "edit-btn confirm",
					onMousedown: l[6] ||= J(() => {}, ["prevent"]),
					onClick: l[7] ||= (t) => I(r).submitEdit(e.cat.id)
				}, [G(I(nu), { class: "btn-icon-small" })], 32)])) : (V(), H(B, { key: 2 }, [W("div", gd, [G(I(Su), { class: "item-icon" }), W("span", {
					class: "item-name",
					"data-tooltip": e.cat.name
				}, j(e.cat.name), 9, _d)]), W("div", {
					class: "item-right",
					onClick: l[12] ||= J(() => {}, ["stop"])
				}, [I(n).showNoteCount && s(e.cat.id) > 0 ? (V(), H("span", vd, j(s(e.cat.id)), 1)) : K("", !0), e.cat.isSystem ? K("", !0) : (V(), H("div", yd, [
					W("button", {
						class: "action-btn",
						"data-tooltip": "添加子分类",
						onClick: l[9] ||= (t) => I(r).startAddSub(e.cat.id)
					}, [G(I(zu), { class: "action-icon" })]),
					W("button", {
						class: "action-btn",
						"data-tooltip": "编辑分类",
						onClick: l[10] ||= (t) => I(r).startEdit(e.cat.id, e.cat.name)
					}, [G(I(Pu), { class: "action-icon" })]),
					W("button", {
						class: "action-btn delete",
						"data-tooltip": "删除分类",
						onClick: l[11] ||= (t) => I(r).confirmDelete(e.cat.id, e.cat.name)
					}, [G(I(Zu), { class: "action-icon" })])
				]))])], 64))
			], 46, hd), W("div", { class: O(["sub-categories", { "is-collapsed": i.value }]) }, [W("div", bd, [(V(!0), H(B, null, $r(e.cat.children, (t) => (V(), U(u, {
				key: t.id,
				cat: t,
				level: e.level + 1
			}, null, 8, ["cat", "level"]))), 128)), o.value ? (V(), H("div", {
				key: 0,
				class: "menu-item virtual-add-item",
				style: D({ "--item-level": e.level + 1 })
			}, [W("div", {
				class: "item-edit-wrapper",
				onClick: l[24] ||= J(() => {}, ["stop"])
			}, [Ln(W("input", {
				"onUpdate:modelValue": l[18] ||= (e) => I(n).newSubCategoryName = e,
				type: "text",
				placeholder: "子分类名称...",
				class: "item-edit-input",
				onKeyup: [l[19] ||= Us((t) => I(r).submitAddSub(e.cat.id), ["enter"]), l[20] ||= Us((...e) => I(r).cancelAddSub && I(r).cancelAddSub(...e), ["esc"])],
				onBlur: l[21] ||= (t) => I(r).submitAddSub(e.cat.id)
			}, null, 544), [[ks, I(n).newSubCategoryName], [c]]), W("button", {
				class: "edit-btn confirm",
				onMousedown: l[22] ||= J(() => {}, ["prevent"]),
				onClick: l[23] ||= (t) => I(r).submitAddSub(e.cat.id)
			}, [G(I(nu), { class: "btn-icon-small" })], 32)])], 4)) : K("", !0)])], 2)]);
		};
	}
}), Z = (e, t) => {
	let n = e.__vccOpts || e;
	for (let [e, r] of t) n[e] = r;
	return n;
}, Sd = /*#__PURE__*/ Z(xd, [["__scopeId", "data-v-fd7620eb"]]), Cd = {
	key: 0,
	class: "active-indicator"
}, wd = { class: "item-left" }, Td = ["data-tooltip"], Ed = {
	key: 1,
	class: "item-badge"
}, Dd = /*#__PURE__*/ Z(/* @__PURE__ */ z({
	__name: "CategoryMenuItem",
	props: {
		title: {},
		icon: { default: void 0 },
		isActive: {
			type: Boolean,
			default: !1
		},
		badge: { default: 0 },
		tooltip: { default: void 0 },
		level: { default: 0 },
		customClass: { default: "" },
		showActiveIndicator: {
			type: Boolean,
			default: !0
		}
	},
	setup(e) {
		return (t, n) => (V(), H("div", {
			class: O(["menu-item", [e.customClass, { active: e.isActive }]]),
			style: D({ "--item-level": e.level })
		}, [
			e.showActiveIndicator ? (V(), H("div", Cd)) : K("", !0),
			W("div", wd, [e.icon ? (V(), U(Xr(e.icon), {
				key: 0,
				class: "item-icon"
			})) : K("", !0), W("span", {
				class: "item-name",
				"data-tooltip": e.tooltip
			}, j(e.title), 9, Td)]),
			e.badge && Number(e.badge) > 0 ? (V(), H("span", Ed, j(e.badge), 1)) : K("", !0),
			ei(t.$slots, "right", {}, void 0, !0)
		], 6));
	}
}), [["__scopeId", "data-v-c8d83775"]]);
//#endregion
//#region src/utils/useDragAutoScroll.ts
function Od(e, t = {}) {
	let n = t.threshold ?? 90, r = t.maxSpeed ?? 20, i = t.minSpeed ?? 3, a = t.overflowMargin ?? 200, o = null, s = 0, c = () => {
		o !== null && (cancelAnimationFrame(o), o = null), s = 0;
	}, l = () => {
		let t = e.value;
		if (!t || s === 0) {
			c();
			return;
		}
		t.scrollTop += s, o = requestAnimationFrame(l);
	};
	return Hr(() => {
		c();
	}), {
		handleDragOver: (t) => {
			let u = e.value;
			if (!u || t.clientX === 0 && t.clientY === 0) return;
			let d = u.getBoundingClientRect(), f = t.clientX, p = t.clientY;
			if (f < d.left - 80 || f > d.right + 80) {
				c();
				return;
			}
			let m = p - d.top, h = d.bottom - p;
			if (m < n && m > -a) {
				let e = m <= 0 ? 1 : Math.min(1, Math.max(0, (n - m) / n));
				s = -Math.max(i, e * r), o === null && (o = requestAnimationFrame(l));
			} else if (h < n && h > -a) {
				let e = h <= 0 ? 1 : Math.min(1, Math.max(0, (n - h) / n));
				s = Math.max(i, e * r), o === null && (o = requestAnimationFrame(l));
			} else c();
		},
		stopScroll: c
	};
}
//#endregion
//#region src/utils/useResponsive.ts
var kd = {
	mobile: 599,
	tablet: 869,
	compact: 1049
}, Ad = /* @__PURE__ */ F(!1), jd = /* @__PURE__ */ F(!1), Md = /* @__PURE__ */ F(!1), Nd = /* @__PURE__ */ F(!1), Pd = !1;
function Fd() {
	if (typeof window > "u") return;
	let e = window.innerWidth;
	Ad.value = e <= kd.mobile, jd.value = e <= kd.tablet, Md.value = e <= kd.compact;
	let t = typeof navigator < "u" && (navigator.maxTouchPoints || 0) > 0, n = window.matchMedia("(pointer: coarse)").matches;
	Nd.value = t || n;
}
function Id() {
	if (!(Pd || typeof window > "u") && (Pd = !0, Fd(), window.addEventListener("resize", Fd, { passive: !0 }), window.matchMedia)) {
		let e = window.matchMedia("(pointer: coarse)");
		e.addEventListener && e.addEventListener("change", Fd);
	}
}
function Ld() {
	return Id(), Fd(), {
		isMobile: /* @__PURE__ */ zt(Ad),
		isTablet: /* @__PURE__ */ zt(jd),
		isCompact: /* @__PURE__ */ zt(Md),
		isTouch: /* @__PURE__ */ zt(Nd),
		breakpoints: kd
	};
}
//#endregion
//#region src/modules/CategorySidebar/CategoryList.vue
var Rd = /*#__PURE__*/ Z(/* @__PURE__ */ z({
	__name: "CategoryList",
	setup(e) {
		let t = Wl(), { isMobile: n } = Ld(), r = /* @__PURE__ */ F(null), i = /* @__PURE__ */ F(""), a = /* @__PURE__ */ F(null), o = (e, t) => {
			r.value = e, i.value = t;
		}, s = () => {
			r.value = null, i.value = "";
		}, c = (e) => {
			if (r.value !== e) return;
			let n = i.value.trim();
			if (n) {
				let i = t.categories.find((t) => t.id === e);
				if (i && i.name === n) {
					s();
					return;
				}
				t.updateCategory(e, n), t.showToast(`分类已重命名为 "${n}"`), r.value = null;
			} else s();
		}, l = async (e, n) => {
			await t.askConfirm("确认删除分类", `确定要删除分类 "${n}" 吗？该分类下的子分类会自动上移，该分类下的便签将被移至最近删除。`) && (t.deleteCategory(e), t.showToast(`分类 "${n}" 已删除`));
		}, u = /* @__PURE__ */ F(null), d = /* @__PURE__ */ F(null), f = /* @__PURE__ */ F(null), { handleDragOver: p, stopScroll: m } = Od(a);
		Gn(() => u.value, (e) => {
			e ? window.addEventListener("dragover", p) : (window.removeEventListener("dragover", p), m());
		}), Hr(() => {
			window.removeEventListener("dragover", p), m();
		});
		let h = (e) => {
			if (e === "all" || e === "trash" || e === "recent") return 0;
			let n = 0, r = t.categories.find((t) => t.id === e && !t.isDeleted);
			for (; r && r.parentId;) {
				n++;
				let e = r.parentId;
				r = t.categories.find((t) => t.id === e && !t.isDeleted);
			}
			return n;
		}, g = q(() => {
			let e = d.value, t = f.value;
			if (!e || !t || t === "inside") return {};
			let n = document.querySelector(".category-list-wrapper"), r = document.querySelector(`[data-id="${e}"]`);
			if (n && r) {
				let i = n.getBoundingClientRect(), a = r.getBoundingClientRect(), o = a.top - i.top;
				t === "before" ? o -= 4 : o += a.height + 2;
				let s = 0;
				return e !== "all" && (s = h(e)), {
					top: `${o}px`,
					"--item-level": s
				};
			}
			return {};
		}), _ = (e) => {
			let n = [];
			if (!e.parentId) n = ie.value;
			else {
				let r = t.categories.find((t) => t.id === e.parentId && !t.isDeleted);
				if (r) {
					let e = (t) => {
						for (let n of t) {
							if (n.id === r.id) return n.children;
							if (n.children) {
								let t = e(n.children);
								if (t) return t;
							}
						}
						return null;
					};
					n = e(ie.value) || [];
				}
			}
			let r = n.findIndex((t) => t.id === e.id);
			return r !== -1 && r < n.length - 1 ? n[r + 1] : null;
		}, v = (e, t) => {
			u.value = t.id, e.dataTransfer && (e.dataTransfer.effectAllowed = "move", e.dataTransfer.setData("text/plain", t.id));
		}, y = (e, n) => {
			if (!u.value) return;
			if (p(e), e.preventDefault(), e.stopPropagation(), u.value === n.id) {
				d.value = null, f.value = null;
				return;
			}
			let r = (e) => !u.value || e === u.value ? !1 : u.value === "all" ? !0 : !t.getCategoryDescendants(u.value).has(e), i = e.currentTarget.getBoundingClientRect(), a = e.clientY - i.top, o = i.height * .25, s = i.height * .75;
			if (a < o) r(n.id) ? (d.value = n.id, f.value = "before") : (d.value = null, f.value = null);
			else if (a > s) {
				let e = t.collapsedCategoryIds.includes(n.id), i = n.children && n.children.length > 0;
				if (u.value === "all") {
					let e = _(n);
					e && !e.parentId && r(e.id) ? (d.value = e.id, f.value = "before") : (d.value = n.id, f.value = "after");
				} else if (i && !e) {
					let e = n.children[0].id;
					r(e) && (d.value = e, f.value = "before");
				} else {
					let e = _(n);
					e && r(e.id) ? (d.value = e.id, f.value = "before") : (d.value = n.id, f.value = "after");
				}
			} else u.value === "all" || n.isSystem ? (d.value = null, f.value = null) : r(n.id) ? (d.value = n.id, f.value = "inside") : (d.value = null, f.value = null);
		}, b = (e) => {
			if (e.preventDefault(), !u.value) return;
			let n = u.value;
			if (d.value && f.value) {
				let e = d.value;
				if (e === "all") {
					let e = ie.value.find((e) => e.id !== n && !e.isSystem);
					e && f.value === "after" ? t.moveCategory(n, void 0, e.id, "before") : t.moveCategory(n, void 0, "all", f.value);
					let r = t.categories.find((e) => e.id === n && !e.isDeleted);
					t.showToast(`已将分类 "${r?.name || "全部便签"}" 移至对应位置`);
				} else {
					let r = t.categories.find((t) => t.id === e && !t.isDeleted);
					if (r) if (f.value === "inside") {
						t.moveCategory(n, e, void 0, "inside");
						let i = t.categories.find((e) => e.id === n && !e.isDeleted);
						t.showToast(`已将分类 "${i?.name}" 移入 "${r.name}" 内部`);
					} else {
						t.moveCategory(n, r.parentId, e, f.value);
						let i = t.categories.find((e) => e.id === n && !e.isDeleted), a = f.value === "before" ? "上方" : "下方";
						t.showToast(`已将分类 "${i?.name || "全部便签"}" 移至 "${r.name}" 的${a}`);
					}
				}
			}
			S();
		}, x = () => {
			S();
		}, S = () => {
			u.value = null, d.value = null, f.value = null;
		}, C = (e) => {
			if (!u.value) return;
			p(e);
			let t = e.target;
			t && (t.classList.contains("sidebar-menu") || t.closest(".trash-item")) && (d.value = null, f.value = null);
		}, w = (e) => {
			t.addingSubParentId = e, t.newSubCategoryName = "分类", t.collapsedCategoryIds.includes(e) && t.toggleCategoryCollapse(e);
		}, ee = () => {
			t.addingSubParentId = null, t.newSubCategoryName = "";
		}, te = (e) => {
			if (t.addingSubParentId !== e) return;
			let n = t.newSubCategoryName.trim();
			n && (t.addCategory(n, e), t.showToast(`已成功创建子分类 "${n}"`)), ee();
		}, ne = (e) => {
			t.currentCategoryId = e, n.value && t.closeMobileSidebar();
		}, T = (e) => {
			ne(e.id);
		}, re = (e) => {
			e.isSystem || e.children && e.children.length > 0 && t.toggleCategoryCollapse(e.id);
		}, ie = q(() => {
			let e = t.categories.filter((e) => !e.isDeleted), n = new Map(e.map((e) => [e.id, {
				...e,
				children: []
			}])), r = [], i = {
				id: "all",
				name: "全部便签",
				isSystem: !0,
				createdAt: 0,
				children: []
			};
			n.set("all", i), r.push(i), e.forEach((e) => {
				let t = n.get(e.id);
				e.parentId && n.has(e.parentId) ? n.get(e.parentId).children.push(t) : r.push(t);
			});
			let a = (e) => {
				let n = t.categoryOrder.indexOf(e);
				return n === -1 ? Infinity : n;
			}, o = (e, t) => a(e.id) - a(t.id);
			return r.sort(o), n.forEach((e) => e.children.sort(o)), r;
		});
		return zn("categoryContext", {
			draggedCatId: u,
			dragOverCatId: d,
			dragPlacement: f,
			editingId: r,
			editCategoryName: i,
			startEdit: o,
			cancelEdit: s,
			submitEdit: c,
			confirmDelete: l,
			onDragStart: v,
			onDragOverItem: y,
			onDragEnd: x,
			startAddSub: w,
			submitAddSub: te,
			cancelAddSub: ee,
			handleCategoryClick: T,
			handleCategoryDblClick: re
		}), (e, n) => (V(), H("div", {
			ref_key: "sidebarMenuRef",
			ref: a,
			class: O([{ "is-dragging": u.value !== null }, "sidebar-menu"]),
			onDragover: C,
			onDrop: b
		}, [
			W("div", {
				class: "category-list-wrapper",
				onDragover: n[0] ||= J(() => {}, ["prevent"])
			}, [(V(!0), H(B, null, $r(ie.value, (e) => (V(), U(Sd, {
				key: e.id,
				cat: e,
				level: 0
			}, null, 8, ["cat"]))), 128)), d.value && f.value && f.value !== "inside" ? (V(), H("div", {
				key: 0,
				class: "drag-indicator-line",
				style: D(g.value)
			}, null, 4)) : K("", !0)], 32),
			n[3] ||= W("div", { class: "menu-divider" }, null, -1),
			G(Dd, {
				title: "最近使用",
				icon: I(wu),
				"is-active": I(t).currentCategoryId === "recent",
				badge: I(t).showNoteCount ? I(t).recentNotesCount : 0,
				"custom-class": "recent-item",
				tooltip: "最近复制/双击使用过的便签",
				onClick: n[1] ||= (e) => ne("recent")
			}, null, 8, [
				"icon",
				"is-active",
				"badge"
			]),
			G(Dd, {
				title: "最近删除",
				icon: I(Zu),
				"is-active": I(t).currentCategoryId === "trash",
				badge: I(t).showNoteCount ? I(t).trashNotesCount : 0,
				"custom-class": "trash-item",
				tooltip: "已删除的便签",
				onClick: n[2] ||= (e) => ne("trash")
			}, null, 8, [
				"icon",
				"is-active",
				"badge"
			])
		], 34));
	}
}), [["__scopeId", "data-v-f6c8c0b7"]]), zd = { class: "category-add-container" }, Bd = {
	key: 0,
	class: "add-category-input-wrapper"
}, Vd = { class: "add-actions" }, Hd = /*#__PURE__*/ Z(/* @__PURE__ */ z({
	__name: "CategoryAdd",
	props: {
		isAdding: {
			type: Boolean,
			default: !1
		},
		isAddingModifiers: {}
	},
	emits: ["update:isAdding"],
	setup(e) {
		let t = Wl(), n = Di(e, "isAdding"), r = /* @__PURE__ */ F(""), i = /* @__PURE__ */ F(null), a = async () => {
			n.value = !0, r.value = "分类", await Tn(), i.value && (i.value.focus(), i.value.select());
		}, o = () => {
			n.value = !1, r.value = "";
		}, s = () => {
			if (!n.value) return;
			let e = r.value.trim();
			e ? (t.addCategory(e), t.showToast(`已成功创建分类 "${e}"`), n.value = !1, r.value = "") : o();
		};
		return (e, t) => (V(), H("div", zd, [n.value ? (V(), H("div", Bd, [Ln(W("input", {
			ref_key: "addInputRef",
			ref: i,
			"onUpdate:modelValue": t[0] ||= (e) => r.value = e,
			type: "text",
			placeholder: "分类名称...",
			class: "add-input",
			onKeyup: [Us(s, ["enter"]), Us(o, ["esc"])],
			onBlur: s
		}, null, 544), [[ks, r.value]]), W("div", Vd, [W("button", {
			class: "add-confirm-btn",
			onMousedown: t[1] ||= J(() => {}, ["prevent"]),
			onClick: s
		}, [G(I(nu), { class: "btn-icon" })], 32), W("button", {
			class: "add-cancel-btn",
			onMousedown: t[2] ||= J(() => {}, ["prevent"]),
			onClick: o
		}, [G(I(td), { class: "btn-icon" })], 32)])])) : (V(), H("button", {
			key: 1,
			class: "add-category-btn",
			onClick: a
		}, [G(I(zu), { class: "add-icon" }), t[3] ||= W("span", null, "添加新分类", -1)]))]));
	}
}), [["__scopeId", "data-v-052ae00a"]]), Ud = {
	class: "sidebar-brand",
	"data-tauri-drag-region": ""
}, Wd = ["src"], Gd = { class: "sidebar-footer" }, Kd = { class: "sidebar-footer-actions" }, qd = /*#__PURE__*/ Z(/* @__PURE__ */ z({
	__name: "CategorySidebar",
	setup(e) {
		let t = Wl(), n = /* @__PURE__ */ F(!1), r = (e) => {
			sd(e);
		}, { sidebarWidth: i, isResizing: a, startResize: o } = fd();
		return (e, s) => (V(), H("aside", {
			class: O(["sidebar-container", { "mobile-open": I(t).isMobileSidebarOpen }]),
			style: D({ width: I(i) + "px" })
		}, [
			W("div", {
				class: "sidebar-header",
				"data-tauri-drag-region": "",
				onMousedown: r
			}, [W("div", Ud, [W("img", {
				src: I(pd),
				class: "logo",
				alt: "logo",
				"data-tauri-drag-region": ""
			}, null, 8, Wd), s[4] ||= W("h2", {
				class: "header-title",
				"data-tauri-drag-region": ""
			}, " 拾光便签 ", -1)]), W("button", {
				class: "mobile-sidebar-close",
				"aria-label": "关闭侧边栏",
				onClick: s[0] ||= (...e) => I(t).closeMobileSidebar && I(t).closeMobileSidebar(...e)
			}, [G(I(td), { class: "close-icon" })])], 32),
			G(Rd),
			W("div", Gd, [W("div", Kd, [G(Hd, {
				"is-adding": n.value,
				"onUpdate:isAdding": s[1] ||= (e) => n.value = e,
				class: "category-add-wrapper"
			}, null, 8, ["is-adding"]), W("button", {
				class: O(["settings-btn", { "is-hidden": n.value }]),
				"data-tooltip": "打开设置",
				onClick: s[2] ||= (e) => I(t).openSettings()
			}, [G(I(Gu), { class: "settings-btn-icon" })], 2)])]),
			W("div", {
				class: O(["resize-handle", { resizing: I(a) }]),
				onMousedown: s[3] ||= (...e) => I(o) && I(o)(...e)
			}, null, 34)
		], 6));
	}
}), [["__scopeId", "data-v-c869d7d5"]]), Jd = { class: "search-section" }, Yd = { class: "search-wrapper" }, Xd = ["placeholder"], Zd = {
	key: 0,
	class: "target-popover"
}, Qd = { class: "target-list" }, $d = ["onClick"], ef = { class: "target-text" }, tf = {
	key: 0,
	class: "check-icon"
}, nf = /*#__PURE__*/ Z(/* @__PURE__ */ z({
	__name: "SearchSection",
	setup(e) {
		let t = Wl(), n = /* @__PURE__ */ F(!1), r = [
			{
				value: "all",
				label: "全部"
			},
			{
				value: "title",
				label: "标题"
			},
			{
				value: "content",
				label: "内容"
			},
			{
				value: "tag",
				label: "标签"
			},
			{
				value: "category",
				label: "分类"
			}
		], i = q(() => {
			if (t.searchTarget.includes("all")) return "搜索全部信息...";
			let e = [];
			return t.searchTarget.includes("title") && e.push("标题"), t.searchTarget.includes("content") && e.push("内容"), t.searchTarget.includes("tag") && e.push("标签"), t.searchTarget.includes("category") && e.push("分类"), e.length > 0 ? `搜索便签${e.join("/")}...` : "搜索全部信息...";
		}), a = () => {
			t.searchQuery = "";
		}, o = () => {
			n.value = !n.value;
		}, s = (e) => t.searchTarget.includes(e), c = (e) => {
			let n = [];
			if (e === "all") n = ["all"];
			else {
				n = t.searchTarget.filter((e) => e !== "all"), n.includes(e) ? n = n.filter((t) => t !== e) : n.push(e);
				let i = r.filter((e) => e.value !== "all").length;
				(n.length === 0 || n.length === i) && (n = ["all"]);
			}
			t.searchTarget = n;
		}, l = () => {
			n.value = !1;
		};
		return Rr(() => {
			document.addEventListener("click", l);
		}), Hr(() => {
			document.removeEventListener("click", l);
		}), (e, l) => (V(), H("div", Jd, [W("div", Yd, [
			G(I(Wu), { class: "search-icon" }),
			Ln(W("input", {
				"onUpdate:modelValue": l[0] ||= (e) => I(t).searchQuery = e,
				type: "text",
				placeholder: i.value,
				class: "search-input",
				"data-tooltip": "支持空格分隔的多关键词检索"
			}, null, 8, Xd), [[ks, I(t).searchQuery]]),
			I(t).searchQuery ? (V(), H("button", {
				key: 0,
				class: "clear-search-btn",
				"data-tooltip": "清空搜索",
				onClick: a
			}, [G(I(td), { class: "clear-icon" })])) : K("", !0),
			W("div", {
				class: "search-target-wrapper",
				onClick: l[1] ||= J(() => {}, ["stop"])
			}, [W("button", {
				class: O(["target-trigger-btn", { active: n.value }]),
				"data-tooltip": "选择搜索范围",
				onClick: o
			}, [G(I(ru), { class: O(["chevron-icon", { open: n.value }]) }, null, 8, ["class"])], 2), n.value ? (V(), H("div", Zd, [l[2] ||= W("div", { class: "popover-title" }, " 搜索范围 ", -1), W("div", Qd, [(V(), H(B, null, $r(r, (e) => W("button", {
				key: e.value,
				class: O(["target-item", { selected: s(e.value) }]),
				onClick: (t) => c(e.value)
			}, [W("span", ef, j(e.label), 1), s(e.value) ? (V(), H("span", tf, "✓")) : K("", !0)], 10, $d)), 64))])])) : K("", !0)])
		])]));
	}
}), [["__scopeId", "data-v-665aab41"]]), rf = { class: "sort-list" }, af = {
	key: 0,
	class: "sort-direction"
}, of = {
	key: 0,
	class: "sort-direction"
}, sf = {
	key: 0,
	class: "sort-direction"
}, cf = {
	key: 0,
	class: "sort-direction"
}, lf = /*#__PURE__*/ Z(/* @__PURE__ */ z({
	__name: "SortPopover",
	props: {
		isOpen: { type: Boolean },
		placement: { default: "bottom" }
	},
	emits: ["toggle", "close"],
	setup(e, { emit: t }) {
		let n = Wl(), r = t, i = (e) => {
			n.setSortMode(e), r("close");
			let t = "";
			t = e === "date" ? n.sortOrder === "desc" ? "日期 (从新到旧)" : "日期 (从旧到新)" : e === "title" ? n.sortOrder === "asc" ? "标题首字母 (A-Z)" : "标题首字母 (Z-A)" : e === "tag" ? n.sortOrder === "asc" ? "标签首字母 (A-Z)" : "标签首字母 (Z-A)" : e === "useCount" ? n.sortOrder === "desc" ? "使用次数 (从多到少)" : "使用次数 (从少到多)" : "自定义", n.showToast(`已切换排序方式为：${t}`, "success");
		};
		return (t, a) => (V(), H("div", {
			class: "action-popover-wrapper",
			onClick: a[6] ||= J(() => {}, ["stop"])
		}, [W("button", {
			class: O(["icon-btn", { active: e.isOpen }]),
			"data-tooltip": "排序方式",
			onClick: a[0] ||= (e) => r("toggle")
		}, [G(I(eu), { class: "btn-icon" })], 2), e.isOpen ? (V(), H("div", {
			key: 0,
			class: O(["sort-popover", `placement-${e.placement}`])
		}, [a[16] ||= W("div", { class: "popover-title" }, " 排序方式 ", -1), W("div", rf, [
			W("button", {
				class: O(["sort-item", { active: I(n).sortMode === "date" }]),
				onClick: a[1] ||= (e) => i("date")
			}, [
				a[7] ||= W("span", { class: "sort-item-icon" }, "📅", -1),
				a[8] ||= W("span", null, "按日期排序", -1),
				I(n).sortMode === "date" ? (V(), H("span", af, j(I(n).sortOrder === "desc" ? "↓" : "↑"), 1)) : K("", !0)
			], 2),
			W("button", {
				class: O(["sort-item", { active: I(n).sortMode === "title" }]),
				onClick: a[2] ||= (e) => i("title")
			}, [
				a[9] ||= W("span", { class: "sort-item-icon" }, "🔤", -1),
				a[10] ||= W("span", null, "按标题首字母", -1),
				I(n).sortMode === "title" ? (V(), H("span", of, j(I(n).sortOrder === "asc" ? "↓" : "↑"), 1)) : K("", !0)
			], 2),
			W("button", {
				class: O(["sort-item", { active: I(n).sortMode === "tag" }]),
				onClick: a[3] ||= (e) => i("tag")
			}, [
				a[11] ||= W("span", { class: "sort-item-icon" }, "🏷️", -1),
				a[12] ||= W("span", null, "按标签排序", -1),
				I(n).sortMode === "tag" ? (V(), H("span", sf, j(I(n).sortOrder === "asc" ? "↓" : "↑"), 1)) : K("", !0)
			], 2),
			W("button", {
				class: O(["sort-item", { active: I(n).sortMode === "useCount" }]),
				onClick: a[4] ||= (e) => i("useCount")
			}, [
				a[13] ||= W("span", { class: "sort-item-icon" }, "🔥", -1),
				a[14] ||= W("span", null, "按使用次数", -1),
				I(n).sortMode === "useCount" ? (V(), H("span", cf, j(I(n).sortOrder === "desc" ? "↓" : "↑"), 1)) : K("", !0)
			], 2),
			W("button", {
				class: O(["sort-item", { active: I(n).sortMode === "custom" }]),
				onClick: a[5] ||= (e) => i("custom")
			}, [...a[15] ||= [W("span", { class: "sort-item-icon" }, "✍️", -1), W("span", null, "自定义排序", -1)]], 2)
		])], 2)) : K("", !0)]));
	}
}), [["__scopeId", "data-v-afdbde53"]]), uf = {
	key: 0,
	class: "columns-popover"
}, df = { class: "columns-list" }, ff = ["onClick"], pf = /*#__PURE__*/ Z(/* @__PURE__ */ z({
	__name: "GridColumnsPopover",
	props: { isOpen: { type: Boolean } },
	emits: ["toggle", "close"],
	setup(e, { emit: t }) {
		let n = Wl(), r = t, i = (e) => {
			n.setGridColumns(e), r("close");
			let t = e === "auto" ? "自动" : `${e} 列`;
			n.showToast(`已强制设置卡片列数为：${t}`, "success");
		};
		return (t, a) => (V(), H("div", {
			class: "action-popover-wrapper",
			onClick: a[2] ||= J(() => {}, ["stop"])
		}, [W("button", {
			class: O(["icon-btn", { active: e.isOpen }]),
			"data-tooltip": "列数设置",
			onClick: a[0] ||= (e) => r("toggle")
		}, [G(I(Du), { class: "btn-icon" })], 2), e.isOpen ? (V(), H("div", uf, [a[5] ||= W("div", { class: "popover-title" }, " 列数设置 ", -1), W("div", df, [W("button", {
			class: O(["columns-item", { active: I(n).gridColumns === "auto" }]),
			onClick: a[1] ||= (e) => i("auto")
		}, [...a[3] ||= [W("span", { class: "columns-item-icon" }, "⚡", -1), W("span", null, "自动适应", -1)]], 2), (V(), H(B, null, $r([
			1,
			2,
			3,
			4
		], (e) => W("button", {
			key: e,
			class: O(["columns-item", { active: I(n).gridColumns === e }]),
			onClick: (t) => i(e)
		}, [a[4] ||= W("span", { class: "columns-item-icon" }, "📊", -1), W("span", null, j(e) + " 列布局", 1)], 10, ff)), 64))])])) : K("", !0)]));
	}
}), [["__scopeId", "data-v-7bea2273"]]), mf = { class: "mobile-category-name" }, hf = { class: "actions-wrapper" }, gf = ["data-tooltip", "disabled"], _f = ["disabled", "data-tooltip"], vf = ["disabled"], yf = {
	key: 7,
	class: "window-control-wrapper"
}, bf = ["data-tooltip", "title"], xf = /*#__PURE__*/ Z(/* @__PURE__ */ z({
	__name: "ActionBar",
	setup(e) {
		let t = Wl(), n = q(() => {
			if (t.currentCategoryId === "all") return "全部便签";
			if (t.currentCategoryId === "recent") return "最近使用";
			if (t.currentCategoryId === "trash") return "最近删除";
			let e = t.categories.find((e) => e.id === t.currentCategoryId);
			return e ? e.name : "全部便签";
		}), r = q(() => od()), i = q(() => ad.value ? "已置顶固定 (失焦不隐藏，点击取消置顶)" : "未置顶 (点击其他地方自动隐藏，点击置顶固定)"), a = async () => {
			await ld(), t.showToast(ad.value ? "已置顶固定 (失焦不隐藏)" : "已取消置顶 (点击外部自动隐藏)");
		}, o = (e) => {
			e.target === e.currentTarget && sd(e);
		}, s = /* @__PURE__ */ F(null), c = (e) => {
			s.value = s.value === e ? null : e;
		}, l = () => {
			s.value = null;
		}, u = q(() => t.currentCategoryId === "trash" ? "清空便签" : t.currentCategoryId === "all" ? "清空所有便签" : "清空当前分类便签"), d = dl.config, f = dl.syncState, p = q(() => d.value.enabled ? f.value === "syncing" ? "正在同步中..." : f.value === "error" ? `同步异常: ${d.value.lastSyncMessage || "点击重试"}` : `WebDAV 已就绪 (上次同步: ${d.value.lastSyncTime ? new Date(d.value.lastSyncTime).toLocaleTimeString() : "尚未同步"}，点击立即同步)` : "WebDAV 未启用 (前往设置开启)"), m = async () => {
			if (!d.value.enabled) {
				t.openSettings();
				return;
			}
			let e = await t.syncWithWebdav();
			e.success ? t.showToast("✅ WebDAV 同步成功！") : t.showToast(`❌ ${e.message}`);
		};
		Rr(() => {
			document.addEventListener("click", l), t.initTheme();
		}), Hr(() => {
			document.removeEventListener("click", l);
		});
		let h = async () => {
			if (t.currentCategoryId === "trash") {
				await t.askConfirm("确认清空便签吗？", "⚠️ 警告：清空便签将彻底从设备删除其中所有的便签，此操作不可逆，数据无法找回！") && t.clearTrash();
				return;
			}
			let e = t.categories.find((e) => e.id === t.currentCategoryId), n = t.currentCategoryId === "all" ? "\"全部便签\"" : e ? `"${e.name}"` : "当前分类";
			await t.askConfirm("确认删除便签", `⚠️ 警告：确定要清空 ${n} 下的所有便签吗？这些便签将被移动到最近删除。`) && (t.clearNotes(t.currentCategoryId), t.showToast("已将所有便签移至最近删除"));
		}, g = () => {
			t.addNote(t.currentCategoryId, "", ""), t.showToast("已新建空便签，可以直接编辑");
		};
		return (e, _) => (V(), H("div", {
			class: "action-bar-container",
			"data-tauri-drag-region": "",
			onMousedown: o
		}, [
			W("button", {
				class: "mobile-category-trigger",
				"aria-label": "打开分类菜单",
				"data-tooltip": "打开分类菜单",
				onClick: _[0] ||= (...e) => I(t).toggleMobileSidebar && I(t).toggleMobileSidebar(...e)
			}, [G(I(ku), { class: "mobile-menu-icon" }), W("span", mf, j(n.value), 1)]),
			G(nf),
			W("div", hf, [
				I(d).enabled ? (V(), H("button", {
					key: 0,
					class: O(["icon-btn webdav-sync-btn", I(f)]),
					"data-tooltip": p.value,
					disabled: I(f) === "syncing",
					onClick: m
				}, [I(f) === "syncing" ? (V(), U(I(Vu), {
					key: 0,
					class: "btn-icon spin"
				})) : (V(), U(I(du), {
					key: 1,
					class: "btn-icon"
				}))], 10, gf)) : K("", !0),
				I(t).enabledActionBarButtons.includes("theme-toggle") ? (V(), H("button", {
					key: 1,
					class: "icon-btn theme-toggle desktop-only-action",
					"data-tooltip": "切换主题",
					onClick: _[1] ||= (...e) => I(t).toggleTheme && I(t).toggleTheme(...e)
				}, [I(t).isDark ? (V(), U(I(Xu), {
					key: 0,
					class: "btn-icon"
				})) : (V(), U(I(ju), {
					key: 1,
					class: "btn-icon"
				}))])) : K("", !0),
				I(t).enabledActionBarButtons.includes("sort-select") ? (V(), U(lf, {
					key: 2,
					class: "desktop-only-action",
					"is-open": s.value === "sort",
					onToggle: _[2] ||= (e) => c("sort"),
					onClose: l
				}, null, 8, ["is-open"])) : K("", !0),
				I(t).enabledActionBarButtons.includes("columns-select") ? (V(), U(pf, {
					key: 3,
					class: "desktop-only-action",
					"is-open": s.value === "columns",
					onToggle: _[3] ||= (e) => c("columns"),
					onClose: l
				}, null, 8, ["is-open"])) : K("", !0),
				I(t).currentCategoryId !== "trash" && I(t).currentCategoryId !== "recent" && I(t).enabledActionBarButtons.includes("clear-notes") ? (V(), H("button", {
					key: 4,
					class: "icon-btn danger",
					disabled: I(t).filteredNotes.length === 0,
					"data-tooltip": u.value,
					onClick: h
				}, [G(I(Zu), { class: "btn-icon" })], 8, _f)) : K("", !0),
				I(t).currentCategoryId === "trash" && I(t).enabledActionBarButtons.includes("clear-notes") ? (V(), H("button", {
					key: 5,
					class: "primary-btn danger-btn",
					disabled: I(t).filteredNotes.length === 0,
					"data-tooltip": "清空便签",
					onClick: h
				}, [G(I(Zu), { class: "btn-icon-plus" }), _[4] ||= W("span", null, "清空便签", -1)], 8, vf)) : K("", !0),
				I(t).currentCategoryId !== "trash" && I(t).currentCategoryId !== "recent" ? (V(), H("button", {
					key: 6,
					class: "primary-btn add-btn desktop-only-action",
					"data-tooltip": "新建便签",
					onClick: g
				}, [G(I(zu), { class: "btn-icon-plus" }), _[5] ||= W("span", null, "新建便签", -1)])) : K("", !0),
				r.value ? (V(), H("div", yf, [_[6] ||= W("div", { class: "window-control-divider" }, null, -1), W("button", {
					class: O(["icon-btn window-pin-btn", { "is-pinned": I(ad) }]),
					"data-tooltip": i.value,
					title: i.value,
					onClick: J(a, ["stop"])
				}, [I(ad) ? (V(), U(I(Lu), {
					key: 0,
					class: "btn-icon pinned"
				})) : (V(), U(I(Iu), {
					key: 1,
					class: "btn-icon"
				}))], 10, bf)])) : K("", !0)
			])
		], 32));
	}
}), [["__scopeId", "data-v-304113ad"]]), Sf = "detached-note", Cf = "moment-notes:detached-note-refresh", wf = "moment-notes:detached-note-changed", Tf = 520, Ef = 640, Df = null;
if (typeof window < "u" && "BroadcastChannel" in window) try {
	Df = new BroadcastChannel("moment-notes-sync");
} catch (e) {
	console.warn("[BroadcastChannel] not supported:", e);
}
var Of = (e = window.location.search) => {
	let t = new URLSearchParams(e);
	return t.get("view") === "detached-note" && t.get("noteId")?.trim() || null;
}, kf = (e = window.location.search) => Of(e) !== null, Af = (e, t = window.location.href) => {
	let n = new URLSearchParams({
		view: Sf,
		noteId: e
	}), r = new URL(t);
	return r.search = n.toString(), r.hash = "", r.toString();
}, jf = (e) => {
	let t = window.open(Af(e.id, window.location.href), `moment-notes-${e.id}`, `popup,width=${Tf},height=${Ef},resizable=yes`);
	return t?.focus(), t !== null;
}, Mf = async (e) => {
	let t = Ac();
	if (t?.windows) {
		let n = `plugin-moment-notes-note-${e.id}`;
		try {
			if (await t.windows.exists?.(n)) return "focused";
			let r = `pluginwin.html?plugin=${encodeURIComponent(t.id || "custom.moment-notes")}&label=${encodeURIComponent(n)}&view=${Sf}&noteId=${encodeURIComponent(e.id)}`;
			return await t.windows.create(n, {
				url: r,
				title: e.title?.trim() || "拾光便签",
				width: Tf,
				height: Ef,
				transparent: !0,
				decorations: !1,
				shadow: !0,
				alwaysOnTop: !0,
				resizable: !0,
				center: !0
			}) === "created" ? "created" : "focused";
		} catch (e) {
			console.error("[DetachedNoteWindow] ctx.windows.create failed:", e);
		}
	}
	if (t?.bus) try {
		return await t.bus.publish("moment-notes:open-window", {
			type: "detached",
			noteId: e.id,
			title: e.title
		}), "created";
	} catch (e) {
		console.warn("[DetachedNoteWindow] Failed to request via bus:", e);
	}
	return jf(e) ? "browser" : "failed";
}, Nf = () => {
	let e = Ac();
	e?.bus && e.bus.publish(Cf, { timestamp: Date.now() }).catch(() => {}), Df && Df.postMessage({
		type: Cf,
		timestamp: Date.now()
	});
}, Pf = (e) => {
	let t = Ac();
	t?.bus && t.bus.publish(wf, {
		noteId: e,
		timestamp: Date.now()
	}).catch(() => {}), Df && Df.postMessage({
		type: wf,
		noteId: e,
		timestamp: Date.now()
	});
}, Ff = (e, t) => {
	let n = [], r = Ac();
	if (r?.bus) {
		let i = r.bus.subscribe(Cf, () => {
			e();
		});
		if (n.push(() => {
			Promise.resolve(i).then((e) => typeof e == "function" && e()).catch(() => {});
		}), t) {
			let e = r.bus.subscribe(wf, (e) => {
				let n = (e?.p ?? e?.payload ?? e)?.noteId;
				n && t(n);
			});
			n.push(() => {
				Promise.resolve(e).then((e) => typeof e == "function" && e()).catch(() => {});
			});
		}
	}
	if (Df) {
		let r = (n) => {
			n.data?.type === "moment-notes:detached-note-refresh" ? e() : n.data?.type === "moment-notes:detached-note-changed" && t && t(n.data.noteId);
		};
		Df.addEventListener("message", r), n.push(() => Df?.removeEventListener("message", r));
	}
	return () => {
		n.forEach((e) => e());
	};
}, If = ["data-tooltip"], Lf = ["data-tooltip"], Rf = ["data-tooltip"], zf = /*#__PURE__*/ Z(/* @__PURE__ */ z({
	__name: "NoteCardHeader",
	props: /*@__PURE__*/ si({
		note: {},
		isEditing: { type: Boolean },
		isFullScreen: { type: Boolean },
		isImmersiveFullScreen: { type: Boolean }
	}, {
		title: { default: "" },
		titleModifiers: {}
	}),
	emits: /*@__PURE__*/ si([
		"toggle-pin",
		"enter-edit",
		"save-edit",
		"cancel-edit",
		"toggle-preview"
	], ["update:title"]),
	setup(e, { emit: t }) {
		let n = e, r = Di(e, "title"), i = t, a = Il(), o = Wl(), s = q(() => o.previewNoteId === n.note.id), c = q(() => !!n.isFullScreen), l = kf(), u = async () => {
			let e = tl[n.note.color] || tl.yellow;
			await Mf({
				id: n.note.id,
				title: n.note.title,
				backgroundColor: o.isDark ? e.darkBg : e.lightBg
			}) === "failed" && o.showToast("独立便签窗口打开失败", "error");
		}, d = (e) => {
			let t = a.getEventKeyString(e);
			if (!t) return;
			let n = a.shortcuts.find((e) => e.currentKey === t);
			n ? n.id === "saveEdit" ? (e.preventDefault(), e.stopPropagation(), i("save-edit")) : n.id === "cancelEdit" && (e.preventDefault(), e.stopPropagation(), i("cancel-edit")) : e.key === "Enter" && (e.preventDefault(), e.stopPropagation(), i("save-edit"));
		};
		return (t, n) => (V(), H(B, null, [
			!e.note.isDeleted && !I(l) ? (V(), H("div", {
				key: 0,
				class: O(["header-left-actions", { "is-full-screen": c.value }])
			}, [
				W("button", {
					class: O(["pin-btn", { active: e.note.isPinned }]),
					"data-tooltip": e.note.isPinned ? "取消置顶" : "置顶便签",
					onClick: n[0] ||= J((e) => i("toggle-pin"), ["stop"])
				}, [G(I(Lu), { class: "pin-icon" })], 10, If),
				c.value ? K("", !0) : (V(), H("button", {
					key: 0,
					class: "detach-btn",
					"aria-label": "在独立窗口打开",
					"data-tooltip": "在独立窗口打开",
					onClick: J(u, ["stop"])
				}, [G(I(gu), { class: "detach-icon" })])),
				W("button", {
					class: O(["preview-btn", { active: s.value }]),
					"data-tooltip": s.value ? "收起全屏" : "全屏显示便签",
					onClick: n[1] ||= J((e) => i("toggle-preview"), ["stop"])
				}, [s.value ? (V(), U(I(Au), {
					key: 0,
					class: "preview-icon"
				})) : (V(), U(I(Ou), {
					key: 1,
					class: "preview-icon"
				}))], 10, Lf)
			], 2)) : K("", !0),
			!e.isEditing && !e.note.isDeleted ? (V(), H("button", {
				key: 1,
				class: O(["edit-trigger-btn absolute-edit-btn", {
					"is-full-screen": c.value,
					"is-immersive-full-screen": c.value && e.isImmersiveFullScreen
				}]),
				"data-tooltip": "编辑便签",
				onClick: n[2] ||= J((e) => i("enter-edit"), ["stop"])
			}, [G(I(Fu), { class: "edit-icon" })], 2)) : K("", !0),
			e.isEditing || e.note.title ? (V(), H("div", {
				key: 2,
				class: O(["card-header", { "is-full-screen": c.value }])
			}, [e.isEditing ? Ln((V(), H("input", {
				key: 0,
				"onUpdate:modelValue": n[3] ||= (e) => r.value = e,
				type: "text",
				placeholder: "标题 (可选)...",
				class: O(["title-input", { "is-full-screen": c.value }]),
				onKeydown: d
			}, null, 34)), [[ks, r.value]]) : e.note.title ? (V(), H("h3", {
				key: 1,
				class: O(["card-title", { "is-full-screen": c.value }]),
				"data-tooltip": e.note.title,
				"data-tooltip-only-overflow": ""
			}, j(e.note.title), 11, Rf)) : K("", !0)], 2)) : K("", !0)
		], 64));
	}
}), [["__scopeId", "data-v-37a74fe5"]]);
//#endregion
//#region src/utils/useNoteTagMeasure.ts
function Bf(e) {
	let t = Wl(), n = () => /* @__PURE__ */ Jt(e) ? e.value : typeof e == "function" ? e() : e, r = /* @__PURE__ */ F(null), i = /* @__PURE__ */ F(null), a = n()?.tags, o = /* @__PURE__ */ F(Array.isArray(a) ? [...a] : []), s = /* @__PURE__ */ F(!1), c = /* @__PURE__ */ F(""), l = null, u = 0, d = (e = !1) => {
		let a = n()?.tags;
		if (!a || a.length === 0) {
			o.value.length > 0 && (o.value = []), s.value !== !1 && (s.value = !1), c.value !== "" && (c.value = ""), u = 0;
			return;
		}
		let l = a.map((e) => t.prefixTagWithHash ? `#${e}` : e).join(" ");
		c.value !== l && (c.value = l), Tn(() => {
			let t = r.value;
			if (!t) {
				o.value = [...a];
				return;
			}
			let n = t.clientWidth;
			if (n === 0) {
				o.value.length === 0 && a.length > 0 && (o.value = [...a]);
				return;
			}
			if (!e && n === u && o.value.length > 0) return;
			u = n;
			let c = t.children;
			if (c.length < 2) {
				(o.value.length !== a.length || !o.value.every((e, t) => e === a[t])) && (o.value = [...a]), s.value !== !1 && (s.value = !1);
				return;
			}
			let l = i.value, d = l ? l.offsetWidth : 30, f = [], p = [], m = a.length;
			for (let e = 0; e < m; e++) {
				let t = c[e];
				if (!t) continue;
				let n = t.offsetTop, r = t.offsetLeft, i = t.offsetWidth, a = f.findIndex((e) => Math.abs(e - n) < 5);
				a === -1 && (f.push(n), f.sort((e, t) => e - t), a = f.indexOf(n)), p.push({
					index: e,
					offsetLeft: r,
					offsetWidth: i,
					offsetTop: n
				});
			}
			let h = t.clientWidth, g = f.map(() => []);
			p.forEach((e) => {
				let t = f.findIndex((t) => Math.abs(t - e.offsetTop) < 5);
				t !== -1 && g[t].push(e);
			});
			let _ = g.length, v = [], y = !1;
			if (_ <= 2) v = [...a], y = !1;
			else {
				y = !0;
				let e = -1, t = g[1];
				if (t && t.length > 0) for (let n = t.length - 1; n >= 0; n--) {
					let r = t[n];
					if (h - (r.offsetLeft + r.offsetWidth) >= 6 + d) {
						e = r.index;
						break;
					}
				}
				if (e === -1) {
					let t = g[0];
					if (t && t.length > 0) for (let n = t.length - 1; n >= 0; n--) {
						let r = t[n];
						if (h - (r.offsetLeft + r.offsetWidth) >= 6 + d) {
							e = r.index;
							break;
						}
					}
				}
				v = e === -1 ? a.length > 0 ? [a[0]] : [] : a.slice(0, e + 1);
			}
			o.value.length === v.length && o.value.every((e, t) => e === v[t]) || (o.value = v), s.value !== y && (s.value = y);
		});
	};
	return Gn(() => n()?.tags, () => {
		d(!0);
	}, {
		deep: !0,
		immediate: !0
	}), Gn(() => t.prefixTagWithHash, () => {
		d(!0);
	}), Gn(r, (e, t) => {
		l && (t && l.unobserve(t), e && (l.observe(e), d(!0)));
	}), Rr(() => {
		if (window.ResizeObserver) {
			l = new ResizeObserver((e) => {
				for (let t of e) {
					let e = t.contentRect.width;
					e === 0 || e === u && o.value.length > 0 || d();
				}
			});
			let e = r.value;
			e && l.observe(e);
		}
		d(!0);
	}), Vr(() => {
		l &&= (l.disconnect(), null);
	}), {
		measureContainerRef: r,
		measureEllipsisRef: i,
		visibleTags: o,
		hasMore: s,
		allTagsText: c,
		calculateVisibleTags: d
	};
}
//#endregion
//#region src/utils/imageHandler.ts
var Vf = /* @__PURE__ */ F(!1), Hf = /* @__PURE__ */ F(""), Uf = /* @__PURE__ */ F([]), Wf = /* @__PURE__ */ F(0);
function Gf(e, t = [], n = 0) {
	if (!e) return;
	let r = t.length > 0 ? t : [e], i = n >= 0 && n < r.length ? n : Math.max(0, r.indexOf(e));
	Uf.value = r, Wf.value = i === -1 ? 0 : i, Hf.value = r[Wf.value] || e, Vf.value = !0;
}
function Kf() {
	Uf.value.length <= 1 || (Wf.value = (Wf.value - 1 + Uf.value.length) % Uf.value.length, Hf.value = Uf.value[Wf.value]);
}
function qf() {
	Uf.value.length <= 1 || (Wf.value = (Wf.value + 1) % Uf.value.length, Hf.value = Uf.value[Wf.value]);
}
function Jf() {
	Vf.value = !1, Hf.value = "", Uf.value = [], Wf.value = 0;
}
function Yf(e) {
	if (!e || e <= 0) return "0 B";
	let t = [
		"B",
		"KB",
		"MB",
		"GB"
	], n = Math.floor(Math.log(e) / Math.log(1024));
	return `${(e / 1024 ** n).toFixed(n === 0 ? 0 : 1)} ${t[n]}`;
}
async function Xf(e, t) {
	let n = typeof window < "u" ? window : globalThis.window, r = n && typeof n.showSaveFilePicker == "function" ? n.showSaveFilePicker.bind(n) : typeof globalThis.showSaveFilePicker == "function" ? globalThis.showSaveFilePicker : null;
	if (r) try {
		let n = t.includes(".") && t.split(".").pop() || "", i = await (await r({
			suggestedName: t,
			types: n ? [{
				description: `${n.toUpperCase()} 文件`,
				accept: { [e.type || "application/octet-stream"]: [`.${n}`] }
			}] : void 0
		})).createWritable();
		return await i.write(e), await i.close(), "saved";
	} catch (e) {
		if (e.name === "AbortError") return "canceled";
		console.warn("[downloadBlob] showSaveFilePicker failed, trying fallback:", e);
	}
	try {
		let r = typeof document < "u" ? document : n?.document;
		if (!r?.createElement) return "failed";
		let i = URL.createObjectURL(e), a = r.createElement("a");
		return a.href = i, a.download = t || "download", a.target = "_blank", r.body.appendChild(a), a.click(), r.body.removeChild(a), setTimeout(() => URL.revokeObjectURL(i), 15e3), "fallback";
	} catch (e) {
		return console.error("[downloadBlob] fallback <a> download failed:", e), "failed";
	}
}
function Zf(e) {
	let t = [];
	if ("clipboardData" in e && e.clipboardData?.files && e.clipboardData.files.length > 0) for (let n = 0; n < e.clipboardData.files.length; n++) t.push(e.clipboardData.files[n]);
	else if ("dataTransfer" in e && e.dataTransfer?.files && e.dataTransfer.files.length > 0) for (let n = 0; n < e.dataTransfer.files.length; n++) t.push(e.dataTransfer.files[n]);
	return t;
}
async function Qf(e, t) {
	let n = await al.saveImage(e, {
		originalName: e.name,
		autoCompress: t?.autoCompress !== !1,
		maxSizeMB: t?.maxSizeMB || 5
	});
	dl.syncPendingImages().catch((e) => {
		console.warn("[ImageHandler] Auto sync attachment error:", e);
	});
	let r = n.meta.type || "file", i = (e.name || "附件").replace(/[\[\]()]/g, ""), a = "";
	return a = r === "image" ? `\n![${i}](${n.path})\n` : r === "audio" ? `\n[audio:${i}](${n.path})\n` : r === "video" ? `\n[video:${i}](${n.path})\n` : `\n[📎 ${i} (${Yf(e.size)})](${n.path})\n`, {
		id: n.id,
		path: n.path,
		url: n.url,
		markdownText: a,
		type: r,
		originalName: e.name,
		size: e.size
	};
}
//#endregion
//#region node_modules/marked/lib/marked.esm.js
function $f() {
	return {
		async: !1,
		breaks: !1,
		extensions: null,
		gfm: !0,
		hooks: null,
		pedantic: !1,
		renderer: null,
		silent: !1,
		tokenizer: null,
		walkTokens: null
	};
}
var ep = $f();
function tp(e) {
	ep = e;
}
var np = { exec: () => null };
function rp(e) {
	let t = [];
	return (n) => {
		let r = Math.max(0, Math.min(3, n - 1)), i = t[r];
		return i || (i = e(r), t[r] = i), i;
	};
}
function Q(e, t = "") {
	let n = typeof e == "string" ? e : e.source, r = {
		replace: (e, t) => {
			let i = typeof t == "string" ? t : t.source;
			return i = i.replace(ap.caret, "$1"), n = n.replace(e, i), r;
		},
		getRegex: () => new RegExp(n, t)
	};
	return r;
}
var ip = ((e = "") => {
	try {
		return !!RegExp("(?<=1)(?<!1)" + e);
	} catch {
		return !1;
	}
})(), ap = {
	codeRemoveIndent: /^(?: {1,4}| {0,3}\t)/gm,
	outputLinkReplace: /\\([\[\]])/g,
	indentCodeCompensation: /^(\s+)(?:```)/,
	beginningSpace: /^\s+/,
	endingHash: /#$/,
	startingSpaceChar: /^ /,
	endingSpaceChar: / $/,
	nonSpaceChar: /[^ ]/,
	newLineCharGlobal: /\n/g,
	tabCharGlobal: /\t/g,
	multipleSpaceGlobal: /\s+/g,
	blankLine: /^[ \t]*$/,
	doubleBlankLine: /\n[ \t]*\n[ \t]*$/,
	blockquoteStart: /^ {0,3}>/,
	blockquoteSetextReplace: /\n {0,3}((?:=+|-+) *)(?=\n|$)/g,
	blockquoteSetextReplace2: /^ {0,3}>[ \t]?/gm,
	listReplaceNesting: /^ {1,4}(?=( {4})*[^ ])/g,
	listIsTask: /^\[[ xX]\] +\S/,
	listReplaceTask: /^\[[ xX]\] +/,
	listTaskCheckbox: /\[[ xX]\]/,
	anyLine: /\n.*\n/,
	hrefBrackets: /^<(.*)>$/,
	tableDelimiter: /[:|]/,
	tableAlignChars: /^\||\| *$/g,
	tableRowBlankLine: /\n[ \t]*$/,
	tableAlignRight: /^ *-+: *$/,
	tableAlignCenter: /^ *:-+: *$/,
	tableAlignLeft: /^ *:-+ *$/,
	startATag: /^<a /i,
	endATag: /^<\/a>/i,
	startPreScriptTag: /^<(pre|code|kbd|script)(\s|>)/i,
	endPreScriptTag: /^<\/(pre|code|kbd|script)(\s|>)/i,
	startAngleBracket: /^</,
	endAngleBracket: />$/,
	pedanticHrefTitle: /^([^'"]*[^\s])\s+(['"])(.*)\2/,
	unicodeAlphaNumeric: /[\p{L}\p{N}]/u,
	escapeTest: /[&<>"']/,
	escapeReplace: /[&<>"']/g,
	escapeTestNoEncode: /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/,
	escapeReplaceNoEncode: /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/g,
	caret: /(^|[^\[])\^/g,
	percentDecode: /%25/g,
	findPipe: /\|/g,
	splitPipe: / \|/,
	slashPipe: /\\\|/g,
	carriageReturn: /\r\n|\r/g,
	spaceLine: /^ +$/gm,
	notSpaceStart: /^\S*/,
	endingNewline: /\n$/,
	listItemRegex: (e) => RegExp(`^( {0,3}${e})((?:[	 ][^\\n]*)?(?:\\n|$))`),
	nextBulletRegex: rp((e) => RegExp(`^ {0,${e}}(?:[*+-]|\\d{1,9}[.)])((?:[ 	][^\\n]*)?(?:\\n|$))`)),
	hrRegex: rp((e) => RegExp(`^ {0,${e}}((?:- *){3,}|(?:_ *){3,}|(?:\\* *){3,})(?:\\n+|$)`)),
	fencesBeginRegex: rp((e) => RegExp(`^ {0,${e}}(?:\`\`\`|~~~)`)),
	headingBeginRegex: rp((e) => RegExp(`^ {0,${e}}#`)),
	htmlBeginRegex: rp((e) => RegExp(`^ {0,${e}}<(?:[a-z].*>|!--)`, "i")),
	blockquoteBeginRegex: rp((e) => RegExp(`^ {0,${e}}>`))
}, op = /^(?:[ \t]*(?:\n|$))+/, sp = /^((?: {4}| {0,3}\t)[^\n]+(?:\n(?:[ \t]*(?:\n|$))*)?)+/, cp = /^ {0,3}(`{3,}(?=[^`\n]*(?:\n|$))|~{3,})([^\n]*)(?:\n|$)(?:|([\s\S]*?)(?:\n|$))(?: {0,3}\1[~`]* *(?=\n|$)|$)/, lp = /^ {0,3}((?:-[\t ]*){3,}|(?:_[ \t]*){3,}|(?:\*[ \t]*){3,})(?:\n+|$)/, up = /^ {0,3}(#{1,6})(?=\s|$)(.*)(?:\n+|$)/, dp = / {0,3}(?:[*+-]|\d{1,9}[.)])/, fp = /^(?!bull |blockCode|fences|blockquote|heading|html|table)((?:.|\n(?!\s*?\n|bull |blockCode|fences|blockquote|heading|html|table))+?)\n {0,3}(=+|-+) *(?:\n+|$)/, pp = Q(fp).replace(/bull/g, dp).replace(/blockCode/g, /(?: {4}| {0,3}\t)/).replace(/fences/g, / {0,3}(?:`{3,}|~{3,})/).replace(/blockquote/g, / {0,3}>/).replace(/heading/g, / {0,3}#{1,6}(?:\s|$)/).replace(/html/g, / {0,3}<[^\n>]+>\n/).replace(/\|table/g, "").getRegex(), mp = Q(fp).replace(/bull/g, dp).replace(/blockCode/g, /(?: {4}| {0,3}\t)/).replace(/fences/g, / {0,3}(?:`{3,}|~{3,})/).replace(/blockquote/g, / {0,3}>/).replace(/heading/g, / {0,3}#{1,6}(?:\s|$)/).replace(/html/g, / {0,3}<[^\n>]+>\n/).replace(/table/g, / {0,3}\|?(?:[:\- ]*\|)+[\:\- ]*\n/).getRegex(), hp = /^([^\n]+(?:\n(?!hr|heading|lheading|blockquote|fences|list|html|table|[ \t]+\n)[^\n]+)*)/, gp = /^[^\n]+/, _p = /(?!\s*\])(?:\\[\s\S]|[^\[\]\\])+/, vp = Q(/^ {0,3}\[(label)\]: *(?:\n[ \t]*)?([^<\s][^\s]*|<.*?>)(?:(?: +(?:\n[ \t]*)?| *\n[ \t]*)(title))? *(?:\n+|$)/).replace("label", _p).replace("title", /(?:"(?:\\"?|[^"\\])*"|'[^'\n]*(?:\n[^'\n]+)*\n?'|\([^()]*\))/).getRegex(), yp = Q(/^(bull)([ \t][^\n]*?)?(?:\n|$)/).replace(/bull/g, dp).getRegex(), bp = "address|article|aside|base|basefont|blockquote|body|caption|center|col|colgroup|dd|details|dialog|dir|div|dl|dt|fieldset|figcaption|figure|footer|form|frame|frameset|h[1-6]|head|header|hr|html|iframe|legend|li|link|main|menu|menuitem|meta|nav|noframes|ol|optgroup|option|p|param|search|section|summary|table|tbody|td|tfoot|th|thead|title|tr|track|ul", xp = /<!--(?:-?>|[\s\S]*?(?:-->|$))/, Sp = Q("^ {0,3}(?:<(script|pre|style|textarea)[\\s>][\\s\\S]*?(?:</\\1>[^\\n]*\\n*|$)|comment[^\\n]*(\\n+|$)|<\\?[\\s\\S]*?(?:\\?>[^\\n]*\\n*|$)|<![A-Z][\\s\\S]*?(?:>[^\\n]*\\n*|$)|<!\\[CDATA\\[[\\s\\S]*?(?:\\]\\]>[^\\n]*\\n*|$)|</?(tag)(?: +|\\n|/?>)[\\s\\S]*?(?:(?:\\n[ 	]*)+\\n|$)|<(?!script|pre|style|textarea)([a-z][\\w-]*)(?:attribute)*? */?>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n[ 	]*)+\\n|$)|</(?!script|pre|style|textarea)[a-z][\\w-]*\\s*>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n[ 	]*)+\\n|$))", "i").replace("comment", xp).replace("tag", bp).replace("attribute", / +[a-zA-Z:_][\w.:-]*(?: *= *"[^"\n]*"| *= *'[^'\n]*'| *= *[^\s"'=<>`]+)?/).getRegex(), Cp = (e) => Q(hp).replace("hr", lp).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("|table", "").replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~~~)[^\\n]*\\n").replace("list", e).replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", bp).getRegex(), wp = Cp(/ {0,3}(?:[*+-]|1[.)])[ \t]+[^ \t\n]/), Tp = Cp(/ {0,3}(?:[*+-]|\d{1,9}[.)])(?:[ \t]|\n|$)/), Ep = {
	blockquote: Q(/^( {0,3}> ?(paragraph|[^\n]*)(?:\n|$))+/).replace("paragraph", Tp).getRegex(),
	code: sp,
	def: vp,
	fences: cp,
	heading: up,
	hr: lp,
	html: Sp,
	lheading: pp,
	list: yp,
	newline: op,
	paragraph: wp,
	table: np,
	text: gp
}, Dp = Q("^ *([^\\n ].*)\\n {0,3}((?:\\| *)?:?-+:? *(?:\\| *:?-+:? *)*(?:\\| *)?)(?:\\n((?:(?! *\\n|hr|heading|blockquote|code|fences|list|html).*(?:\\n|$))*)\\n*|$)").replace("hr", lp).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("blockquote", " {0,3}>").replace("code", "(?: {4}| {0,3}	)[^\\n]").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~~~)[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)])[ \\t]").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", bp).getRegex(), Op = {
	...Ep,
	lheading: mp,
	table: Dp,
	paragraph: Q(hp).replace("hr", lp).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("table", Dp).replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~~~)[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)])[ \\t]+[^ \\t\\n]").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", bp).getRegex()
}, kp = {
	...Ep,
	html: Q("^ *(?:comment *(?:\\n|\\s*$)|<(tag)[\\s\\S]+?</\\1> *(?:\\n{2,}|\\s*$)|<tag(?:\"[^\"]*\"|'[^']*'|\\s[^'\"/>\\s]*)*?/?> *(?:\\n{2,}|\\s*$))").replace("comment", xp).replace(/tag/g, "(?!(?:a|em|strong|small|s|cite|q|dfn|abbr|data|time|code|var|samp|kbd|sub|sup|i|b|u|mark|ruby|rt|rp|bdi|bdo|span|br|wbr|ins|del|img)\\b)\\w+(?!:|[^\\w\\s@]*@)\\b").getRegex(),
	def: /^ *\[([^\]]+)\]: *<?([^\s>]+)>?(?: +(["(][^\n]+[")]))? *(?:\n+|$)/,
	heading: /^(#{1,6})(.*)(?:\n+|$)/,
	fences: np,
	lheading: /^(.+?)\n {0,3}(=+|-+) *(?:\n+|$)/,
	paragraph: Q(hp).replace("hr", lp).replace("heading", " *#{1,6} *[^\n]").replace("lheading", pp).replace("|table", "").replace("blockquote", " {0,3}>").replace("|fences", "").replace("|list", "").replace("|html", "").replace("|tag", "").getRegex()
}, Ap = /^\\([!"#$%&'()*+,\-./:;<=>?@\[\]\\^_`{|}~])/, jp = /^(`+)([^`]|[^`][\s\S]*?[^`])\1(?!`)/, Mp = /^( {2,}|\\)\n(?!\s*$)/, Np = /^(`+|[^`])(?:(?= {2,}\n)|[\s\S]*?(?:(?=[\\<!\[`*_]|\b_|$)|[^ ](?= {2,}\n)))/, Pp = /[\p{P}\p{S}]/u, Fp = /[\s\p{P}\p{S}]/u, Ip = /[^\s\p{P}\p{S}]/u, Lp = Q(/^((?![*_])punctSpace)/, "u").replace(/punctSpace/g, Fp).getRegex(), Rp = /(?!~)[\p{P}\p{S}]/u, zp = /(?!~)[\s\p{P}\p{S}]/u, Bp = /(?:[^\s\p{P}\p{S}]|~)/u, Vp = Q(/link|precode-code|html/, "g").replace("link", /\[(?:[^\[\]`]|(?<a>`+)[^`]+\k<a>(?!`))*?\]\((?:\\[\s\S]|[^\\\(\)]|\((?:\\[\s\S]|[^\\\(\)])*\))*\)/).replace("precode-", ip ? "(?<!`)()" : "(^^|[^`])").replace("code", /(?<b>`+)[^`]+\k<b>(?!`)/).replace("html", /<(?! )[^<>]*?>/).getRegex(), Hp = /^(?:\*+(?:((?!\*)punct)|([^\s*]))?)|^_+(?:((?!_)punct)|([^\s_]))?/, Up = Q(Hp, "u").replace(/punct/g, Pp).getRegex(), Wp = Q(Hp, "u").replace(/punct/g, Rp).getRegex(), Gp = "^[^_*]*?__[^_*]*?\\*[^_*]*?(?=__)|[^*]+(?=[^*])|(?!\\*)punct(\\*+)(?=[\\s]|$)|notPunctSpace(\\*+)(?!\\*)(?=punctSpace|$)|(?!\\*)punctSpace(\\*+)(?=notPunctSpace)|[\\s](\\*+)(?!\\*)(?=punct)|(?!\\*)punct(\\*+)(?!\\*)(?=punct)|notPunctSpace(\\*+)(?=notPunctSpace)", Kp = Q(Gp, "gu").replace(/notPunctSpace/g, Ip).replace(/punctSpace/g, Fp).replace(/punct/g, Pp).getRegex(), qp = Q(Gp, "gu").replace(/notPunctSpace/g, Bp).replace(/punctSpace/g, zp).replace(/punct/g, Rp).getRegex(), Jp = Q("^[^_*]*?\\*\\*[^_*]*?_[^_*]*?(?=\\*\\*)|[^_]+(?=[^_])|(?!_)punct(_+)(?=[\\s]|$)|notPunctSpace(_+)(?!_)(?=punctSpace|$)|(?!_)punctSpace(_+)(?=notPunctSpace)|[\\s](_+)(?!_)(?=punct)|(?!_)punct(_+)(?!_)(?=punct)", "gu").replace(/notPunctSpace/g, Ip).replace(/punctSpace/g, Fp).replace(/punct/g, Pp).getRegex(), Yp = Q(/^~~?(?:((?!~)punct)|[^\s~])/, "u").replace(/punct/g, Pp).getRegex(), Xp = Q("^[^~]+(?=[^~])|(?!~)punct(~~?)(?=[\\s]|$)|notPunctSpace(~~?)(?!~)(?=punctSpace|$)|(?!~)punctSpace(~~?)(?=notPunctSpace)|[\\s](~~?)(?!~)(?=punct)|(?!~)punct(~~?)(?!~)(?=punct)|notPunctSpace(~~?)(?=notPunctSpace)", "gu").replace(/notPunctSpace/g, Ip).replace(/punctSpace/g, Fp).replace(/punct/g, Pp).getRegex(), Zp = Q(/\\(punct)/, "gu").replace(/punct/g, Pp).getRegex(), Qp = Q(/^<(scheme:[^\s\x00-\x1f<>]*|email)>/).replace("scheme", /[a-zA-Z][a-zA-Z0-9+.-]{1,31}/).replace("email", /[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(@)[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+(?![-_])/).getRegex(), $p = Q(xp).replace("(?:-->|$)", "-->").getRegex(), em = Q("^comment|^</[a-zA-Z][\\w:-]*\\s*>|^<[a-zA-Z][\\w-]*(?:attribute)*?\\s*/?>|^<\\?[\\s\\S]*?\\?>|^<![a-zA-Z]+\\s[\\s\\S]*?>|^<!\\[CDATA\\[[\\s\\S]*?\\]\\]>").replace("comment", $p).replace("attribute", /\s+[a-zA-Z:_][\w.:-]*(?:\s*=\s*"[^"]*"|\s*=\s*'[^']*'|\s*=\s*[^\s"'=<>`]+)?/).getRegex(), tm = /(?:\[(?:\\[\s\S]|[^\[\]\\])*\]|\\[\s\S]|`+(?!`)[^`]*?`+(?!`)|``+(?=\])|[^\[\]\\`])*?/, nm = Q(/^!?\[(label)\]\(\s*(href)(?:(?:[ \t]+(?:\n[ \t]*)?|\n[ \t]*)(title))?\s*\)/).replace("label", tm).replace("href", /<(?:\\.|[^\n<>\\])+>|[^ \t\n\x00-\x1f]+|(?=\))/).replace("title", /"(?:\\"?|[^"\\])*"|'(?:\\'?|[^'\\])*'|\((?:\\\)?|[^)\\])*\)/).getRegex(), rm = Q(/^!?\[(label)\]\[(ref)\]/).replace("label", tm).replace("ref", _p).getRegex(), im = Q(/^!?\[(ref)\](?:\[\])?/).replace("ref", _p).getRegex(), am = Q("reflink|nolink(?!\\()", "g").replace("reflink", rm).replace("nolink", im).getRegex(), om = /[hH][tT][tT][pP][sS]?|[fF][tT][pP]/, sm = {
	_backpedal: np,
	anyPunctuation: Zp,
	autolink: Qp,
	blockSkip: Vp,
	br: Mp,
	code: jp,
	del: np,
	delLDelim: np,
	delRDelim: np,
	emStrongLDelim: Up,
	emStrongRDelimAst: Kp,
	emStrongRDelimUnd: Jp,
	escape: Ap,
	link: nm,
	nolink: im,
	punctuation: Lp,
	reflink: rm,
	reflinkSearch: am,
	tag: em,
	text: Np,
	url: np
}, cm = {
	...sm,
	link: Q(/^!?\[(label)\]\((.*?)\)/).replace("label", tm).getRegex(),
	reflink: Q(/^!?\[(label)\]\s*\[([^\]]*)\]/).replace("label", tm).getRegex()
}, lm = {
	...sm,
	emStrongRDelimAst: qp,
	emStrongLDelim: Wp,
	delLDelim: Yp,
	delRDelim: Xp,
	url: Q(/^((?:protocol):\/\/|www\.)(?:[a-zA-Z0-9\-]+\.?)+[^\s<]*|^email/).replace("protocol", om).replace("email", /[A-Za-z0-9._+-]+(@)[a-zA-Z0-9-_]+(?:\.[a-zA-Z0-9-_]*[a-zA-Z0-9])+(?![-_])/).getRegex(),
	_backpedal: /(?:[^?!.,:;*_'"~()&]+|\([^)]*\)|&(?![a-zA-Z0-9]+;$)|[?!.,:;*_'"~)]+(?!$))+/,
	del: /^(~~?)(?=[^\s~])((?:\\[\s\S]|[^\\])*?(?:\\[\s\S]|[^\s~\\]))\1(?=[^~]|$)/,
	text: Q(/^(`+|~+|[^`~])(?:(?=[`~])|(?= {2,}\n)|(?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)|[\s\S]*?(?:(?=[\\<!\[`*~_]|\b_|protocol:\/\/|www\.|$)|[^ ](?= {2,}\n)|[^a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-](?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)))/).replace("protocol", om).getRegex()
}, um = {
	...lm,
	br: Q(Mp).replace("{2,}", "*").getRegex(),
	text: Q(lm.text).replace("\\b_", "\\b_| {2,}\\n").replace(/\{2,\}/g, "*").getRegex()
}, dm = {
	normal: Ep,
	gfm: Op,
	pedantic: kp
}, fm = {
	normal: sm,
	gfm: lm,
	breaks: um,
	pedantic: cm
}, pm = {
	"&": "&amp;",
	"<": "&lt;",
	">": "&gt;",
	"\"": "&quot;",
	"'": "&#39;"
}, mm = (e) => pm[e];
function hm(e, t) {
	if (t) {
		if (ap.escapeTest.test(e)) return e.replace(ap.escapeReplace, mm);
	} else if (ap.escapeTestNoEncode.test(e)) return e.replace(ap.escapeReplaceNoEncode, mm);
	return e;
}
function gm(e) {
	try {
		e = encodeURI(e).replace(ap.percentDecode, "%");
	} catch {
		return null;
	}
	return e;
}
function _m(e, t) {
	let n = e.replace(ap.findPipe, (e, t, n) => {
		let r = !1, i = t;
		for (; --i >= 0 && n[i] === "\\";) r = !r;
		return r ? "|" : " |";
	}).split(ap.splitPipe), r = 0;
	if (n[0].trim() || n.shift(), n.length > 0 && !n.at(-1)?.trim() && n.pop(), t) if (n.length > t) n.splice(t);
	else for (; n.length < t;) n.push("");
	for (; r < n.length; r++) n[r] = n[r].trim().replace(ap.slashPipe, "|");
	return n;
}
function vm(e, t, n) {
	let r = e.length;
	if (r === 0) return "";
	let i = 0;
	for (; i < r;) {
		let a = e.charAt(r - i - 1);
		if (a === t && !n) i++;
		else if (a !== t && n) i++;
		else break;
	}
	return e.slice(0, r - i);
}
function ym(e) {
	let t = e.split("\n"), n = t.length - 1;
	for (; n >= 0 && ap.blankLine.test(t[n]);) n--;
	return t.length - n <= 2 ? e : t.slice(0, n + 1).join("\n");
}
function bm(e, t) {
	if (e.indexOf(t[1]) === -1) return -1;
	let n = 0;
	for (let r = 0; r < e.length; r++) if (e[r] === "\\") r++;
	else if (e[r] === t[0]) n++;
	else if (e[r] === t[1] && (n--, n < 0)) return r;
	return n > 0 ? -2 : -1;
}
function xm(e, t = 0) {
	let n = t, r = "";
	for (let t of e) if (t === "	") {
		let e = 4 - n % 4;
		r += " ".repeat(e), n += e;
	} else r += t, n++;
	return r;
}
function Sm(e, t, n, r, i) {
	let a = t.href, o = t.title || null, s = e[1].replace(i.other.outputLinkReplace, "$1");
	r.state.inLink = !0;
	let c = {
		type: e[0].charAt(0) === "!" ? "image" : "link",
		raw: n,
		href: a,
		title: o,
		text: s,
		tokens: r.inlineTokens(s)
	};
	return r.state.inLink = !1, c;
}
function Cm(e, t, n) {
	let r = e.match(n.other.indentCodeCompensation);
	if (r === null) return t;
	let i = r[1];
	return t.split("\n").map((e) => {
		let t = e.match(n.other.beginningSpace);
		if (t === null) return e;
		let [r] = t;
		return r.length >= i.length ? e.slice(i.length) : e;
	}).join("\n");
}
var wm = class {
	options;
	rules;
	lexer;
	constructor(e) {
		this.options = e || ep;
	}
	space(e) {
		let t = this.rules.block.newline.exec(e);
		if (t && t[0].length > 0) return {
			type: "space",
			raw: t[0]
		};
	}
	code(e) {
		let t = this.rules.block.code.exec(e);
		if (t) {
			let e = this.options.pedantic ? t[0] : ym(t[0]);
			return {
				type: "code",
				raw: e,
				codeBlockStyle: "indented",
				text: e.replace(this.rules.other.codeRemoveIndent, "")
			};
		}
	}
	fences(e) {
		let t = this.rules.block.fences.exec(e);
		if (t) {
			let e = t[0], n = Cm(e, t[3] || "", this.rules);
			return {
				type: "code",
				raw: e,
				lang: t[2] ? t[2].trim().replace(this.rules.inline.anyPunctuation, "$1") : t[2],
				text: n
			};
		}
	}
	heading(e) {
		let t = this.rules.block.heading.exec(e);
		if (t) {
			let e = t[2].trim();
			if (this.rules.other.endingHash.test(e)) {
				let t = vm(e, "#");
				(this.options.pedantic || !t || this.rules.other.endingSpaceChar.test(t)) && (e = t.trim());
			}
			return {
				type: "heading",
				raw: vm(t[0], "\n"),
				depth: t[1].length,
				text: e,
				tokens: this.lexer.inline(e)
			};
		}
	}
	hr(e) {
		let t = this.rules.block.hr.exec(e);
		if (t) return {
			type: "hr",
			raw: vm(t[0], "\n")
		};
	}
	blockquote(e) {
		let t = this.rules.block.blockquote.exec(e);
		if (t) {
			let e = vm(t[0], "\n").split("\n"), n = "", r = "", i = [];
			for (; e.length > 0;) {
				let t = !1, a = [], o;
				for (o = 0; o < e.length; o++) if (this.rules.other.blockquoteStart.test(e[o])) a.push(e[o]), t = !0;
				else if (!t) a.push(e[o]);
				else break;
				e = e.slice(o);
				let s = a.join("\n"), c = s.replace(this.rules.other.blockquoteSetextReplace, "\n    $1").replace(this.rules.other.blockquoteSetextReplace2, "");
				n = n ? `${n}
${s}` : s, r = r ? `${r}
${c}` : c;
				let l = this.lexer.state.top;
				if (this.lexer.state.top = !0, this.lexer.blockTokens(c, i, !0), this.lexer.state.top = l, e.length === 0) break;
				let u = i.at(-1);
				if (u?.type === "code") break;
				if (u?.type === "blockquote") {
					let t = u, a = t.raw + "\n" + e.join("\n"), o = this.blockquote(a);
					i[i.length - 1] = o, n = n.substring(0, n.length - t.raw.length) + o.raw, r = r.substring(0, r.length - t.text.length) + o.text;
					break;
				} else if (u?.type === "list") {
					let t = u, a = t.raw + "\n" + e.join("\n"), o = this.list(a);
					i[i.length - 1] = o, n = n.substring(0, n.length - u.raw.length) + o.raw, r = r.substring(0, r.length - t.raw.length) + o.raw, e = a.substring(i.at(-1).raw.length).split("\n");
					continue;
				}
			}
			return {
				type: "blockquote",
				raw: n,
				tokens: i,
				text: r
			};
		}
	}
	list(e) {
		let t = this.rules.block.list.exec(e);
		if (t) {
			let n = t[1].trim(), r = n.length > 1, i = {
				type: "list",
				raw: "",
				ordered: r,
				start: r ? +n.slice(0, -1) : "",
				loose: !1,
				items: []
			};
			n = r ? `\\d{1,9}\\${n.slice(-1)}` : `\\${n}`, this.options.pedantic && (n = r ? n : "[*+-]");
			let a = this.rules.other.listItemRegex(n), o = !1;
			for (; e;) {
				let n = !1, r = "", s = "";
				if (!(t = a.exec(e)) || this.rules.block.hr.test(e)) break;
				r = t[0], e = e.substring(r.length);
				let c = xm(t[2].split("\n", 1)[0], t[1].length), l = e.split("\n", 1)[0], u = !c.trim(), d = 0;
				if (this.options.pedantic ? (d = 2, s = c.trimStart()) : u ? d = t[1].length + 1 : (d = c.search(this.rules.other.nonSpaceChar), d = d > 4 ? 1 : d, s = c.slice(d), d += t[1].length), u && this.rules.other.blankLine.test(l) && (r += l + "\n", e = e.substring(l.length + 1), n = !0), !n) {
					let t = this.rules.other.nextBulletRegex(d), n = this.rules.other.hrRegex(d), i = this.rules.other.fencesBeginRegex(d), a = this.rules.other.headingBeginRegex(d), o = this.rules.other.htmlBeginRegex(d), f = this.rules.other.blockquoteBeginRegex(d);
					for (; e;) {
						let p = e.split("\n", 1)[0], m;
						if (l = p, this.options.pedantic ? (l = l.replace(this.rules.other.listReplaceNesting, "  "), m = l) : m = l.replace(this.rules.other.tabCharGlobal, "    "), i.test(l) || a.test(l) || o.test(l) || f.test(l) || t.test(l) || n.test(l)) break;
						if (m.search(this.rules.other.nonSpaceChar) >= d || !l.trim()) s += "\n" + m.slice(d);
						else {
							if (u || c.replace(this.rules.other.tabCharGlobal, "    ").search(this.rules.other.nonSpaceChar) >= 4 || i.test(c) || a.test(c) || n.test(c)) break;
							s += "\n" + l;
						}
						u = !l.trim(), r += p + "\n", e = e.substring(p.length + 1), c = m.slice(d);
					}
				}
				i.loose || (o ? i.loose = !0 : this.rules.other.doubleBlankLine.test(r) && (o = !0)), i.items.push({
					type: "list_item",
					raw: r,
					task: !!this.options.gfm && this.rules.other.listIsTask.test(s),
					loose: !1,
					text: s,
					tokens: []
				}), i.raw += r;
			}
			let s = i.items.at(-1);
			if (s) s.raw = s.raw.trimEnd(), s.text = s.text.trimEnd();
			else return;
			i.raw = i.raw.trimEnd();
			for (let e of i.items) {
				this.lexer.state.top = !1, e.tokens = this.lexer.blockTokens(e.text, []);
				let t = e.tokens[0];
				if (e.task && (t?.type === "text" || t?.type === "paragraph")) {
					e.text = e.text.replace(this.rules.other.listReplaceTask, ""), t.raw = t.raw.replace(this.rules.other.listReplaceTask, ""), t.text = t.text.replace(this.rules.other.listReplaceTask, "");
					for (let e = this.lexer.inlineQueue.length - 1; e >= 0; e--) if (this.rules.other.listIsTask.test(this.lexer.inlineQueue[e].src)) {
						this.lexer.inlineQueue[e].src = this.lexer.inlineQueue[e].src.replace(this.rules.other.listReplaceTask, "");
						break;
					}
					let n = this.rules.other.listTaskCheckbox.exec(e.raw);
					if (n) {
						let t = {
							type: "checkbox",
							raw: n[0] + " ",
							checked: n[0] !== "[ ]"
						};
						e.checked = t.checked, i.loose ? e.tokens[0] && ["paragraph", "text"].includes(e.tokens[0].type) && "tokens" in e.tokens[0] && e.tokens[0].tokens ? (e.tokens[0].raw = t.raw + e.tokens[0].raw, e.tokens[0].text = t.raw + e.tokens[0].text, e.tokens[0].tokens.unshift(t)) : e.tokens.unshift({
							type: "paragraph",
							raw: t.raw,
							text: t.raw,
							tokens: [t]
						}) : e.tokens.unshift(t);
					}
				} else e.task &&= !1;
				if (!i.loose) {
					let t = e.tokens.filter((e) => e.type === "space");
					i.loose = t.length > 0 && t.some((e) => this.rules.other.anyLine.test(e.raw));
				}
			}
			if (i.loose) for (let e of i.items) {
				e.loose = !0;
				for (let t of e.tokens) t.type === "text" && (t.type = "paragraph");
			}
			return i;
		}
	}
	html(e) {
		let t = this.rules.block.html.exec(e);
		if (t) {
			let e = ym(t[0]);
			return {
				type: "html",
				block: !0,
				raw: e,
				pre: t[1] === "pre" || t[1] === "script" || t[1] === "style",
				text: e
			};
		}
	}
	def(e) {
		let t = this.rules.block.def.exec(e);
		if (t) {
			let e = t[1].toLowerCase().replace(this.rules.other.multipleSpaceGlobal, " "), n = t[2] ? t[2].replace(this.rules.other.hrefBrackets, "$1").replace(this.rules.inline.anyPunctuation, "$1") : "", r = t[3] ? t[3].substring(1, t[3].length - 1).replace(this.rules.inline.anyPunctuation, "$1") : t[3];
			return {
				type: "def",
				tag: e,
				raw: vm(t[0], "\n"),
				href: n,
				title: r
			};
		}
	}
	table(e) {
		let t = this.rules.block.table.exec(e);
		if (!t || !this.rules.other.tableDelimiter.test(t[2])) return;
		let n = _m(t[1]), r = t[2].replace(this.rules.other.tableAlignChars, "").split("|"), i = t[3]?.trim() ? t[3].replace(this.rules.other.tableRowBlankLine, "").split("\n") : [], a = {
			type: "table",
			raw: vm(t[0], "\n"),
			header: [],
			align: [],
			rows: []
		};
		if (n.length === r.length) {
			for (let e of r) this.rules.other.tableAlignRight.test(e) ? a.align.push("right") : this.rules.other.tableAlignCenter.test(e) ? a.align.push("center") : this.rules.other.tableAlignLeft.test(e) ? a.align.push("left") : a.align.push(null);
			for (let e = 0; e < n.length; e++) a.header.push({
				text: n[e],
				tokens: this.lexer.inline(n[e]),
				header: !0,
				align: a.align[e]
			});
			for (let e of i) a.rows.push(_m(e, a.header.length).map((e, t) => ({
				text: e,
				tokens: this.lexer.inline(e),
				header: !1,
				align: a.align[t]
			})));
			return a;
		}
	}
	lheading(e) {
		let t = this.rules.block.lheading.exec(e);
		if (t) {
			let e = t[1].trim();
			return {
				type: "heading",
				raw: vm(t[0], "\n"),
				depth: t[2].charAt(0) === "=" ? 1 : 2,
				text: e,
				tokens: this.lexer.inline(e)
			};
		}
	}
	paragraph(e) {
		let t = this.rules.block.paragraph.exec(e);
		if (t) {
			let e = t[1].charAt(t[1].length - 1) === "\n" ? t[1].slice(0, -1) : t[1];
			return {
				type: "paragraph",
				raw: t[0],
				text: e,
				tokens: this.lexer.inline(e)
			};
		}
	}
	text(e) {
		let t = this.rules.block.text.exec(e);
		if (t) return {
			type: "text",
			raw: t[0],
			text: t[0],
			tokens: this.lexer.inline(t[0])
		};
	}
	escape(e) {
		let t = this.rules.inline.escape.exec(e);
		if (t) return {
			type: "escape",
			raw: t[0],
			text: t[1]
		};
	}
	tag(e) {
		let t = this.rules.inline.tag.exec(e);
		if (t) return !this.lexer.state.inLink && this.rules.other.startATag.test(t[0]) ? this.lexer.state.inLink = !0 : this.lexer.state.inLink && this.rules.other.endATag.test(t[0]) && (this.lexer.state.inLink = !1), !this.lexer.state.inRawBlock && this.rules.other.startPreScriptTag.test(t[0]) ? this.lexer.state.inRawBlock = !0 : this.lexer.state.inRawBlock && this.rules.other.endPreScriptTag.test(t[0]) && (this.lexer.state.inRawBlock = !1), {
			type: "html",
			raw: t[0],
			inLink: this.lexer.state.inLink,
			inRawBlock: this.lexer.state.inRawBlock,
			block: !1,
			text: t[0]
		};
	}
	link(e) {
		let t = this.rules.inline.link.exec(e);
		if (t) {
			let e = t[2].trim();
			if (!this.options.pedantic && this.rules.other.startAngleBracket.test(e)) {
				if (!this.rules.other.endAngleBracket.test(e)) return;
				let t = vm(e.slice(0, -1), "\\");
				if ((e.length - t.length) % 2 == 0) return;
			} else {
				let e = bm(t[2], "()");
				if (e === -2) return;
				if (e > -1) {
					let n = (t[0].indexOf("!") === 0 ? 5 : 4) + t[1].length + e;
					t[2] = t[2].substring(0, e), t[0] = t[0].substring(0, n).trim(), t[3] = "";
				}
			}
			let n = t[2], r = "";
			if (this.options.pedantic) {
				let e = this.rules.other.pedanticHrefTitle.exec(n);
				e && (n = e[1], r = e[3]);
			} else r = t[3] ? t[3].slice(1, -1) : "";
			return n = n.trim(), this.rules.other.startAngleBracket.test(n) && (n = this.options.pedantic && !this.rules.other.endAngleBracket.test(e) ? n.slice(1) : n.slice(1, -1)), Sm(t, {
				href: n && n.replace(this.rules.inline.anyPunctuation, "$1"),
				title: r && r.replace(this.rules.inline.anyPunctuation, "$1")
			}, t[0], this.lexer, this.rules);
		}
	}
	reflink(e, t) {
		let n;
		if ((n = this.rules.inline.reflink.exec(e)) || (n = this.rules.inline.nolink.exec(e))) {
			let e = t[(n[2] || n[1]).replace(this.rules.other.multipleSpaceGlobal, " ").toLowerCase()];
			if (!e) {
				let e = n[0].charAt(0);
				return {
					type: "text",
					raw: e,
					text: e
				};
			}
			return Sm(n, e, n[0], this.lexer, this.rules);
		}
	}
	emStrong(e, t, n = "") {
		let r = this.rules.inline.emStrongLDelim.exec(e);
		if (!(!r || !r[1] && !r[2] && !r[3] && !r[4] || r[4] && n.match(this.rules.other.unicodeAlphaNumeric)) && (!(r[1] || r[3]) || !n || this.rules.inline.punctuation.exec(n))) {
			let n = [...r[0]].length - 1, i, a, o = n, s = 0, c = r[0][0] === "*" ? this.rules.inline.emStrongRDelimAst : this.rules.inline.emStrongRDelimUnd;
			for (c.lastIndex = 0, t = t.slice(-1 * e.length + n); (r = c.exec(t)) !== null;) {
				if (i = r[1] || r[2] || r[3] || r[4] || r[5] || r[6], !i) continue;
				if (a = [...i].length, r[3] || r[4]) {
					o += a;
					continue;
				} else if ((r[5] || r[6]) && n % 3 && !((n + a) % 3)) {
					s += a;
					continue;
				}
				if (o -= a, o > 0) continue;
				a = Math.min(a, a + o + s);
				let t = [...r[0]][0].length, c = e.slice(0, n + r.index + t + a);
				if (Math.min(n, a) % 2) {
					let e = c.slice(1, -1);
					return {
						type: "em",
						raw: c,
						text: e,
						tokens: this.lexer.inlineTokens(e)
					};
				}
				let l = c.slice(2, -2);
				return {
					type: "strong",
					raw: c,
					text: l,
					tokens: this.lexer.inlineTokens(l)
				};
			}
		}
	}
	codespan(e) {
		let t = this.rules.inline.code.exec(e);
		if (t) {
			let e = t[2].replace(this.rules.other.newLineCharGlobal, " "), n = this.rules.other.nonSpaceChar.test(e), r = this.rules.other.startingSpaceChar.test(e) && this.rules.other.endingSpaceChar.test(e);
			return n && r && (e = e.substring(1, e.length - 1)), {
				type: "codespan",
				raw: t[0],
				text: e
			};
		}
	}
	br(e) {
		let t = this.rules.inline.br.exec(e);
		if (t) return {
			type: "br",
			raw: t[0]
		};
	}
	del(e, t, n = "") {
		let r = this.rules.inline.delLDelim.exec(e);
		if (r && (!r[1] || !n || this.rules.inline.punctuation.exec(n))) {
			let n = [...r[0]].length - 1, i, a, o = n, s = this.rules.inline.delRDelim;
			for (s.lastIndex = 0, t = t.slice(-1 * e.length + n); (r = s.exec(t)) !== null;) {
				if (i = r[1] || r[2] || r[3] || r[4] || r[5] || r[6], !i || (a = [...i].length, a !== n)) continue;
				if (r[3] || r[4]) {
					o += a;
					continue;
				}
				if (o -= a, o > 0) continue;
				a = Math.min(a, a + o);
				let t = [...r[0]][0].length, s = e.slice(0, n + r.index + t + a), c = s.slice(n, -n);
				return {
					type: "del",
					raw: s,
					text: c,
					tokens: this.lexer.inlineTokens(c)
				};
			}
		}
	}
	autolink(e) {
		let t = this.rules.inline.autolink.exec(e);
		if (t) {
			let e, n;
			return t[2] === "@" ? (e = t[1], n = "mailto:" + e) : (e = t[1], n = e), {
				type: "link",
				raw: t[0],
				text: e,
				href: n,
				tokens: [{
					type: "text",
					raw: e,
					text: e
				}]
			};
		}
	}
	url(e) {
		let t;
		if (t = this.rules.inline.url.exec(e)) {
			let e, n;
			if (t[2] === "@") e = t[0], n = "mailto:" + e;
			else {
				let r;
				do
					r = t[0], t[0] = this.rules.inline._backpedal.exec(t[0])?.[0] ?? "";
				while (r !== t[0]);
				e = t[0], n = t[1] === "www." ? "http://" + t[0] : t[0];
			}
			return {
				type: "link",
				raw: t[0],
				text: e,
				href: n,
				tokens: [{
					type: "text",
					raw: e,
					text: e
				}]
			};
		}
	}
	inlineText(e) {
		let t = this.rules.inline.text.exec(e);
		if (t) {
			let e = this.lexer.state.inRawBlock;
			return {
				type: "text",
				raw: t[0],
				text: t[0],
				escaped: e
			};
		}
	}
}, Tm = class e {
	tokens;
	options;
	state;
	inlineQueue;
	tokenizer;
	constructor(e) {
		this.tokens = [], this.tokens.links = Object.create(null), this.options = e || ep, this.options.tokenizer = this.options.tokenizer || new wm(), this.tokenizer = this.options.tokenizer, this.tokenizer.options = this.options, this.tokenizer.lexer = this, this.inlineQueue = [], this.state = {
			inLink: !1,
			inRawBlock: !1,
			top: !0
		};
		let t = {
			other: ap,
			block: dm.normal,
			inline: fm.normal
		};
		this.options.pedantic ? (t.block = dm.pedantic, t.inline = fm.pedantic) : this.options.gfm && (t.block = dm.gfm, this.options.breaks ? t.inline = fm.breaks : t.inline = fm.gfm), this.tokenizer.rules = t;
	}
	static get rules() {
		return {
			block: dm,
			inline: fm
		};
	}
	static lex(t, n) {
		return new e(n).lex(t);
	}
	static lexInline(t, n) {
		return new e(n).inlineTokens(t);
	}
	lex(e) {
		e = e.replace(ap.carriageReturn, "\n"), this.blockTokens(e, this.tokens);
		for (let e = 0; e < this.inlineQueue.length; e++) {
			let t = this.inlineQueue[e];
			this.inlineTokens(t.src, t.tokens);
		}
		return this.inlineQueue = [], this.tokens;
	}
	blockTokens(e, t = [], n = !1) {
		this.tokenizer.lexer = this, this.options.pedantic && (e = e.replace(ap.tabCharGlobal, "    ").replace(ap.spaceLine, ""));
		let r = Infinity;
		for (; e;) {
			if (e.length < r) r = e.length;
			else {
				this.infiniteLoopError(e.charCodeAt(0));
				break;
			}
			let i;
			if (this.options.extensions?.block?.some((n) => (i = n.call({ lexer: this }, e, t)) ? (e = e.substring(i.raw.length), t.push(i), !0) : !1)) continue;
			if (i = this.tokenizer.space(e)) {
				e = e.substring(i.raw.length);
				let n = t.at(-1);
				i.raw.length === 1 && n !== void 0 ? n.raw += "\n" : t.push(i);
				continue;
			}
			if (i = this.tokenizer.code(e)) {
				e = e.substring(i.raw.length);
				let n = t.at(-1);
				n?.type === "paragraph" || n?.type === "text" ? (n.raw += (n.raw.endsWith("\n") ? "" : "\n") + i.raw, n.text += "\n" + i.text, this.inlineQueue.at(-1).src = n.text) : t.push(i);
				continue;
			}
			if (i = this.tokenizer.fences(e)) {
				e = e.substring(i.raw.length), t.push(i);
				continue;
			}
			if (i = this.tokenizer.heading(e)) {
				e = e.substring(i.raw.length), t.push(i);
				continue;
			}
			if (i = this.tokenizer.hr(e)) {
				e = e.substring(i.raw.length), t.push(i);
				continue;
			}
			if (i = this.tokenizer.blockquote(e)) {
				e = e.substring(i.raw.length), t.push(i);
				continue;
			}
			if (i = this.tokenizer.list(e)) {
				e = e.substring(i.raw.length), t.push(i);
				continue;
			}
			if (i = this.tokenizer.html(e)) {
				e = e.substring(i.raw.length), t.push(i);
				continue;
			}
			if (i = this.tokenizer.def(e)) {
				e = e.substring(i.raw.length);
				let n = t.at(-1);
				n?.type === "paragraph" || n?.type === "text" ? (n.raw += (n.raw.endsWith("\n") ? "" : "\n") + i.raw, n.text += "\n" + i.raw, this.inlineQueue.at(-1).src = n.text) : this.tokens.links[i.tag] || (this.tokens.links[i.tag] = {
					href: i.href,
					title: i.title
				}, t.push(i));
				continue;
			}
			if (i = this.tokenizer.table(e)) {
				e = e.substring(i.raw.length), t.push(i);
				continue;
			}
			if (i = this.tokenizer.lheading(e)) {
				e = e.substring(i.raw.length), t.push(i);
				continue;
			}
			let a = e;
			if (this.options.extensions?.startBlock) {
				let t = Infinity, n = e.slice(1), r;
				this.options.extensions.startBlock.forEach((e) => {
					r = e.call({ lexer: this }, n), typeof r == "number" && r >= 0 && (t = Math.min(t, r));
				}), t < Infinity && t >= 0 && (a = e.substring(0, t + 1));
			}
			if (this.state.top && (i = this.tokenizer.paragraph(a))) {
				let r = t.at(-1);
				n && r?.type === "paragraph" ? (r.raw += (r.raw.endsWith("\n") ? "" : "\n") + i.raw, r.text += "\n" + i.text, this.inlineQueue.pop(), this.inlineQueue.at(-1).src = r.text) : t.push(i), n = a.length !== e.length, e = e.substring(i.raw.length);
				continue;
			}
			if (i = this.tokenizer.text(e)) {
				e = e.substring(i.raw.length);
				let n = t.at(-1);
				n?.type === "text" ? (n.raw += (n.raw.endsWith("\n") ? "" : "\n") + i.raw, n.text += "\n" + i.text, this.inlineQueue.pop(), this.inlineQueue.at(-1).src = n.text) : t.push(i);
				continue;
			}
			if (e) {
				this.infiniteLoopError(e.charCodeAt(0));
				break;
			}
		}
		return this.state.top = !0, t;
	}
	inline(e, t = []) {
		return this.inlineQueue.push({
			src: e,
			tokens: t
		}), t;
	}
	inlineTokens(e, t = []) {
		this.tokenizer.lexer = this;
		let n = e;
		if (this.tokens.links) {
			let e = Object.keys(this.tokens.links);
			e.length > 0 && (n = n.replace(this.tokenizer.rules.inline.reflinkSearch, (t) => e.includes(t.slice(t.lastIndexOf("[") + 1, -1)) ? "[" + "a".repeat(t.length - 2) + "]" : t));
		}
		n = n.replace(this.tokenizer.rules.inline.anyPunctuation, "++"), n = n.replace(this.tokenizer.rules.inline.blockSkip, (e, t, n) => {
			let r = n ? n.length : 0;
			return e.slice(0, r) + "[" + "a".repeat(e.length - r - 2) + "]";
		}), n = this.options.hooks?.emStrongMask?.call({ lexer: this }, n) ?? n;
		let r = !1, i = "", a = Infinity;
		for (; e;) {
			if (e.length < a) a = e.length;
			else {
				this.infiniteLoopError(e.charCodeAt(0));
				break;
			}
			r || (i = ""), r = !1;
			let o;
			if (this.options.extensions?.inline?.some((n) => (o = n.call({ lexer: this }, e, t)) ? (e = e.substring(o.raw.length), t.push(o), !0) : !1)) continue;
			if (o = this.tokenizer.escape(e)) {
				e = e.substring(o.raw.length), t.push(o);
				continue;
			}
			if (o = this.tokenizer.tag(e)) {
				e = e.substring(o.raw.length), t.push(o);
				continue;
			}
			if (o = this.tokenizer.link(e)) {
				e = e.substring(o.raw.length), t.push(o);
				continue;
			}
			if (o = this.tokenizer.reflink(e, this.tokens.links)) {
				e = e.substring(o.raw.length);
				let n = t.at(-1);
				o.type === "text" && n?.type === "text" ? (n.raw += o.raw, n.text += o.text) : t.push(o);
				continue;
			}
			if (o = this.tokenizer.emStrong(e, n, i)) {
				e = e.substring(o.raw.length), t.push(o);
				continue;
			}
			if (o = this.tokenizer.codespan(e)) {
				e = e.substring(o.raw.length), t.push(o);
				continue;
			}
			if (o = this.tokenizer.br(e)) {
				e = e.substring(o.raw.length), t.push(o);
				continue;
			}
			if (o = this.tokenizer.del(e, n, i)) {
				e = e.substring(o.raw.length), t.push(o);
				continue;
			}
			if (o = this.tokenizer.autolink(e)) {
				e = e.substring(o.raw.length), t.push(o);
				continue;
			}
			if (!this.state.inLink && (o = this.tokenizer.url(e))) {
				e = e.substring(o.raw.length), t.push(o);
				continue;
			}
			let s = e;
			if (this.options.extensions?.startInline) {
				let t = Infinity, n = e.slice(1), r;
				this.options.extensions.startInline.forEach((e) => {
					r = e.call({ lexer: this }, n), typeof r == "number" && r >= 0 && (t = Math.min(t, r));
				}), t < Infinity && t >= 0 && (s = e.substring(0, t + 1));
			}
			if (o = this.tokenizer.inlineText(s)) {
				e = e.substring(o.raw.length), o.raw.slice(-1) !== "_" && (i = o.raw.slice(-1)), r = !0;
				let n = t.at(-1);
				n?.type === "text" ? (n.raw += o.raw, n.text += o.text) : t.push(o);
				continue;
			}
			if (e) {
				this.infiniteLoopError(e.charCodeAt(0));
				break;
			}
		}
		return t;
	}
	infiniteLoopError(e) {
		let t = "Infinite loop on byte: " + e;
		if (this.options.silent) console.error(t);
		else throw Error(t);
	}
}, Em = class {
	options;
	parser;
	constructor(e) {
		this.options = e || ep;
	}
	space(e) {
		return "";
	}
	code({ text: e, lang: t, escaped: n }) {
		let r = (t || "").match(ap.notSpaceStart)?.[0], i = e.replace(ap.endingNewline, "") + "\n";
		return r ? "<pre><code class=\"language-" + hm(r) + "\">" + (n ? i : hm(i, !0)) + "</code></pre>\n" : "<pre><code>" + (n ? i : hm(i, !0)) + "</code></pre>\n";
	}
	blockquote({ tokens: e }) {
		return `<blockquote>
${this.parser.parse(e)}</blockquote>
`;
	}
	html({ text: e }) {
		return e;
	}
	def(e) {
		return "";
	}
	heading({ tokens: e, depth: t }) {
		return `<h${t}>${this.parser.parseInline(e)}</h${t}>
`;
	}
	hr(e) {
		return "<hr>\n";
	}
	list(e) {
		let t = e.ordered, n = e.start, r = "";
		for (let t = 0; t < e.items.length; t++) {
			let n = e.items[t];
			r += this.listitem(n);
		}
		let i = t ? "ol" : "ul", a = t && n !== 1 ? " start=\"" + n + "\"" : "";
		return "<" + i + a + ">\n" + r + "</" + i + ">\n";
	}
	listitem(e) {
		return `<li>${this.parser.parse(e.tokens)}</li>
`;
	}
	checkbox({ checked: e }) {
		return "<input " + (e ? "checked=\"\" " : "") + "disabled=\"\" type=\"checkbox\"> ";
	}
	paragraph({ tokens: e }) {
		return `<p>${this.parser.parseInline(e)}</p>
`;
	}
	table(e) {
		let t = "", n = "";
		for (let t = 0; t < e.header.length; t++) n += this.tablecell(e.header[t]);
		t += this.tablerow({ text: n });
		let r = "";
		for (let t = 0; t < e.rows.length; t++) {
			let i = e.rows[t];
			n = "";
			for (let e = 0; e < i.length; e++) n += this.tablecell(i[e]);
			r += this.tablerow({ text: n });
		}
		return r &&= `<tbody>${r}</tbody>`, "<table>\n<thead>\n" + t + "</thead>\n" + r + "</table>\n";
	}
	tablerow({ text: e }) {
		return `<tr>
${e}</tr>
`;
	}
	tablecell(e) {
		let t = this.parser.parseInline(e.tokens), n = e.header ? "th" : "td";
		return (e.align ? `<${n} align="${e.align}">` : `<${n}>`) + t + `</${n}>
`;
	}
	strong({ tokens: e }) {
		return `<strong>${this.parser.parseInline(e)}</strong>`;
	}
	em({ tokens: e }) {
		return `<em>${this.parser.parseInline(e)}</em>`;
	}
	codespan({ text: e }) {
		return `<code>${hm(e, !0)}</code>`;
	}
	br(e) {
		return "<br>";
	}
	del({ tokens: e }) {
		return `<del>${this.parser.parseInline(e)}</del>`;
	}
	link({ href: e, title: t, tokens: n }) {
		let r = this.parser.parseInline(n), i = gm(e);
		if (i === null) return r;
		e = i;
		let a = "<a href=\"" + e + "\"";
		return t && (a += " title=\"" + hm(t) + "\""), a += ">" + r + "</a>", a;
	}
	image({ href: e, title: t, text: n, tokens: r }) {
		r && (n = this.parser.parseInline(r, this.parser.textRenderer));
		let i = gm(e);
		if (i === null) return hm(n);
		e = i;
		let a = `<img src="${e}" alt="${hm(n)}"`;
		return t && (a += ` title="${hm(t)}"`), a += ">", a;
	}
	text(e) {
		return "tokens" in e && e.tokens ? this.parser.parseInline(e.tokens) : "escaped" in e && e.escaped ? e.text : hm(e.text);
	}
}, Dm = class {
	strong({ text: e }) {
		return e;
	}
	em({ text: e }) {
		return e;
	}
	codespan({ text: e }) {
		return e;
	}
	del({ text: e }) {
		return e;
	}
	html({ text: e }) {
		return e;
	}
	text({ text: e }) {
		return e;
	}
	link({ text: e }) {
		return "" + e;
	}
	image({ text: e }) {
		return "" + e;
	}
	br() {
		return "";
	}
	checkbox({ raw: e }) {
		return e;
	}
}, Om = class e {
	options;
	renderer;
	textRenderer;
	constructor(e) {
		this.options = e || ep, this.options.renderer = this.options.renderer || new Em(), this.renderer = this.options.renderer, this.renderer.options = this.options, this.renderer.parser = this, this.textRenderer = new Dm();
	}
	static parse(t, n) {
		return new e(n).parse(t);
	}
	static parseInline(t, n) {
		return new e(n).parseInline(t);
	}
	parse(e) {
		this.renderer.parser = this;
		let t = "";
		for (let n = 0; n < e.length; n++) {
			let r = e[n];
			if (this.options.extensions?.renderers?.[r.type]) {
				let e = r, n = this.options.extensions.renderers[e.type].call({ parser: this }, e);
				if (n !== !1 || ![
					"space",
					"hr",
					"heading",
					"code",
					"table",
					"blockquote",
					"list",
					"html",
					"def",
					"paragraph",
					"text"
				].includes(e.type)) {
					t += n || "";
					continue;
				}
			}
			let i = r;
			switch (i.type) {
				case "space":
					t += this.renderer.space(i);
					break;
				case "hr":
					t += this.renderer.hr(i);
					break;
				case "heading":
					t += this.renderer.heading(i);
					break;
				case "code":
					t += this.renderer.code(i);
					break;
				case "table":
					t += this.renderer.table(i);
					break;
				case "blockquote":
					t += this.renderer.blockquote(i);
					break;
				case "list":
					t += this.renderer.list(i);
					break;
				case "checkbox":
					t += this.renderer.checkbox(i);
					break;
				case "html":
					t += this.renderer.html(i);
					break;
				case "def":
					t += this.renderer.def(i);
					break;
				case "paragraph":
					t += this.renderer.paragraph(i);
					break;
				case "text":
					t += this.renderer.text(i);
					break;
				default: {
					let e = "Token with \"" + i.type + "\" type was not found.";
					if (this.options.silent) return console.error(e), "";
					throw Error(e);
				}
			}
		}
		return t;
	}
	parseInline(e, t = this.renderer) {
		this.renderer.parser = this;
		let n = "";
		for (let r = 0; r < e.length; r++) {
			let i = e[r];
			if (this.options.extensions?.renderers?.[i.type]) {
				let e = this.options.extensions.renderers[i.type].call({ parser: this }, i);
				if (e !== !1 || ![
					"escape",
					"html",
					"link",
					"image",
					"strong",
					"em",
					"codespan",
					"br",
					"del",
					"text"
				].includes(i.type)) {
					n += e || "";
					continue;
				}
			}
			let a = i;
			switch (a.type) {
				case "escape":
					n += t.text(a);
					break;
				case "html":
					n += t.html(a);
					break;
				case "link":
					n += t.link(a);
					break;
				case "image":
					n += t.image(a);
					break;
				case "checkbox":
					n += t.checkbox(a);
					break;
				case "strong":
					n += t.strong(a);
					break;
				case "em":
					n += t.em(a);
					break;
				case "codespan":
					n += t.codespan(a);
					break;
				case "br":
					n += t.br(a);
					break;
				case "del":
					n += t.del(a);
					break;
				case "text":
					n += t.text(a);
					break;
				default: {
					let e = "Token with \"" + a.type + "\" type was not found.";
					if (this.options.silent) return console.error(e), "";
					throw Error(e);
				}
			}
		}
		return n;
	}
}, km = class {
	options;
	block;
	constructor(e) {
		this.options = e || ep;
	}
	static passThroughHooks = new Set([
		"preprocess",
		"postprocess",
		"processAllTokens",
		"emStrongMask"
	]);
	static passThroughHooksRespectAsync = new Set([
		"preprocess",
		"postprocess",
		"processAllTokens"
	]);
	preprocess(e) {
		return e;
	}
	postprocess(e) {
		return e;
	}
	processAllTokens(e) {
		return e;
	}
	emStrongMask(e) {
		return e;
	}
	provideLexer(e = this.block) {
		return e ? Tm.lex : Tm.lexInline;
	}
	provideParser(e = this.block) {
		return e ? Om.parse : Om.parseInline;
	}
}, Am = new class {
	defaults = $f();
	options = this.setOptions;
	parse = this.parseMarkdown(!0);
	parseInline = this.parseMarkdown(!1);
	Parser = Om;
	Renderer = Em;
	TextRenderer = Dm;
	Lexer = Tm;
	Tokenizer = wm;
	Hooks = km;
	constructor(...e) {
		this.use(...e);
	}
	walkTokens(e, t) {
		let n = [];
		for (let r of e) switch (n = n.concat(t.call(this, r)), r.type) {
			case "table": {
				let e = r;
				for (let r of e.header) n = n.concat(this.walkTokens(r.tokens, t));
				for (let r of e.rows) for (let e of r) n = n.concat(this.walkTokens(e.tokens, t));
				break;
			}
			case "list": {
				let e = r;
				n = n.concat(this.walkTokens(e.items, t));
				break;
			}
			default: {
				let e = r;
				this.defaults.extensions?.childTokens?.[e.type] ? this.defaults.extensions.childTokens[e.type].forEach((r) => {
					let i = e[r].flat(Infinity);
					n = n.concat(this.walkTokens(i, t));
				}) : e.tokens && (n = n.concat(this.walkTokens(e.tokens, t)));
			}
		}
		return n;
	}
	use(...e) {
		let t = this.defaults.extensions || {
			renderers: {},
			childTokens: {}
		};
		return e.forEach((e) => {
			let n = { ...e };
			if (n.async = this.defaults.async || n.async || !1, e.extensions && (e.extensions.forEach((e) => {
				if (!e.name) throw Error("extension name required");
				if ("renderer" in e) {
					let n = t.renderers[e.name];
					n ? t.renderers[e.name] = function(...t) {
						let r = e.renderer.apply(this, t);
						return r === !1 && (r = n.apply(this, t)), r;
					} : t.renderers[e.name] = e.renderer;
				}
				if ("tokenizer" in e) {
					if (!e.level || e.level !== "block" && e.level !== "inline") throw Error("extension level must be 'block' or 'inline'");
					let n = t[e.level];
					n ? n.unshift(e.tokenizer) : t[e.level] = [e.tokenizer], e.start && (e.level === "block" ? t.startBlock ? t.startBlock.push(e.start) : t.startBlock = [e.start] : e.level === "inline" && (t.startInline ? t.startInline.push(e.start) : t.startInline = [e.start]));
				}
				"childTokens" in e && e.childTokens && (t.childTokens[e.name] = e.childTokens);
			}), n.extensions = t), e.renderer) {
				let t = this.defaults.renderer || new Em(this.defaults);
				for (let n in e.renderer) {
					if (!(n in t)) throw Error(`renderer '${n}' does not exist`);
					if (["options", "parser"].includes(n)) continue;
					let r = n, i = e.renderer[r], a = t[r];
					t[r] = (...e) => {
						let n = i.apply(t, e);
						return n === !1 && (n = a.apply(t, e)), n || "";
					};
				}
				n.renderer = t;
			}
			if (e.tokenizer) {
				let t = this.defaults.tokenizer || new wm(this.defaults);
				for (let n in e.tokenizer) {
					if (!(n in t)) throw Error(`tokenizer '${n}' does not exist`);
					if ([
						"options",
						"rules",
						"lexer"
					].includes(n)) continue;
					let r = n, i = e.tokenizer[r], a = t[r];
					t[r] = (...e) => {
						let n = i.apply(t, e);
						return n === !1 && (n = a.apply(t, e)), n;
					};
				}
				n.tokenizer = t;
			}
			if (e.hooks) {
				let t = this.defaults.hooks || new km();
				for (let n in e.hooks) {
					if (!(n in t)) throw Error(`hook '${n}' does not exist`);
					if (["options", "block"].includes(n)) continue;
					let r = n, i = e.hooks[r], a = t[r];
					km.passThroughHooks.has(n) ? t[r] = (e) => {
						if (this.defaults.async && km.passThroughHooksRespectAsync.has(n)) return (async () => {
							let n = await i.call(t, e);
							return a.call(t, n);
						})();
						let r = i.call(t, e);
						return a.call(t, r);
					} : t[r] = (...e) => {
						if (this.defaults.async) return (async () => {
							let n = await i.apply(t, e);
							return n === !1 && (n = await a.apply(t, e)), n;
						})();
						let n = i.apply(t, e);
						return n === !1 && (n = a.apply(t, e)), n;
					};
				}
				n.hooks = t;
			}
			if (e.walkTokens) {
				let t = this.defaults.walkTokens, r = e.walkTokens;
				n.walkTokens = function(e) {
					let n = [];
					return n.push(r.call(this, e)), t && (n = n.concat(t.call(this, e))), n;
				};
			}
			this.defaults = {
				...this.defaults,
				...n
			};
		}), this;
	}
	setOptions(e) {
		return this.defaults = {
			...this.defaults,
			...e
		}, this;
	}
	lexer(e, t) {
		return Tm.lex(e, t ?? this.defaults);
	}
	parser(e, t) {
		return Om.parse(e, t ?? this.defaults);
	}
	parseMarkdown(e) {
		return (t, n) => {
			let r = { ...n }, i = {
				...this.defaults,
				...r
			}, a = this.onError(!!i.silent, !!i.async);
			if (this.defaults.async === !0 && r.async === !1) return a(/* @__PURE__ */ Error("marked(): The async option was set to true by an extension. Remove async: false from the parse options object to return a Promise."));
			if (typeof t > "u" || t === null) return a(/* @__PURE__ */ Error("marked(): input parameter is undefined or null"));
			if (typeof t != "string") return a(/* @__PURE__ */ Error("marked(): input parameter is of type " + Object.prototype.toString.call(t) + ", string expected"));
			if (i.hooks && (i.hooks.options = i, i.hooks.block = e), i.async) return (async () => {
				let n = i.hooks ? await i.hooks.preprocess(t) : t, r = await (i.hooks ? await i.hooks.provideLexer(e) : e ? Tm.lex : Tm.lexInline)(n, i), a = i.hooks ? await i.hooks.processAllTokens(r) : r;
				i.walkTokens && await Promise.all(this.walkTokens(a, i.walkTokens));
				let o = await (i.hooks ? await i.hooks.provideParser(e) : e ? Om.parse : Om.parseInline)(a, i);
				return i.hooks ? await i.hooks.postprocess(o) : o;
			})().catch(a);
			try {
				i.hooks && (t = i.hooks.preprocess(t));
				let n = (i.hooks ? i.hooks.provideLexer(e) : e ? Tm.lex : Tm.lexInline)(t, i);
				i.hooks && (n = i.hooks.processAllTokens(n)), i.walkTokens && this.walkTokens(n, i.walkTokens);
				let r = (i.hooks ? i.hooks.provideParser(e) : e ? Om.parse : Om.parseInline)(n, i);
				return i.hooks && (r = i.hooks.postprocess(r)), r;
			} catch (e) {
				return a(e);
			}
		};
	}
	onError(e, t) {
		return (n) => {
			if (n.message += "\nPlease report this to https://github.com/markedjs/marked.", e) {
				let e = "<p>An error occurred:</p><pre>" + hm(n.message + "", !0) + "</pre>";
				return t ? Promise.resolve(e) : e;
			}
			if (t) return Promise.reject(n);
			throw n;
		};
	}
}();
function jm(e, t) {
	return Am.parse(e, t);
}
jm.options = jm.setOptions = function(e) {
	return Am.setOptions(e), jm.defaults = Am.defaults, tp(jm.defaults), jm;
}, jm.getDefaults = $f, jm.defaults = ep, jm.use = function(...e) {
	return Am.use(...e), jm.defaults = Am.defaults, tp(jm.defaults), jm;
}, jm.walkTokens = function(e, t) {
	return Am.walkTokens(e, t);
}, jm.parseInline = Am.parseInline, jm.Parser = Om, jm.parser = Om.parse, jm.Renderer = Em, jm.TextRenderer = Dm, jm.Lexer = Tm, jm.lexer = Tm.lex, jm.Tokenizer = wm, jm.Hooks = km, jm.parse = jm, jm.options, jm.setOptions, jm.use, jm.walkTokens, jm.parseInline, Om.parse, Tm.lex;
//#endregion
//#region node_modules/dompurify/dist/purify.es.mjs
function Mm(e, t) {
	(t == null || t > e.length) && (t = e.length);
	for (var n = 0, r = Array(t); n < t; n++) r[n] = e[n];
	return r;
}
function Nm(e) {
	if (Array.isArray(e)) return e;
}
function Pm(e, t) {
	var n = e == null ? null : typeof Symbol < "u" && e[Symbol.iterator] || e["@@iterator"];
	if (n != null) {
		var r, i, a, o, s = [], c = !0, l = !1;
		try {
			if (a = (n = n.call(e)).next, t !== 0) for (; !(c = (r = a.call(n)).done) && (s.push(r.value), s.length !== t); c = !0);
		} catch (e) {
			l = !0, i = e;
		} finally {
			try {
				if (!c && n.return != null && (o = n.return(), Object(o) !== o)) return;
			} finally {
				if (l) throw i;
			}
		}
		return s;
	}
}
function Fm() {
	throw TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function Im(e, t) {
	return Nm(e) || Pm(e, t) || Lm(e, t) || Fm();
}
function Lm(e, t) {
	if (e) {
		if (typeof e == "string") return Mm(e, t);
		var n = {}.toString.call(e).slice(8, -1);
		return n === "Object" && e.constructor && (n = e.constructor.name), n === "Map" || n === "Set" ? Array.from(e) : n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n) ? Mm(e, t) : void 0;
	}
}
var Rm = Object.entries, zm = Object.setPrototypeOf, Bm = Object.isFrozen, Vm = Object.getPrototypeOf, Hm = Object.getOwnPropertyDescriptor, Um = Object.freeze, Wm = Object.seal, Gm = Object.create, Km = typeof Reflect < "u" && Reflect, qm = Km.apply, Jm = Km.construct;
Um ||= function(e) {
	return e;
}, Wm ||= function(e) {
	return e;
}, qm ||= function(e, t) {
	var n = [...arguments].slice(2);
	return e.apply(t, n);
}, Jm ||= function(e) {
	return new e(...[...arguments].slice(1));
};
var Ym = hh(Array.prototype.forEach), Xm = hh(Array.prototype.lastIndexOf), Zm = hh(Array.prototype.pop), Qm = hh(Array.prototype.push), $m = hh(Array.prototype.splice), eh = Array.isArray, th = hh(String.prototype.toLowerCase), nh = hh(String.prototype.toString), rh = hh(String.prototype.match), ih = hh(String.prototype.replace), ah = hh(String.prototype.indexOf), oh = hh(String.prototype.trim), sh = hh(Number.prototype.toString), ch = hh(Boolean.prototype.toString), lh = typeof BigInt > "u" ? null : hh(BigInt.prototype.toString), uh = typeof Symbol > "u" ? null : hh(Symbol.prototype.toString), dh = hh(Object.prototype.hasOwnProperty), fh = hh(Object.prototype.toString), ph = hh(RegExp.prototype.test), mh = gh(TypeError);
function hh(e) {
	return function(t) {
		t instanceof RegExp && (t.lastIndex = 0);
		var n = [...arguments].slice(1);
		return qm(e, t, n);
	};
}
function gh(e) {
	return function() {
		return Jm(e, [...arguments]);
	};
}
function $(e, t) {
	let n = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : th;
	if (zm && zm(e, null), !eh(t)) return e;
	let r = t.length;
	for (; r--;) {
		let i = t[r];
		if (typeof i == "string") {
			let e = n(i);
			e !== i && (Bm(t) || (t[r] = e), i = e);
		}
		e[i] = !0;
	}
	return e;
}
function _h(e) {
	for (let t = 0; t < e.length; t++) dh(e, t) || (e[t] = null);
	return e;
}
function vh(e) {
	let t = Gm(null);
	for (let r of Rm(e)) {
		var n = Im(r, 2);
		let i = n[0], a = n[1];
		dh(e, i) && (eh(a) ? t[i] = _h(a) : a && typeof a == "object" && a.constructor === Object ? t[i] = vh(a) : t[i] = a);
	}
	return t;
}
function yh(e) {
	switch (typeof e) {
		case "string": return e;
		case "number": return sh(e);
		case "boolean": return ch(e);
		case "bigint": return lh ? lh(e) : "0";
		case "symbol": return uh ? uh(e) : "Symbol()";
		case "undefined": return fh(e);
		case "function":
		case "object": {
			if (e === null) return fh(e);
			let t = e, n = bh(t, "toString");
			if (typeof n == "function") {
				let e = n(t);
				return typeof e == "string" ? e : fh(e);
			}
			return fh(e);
		}
		default: return fh(e);
	}
}
function bh(e, t) {
	for (; e !== null;) {
		let n = Hm(e, t);
		if (n) {
			if (n.get) return hh(n.get);
			if (typeof n.value == "function") return hh(n.value);
		}
		e = Vm(e);
	}
	function n() {
		return null;
	}
	return n;
}
function xh(e) {
	try {
		return ph(e, ""), !0;
	} catch {
		return !1;
	}
}
var Sh = Um(/* @__PURE__ */ "a.abbr.acronym.address.area.article.aside.audio.b.bdi.bdo.big.blink.blockquote.body.br.button.canvas.caption.center.cite.code.col.colgroup.content.data.datalist.dd.decorator.del.details.dfn.dialog.dir.div.dl.dt.element.em.fieldset.figcaption.figure.font.footer.form.h1.h2.h3.h4.h5.h6.head.header.hgroup.hr.html.i.img.input.ins.kbd.label.legend.li.main.map.mark.marquee.menu.menuitem.meter.nav.nobr.ol.optgroup.option.output.p.picture.pre.progress.q.rp.rt.ruby.s.samp.search.section.select.shadow.slot.small.source.spacer.span.strike.strong.style.sub.summary.sup.table.tbody.td.template.textarea.tfoot.th.thead.time.tr.track.tt.u.ul.var.video.wbr".split(".")), Ch = Um(/* @__PURE__ */ "svg.a.altglyph.altglyphdef.altglyphitem.animatecolor.animatemotion.animatetransform.circle.clippath.defs.desc.ellipse.enterkeyhint.exportparts.filter.font.g.glyph.glyphref.hkern.image.inputmode.line.lineargradient.marker.mask.metadata.mpath.part.path.pattern.polygon.polyline.radialgradient.rect.stop.style.switch.symbol.text.textpath.title.tref.tspan.view.vkern".split(".")), wh = Um([
	"feBlend",
	"feColorMatrix",
	"feComponentTransfer",
	"feComposite",
	"feConvolveMatrix",
	"feDiffuseLighting",
	"feDisplacementMap",
	"feDistantLight",
	"feDropShadow",
	"feFlood",
	"feFuncA",
	"feFuncB",
	"feFuncG",
	"feFuncR",
	"feGaussianBlur",
	"feImage",
	"feMerge",
	"feMergeNode",
	"feMorphology",
	"feOffset",
	"fePointLight",
	"feSpecularLighting",
	"feSpotLight",
	"feTile",
	"feTurbulence"
]), Th = Um([
	"animate",
	"color-profile",
	"cursor",
	"discard",
	"font-face",
	"font-face-format",
	"font-face-name",
	"font-face-src",
	"font-face-uri",
	"foreignobject",
	"hatch",
	"hatchpath",
	"mesh",
	"meshgradient",
	"meshpatch",
	"meshrow",
	"missing-glyph",
	"script",
	"set",
	"solidcolor",
	"unknown",
	"use"
]), Eh = Um(/* @__PURE__ */ "math.menclose.merror.mfenced.mfrac.mglyph.mi.mlabeledtr.mmultiscripts.mn.mo.mover.mpadded.mphantom.mroot.mrow.ms.mspace.msqrt.mstyle.msub.msup.msubsup.mtable.mtd.mtext.mtr.munder.munderover.mprescripts".split(".")), Dh = Um([
	"maction",
	"maligngroup",
	"malignmark",
	"mlongdiv",
	"mscarries",
	"mscarry",
	"msgroup",
	"mstack",
	"msline",
	"msrow",
	"semantics",
	"annotation",
	"annotation-xml",
	"mprescripts",
	"none"
]), Oh = Um(["#text"]), kh = Um(/* @__PURE__ */ "accept.action.align.alt.autocapitalize.autocomplete.autopictureinpicture.autoplay.background.bgcolor.border.capture.cellpadding.cellspacing.checked.cite.class.clear.color.cols.colspan.command.commandfor.controls.controlslist.coords.crossorigin.datetime.decoding.default.dir.disabled.disablepictureinpicture.disableremoteplayback.download.draggable.enctype.enterkeyhint.exportparts.face.for.headers.height.hidden.high.href.hreflang.id.inert.inputmode.integrity.ismap.kind.label.lang.list.loading.loop.low.max.maxlength.media.method.min.minlength.multiple.muted.name.nonce.noshade.novalidate.nowrap.open.optimum.part.pattern.placeholder.playsinline.popover.popovertarget.popovertargetaction.poster.preload.pubdate.radiogroup.readonly.rel.required.rev.reversed.role.rows.rowspan.spellcheck.scope.selected.shape.size.sizes.slot.span.srclang.start.src.srcset.step.style.summary.tabindex.title.translate.type.usemap.valign.value.width.wrap.xmlns".split(".")), Ah = Um(/* @__PURE__ */ "accent-height.accumulate.additive.alignment-baseline.amplitude.ascent.attributename.attributetype.azimuth.basefrequency.baseline-shift.begin.bias.by.class.clip.clippathunits.clip-path.clip-rule.color.color-interpolation.color-interpolation-filters.color-profile.color-rendering.cx.cy.d.dx.dy.diffuseconstant.direction.display.divisor.dominant-baseline.dur.edgemode.elevation.end.exponent.fill.fill-opacity.fill-rule.filter.filterunits.flood-color.flood-opacity.font-family.font-size.font-size-adjust.font-stretch.font-style.font-variant.font-weight.fx.fy.g1.g2.glyph-name.glyphref.gradientunits.gradienttransform.height.href.id.image-rendering.in.in2.intercept.k.k1.k2.k3.k4.kerning.keypoints.keysplines.keytimes.lang.lengthadjust.letter-spacing.kernelmatrix.kernelunitlength.lighting-color.local.marker-end.marker-mid.marker-start.markerheight.markerunits.markerwidth.maskcontentunits.maskunits.max.mask.mask-type.media.method.mode.min.name.numoctaves.offset.operator.opacity.order.orient.orientation.origin.overflow.paint-order.path.pathlength.patterncontentunits.patterntransform.patternunits.points.preservealpha.preserveaspectratio.primitiveunits.r.rx.ry.radius.refx.refy.repeatcount.repeatdur.restart.result.rotate.scale.seed.shape-rendering.slope.specularconstant.specularexponent.spreadmethod.startoffset.stddeviation.stitchtiles.stop-color.stop-opacity.stroke-dasharray.stroke-dashoffset.stroke-linecap.stroke-linejoin.stroke-miterlimit.stroke-opacity.stroke.stroke-width.style.surfacescale.systemlanguage.tabindex.tablevalues.targetx.targety.transform.transform-origin.text-anchor.text-decoration.text-orientation.text-rendering.textlength.type.u1.u2.unicode.values.viewbox.visibility.version.vert-adv-y.vert-origin-x.vert-origin-y.width.word-spacing.wrap.writing-mode.xchannelselector.ychannelselector.x.x1.x2.xmlns.y.y1.y2.z.zoomandpan".split(".")), jh = Um(/* @__PURE__ */ "accent.accentunder.align.bevelled.close.columnalign.columnlines.columnspacing.columnspan.denomalign.depth.dir.display.displaystyle.encoding.fence.frame.height.href.id.largeop.length.linethickness.lquote.lspace.mathbackground.mathcolor.mathsize.mathvariant.maxsize.minsize.movablelimits.notation.numalign.open.rowalign.rowlines.rowspacing.rowspan.rspace.rquote.scriptlevel.scriptminsize.scriptsizemultiplier.selection.separator.separators.stretchy.subscriptshift.supscriptshift.symmetric.voffset.width.xmlns".split(".")), Mh = Um([
	"xlink:href",
	"xml:id",
	"xlink:title",
	"xml:space",
	"xmlns:xlink"
]), Nh = Wm(/{{[\w\W]*|^[\w\W]*}}/g), Ph = Wm(/<%[\w\W]*|^[\w\W]*%>/g), Fh = Wm(/\${[\w\W]*/g), Ih = Wm(/^data-[\-\w.\u00B7-\uFFFF]+$/), Lh = Wm(/^aria-[\-\w]+$/), Rh = Wm(/^(?:(?:(?:f|ht)tps?|mailto|tel|callto|sms|cid|xmpp|matrix):|[^a-z]|[a-z+.\-]+(?:[^a-z+.\-:]|$))/i), zh = Wm(/^(?:\w+script|data):/i), Bh = Wm(/[\u0000-\u0020\u00A0\u1680\u180E\u2000-\u2029\u205F\u3000]/g), Vh = Wm(/^html$/i), Hh = Wm(/^[a-z][.\w]*(-[.\w]+)+$/i), Uh = Wm(/<[/\w!]/g), Wh = Wm(/<[/\w]/g), Gh = Wm(/<\/no(script|embed|frames)/i), Kh = Wm(/\/>/i), qh = {
	element: 1,
	attribute: 2,
	text: 3,
	cdataSection: 4,
	entityReference: 5,
	entityNode: 6,
	processingInstruction: 7,
	comment: 8,
	document: 9,
	documentType: 10,
	documentFragment: 11,
	notation: 12
}, Jh = function() {
	return typeof window > "u" ? null : window;
}, Yh = function(e, t) {
	if (typeof e != "object" || typeof e.createPolicy != "function") return null;
	let n = null, r = "data-tt-policy-suffix";
	t && t.hasAttribute(r) && (n = t.getAttribute(r));
	let i = "dompurify" + (n ? "#" + n : "");
	try {
		return e.createPolicy(i, {
			createHTML(e) {
				return e;
			},
			createScriptURL(e) {
				return e;
			}
		});
	} catch {
		return console.warn("TrustedTypes policy " + i + " could not be created."), null;
	}
}, Xh = function() {
	return {
		afterSanitizeAttributes: [],
		afterSanitizeElements: [],
		afterSanitizeShadowDOM: [],
		beforeSanitizeAttributes: [],
		beforeSanitizeElements: [],
		beforeSanitizeShadowDOM: [],
		uponSanitizeAttribute: [],
		uponSanitizeElement: [],
		uponSanitizeShadowNode: []
	};
}, Zh = function(e, t, n, r) {
	return dh(e, t) && eh(e[t]) ? $(r.base ? vh(r.base) : {}, e[t], r.transform) : n;
};
function Qh() {
	let e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : Jh(), t = (e) => Qh(e);
	if (t.version = "3.4.12", t.removed = [], !e || !e.document || e.document.nodeType !== qh.document || !e.Element) return t.isSupported = !1, t;
	let n = e.document, r = n, i = r.currentScript;
	e.DocumentFragment;
	let a = e.HTMLTemplateElement, o = e.Node, s = e.Element, c = e.NodeFilter;
	e.NamedNodeMap === void 0 && (e.NamedNodeMap || e.MozNamedAttrMap), e.HTMLFormElement;
	let l = e.DOMParser, u = e.trustedTypes, d = s.prototype, f = bh(d, "cloneNode"), p = bh(d, "remove"), m = bh(d, "nextSibling"), h = bh(d, "childNodes"), g = bh(d, "parentNode"), _ = bh(d, "shadowRoot"), v = bh(d, "attributes"), y = o && o.prototype ? bh(o.prototype, "nodeType") : null, b = o && o.prototype ? bh(o.prototype, "nodeName") : null;
	if (typeof a == "function") {
		let e = n.createElement("template");
		e.content && e.content.ownerDocument && (n = e.content.ownerDocument);
	}
	let x, S = "", C, w = !1, ee = 0, te = function() {
		if (ee > 0) throw mh("A configured TRUSTED_TYPES_POLICY callback (createHTML or createScriptURL) must not call DOMPurify.sanitize, as that causes infinite recursion. Do not pass a policy whose callbacks wrap DOMPurify as TRUSTED_TYPES_POLICY; see the \"DOMPurify and Trusted Types\" section of the README.");
	}, ne = function(e) {
		te(), ee++;
		try {
			return x.createHTML(e);
		} finally {
			ee--;
		}
	}, T = function(e) {
		te(), ee++;
		try {
			return x.createScriptURL(e);
		} finally {
			ee--;
		}
	}, re = function() {
		return w ||= (C = Yh(u, i), !0), C;
	}, ie = n, ae = ie.implementation, oe = ie.createNodeIterator, se = ie.createDocumentFragment, ce = ie.getElementsByTagName, le = r.importNode, E = Xh();
	t.isSupported = typeof Rm == "function" && typeof g == "function" && ae && ae.createHTMLDocument !== void 0;
	let ue = Nh, de = Ph, fe = Fh, D = Ih, pe = Lh, me = zh, he = Bh, ge = Hh, O = Rh, _e = null, ve = $({}, [
		...Sh,
		...Ch,
		...wh,
		...Eh,
		...Oh
	]), k = null, ye = $({}, [
		...kh,
		...Ah,
		...jh,
		...Mh
	]), A = Object.seal(Gm(null, {
		tagNameCheck: {
			writable: !0,
			configurable: !1,
			enumerable: !0,
			value: null
		},
		attributeNameCheck: {
			writable: !0,
			configurable: !1,
			enumerable: !0,
			value: null
		},
		allowCustomizedBuiltInElements: {
			writable: !0,
			configurable: !1,
			enumerable: !0,
			value: !1
		}
	})), be = null, xe = null, j = Object.seal(Gm(null, {
		tagCheck: {
			writable: !0,
			configurable: !1,
			enumerable: !0,
			value: null
		},
		attributeCheck: {
			writable: !0,
			configurable: !1,
			enumerable: !0,
			value: null
		}
	})), Se = !0, Ce = !0, we = !1, Te = !0, Ee = !1, De = !0, Oe = !1, M = !1, ke = null, Ae = null, je = !1, Me = !1, Ne = !1, Pe = !1, Fe = !0, Ie = !1, Le = "user-content-", Re = !0, ze = !1, Be = {}, Ve = null, He = $({}, /* @__PURE__ */ "annotation-xml.audio.colgroup.desc.foreignobject.head.iframe.math.mi.mn.mo.ms.mtext.noembed.noframes.noscript.plaintext.script.selectedcontent.style.svg.template.thead.title.video.xmp".split(".")), Ue = null, We = $({}, [
		"audio",
		"video",
		"img",
		"source",
		"image",
		"track"
	]), Ge = null, Ke = $({}, [
		"alt",
		"class",
		"for",
		"id",
		"label",
		"name",
		"pattern",
		"placeholder",
		"role",
		"summary",
		"title",
		"value",
		"style",
		"xmlns"
	]), qe = "http://www.w3.org/1998/Math/MathML", Je = "http://www.w3.org/2000/svg", Ye = "http://www.w3.org/1999/xhtml", Xe = Ye, Ze = !1, Qe = null, $e = $({}, [
		qe,
		Je,
		Ye
	], nh), et = Um([
		"mi",
		"mo",
		"mn",
		"ms",
		"mtext"
	]), tt = $({}, et), nt = Um(["annotation-xml"]), rt = $({}, nt), it = $({}, [
		"title",
		"style",
		"font",
		"a",
		"script"
	]), at = null, ot = ["application/xhtml+xml", "text/html"], N = null, st = null, ct = n.createElement("form"), lt = function(e) {
		return e instanceof RegExp || e instanceof Function;
	}, ut = function() {
		let e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
		if (st && st === e) return;
		(!e || typeof e != "object") && (e = {}), e = vh(e), at = ot.indexOf(e.PARSER_MEDIA_TYPE) === -1 ? "text/html" : e.PARSER_MEDIA_TYPE, N = at === "application/xhtml+xml" ? nh : th, _e = Zh(e, "ALLOWED_TAGS", ve, { transform: N }), k = Zh(e, "ALLOWED_ATTR", ye, { transform: N }), Qe = Zh(e, "ALLOWED_NAMESPACES", $e, { transform: nh }), Ge = Zh(e, "ADD_URI_SAFE_ATTR", Ke, {
			transform: N,
			base: Ke
		}), Ue = Zh(e, "ADD_DATA_URI_TAGS", We, {
			transform: N,
			base: We
		}), Ve = Zh(e, "FORBID_CONTENTS", He, { transform: N }), be = Zh(e, "FORBID_TAGS", vh({}), { transform: N }), xe = Zh(e, "FORBID_ATTR", vh({}), { transform: N }), Be = dh(e, "USE_PROFILES") ? e.USE_PROFILES && typeof e.USE_PROFILES == "object" ? vh(e.USE_PROFILES) : e.USE_PROFILES : !1, Se = e.ALLOW_ARIA_ATTR !== !1, Ce = e.ALLOW_DATA_ATTR !== !1, we = e.ALLOW_UNKNOWN_PROTOCOLS || !1, Te = e.ALLOW_SELF_CLOSE_IN_ATTR !== !1, Ee = e.SAFE_FOR_TEMPLATES || !1, De = e.SAFE_FOR_XML !== !1, Oe = e.WHOLE_DOCUMENT || !1, Me = e.RETURN_DOM || !1, Ne = e.RETURN_DOM_FRAGMENT || !1, Pe = e.RETURN_TRUSTED_TYPE || !1, je = e.FORCE_BODY || !1, Fe = e.SANITIZE_DOM !== !1, Ie = e.SANITIZE_NAMED_PROPS || !1, Re = e.KEEP_CONTENT !== !1, ze = e.IN_PLACE || !1, O = xh(e.ALLOWED_URI_REGEXP) ? e.ALLOWED_URI_REGEXP : Rh, Xe = typeof e.NAMESPACE == "string" ? e.NAMESPACE : Ye, tt = dh(e, "MATHML_TEXT_INTEGRATION_POINTS") && e.MATHML_TEXT_INTEGRATION_POINTS && typeof e.MATHML_TEXT_INTEGRATION_POINTS == "object" ? vh(e.MATHML_TEXT_INTEGRATION_POINTS) : $({}, et), rt = dh(e, "HTML_INTEGRATION_POINTS") && e.HTML_INTEGRATION_POINTS && typeof e.HTML_INTEGRATION_POINTS == "object" ? vh(e.HTML_INTEGRATION_POINTS) : $({}, nt);
		let t = dh(e, "CUSTOM_ELEMENT_HANDLING") && e.CUSTOM_ELEMENT_HANDLING && typeof e.CUSTOM_ELEMENT_HANDLING == "object" ? vh(e.CUSTOM_ELEMENT_HANDLING) : Gm(null);
		if (A = Gm(null), dh(t, "tagNameCheck") && lt(t.tagNameCheck) && (A.tagNameCheck = t.tagNameCheck), dh(t, "attributeNameCheck") && lt(t.attributeNameCheck) && (A.attributeNameCheck = t.attributeNameCheck), dh(t, "allowCustomizedBuiltInElements") && typeof t.allowCustomizedBuiltInElements == "boolean" && (A.allowCustomizedBuiltInElements = t.allowCustomizedBuiltInElements), Wm(A), Ee && (Ce = !1), Ne && (Me = !0), Be && (_e = $({}, Oh), k = Gm(null), Be.html === !0 && ($(_e, Sh), $(k, kh)), Be.svg === !0 && ($(_e, Ch), $(k, Ah), $(k, Mh)), Be.svgFilters === !0 && ($(_e, wh), $(k, Ah), $(k, Mh)), Be.mathMl === !0 && ($(_e, Eh), $(k, jh), $(k, Mh))), j.tagCheck = null, j.attributeCheck = null, dh(e, "ADD_TAGS") && (typeof e.ADD_TAGS == "function" ? j.tagCheck = e.ADD_TAGS : eh(e.ADD_TAGS) && (_e === ve && (_e = vh(_e)), $(_e, e.ADD_TAGS, N))), dh(e, "ADD_ATTR") && (typeof e.ADD_ATTR == "function" ? j.attributeCheck = e.ADD_ATTR : eh(e.ADD_ATTR) && (k === ye && (k = vh(k)), $(k, e.ADD_ATTR, N))), dh(e, "ADD_URI_SAFE_ATTR") && eh(e.ADD_URI_SAFE_ATTR) && $(Ge, e.ADD_URI_SAFE_ATTR, N), dh(e, "FORBID_CONTENTS") && eh(e.FORBID_CONTENTS) && (Ve === He && (Ve = vh(Ve)), $(Ve, e.FORBID_CONTENTS, N)), dh(e, "ADD_FORBID_CONTENTS") && eh(e.ADD_FORBID_CONTENTS) && (Ve === He && (Ve = vh(Ve)), $(Ve, e.ADD_FORBID_CONTENTS, N)), Re && (_e["#text"] = !0), Oe && $(_e, [
			"html",
			"head",
			"body"
		]), _e.table && ($(_e, ["tbody"]), delete be.tbody), e.TRUSTED_TYPES_POLICY) {
			if (typeof e.TRUSTED_TYPES_POLICY.createHTML != "function") throw mh("TRUSTED_TYPES_POLICY configuration option must provide a \"createHTML\" hook.");
			if (typeof e.TRUSTED_TYPES_POLICY.createScriptURL != "function") throw mh("TRUSTED_TYPES_POLICY configuration option must provide a \"createScriptURL\" hook.");
			let t = x;
			x = e.TRUSTED_TYPES_POLICY;
			try {
				S = ne("");
			} catch (e) {
				throw x = t, e;
			}
		} else e.TRUSTED_TYPES_POLICY === null ? (x = void 0, S = "") : (x === void 0 && (x = re()), x && typeof S == "string" && (S = ne("")));
		Um && Um(e), st = e;
	}, dt = $({}, [
		...Ch,
		...wh,
		...Th
	]), ft = $({}, [...Eh, ...Dh]), pt = function(e, t, n) {
		return t.namespaceURI === Ye ? e === "svg" : t.namespaceURI === qe ? e === "svg" && (n === "annotation-xml" || tt[n]) : !!dt[e];
	}, mt = function(e, t, n) {
		return t.namespaceURI === Ye ? e === "math" : t.namespaceURI === Je ? e === "math" && rt[n] : !!ft[e];
	}, ht = function(e, t, n) {
		return t.namespaceURI === Je && !rt[n] || t.namespaceURI === qe && !tt[n] ? !1 : !ft[e] && (it[e] || !dt[e]);
	}, gt = function(e) {
		let t = g(e);
		(!t || !t.tagName) && (t = {
			namespaceURI: Xe,
			tagName: "template"
		});
		let n = th(e.tagName), r = th(t.tagName);
		return Qe[e.namespaceURI] ? e.namespaceURI === Je ? pt(n, t, r) : e.namespaceURI === qe ? mt(n, t, r) : e.namespaceURI === Ye ? ht(n, t, r) : !!(at === "application/xhtml+xml" && Qe[e.namespaceURI]) : !1;
	}, _t = function(e) {
		Qm(t.removed, { element: e });
		try {
			g(e).removeChild(e);
		} catch {
			if (p(e), !g(e)) throw mh("a node selected for removal could not be detached from its tree and cannot be safely returned; refusing to sanitize in place");
		}
	}, vt = function(e) {
		xt(e);
		let t = h(e);
		if (t) {
			let e = [];
			Ym(t, (t) => {
				Qm(e, t);
			}), Ym(e, (e) => {
				try {
					p(e);
				} catch {}
			});
		}
		let n = v(e);
		if (n) for (let t = n.length - 1; t >= 0; --t) {
			let r = n[t], i = r && r.name;
			if (typeof i == "string") try {
				e.removeAttribute(i);
			} catch {}
		}
	}, yt = function(e, n) {
		try {
			Qm(t.removed, {
				attribute: n.getAttributeNode(e),
				from: n
			});
		} catch {
			Qm(t.removed, {
				attribute: null,
				from: n
			});
		}
		if (n.removeAttribute(e), e === "is") if (Me || Ne) try {
			_t(n);
		} catch {}
		else try {
			n.setAttribute(e, "");
		} catch {}
	}, bt = function(e) {
		let t = v(e);
		if (t) for (let n = t.length - 1; n >= 0; --n) {
			let r = t[n], i = r && r.name;
			if (!(typeof i != "string" || k[N(i)])) try {
				e.removeAttribute(i);
			} catch {}
		}
	}, xt = function(e) {
		let t = [e];
		for (; t.length > 0;) {
			let e = t.pop();
			(y ? y(e) : e.nodeType) === qh.element && bt(e);
			let n = h(e);
			if (n) for (let e = n.length - 1; e >= 0; --e) t.push(n[e]);
		}
	}, St = function(e) {
		if (!De) return;
		let t = [e];
		for (; t.length > 0;) {
			let e = t.pop(), n = y ? y(e) : e.nodeType;
			if (n === qh.processingInstruction || n === qh.comment && ph(Wh, e.data)) {
				try {
					p(e);
				} catch {}
				continue;
			}
			if (n === qh.element) {
				let t = e, n = N(b ? b(e) : e.nodeName);
				try {
					t.hasAttribute && t.hasAttribute("patchsrc") && t.removeAttribute("patchsrc"), t.hasAttribute && t.hasAttribute("for") && n !== "label" && n !== "output" && t.removeAttribute("for");
				} catch {}
			}
			let r = h(e);
			if (r) for (let e = r.length - 1; e >= 0; --e) t.push(r[e]);
		}
	}, Ct = function(e) {
		let t = null, r = null;
		if (je) e = "<remove></remove>" + e;
		else {
			let t = rh(e, /^[\r\n\t ]+/);
			r = t && t[0];
		}
		at === "application/xhtml+xml" && Xe === Ye && (e = "<html xmlns=\"http://www.w3.org/1999/xhtml\"><head></head><body>" + e + "</body></html>");
		let i = x ? ne(e) : e;
		if (Xe === Ye) try {
			t = new l().parseFromString(i, at);
		} catch {}
		if (!t || !t.documentElement) {
			t = ae.createDocument(Xe, "template", null);
			try {
				t.documentElement.innerHTML = Ze ? S : i;
			} catch {}
		}
		let a = t.body || t.documentElement;
		return e && r && a.insertBefore(n.createTextNode(r), a.childNodes[0] || null), Xe === Ye ? ce.call(t, Oe ? "html" : "body")[0] : Oe ? t.documentElement : a;
	}, wt = function(e) {
		return oe.call(e.ownerDocument || e, e, c.SHOW_ELEMENT | c.SHOW_COMMENT | c.SHOW_TEXT | c.SHOW_PROCESSING_INSTRUCTION | c.SHOW_CDATA_SECTION, null);
	}, Tt = function(e) {
		return e = ih(e, ue, " "), e = ih(e, de, " "), e = ih(e, fe, " "), e;
	}, Et = function(e) {
		e.normalize();
		let t = oe.call(e.ownerDocument || e, e, c.SHOW_TEXT | c.SHOW_COMMENT | c.SHOW_CDATA_SECTION | c.SHOW_PROCESSING_INSTRUCTION, null), n = t.nextNode();
		for (; n;) n.data = Tt(n.data), n = t.nextNode();
		let r = e.querySelectorAll?.call(e, "template");
		r && Ym(r, (e) => {
			Ot(e.content) && Et(e.content);
		});
	}, Dt = function(e) {
		let t = b ? b(e) : null;
		return typeof t != "string" || N(t) !== "form" ? !1 : typeof e.nodeName != "string" || typeof e.textContent != "string" || typeof e.removeChild != "function" || e.attributes !== v(e) || typeof e.removeAttribute != "function" || typeof e.setAttribute != "function" || typeof e.namespaceURI != "string" || typeof e.insertBefore != "function" || typeof e.hasChildNodes != "function" || e.nodeType !== y(e) || e.childNodes !== h(e);
	}, Ot = function(e) {
		if (!y || typeof e != "object" || !e) return !1;
		try {
			return y(e) === qh.documentFragment;
		} catch {
			return !1;
		}
	}, kt = function(e) {
		if (!y || typeof e != "object" || !e) return !1;
		try {
			return typeof y(e) == "number";
		} catch {
			return !1;
		}
	};
	function At(e, n, r) {
		e.length !== 0 && Ym(e, (e) => {
			e.call(t, n, r, st);
		});
	}
	let jt = function(e, t) {
		return !!(De && e.hasChildNodes() && !kt(e.firstElementChild) && ph(Uh, e.textContent) && ph(Uh, e.innerHTML) || De && e.namespaceURI === Ye && t === "style" && kt(e.firstElementChild) || e.nodeType === qh.processingInstruction || De && e.nodeType === qh.comment && ph(Wh, e.data));
	}, Mt = function(e, t) {
		if (!be[t] && It(t) && (A.tagNameCheck instanceof RegExp && ph(A.tagNameCheck, t) || A.tagNameCheck instanceof Function && A.tagNameCheck(t))) return !1;
		if (Re && !Ve[t]) {
			let t = g(e), n = h(e);
			if (n && t) {
				let r = n.length;
				for (let i = r - 1; i >= 0; --i) {
					let r = ze ? n[i] : f(n[i], !0);
					t.insertBefore(r, m(e));
				}
			}
		}
		return _t(e), !0;
	}, Nt = function(e, n) {
		if (At(E.beforeSanitizeElements, e, null), e !== n && g(e) === null) return !0;
		if (Dt(e)) return _t(e), !0;
		let r = N(b ? b(e) : e.nodeName);
		if (At(E.uponSanitizeElement, e, {
			tagName: r,
			allowedTags: _e
		}), e !== n && g(e) === null) return !0;
		if (jt(e, r)) return _t(e), !0;
		if (be[r] || !(j.tagCheck instanceof Function && j.tagCheck(r)) && !_e[r]) {
			let t = Mt(e, r);
			return t === !1 && At(E.afterSanitizeElements, e, null), t;
		}
		if ((y ? y(e) : e.nodeType) === qh.element && !gt(e) || (r === "noscript" || r === "noembed" || r === "noframes") && ph(Gh, e.innerHTML)) return _t(e), !0;
		if (Ee && e.nodeType === qh.text) {
			let n = Tt(e.textContent);
			e.textContent !== n && (Qm(t.removed, { element: e.cloneNode() }), e.textContent = n);
		}
		return At(E.afterSanitizeElements, e, null), !1;
	}, Pt = function(e, t, r) {
		if (xe[t] || De && t === "patchsrc" || De && t === "for" && e !== "label" && e !== "output" || Fe && (t === "id" || t === "name") && (r in n || r in ct)) return !1;
		let i = k[t] || j.attributeCheck instanceof Function && j.attributeCheck(t, e);
		if (!(Ce && ph(D, t)) && !(Se && ph(pe, t))) {
			if (!i) {
				if (!(It(e) && (A.tagNameCheck instanceof RegExp && ph(A.tagNameCheck, e) || A.tagNameCheck instanceof Function && A.tagNameCheck(e)) && (A.attributeNameCheck instanceof RegExp && ph(A.attributeNameCheck, t) || A.attributeNameCheck instanceof Function && A.attributeNameCheck(t, e)) || t === "is" && A.allowCustomizedBuiltInElements && (A.tagNameCheck instanceof RegExp && ph(A.tagNameCheck, r) || A.tagNameCheck instanceof Function && A.tagNameCheck(r)))) return !1;
			} else if (!Ge[t] && !ph(O, ih(r, he, "")) && !((t === "src" || t === "xlink:href" || t === "href") && e !== "script" && ah(r, "data:") === 0 && Ue[e]) && !(we && !ph(me, ih(r, he, ""))) && r) return !1;
		}
		return !0;
	}, Ft = $({}, [
		"annotation-xml",
		"color-profile",
		"font-face",
		"font-face-format",
		"font-face-name",
		"font-face-src",
		"font-face-uri",
		"missing-glyph"
	]), It = function(e) {
		return !Ft[th(e)] && ph(ge, e);
	}, Lt = function(e, t, n, r) {
		if (x && typeof u == "object" && typeof u.getAttributeType == "function" && !n) switch (u.getAttributeType(e, t)) {
			case "TrustedHTML": return ne(r);
			case "TrustedScriptURL": return T(r);
		}
		return r;
	}, Rt = function(e, n, r, i) {
		try {
			r ? e.setAttributeNS(r, n, i) : e.setAttribute(n, i), Dt(e) ? _t(e) : Zm(t.removed);
		} catch {
			yt(n, e);
		}
	}, zt = function(e) {
		At(E.beforeSanitizeAttributes, e, null);
		let t = e.attributes;
		if (!t || Dt(e)) return;
		let n = {
			attrName: "",
			attrValue: "",
			keepAttr: !0,
			allowedAttributes: k,
			forceKeepAttr: void 0
		}, r = t.length, i = N(e.nodeName);
		for (; r--;) {
			let a = t[r], o = a.name, s = a.namespaceURI, c = a.value, l = N(o), u = c, d = o === "value" ? u : oh(u);
			if (n.attrName = l, n.attrValue = d, n.keepAttr = !0, n.forceKeepAttr = void 0, At(E.uponSanitizeAttribute, e, n), d = n.attrValue, Ie && (l === "id" || l === "name") && ah(d, Le) !== 0 && (yt(o, e), d = Le + d), De && ph(/((--!?|])>)|<\/(style|script|title|xmp|textarea|noscript|iframe|noembed|noframes)/i, d)) {
				yt(o, e);
				continue;
			}
			if (l === "attributename" && rh(d, "href")) {
				yt(o, e);
				continue;
			}
			if (!n.forceKeepAttr) {
				if (!n.keepAttr) {
					yt(o, e);
					continue;
				}
				if (!Te && ph(Kh, d)) {
					yt(o, e);
					continue;
				}
				if (Ee && (d = Tt(d)), !Pt(i, l, d)) {
					yt(o, e);
					continue;
				}
				d = Lt(i, l, s, d), d !== u && Rt(e, o, s, d);
			}
		}
		At(E.afterSanitizeAttributes, e, null);
	}, Bt = function(e) {
		let t = null, n = wt(e);
		for (At(E.beforeSanitizeShadowDOM, e, null); t = n.nextNode();) if (At(E.uponSanitizeShadowNode, t, null), Nt(t, e), zt(t), Ot(t.content) && Bt(t.content), (y ? y(t) : t.nodeType) === qh.element) {
			let e = _(t);
			Ot(e) && (Vt(e), Bt(e));
		}
		At(E.afterSanitizeShadowDOM, e, null);
	}, Vt = function(e) {
		let t = [{
			node: e,
			shadow: null
		}];
		for (; t.length > 0;) {
			let e = t.pop();
			if (e.shadow) {
				Bt(e.shadow);
				continue;
			}
			let n = e.node, r = (y ? y(n) : n.nodeType) === qh.element, i = h(n);
			if (i) for (let e = i.length - 1; e >= 0; --e) t.push({
				node: i[e],
				shadow: null
			});
			if (r) {
				let e = b ? b(n) : null;
				if (typeof e == "string" && N(e) === "template") {
					let e = n.content;
					Ot(e) && t.push({
						node: e,
						shadow: null
					});
				}
			}
			if (r) {
				let e = _(n);
				Ot(e) && t.push({
					node: null,
					shadow: e
				}, {
					node: e,
					shadow: null
				});
			}
		}
	};
	return t.sanitize = function(e) {
		let n = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {}, i = null, a = null, o = null, s = null;
		if (Ze = !e, Ze && (e = "<!-->"), typeof e != "string" && !kt(e) && (e = yh(e), typeof e != "string")) throw mh("dirty is not a string, aborting");
		if (!t.isSupported) return e;
		M ? (_e = ke, k = Ae) : ut(n), (E.uponSanitizeElement.length > 0 || E.uponSanitizeAttribute.length > 0) && (_e = vh(_e)), E.uponSanitizeAttribute.length > 0 && (k = vh(k)), t.removed = [];
		let c = ze && typeof e != "string" && kt(e);
		if (c) {
			St(e);
			let t = b ? b(e) : e.nodeName;
			if (typeof t == "string") {
				let n = N(t);
				if (!_e[n] || be[n]) throw vt(e), mh("root node is forbidden and cannot be sanitized in-place");
			}
			if (Dt(e)) throw vt(e), mh("root node is clobbered and cannot be sanitized in-place");
			try {
				Vt(e);
			} catch (t) {
				throw vt(e), t;
			}
		} else if (kt(e)) i = Ct("<!---->"), a = i.ownerDocument.importNode(e, !0), a.nodeType === qh.element && a.nodeName === "BODY" || a.nodeName === "HTML" ? i = a : i.appendChild(a), Vt(a);
		else {
			if (!Me && !Ee && !Oe && e.indexOf("<") === -1) return x && Pe ? ne(e) : e;
			if (i = Ct(e), !i) return Me ? null : Pe ? S : "";
		}
		i && je && _t(i.firstChild);
		let l = c ? e : i, u = wt(l);
		try {
			for (; o = u.nextNode();) Nt(o, l), zt(o), Ot(o.content) && Bt(o.content);
		} catch (n) {
			throw c && (vt(e), Ym(t.removed, (e) => {
				e.element && xt(e.element);
			})), n;
		}
		if (c) return Ym(t.removed, (e) => {
			e.element && xt(e.element);
		}), Ee && Et(e), e;
		if (Me) {
			if (Ee && Et(i), Ne) for (s = se.call(i.ownerDocument); i.firstChild;) s.appendChild(i.firstChild);
			else s = i;
			return (k.shadowroot || k.shadowrootmode) && (s = le.call(r, s, !0)), s;
		}
		let d = Oe ? i.outerHTML : i.innerHTML;
		return Oe && _e["!doctype"] && i.ownerDocument && i.ownerDocument.doctype && i.ownerDocument.doctype.name && ph(Vh, i.ownerDocument.doctype.name) && (d = "<!DOCTYPE " + i.ownerDocument.doctype.name + ">\n" + d), Ee && (d = Tt(d)), x && Pe ? ne(d) : d;
	}, t.setConfig = function() {
		ut(arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {}), M = !0, ke = _e, Ae = k;
	}, t.clearConfig = function() {
		st = null, M = !1, ke = null, Ae = null, x = C, S = "";
	}, t.isValidAttribute = function(e, t, n) {
		return st || ut({}), Pt(N(e), N(t), n);
	}, t.addHook = function(e, t) {
		typeof t == "function" && dh(E, e) && Qm(E[e], t);
	}, t.removeHook = function(e, t) {
		if (dh(E, e)) {
			if (t !== void 0) {
				let n = Xm(E[e], t);
				return n === -1 ? void 0 : $m(E[e], n, 1)[0];
			}
			return Zm(E[e]);
		}
	}, t.removeHooks = function(e) {
		dh(E, e) && (E[e] = []);
	}, t.removeAllHooks = function() {
		E = Xh();
	}, t;
}
var $h = Qh(), eg = ["innerHTML"], tg = "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"13\" height=\"13\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4\"/><polyline points=\"7 10 12 15 17 10\"/><line x1=\"12\" x2=\"12\" y1=\"15\" y2=\"3\"/></svg>", ng = "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"13\" height=\"13\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6\"/><polyline points=\"15 3 21 3 21 9\"/><line x1=\"10\" x2=\"21\" y1=\"14\" y2=\"3\"/></svg>", rg = /* @__PURE__ */ z({
	__name: "MarkdownRenderer",
	props: { content: {} },
	setup(e) {
		let t = e, n = Wl();
		jm.setOptions({
			gfm: !0,
			breaks: !0
		});
		let r = /* @__PURE__ */ F({}), i = (e) => {
			if (!e) return;
			let t = /(?:!\[.*?\]|\[.*?\])\((?:attachment:\/\/)?([^\s\)]+)\)|(?:src|href)=["'](?:attachment:\/\/)?([^"']+)["']/gi, n;
			for (; (n = t.exec(e)) !== null;) {
				let e = n[1] || n[2];
				if (!e || !(e.startsWith("images/") || e.startsWith("attachments/") || /^(?:img_|audio_|video_|file_)/i.test(e) || /\.(?:png|jpe?g|webp|gif|svg|mp3|wav|ogg|m4a|aac|flac|mp4|webm|ogv|mov|mkv|pdf|docx?|xlsx?|pptx?|zip|rar|7z|txt)$/i.test(e))) continue;
				let t = al.normalizeId(e);
				if (!t || r.value[t]) continue;
				let i = al.getImageUrlSync(t);
				if (i) {
					r.value[t] = i;
					continue;
				}
				al.getImageUrl(t).then((e) => {
					e ? r.value[t] = e : dl.downloadImageIfMissing(t).then((e) => {
						e && al.getImageUrl(t).then((e) => {
							e && (r.value[t] = e);
						});
					});
				});
			}
		};
		Gn(() => t.content, (e) => {
			i(e);
		}, { immediate: !0 });
		let a = (e) => {
			let t = e.toLowerCase();
			return t === "pdf" ? "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"20\" height=\"20\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"#e53935\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z\"/><polyline points=\"14 2 14 8 20 8\"/><path d=\"M10 12v6\"/><path d=\"M10 12h2a2 2 0 0 1 0 4h-2\"/></svg>" : ["doc", "docx"].includes(t) ? "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"20\" height=\"20\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"#1976d2\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z\"/><polyline points=\"14 2 14 8 20 8\"/><line x1=\"16\" x2=\"8\" y1=\"13\" y2=\"13\"/><line x1=\"16\" x2=\"8\" y1=\"17\" y2=\"17\"/><line x1=\"10\" x2=\"8\" y1=\"9\" y2=\"9\"/></svg>" : [
				"xls",
				"xlsx",
				"csv"
			].includes(t) ? "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"20\" height=\"20\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"#2e7d32\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z\"/><polyline points=\"14 2 14 8 20 8\"/><path d=\"M8 13h8\"/><path d=\"M8 17h8\"/><path d=\"M12 9v12\"/></svg>" : ["ppt", "pptx"].includes(t) ? "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"20\" height=\"20\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"#e65100\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z\"/><polyline points=\"14 2 14 8 20 8\"/><circle cx=\"12\" cy=\"14\" r=\"3\"/></svg>" : [
				"zip",
				"rar",
				"7z",
				"tar",
				"gz"
			].includes(t) ? "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"20\" height=\"20\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"#f57c00\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><polyline points=\"21 8 21 21 3 21 3 8\"/><rect width=\"22\" height=\"5\" x=\"1\" y=\"3\" rx=\"1\"/><line x1=\"10\" x2=\"14\" y1=\"12\" y2=\"12\"/></svg>" : [
				"mp3",
				"wav",
				"ogg",
				"m4a",
				"aac",
				"flac"
			].includes(t) ? "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"20\" height=\"20\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"#7b1fa2\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M9 18V5l12-2v13\"/><circle cx=\"6\" cy=\"18\" r=\"3\"/><circle cx=\"18\" cy=\"16\" r=\"3\"/></svg>" : [
				"mp4",
				"webm",
				"ogv",
				"mov",
				"mkv"
			].includes(t) ? "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"20\" height=\"20\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"#0288d1\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><rect width=\"20\" height=\"15\" x=\"2\" y=\"5\" rx=\"2\"/><polyline points=\"10 10 14 12.5 10 15\"/></svg>" : "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"20\" height=\"20\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z\"/><polyline points=\"14 2 14 8 20 8\"/></svg>";
		}, o = q(() => {
			if (!t.content) return "";
			let e = t.content;
			return e = e.replace(/!\[(.*?)\]\(((?:attachment:\/\/)?(?:images\/|attachments\/)?([a-zA-Z0-9_\-\.]+\.(?:png|jpe?g|webp|gif|svg|bmp|ico)))\)/gi, (e, t, n, i) => {
				let a = al.normalizeId(i), o = r.value[a] || al.getImageUrlSync(a);
				return o ? `![${t}](${o})` : `![${t || "图片"}](data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="160" height="40" viewBox="0 0 160 40"><rect width="160" height="40" rx="6" fill="%2388888820"/><text x="50%25" y="55%25" text-anchor="middle" dominant-baseline="middle" fill="%23888888" font-size="11" font-family="sans-serif">加载图片中...</text></svg>)`;
			}), e = e.replace(/\[audio:(.*?)\]\(((?:attachment:\/\/)?(?:images\/|attachments\/)?([^\s\)]+))\)/gi, (e, t, n, i) => {
				let a = al.normalizeId(i), o = r.value[a] || al.getImageUrlSync(a), s = al.getMetaSync(a), c = s?.size ? Yf(s.size) : "", l = (t || i || "音频").replace(/[<>&"]/g, ""), u = c ? `<span class="media-audio-size">${c}</span>` : "";
				return `\n\n<div class="media-audio-card" data-asset-id="${a}" data-filename="${l}" data-url="${o || ""}"><div class="media-audio-header"><span class="media-audio-icon"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/></svg></span><span class="media-audio-title" title="${l}">${l}</span>${u}</div><audio controls preload="metadata" src="${o || ""}" class="media-audio-element">您的浏览器不支持音频播放</audio></div>\n\n`;
			}), e = e.replace(/\[video:(.*?)\]\(((?:attachment:\/\/)?(?:images\/|attachments\/)?([^\s\)]+))\)/gi, (e, t, n, i) => {
				let a = al.normalizeId(i), o = r.value[a] || al.getImageUrlSync(a), s = al.getMetaSync(a), c = s?.size ? Yf(s.size) : "", l = (t || i || "视频").replace(/[<>&"]/g, ""), u = c ? `<span class="media-video-size">${c}</span>` : "";
				return `\n\n<div class="media-video-card" data-asset-id="${a}" data-filename="${l}" data-url="${o || ""}"><div class="media-video-header"><span class="media-video-icon"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect width="20" height="15" x="2" y="5" rx="2"/><polyline points="10 10 14 12.5 10 15"/></svg></span><span class="media-video-title" title="${l}">${l}</span>${u}</div><video controls preload="metadata" playsinline src="${o || ""}" class="media-video-element">您的浏览器不支持视频播放</video></div>\n\n`;
			}), e = e.replace(/\[(?:📎\s*)?(.*?)\]\(((?:attachment:\/\/)?(?:images\/|attachments\/)?([^\s\)]+))\)/gi, (e, t, n, i) => {
				if (e.startsWith("[audio:") || e.startsWith("[video:") || !(n.startsWith("attachment://") || n.startsWith("attachments/") || n.startsWith("images/") || /^(?:file_|img_|audio_|video_)/i.test(i))) return e;
				let o = al.normalizeId(i), s = r.value[o] || al.getImageUrlSync(o), c = al.getMetaSync(o), l = (t || i || "附件").trim(), u = "", d = l.match(/\s*\(([0-9.]+\s*[KMGT]?B)\)$/i);
				d && (u = d[1], l = l.replace(/\s*\([0-9.]+\s*[KMGT]?B\)$/i, "").trim()), !u && c?.size && (u = Yf(c.size));
				let f = l.replace(/[<>&"]/g, ""), p = (f.split(".").pop() || i.split(".").pop() || "file").toLowerCase(), m = a(p), h = p === "pdf", g = `<button class="chip-action-btn" type="button" data-action="${h ? "preview" : "download"}" title="${h ? "在浏览器新标签页中预览" : "下载到本地"}">${h ? ng : tg}<span class="action-text">${h ? "预览" : "下载"}</span></button>`, _ = h ? `<button class="chip-action-btn secondary" type="button" data-action="download" title="下载到本地">${tg}</button>` : "";
				return `\n\n<div class="attachment-file-chip" data-asset-id="${o}" data-filename="${f}" data-url="${s || ""}" data-ext="${p}" title="点击${h ? "预览 PDF" : "下载文件"}"><div class="chip-main"><span class="chip-icon">${m}</span><div class="chip-text"><span class="chip-filename" title="${f}">${f}</span><span class="chip-meta">${u || p.toUpperCase()}</span></div></div><div class="chip-actions">${g}${_}</div></div>\n\n`;
			}), e;
		}), s = q(() => {
			if (!o.value) return "";
			let e = jm.parse(o.value);
			return $h.sanitize(e, {
				ALLOWED_URI_REGEXP: /^(?:(?:(?:f|ht)tps?|mailto|tel|callto|sms|cid|xmpp|blob|data):|[^a-z]|[a-z+.\-]+(?:[^a-z+.\-:]|$))/i,
				ADD_TAGS: [
					"audio",
					"video",
					"source",
					"button",
					"svg",
					"path",
					"polyline",
					"line",
					"circle",
					"rect"
				],
				ADD_ATTR: /* @__PURE__ */ "target.class.controls.preload.playsinline.src.type.data-asset-id.data-filename.data-url.data-ext.data-action.title.viewBox.fill.stroke.stroke-width.stroke-linecap.stroke-linejoin.d.x.y.x1.y1.x2.y2.cx.cy.r.rx.ry.points".split(".")
			});
		}), c = async (e, t, r) => {
			if (e) try {
				let i = await al.getImageBlob(e);
				if (i ||= (n.showToast("正在从云端获取附件...", "info"), await dl.downloadImageIfMissing(e)), !i) {
					n.showToast("附件加载失败，未找到本地或云端文件", "error");
					return;
				}
				if (r === "preview" && (t.toLowerCase().endsWith(".pdf") || i.type === "application/pdf")) {
					let e = URL.createObjectURL(i);
					window.open(e, "_blank"), setTimeout(() => URL.revokeObjectURL(e), 6e4), n.showToast(`已在新标签页中打开预览: ${t}`, "info");
				} else {
					let e = await Xf(i, t);
					e === "saved" ? n.showToast(`文件已成功保存: ${t}`, "success") : e === "canceled" || (e === "failed" ? n.showToast("下载触发失败，请重试", "error") : n.showToast(`已开始下载: ${t}`, "success"));
				}
			} catch (e) {
				console.error("File action error:", e), n.showToast(`操作失败: ${e.message || "未知错误"}`, "error");
			}
		}, l = (e) => {
			let t = e.target;
			if (!t) return;
			let n = t.closest(".attachment-file-chip");
			if (n) {
				e.stopPropagation(), e.preventDefault();
				let r = n.getAttribute("data-asset-id") || "", i = n.getAttribute("data-filename") || "attachment", a = n.getAttribute("data-ext") || "";
				c(r, i, t.closest(".chip-action-btn")?.getAttribute("data-action") || (a === "pdf" ? "preview" : "download"));
				return;
			}
			if (t.tagName === "IMG") {
				e.stopPropagation();
				let n = t.src;
				if (n) {
					let t = e.currentTarget, r = (t ? Array.from(t.querySelectorAll("img")) : []).map((e) => e.src).filter(Boolean), i = r.indexOf(n);
					Gf(n, r, i === -1 ? 0 : i);
				}
			} else if (t.tagName === "A") {
				let n = t.getAttribute("href");
				n && (n.startsWith("http://") || n.startsWith("https://")) && (e.stopPropagation(), e.preventDefault(), window.open(n, "_blank", "noopener,noreferrer"));
			}
		};
		return (e, t) => (V(), H("div", {
			class: "markdown-body",
			onClick: l,
			innerHTML: s.value
		}, null, 8, eg));
	}
}), ig = ["placeholder"], ag = { class: "card-body-content" }, og = {
	key: 1,
	class: "card-content"
}, sg = {
	key: 0,
	class: "note-tags-list"
}, cg = ["data-tooltip", "onClick"], lg = ["data-tooltip"], ug = /*#__PURE__*/ Z(/* @__PURE__ */ z({
	__name: "NoteCardBody",
	props: /*@__PURE__*/ si({
		note: {},
		isEditing: { type: Boolean },
		isFullScreen: {
			type: Boolean,
			default: !1
		}
	}, {
		content: { default: "" },
		contentModifiers: {}
	}),
	emits: /*@__PURE__*/ si([
		"cancel-edit",
		"save-edit",
		"switch-to-markdown"
	], ["update:content"]),
	setup(e, { expose: t, emit: n }) {
		let r = e, i = Di(e, "content"), a = n, o = Wl(), s = Il(), c = /* @__PURE__ */ F(null), l = /* @__PURE__ */ F(null), u = /* @__PURE__ */ F(!1), d = async (e) => {
			if (!(!e || e.length === 0)) try {
				o.showToast(e.length > 1 ? `正在处理 ${e.length} 个附件...` : "正在处理附件...", "info");
				let t = [];
				for (let n of e) {
					let e = await Qf(n);
					t.push(e.markdownText);
				}
				let n = t.join("\n");
				if (a("switch-to-markdown"), r.isEditing) {
					let e = c.value;
					if (e) {
						let t = e.selectionStart ?? i.value.length, r = e.selectionEnd ?? i.value.length, a = i.value || "";
						i.value = a.substring(0, t) + n + a.substring(r), await Tn();
						let o = t + n.length;
						e.setSelectionRange(o, o), x();
					} else i.value = (i.value || "") + n;
				} else {
					let e = (r.note.content ? `${r.note.content}\n` : "") + n.trim();
					o.updateNote(r.note.id, {
						content: e,
						type: "markdown"
					});
				}
				o.showToast(e.length > 1 ? `已插入 ${e.length} 个附件` : "附件已插入", "success");
			} catch (e) {
				console.error("Failed to process files:", e), o.showToast(`附件处理失败: ${e.message || "未知异常"}`, "error");
			}
		}, f = () => {
			typeof window < "u" && (window.__isFileDialogActive = !0), l.value?.click();
		}, p = async (e) => {
			typeof window < "u" && window.setTimeout(() => {
				window.__isFileDialogActive = !1;
			}, 500);
			let t = e.target;
			if (!t.files || t.files.length === 0) return;
			let n = Array.from(t.files);
			t.value = "", await d(n);
		}, m = () => {
			typeof window < "u" && window.setTimeout(() => {
				window.__isFileDialogActive = !1;
			}, 300);
		}, h = async (e) => {
			let t = Zf(e);
			!t || t.length === 0 || (e.preventDefault(), e.stopPropagation(), await d(t));
		}, g = (e) => {
			e.dataTransfer && Array.from(e.dataTransfer.types).includes("Files") && (e.preventDefault(), e.stopPropagation(), e.dataTransfer.dropEffect = "copy", u.value = !0);
		}, _ = (e) => {
			(!e.currentTarget || !e.currentTarget.contains(e.relatedTarget)) && (u.value = !1);
		}, v = async (e) => {
			if (e.dataTransfer && Array.from(e.dataTransfer.types).includes("Files")) {
				e.preventDefault(), e.stopPropagation(), u.value = !1;
				let t = Zf(e);
				t.length > 0 && await d(t);
			}
		}, y = (e) => {
			let t = s.getEventKeyString(e);
			if (!t) return;
			let n = s.shortcuts.find((e) => e.currentKey === t);
			n && (n.id === "saveEdit" ? (e.preventDefault(), e.stopPropagation(), a("save-edit")) : n.id === "cancelEdit" && (e.preventDefault(), e.stopPropagation(), a("cancel-edit")));
		}, b = async (e) => {
			try {
				await navigator.clipboard.writeText(e), o.showToast(`已复制标签: ${e}`, "success");
			} catch (e) {
				console.error("Failed to copy tag:", e), o.showToast("复制失败", "error");
			}
		}, x = () => {
			let e = c.value;
			e && (e.style.height = "auto", e.style.height = `${e.scrollHeight}px`);
		}, { measureContainerRef: S, measureEllipsisRef: C, visibleTags: w, hasMore: ee, allTagsText: te, calculateVisibleTags: ne } = Bf(() => r.note);
		return Gn(() => r.isEditing, async (e) => {
			e ? (await Tn(), c.value?.focus(), x()) : ne(!0);
		}), t({ triggerFileInput: f }), (t, n) => (V(), H("div", {
			class: O(["card-body", {
				"is-view-mode": !e.isEditing,
				"is-full-screen": e.isFullScreen,
				"is-drag-over": u.value
			}]),
			onPaste: h,
			onDragover: g,
			onDragleave: _,
			onDrop: v
		}, [W("input", {
			ref_key: "fileInputRef",
			ref: l,
			type: "file",
			multiple: "",
			style: { display: "none" },
			onChange: p,
			onCancel: m
		}, null, 544), e.isEditing ? Ln((V(), H("textarea", {
			key: 0,
			ref_key: "contentInputRef",
			ref: c,
			"onUpdate:modelValue": n[0] ||= (e) => i.value = e,
			placeholder: e.note.type === "markdown" ? "输入 Markdown 源码..." : "写点什么...",
			class: O(["content-textarea", { "is-full-screen": e.isFullScreen }]),
			onKeydown: y,
			onInput: x,
			onPaste: h
		}, null, 42, ig)), [[ks, i.value]]) : (V(), H(B, { key: 1 }, [
			W("div", ag, [e.note.type === "markdown" && e.note.content ? (V(), U(rg, {
				key: 0,
				content: e.note.content
			}, null, 8, ["content"])) : (V(), H("pre", og, j(e.note.content || (e.note.isDeleted ? "无内容" : "双击粘贴，点击右上角编辑...")), 1))]),
			e.note.tags && e.note.tags.length > 0 ? (V(), H("div", sg, [(V(!0), H(B, null, $r(I(w), (e) => (V(), H("span", {
				key: e,
				class: "note-tag-badge",
				"data-tooltip": e,
				onClick: J((t) => b(e), ["stop"])
			}, j(I(o).prefixTagWithHash ? "# " : "") + j(e), 9, cg))), 128)), I(ee) ? (V(), H("span", {
				key: 0,
				class: "note-tag-badge more",
				"data-tooltip": I(te)
			}, " ... ", 8, lg)) : K("", !0)])) : K("", !0),
			e.note.tags && e.note.tags.length > 0 ? (V(), H("div", {
				key: 1,
				ref_key: "measureContainerRef",
				ref: S,
				class: "note-tags-list-measure"
			}, [(V(!0), H(B, null, $r(e.note.tags, (e) => (V(), H("span", {
				key: "measure-" + e,
				class: "note-tag-badge"
			}, j(I(o).prefixTagWithHash ? "# " : "") + j(e), 1))), 128)), W("span", {
				ref_key: "measureEllipsisRef",
				ref: C,
				class: "note-tag-badge more"
			}, "...", 512)], 512)) : K("", !0)
		], 64))], 34));
	}
}), [["__scopeId", "data-v-63e79998"]]), dg = ["onClick"], fg = { class: "tag-input-wrapper" }, pg = ["onKeydown"], mg = {
	key: 0,
	class: "dropdown-item empty"
}, hg = ["data-tooltip", "onClick"], gg = { class: "tag-text" }, _g = {
	key: 0,
	class: "check-icon"
}, vg = /*#__PURE__*/ Z(/* @__PURE__ */ z({
	__name: "NoteCardTagEditor",
	props: {
		tags: { default: () => [] },
		tagsModifiers: {}
	},
	emits: ["update:tags"],
	setup(e, { expose: t }) {
		let n = Di(e, "tags"), r = /* @__PURE__ */ F(""), i = /* @__PURE__ */ F(!1), a = /* @__PURE__ */ F(null), o = Wl(), s = q(() => {
			let e = /* @__PURE__ */ new Set();
			return o.allNotes.forEach((t) => {
				t.tags && t.tags.forEach((t) => {
					t.trim() && e.add(t.trim());
				});
			}), Array.from(e).sort((e, t) => e.localeCompare(t, "zh"));
		}), c = () => {
			let e = r.value.replace(/，/g, ",").trim();
			e.endsWith(",") && (e = e.slice(0, -1).trim()), e && e.split(",").map((e) => e.trim()).filter(Boolean).forEach((e) => {
				n.value.includes(e) || n.value.push(e);
			}), r.value = "";
		}, l = (e) => {
			n.value.splice(e, 1);
		}, u = () => {
			i.value = !i.value, i.value && a.value?.focus();
		}, d = () => {
			c(), i.value = !1;
		}, f = (e) => {
			let t = n.value.indexOf(e);
			t > -1 ? n.value.splice(t, 1) : n.value.push(e);
		}, p = (e) => {
			(e.key === "," || e.key === "，") && (e.preventDefault(), c());
		};
		return t({ addTag: c }), (e, t) => (V(), H("div", {
			class: "tags-editor",
			onClick: t[3] ||= J(() => {}, ["stop"])
		}, [(V(!0), H(B, null, $r(n.value, (e, t) => (V(), H("div", {
			key: t,
			class: "edit-tag-badge"
		}, [W("span", null, j(e), 1), W("button", {
			class: "delete-tag-btn",
			"data-tooltip": "删除标签",
			onClick: J((e) => l(t), ["stop"])
		}, " × ", 8, dg)]))), 128)), W("div", fg, [
			Ln(W("input", {
				ref_key: "inputRef",
				ref: a,
				"onUpdate:modelValue": t[0] ||= (e) => r.value = e,
				type: "text",
				placeholder: "+ 添加标签 (按回车或逗号)",
				class: "tag-input",
				onKeydown: [Us(J(c, ["prevent"]), ["enter"]), p],
				onBlur: d
			}, null, 40, pg), [[ks, r.value]]),
			W("button", {
				class: "arrow-btn",
				type: "button",
				"data-tooltip": "选择已有标签",
				onMousedown: t[1] ||= J(() => {}, ["prevent"]),
				onClick: u
			}, [(V(), H("svg", {
				class: O(["arrow-icon", { open: i.value }]),
				viewBox: "0 0 24 24",
				width: "12",
				height: "12"
			}, [...t[4] ||= [W("path", {
				fill: "currentColor",
				d: "M7 10l5 5 5-5z"
			}, null, -1)]], 2))], 32),
			i.value ? (V(), H("div", {
				key: 0,
				class: "tags-dropdown",
				onMousedown: t[2] ||= J(() => {}, ["prevent"])
			}, [s.value.length === 0 ? (V(), H("div", mg, " 暂无已有标签 ")) : (V(!0), H(B, { key: 1 }, $r(s.value, (e) => (V(), H("div", {
				key: e,
				class: O(["dropdown-item", { selected: n.value.includes(e) }]),
				"data-tooltip": e,
				onClick: (t) => f(e)
			}, [W("span", gg, j(e), 1), n.value.includes(e) ? (V(), H("span", _g, "✓")) : K("", !0)], 10, hg))), 128))], 32)) : K("", !0)
		])]));
	}
}), [["__scopeId", "data-v-c51a1ed9"]]);
//#endregion
//#region src/utils/date.ts
function yg(e, t) {
	if (!t) return "";
	let n = e.getFullYear(), r = e.getMonth() + 1, i = e.getDate(), a = e.getHours(), o = e.getMinutes(), s = e.getSeconds(), c = {
		YYYY: n,
		YY: String(n).slice(-2),
		MM: String(r).padStart(2, "0"),
		M: r,
		DD: String(i).padStart(2, "0"),
		D: i,
		HH: String(a).padStart(2, "0"),
		H: a,
		hh: String(a % 12 || 12).padStart(2, "0"),
		h: a % 12 || 12,
		mm: String(o).padStart(2, "0"),
		m: o,
		ss: String(s).padStart(2, "0"),
		s,
		A: a >= 12 ? "PM" : "AM",
		a: a >= 12 ? "下午" : "上午"
	};
	return t.replace(/Y{2,4}|M{1,2}|D{1,2}|H{1,2}|h{1,2}|m{1,2}|s{1,2}|[Aa]/g, (e) => String(c[e] === void 0 ? e : c[e]));
}
//#endregion
//#region src/components/BasePopover.vue?vue&type=script&setup=true&lang.ts
var bg = {
	key: 0,
	class: "popover-header"
}, xg = { class: "popover-title-text" }, Sg = { class: "popover-content" }, Cg = /*#__PURE__*/ Z(/* @__PURE__ */ z({
	__name: "BasePopover",
	props: {
		isOpen: { type: Boolean },
		title: { default: "" },
		width: { default: "140px" },
		placement: { default: "auto" },
		align: { default: "right" }
	},
	emits: ["close"],
	setup(e, { emit: t }) {
		let n = e, r = t, i = /* @__PURE__ */ F(null), a = /* @__PURE__ */ F("top"), o = () => {
			if (n.placement !== "auto") {
				a.value = n.placement;
				return;
			}
			i.value && (i.value.getBoundingClientRect().top < 200 ? a.value = "bottom" : a.value = "top");
		};
		Gn(() => n.isOpen, (e) => {
			e && o();
		});
		let s = (e) => {
			if (!n.isOpen) return;
			let t = e.target;
			i.value && !i.value.contains(t) && r("close");
		};
		return Rr(() => {
			document.addEventListener("click", s, !0);
		}), Hr(() => {
			document.removeEventListener("click", s, !0);
		}), (t, n) => (V(), H("div", {
			ref_key: "wrapperRef",
			ref: i,
			class: "base-popover-wrapper",
			onClick: n[0] ||= J(() => {}, ["stop"])
		}, [ei(t.$slots, "trigger", {}, void 0, !0), G(wo, { name: "popover-fade" }, {
			default: R(() => [e.isOpen ? (V(), H("div", {
				key: 0,
				class: O(["base-popover-panel", [`placement-${a.value}`, `align-${e.align}`]]),
				style: D({ width: e.width })
			}, [e.title || t.$slots.header ? (V(), H("div", bg, [ei(t.$slots, "header", {}, () => [W("span", xg, j(e.title), 1)], !0)])) : K("", !0), W("div", Sg, [ei(t.$slots, "default", {}, void 0, !0)])], 6)) : K("", !0)]),
			_: 3
		})], 512));
	}
}), [["__scopeId", "data-v-c3d9d743"]]), wg = (e) => {
	if (!e || typeof window > "u") return "";
	let t = window.getSelection();
	if (!t || t.isCollapsed) return "";
	let n = t.toString();
	if (!n || !n.trim()) return "";
	let r = t.anchorNode, i = t.focusNode;
	if (!r && !i) return "";
	let a = (e) => {
		if (!e) return !1;
		let t = typeof Node < "u" ? Node.ELEMENT_NODE : 1;
		return e.nodeType === t;
	}, o = a(r) ? r : r?.parentElement, s = a(i) ? i : i?.parentElement;
	return o && s && e.contains(o) && e.contains(s) ? n : "";
}, Tg = { class: "edit-tools" }, Eg = { class: "edit-actions" }, Dg = ["data-tooltip"], Og = {
	key: 0,
	class: "card-actions is-deleted-actions"
}, kg = ["data-tooltip"], Ag = ["data-tooltip"], jg = { class: "color-picker-list" }, Mg = ["data-tooltip", "onClick"], Ng = { class: "folder-list" }, Pg = ["onClick"], Fg = {
	key: 0,
	style: {
		opacity: "0.5",
		"margin-right": "4px"
	}
}, Ig = { class: "folder-name-text" }, Lg = ["data-tooltip"], Rg = { class: "format-list" }, zg = /*#__PURE__*/ Z(/* @__PURE__ */ z({
	__name: "NoteCardFooter",
	props: {
		note: {},
		isEditing: { type: Boolean }
	},
	emits: [
		"save-edit",
		"cancel-edit",
		"add-attachment",
		"popover-state-change"
	],
	setup(e, { expose: t, emit: n }) {
		let r = e, i = n, a = Wl(), o = /* @__PURE__ */ F(!1), s = /* @__PURE__ */ F(!1), c = /* @__PURE__ */ F(!1);
		Gn(() => o.value || s.value || c.value, (e) => {
			i("popover-state-change", e);
		}), t({ closePopovers: () => {
			o.value = !1, s.value = !1, c.value = !1;
		} });
		let l = q(() => yg(new Date(r.note.updatedAt), a.dateFormat || "YYYY.MM.DD HH:mm")), u = q(() => {
			if (r.note.categoryId === "uncategorized") return "全部便签";
			let e = a.categories.find((e) => e.id === r.note.categoryId);
			return e ? e.name : "全部便签";
		}), d = async (e) => {
			try {
				let t = r.note.content, n = !1;
				if (e && e.currentTarget) {
					let r = wg(e.currentTarget.closest(".note-card"));
					r && (t = r, n = !0);
				}
				if (!t.trim()) {
					a.showToast("便签内容为空，无法复制", "warning");
					return;
				}
				await navigator.clipboard.writeText(t), a.showToast(n ? "已复制选中内容" : "已复制便签内容", "success"), a.updateNoteLastUsed(r.note.id);
			} catch (e) {
				console.error("Failed to copy:", e), a.showToast("复制失败", "error");
			}
		}, f = (e) => {
			a.updateNote(r.note.id, { color: e }, !1), o.value = !1;
		}, p = (e) => {
			a.updateNote(r.note.id, { categoryId: e }, !1), s.value = !1;
			let t = a.categories.find((t) => t.id === e);
			a.showToast(`已移至分类 "${t?.name || "全部便签"}"`);
		}, m = (e) => {
			a.updateNote(r.note.id, { type: e }, !1), c.value = !1, a.showToast(e === "markdown" ? "已切换为 Markdown 格式" : "已切换为纯文本格式");
		}, h = async () => {
			if (a.skipDeleteConfirm) {
				a.deleteNote(r.note.id);
				return;
			}
			await a.askConfirm(r.note.isDeleted ? "确认彻底删除" : "确认删除便签", r.note.isDeleted ? "确定要彻底删除这张便签吗？此操作不可逆，数据将永久丢失。" : "确定要删除这张便签吗？该便签将被移动到最近删除，随时可以恢复。") && a.deleteNote(r.note.id);
		};
		return (t, n) => e.isEditing ? (V(), H("div", {
			key: 0,
			class: "edit-footer",
			onClick: n[3] ||= J(() => {}, ["stop"])
		}, [W("div", Tg, [W("button", {
			class: "edit-tool-btn",
			type: "button",
			title: "添加附件 (图片、音视频、文档等)",
			onClick: n[0] ||= (e) => i("add-attachment")
		}, [G(I(Nu), { class: "edit-tool-icon" }), n[15] ||= W("span", null, "添加附件", -1)])]), W("div", Eg, [W("button", {
			class: "edit-btn cancel",
			onClick: n[1] ||= (e) => i("cancel-edit")
		}, " 取消 "), W("button", {
			class: "edit-btn save",
			onClick: n[2] ||= (e) => i("save-edit")
		}, " 保存 ")])])) : (V(), H("div", {
			key: 1,
			class: "card-footer",
			onClick: n[14] ||= J(() => {}, ["stop"])
		}, [W("div", {
			class: "card-meta-info",
			"data-tooltip": `更新时间: ${l.value} · 总字数: ${e.note.content.length} 字`
		}, j(l.value) + " · " + j(e.note.content.length) + " 字 ", 9, Dg), e.note.isDeleted ? (V(), H("div", Og, [
			W("button", {
				class: "action-btn",
				"data-tooltip": `原分组: ${u.value}`
			}, [G(I(Su), { class: "action-icon" })], 8, kg),
			W("button", {
				class: "action-btn",
				"data-tooltip": "复制内容",
				onClick: d
			}, [G(I(pu), { class: "action-icon" })]),
			W("button", {
				class: "action-btn",
				"data-tooltip": "恢复便签",
				onClick: n[4] ||= (t) => I(a).restoreNote(e.note.id)
			}, [G(I(Hu), { class: "action-icon" })]),
			W("button", {
				class: "action-btn delete",
				"data-tooltip": "彻底删除",
				onClick: h
			}, [G(I(Zu), { class: "action-icon" })])
		])) : (V(), H("div", {
			key: 1,
			class: O(["card-actions", { "has-active-popover": o.value || s.value || c.value }])
		}, [
			["all", "recent"].includes(I(a).currentCategoryId) ? (V(), H("button", {
				key: 0,
				class: "action-btn",
				"data-tooltip": `分组: ${u.value}`
			}, [G(I(Su), { class: "action-icon" })], 8, Ag)) : K("", !0),
			G(Cg, {
				"is-open": o.value,
				width: "auto",
				onClose: n[6] ||= (e) => o.value = !1
			}, {
				trigger: R(() => [W("button", {
					class: "action-btn",
					"data-tooltip": "更改颜色",
					onClick: n[5] ||= (e) => {
						o.value = !o.value, s.value = !1, c.value = !1;
					}
				}, [G(I(Mu), { class: "action-icon" })])]),
				default: R(() => [W("div", jg, [(V(!0), H(B, null, $r(I(tl), (t, n) => (V(), H("button", {
					key: n,
					class: "color-dot",
					style: D({
						background: t.lightBg,
						border: `1px solid ${t.lightBorder}`
					}),
					"data-tooltip": t.name,
					onClick: (e) => f(n.toString())
				}, [e.note.color === n ? (V(), U(I(nu), {
					key: 0,
					class: "dot-check-icon"
				})) : K("", !0)], 12, Mg))), 128))])]),
				_: 1
			}, 8, ["is-open"]),
			G(Cg, {
				"is-open": s.value,
				title: "移动至分类",
				width: "130px",
				onClose: n[9] ||= (e) => s.value = !1
			}, {
				trigger: R(() => [W("button", {
					class: "action-btn",
					"data-tooltip": "移动分类",
					onClick: n[7] ||= (e) => {
						s.value = !s.value, o.value = !1, c.value = !1;
					}
				}, [G(I(xu), { class: "action-icon" })])]),
				default: R(() => [W("div", Ng, [W("button", {
					class: O(["folder-item", { active: e.note.categoryId === "uncategorized" }]),
					onClick: n[8] ||= (e) => p("uncategorized")
				}, [...n[16] ||= [W("span", { class: "folder-name-text" }, "全部便签", -1)]], 2), (V(!0), H(B, null, $r(I(a).orderedCategories.filter((e) => !e.isSystem), (t) => (V(), H("button", {
					key: t.id,
					class: O(["folder-item", { active: e.note.categoryId === t.id }]),
					style: D({ paddingLeft: `${Math.max((t.level || 0) - 1, 0) * 8 + 8}px` }),
					onClick: (e) => p(t.id)
				}, [t.level > 0 ? (V(), H("span", Fg, "└")) : K("", !0), W("span", Ig, j(t.name), 1)], 14, Pg))), 128))])]),
				_: 1
			}, 8, ["is-open"]),
			G(Cg, {
				"is-open": c.value,
				title: "显示格式",
				width: "120px",
				onClose: n[13] ||= (e) => c.value = !1
			}, {
				trigger: R(() => [W("button", {
					class: "action-btn",
					"data-tooltip": e.note.type === "markdown" ? "当前格式: Markdown" : "当前格式: 纯文本",
					onClick: n[10] ||= (e) => {
						c.value = !c.value, o.value = !1, s.value = !1;
					}
				}, [e.note.type === "markdown" ? (V(), U(I(yu), {
					key: 0,
					class: "action-icon"
				})) : (V(), U(I(bu), {
					key: 1,
					class: "action-icon"
				}))], 8, Lg)]),
				default: R(() => [W("div", Rg, [W("button", {
					class: O(["format-item", { active: !e.note.type || e.note.type === "text" }]),
					onClick: n[11] ||= (e) => m("text")
				}, [G(I(bu), { class: "item-icon" }), n[17] ||= W("span", null, "纯文本", -1)], 2), W("button", {
					class: O(["format-item", { active: e.note.type === "markdown" }]),
					onClick: n[12] ||= (e) => m("markdown")
				}, [G(I(yu), { class: "item-icon" }), n[18] ||= W("span", null, "Markdown", -1)], 2)])]),
				_: 1
			}, 8, ["is-open"]),
			W("button", {
				class: "action-btn",
				"data-tooltip": "复制内容",
				onClick: d
			}, [G(I(pu), { class: "action-icon" })]),
			W("button", {
				class: "action-btn delete",
				"data-tooltip": "删除便签",
				onClick: h
			}, [G(I(Zu), { class: "action-icon" })])
		], 2))]));
	}
}), [["__scopeId", "data-v-bee22605"]]), Bg = ["draggable"], Vg = /*#__PURE__*/ Z(/* @__PURE__ */ z({
	__name: "NoteCard",
	props: {
		note: {},
		isFullScreen: {
			type: Boolean,
			default: !1
		},
		isImmersiveFullScreen: {
			type: Boolean,
			default: !1
		}
	},
	setup(e) {
		let t = e, n = Wl(), r = /* @__PURE__ */ F(!1), i = /* @__PURE__ */ F(t.note.title || ""), a = /* @__PURE__ */ F(t.note.content), o = /* @__PURE__ */ F([]), s = /* @__PURE__ */ F(null), c = /* @__PURE__ */ F(null), l = /* @__PURE__ */ F(null), u = () => {
			s.value?.triggerFileInput();
		}, d = /* @__PURE__ */ F(!1), f = (e) => {
			d.value = e;
		}, p = q(() => {
			let e = tl[t.note.color] || tl.yellow;
			return {
				"--card-bg": e.lightBg,
				"--card-border": e.lightBorder,
				"--card-text": e.lightText,
				"--card-bg-dark": e.darkBg,
				"--card-border-dark": e.darkBorder,
				"--card-text-dark": e.darkText,
				"--card-btn-hover-bg": e.lightBtnHoverBg,
				"--card-btn-hover-color": e.lightBtnHoverColor,
				"--card-btn-hover-bg-dark": e.darkBtnHoverBg,
				"--card-btn-hover-color-dark": e.darkBtnHoverColor
			};
		}), m = () => {
			if (!t.isFullScreen && n.defaultEditMode === "fullscreen") {
				n.editingNoteId = t.note.id, n.openedFullscreenForEditNoteId = t.note.id, n.openNotePreview(t.note.id);
				return;
			}
			r.value = !0, i.value = t.note.title || "", a.value = t.note.content, o.value = t.note.tags ? [...t.note.tags] : [], n.editingNoteId = t.note.id;
		}, h = () => {
			c.value?.addTag();
			let e = i.value.trim() !== (t.note.title || "").trim(), s = a.value !== t.note.content, l = t.note.tags || [], u = o.value.length !== l.length || !o.value.every((e, t) => e === l[t]);
			if (e || s || u) n.updateNote(t.note.id, {
				title: i.value.trim(),
				content: a.value,
				tags: o.value
			}), r.value = !1;
			else {
				g();
				return;
			}
			n.editingNoteId === t.note.id && (n.editingNoteId = null), n.openedFullscreenForEditNoteId === t.note.id && n.closeNotePreview();
		}, g = () => {
			r.value = !1, i.value = t.note.title || "", a.value = t.note.content, o.value = [], n.editingNoteId === t.note.id && (n.editingNoteId = null), n.openedFullscreenForEditNoteId === t.note.id && n.closeNotePreview();
		}, _ = () => {
			t.note.type !== "markdown" && n.updateNote(t.note.id, { type: "markdown" }, !1);
		}, v = () => {
			let e = n.openedFullscreenForEditNoteId === t.note.id;
			r.value && h(), e || n.toggleNotePreview(t.note.id);
		}, y = null, b = "", x = () => {
			if (!n.enableAutoCopySelection || r.value || t.note.isDeleted) return;
			let e = wg(ce.value);
			if (!e) {
				y &&= (clearTimeout(y), null), b = "";
				return;
			}
			e !== b && (y && clearTimeout(y), y = window.setTimeout(async () => {
				y = null;
				let r = wg(ce.value);
				if (!(!r || r !== e)) {
					b = r;
					try {
						await navigator.clipboard.writeText(r), n.updateNoteLastUsed(t.note.id);
					} catch (e) {
						console.error("Auto copy failed:", e);
					}
				}
			}, 200));
		}, S = () => {
			r.value || Xc(n.doubleClickNoteAction, {
				copyAndPaste: () => n.handlePasteNote(t.note.content, t.note.id),
				openFullscreen: v,
				deleteNote: () => n.deleteNote(t.note.id)
			});
		}, C = () => {
			t.note.isDeleted || (n.updateNote(t.note.id, { isPinned: !t.note.isPinned }, !1), n.showToast(t.note.isPinned ? "便签已置顶" : "取消置顶"));
		}, w = /* @__PURE__ */ F(!1), ee = () => {
			w.value = !1;
		}, te = () => {
			n.sortMode !== "custom" || r.value || t.note.isDeleted || n.currentCategoryId === "recent" || (w.value = !0);
		}, ne = () => {
			n.draggedNoteId !== t.note.id && (w.value = !1);
		}, T = (e) => {
			if (n.sortMode !== "custom" || r.value || t.note.isDeleted || !w.value) {
				e.preventDefault();
				return;
			}
			n.draggedNoteId = t.note.id, e.dataTransfer && (e.dataTransfer.effectAllowed = "move", e.dataTransfer.setData("text/plain", t.note.id));
		}, re = (e) => {
			if (n.sortMode !== "custom") return;
			let r = n.draggedNoteId;
			if (!r || r === t.note.id || e.clientX === 0 && e.clientY === 0) return;
			let i = n.filteredNotes.findIndex((e) => e.id === r), a = n.filteredNotes.findIndex((e) => e.id === t.note.id);
			if (i === -1 || a === -1 || !ce.value) return;
			let o = ce.value.getBoundingClientRect(), s = document.querySelector(".note-card.dragging");
			if (!s) return;
			let c = s.getBoundingClientRect(), l = Math.abs(c.top - o.top) < 20, u = !1;
			u = l ? i < a ? e.clientX > o.left + o.width / 2 : e.clientX < o.left + o.width / 2 : i < a ? e.clientY > o.top + o.height / 2 : e.clientY < o.top + o.height / 2, u && n.moveNote(r, t.note.id);
		}, ie = () => {
			n.draggedNoteId = null, w.value = !1;
		}, ae = (e) => {
			e.preventDefault(), n.draggedNoteId = null, w.value = !1;
		}, oe = () => {
			l.value?.closePopovers();
		}, se = (e) => {
			let t = e.target;
			t && !t.closest(".base-popover-wrapper") && !t.closest(".action-popover-wrapper") && l.value?.closePopovers();
		}, ce = /* @__PURE__ */ F(null), le = null, E = (e) => {
			le = e.target;
		}, ue = (e) => {
			if (!r.value || !ce.value) return;
			let t = e.target, n = ce.value.contains(le), i = ce.value.contains(t);
			!n && !i && h();
		};
		Gn(r, (e) => {
			e ? Tn(() => {
				document.addEventListener("mousedown", E, !0), document.addEventListener("click", ue, !0);
			}) : (document.removeEventListener("mousedown", E, !0), document.removeEventListener("click", ue, !0), le = null);
		}), Vr(() => {
			y &&= (clearTimeout(y), null), r.value && h(), n.editingNoteId === t.note.id && (n.editingNoteId = null), document.removeEventListener("mousedown", E, !0), document.removeEventListener("click", ue, !0), window.removeEventListener("mouseup", ee), document.removeEventListener("selectionchange", x);
		});
		let de = q(() => ({ "--card-max-height": `${n.noteMaxHeight}px` }));
		return Rr(() => {
			window.addEventListener("mouseup", ee), document.addEventListener("selectionchange", x), n.editingNoteId === t.note.id && m();
		}), (t, y) => (V(), H("div", {
			ref_key: "cardRef",
			ref: ce,
			class: O(["note-card", {
				pinned: e.note.isPinned,
				editing: r.value,
				dragging: I(n).draggedNoteId === e.note.id,
				"is-in-trash": e.note.isDeleted,
				"has-active-popover": d.value,
				"enable-hover-anim": I(n).enableHoverAnimation && !e.isFullScreen,
				"is-full-screen": e.isFullScreen,
				"is-immersive-full-screen": e.isFullScreen && e.isImmersiveFullScreen
			}]),
			style: D([p.value, de.value]),
			draggable: I(n).sortMode === "custom" && !r.value && !e.note.isDeleted && w.value,
			onDblclick: S,
			onDragstart: T,
			onDragover: J(re, ["prevent"]),
			onDragend: ie,
			onDrop: ae,
			onMouseleave: oe,
			onClickCapture: se
		}, [
			I(n).sortMode === "custom" && !r.value && !e.note.isDeleted && !e.isFullScreen ? (V(), H("div", {
				key: 0,
				class: "note-drag-handle",
				"data-tooltip": "按住拖动调整位置",
				onMouseenter: te,
				onMouseleave: ne,
				onDblclick: y[0] ||= J(() => {}, ["stop"])
			}, null, 32)) : K("", !0),
			G(zf, {
				title: i.value,
				"onUpdate:title": y[1] ||= (e) => i.value = e,
				note: e.note,
				"is-editing": r.value,
				"is-full-screen": e.isFullScreen,
				"is-immersive-full-screen": e.isFullScreen && e.isImmersiveFullScreen,
				onTogglePin: C,
				onEnterEdit: m,
				onSaveEdit: h,
				onCancelEdit: g,
				onTogglePreview: v
			}, null, 8, [
				"title",
				"note",
				"is-editing",
				"is-full-screen",
				"is-immersive-full-screen"
			]),
			G(ug, {
				ref_key: "bodyRef",
				ref: s,
				content: a.value,
				"onUpdate:content": y[2] ||= (e) => a.value = e,
				note: e.note,
				"is-editing": r.value,
				"is-full-screen": e.isFullScreen,
				onCancelEdit: g,
				onSaveEdit: h,
				onSwitchToMarkdown: _
			}, null, 8, [
				"content",
				"note",
				"is-editing",
				"is-full-screen"
			]),
			r.value ? (V(), U(vg, {
				key: 1,
				ref_key: "tagEditorRef",
				ref: c,
				tags: o.value,
				"onUpdate:tags": y[3] ||= (e) => o.value = e
			}, null, 8, ["tags"])) : K("", !0),
			G(zg, {
				ref_key: "footerRef",
				ref: l,
				note: e.note,
				"is-editing": r.value,
				onSaveEdit: h,
				onCancelEdit: g,
				onAddAttachment: u,
				onPopoverStateChange: f
			}, null, 8, ["note", "is-editing"])
		], 46, Bg));
	}
}), [["__scopeId", "data-v-04582bcc"]]), Hg = {
	key: 0,
	class: "empty-state"
}, Ug = { class: "empty-illustration-wrapper" }, Wg = { class: "empty-title" }, Gg = { class: "empty-desc" }, Kg = /*#__PURE__*/ Z(/* @__PURE__ */ z({
	__name: "NoteGrid",
	setup(e) {
		let t = Wl(), { isMobile: n } = Ld(), r = /* @__PURE__ */ F(null), { handleDragOver: i, stopScroll: a } = Od(r);
		Gn(() => t.draggedNoteId, (e) => {
			e ? window.addEventListener("dragover", i) : (window.removeEventListener("dragover", i), a());
		}), Hr(() => {
			window.removeEventListener("dragover", i), a();
		});
		let o = q(() => t.gridColumns === "auto" ? "auto" : t.gridColumns), s = q(() => {
			if (o.value !== "auto") {
				let e = o.value;
				return {
					gridTemplateColumns: `repeat(${e}, minmax(0, 1fr))`,
					"--leave-card-width": `calc((100% - (var(--grid-gap, 20px) * ${e - 1})) / ${e})`
				};
			}
			if (n.value) return {
				gridTemplateColumns: "1fr",
				"--leave-card-width": "100%"
			};
			let e = Math.max(100, Math.min(1e3, t.minNoteWidth || 260));
			return {
				gridTemplateColumns: `repeat(auto-fill, minmax(min(100%, ${e}px), 1fr))`,
				"--leave-card-width": `${e}px`
			};
		}), c = () => {
			t.addNote(t.currentCategoryId, "", ""), t.showToast("已新建空便签，可以直接编辑");
		};
		return (e, n) => (V(), H("div", {
			ref_key: "containerRef",
			ref: r,
			class: "note-grid-container",
			onDragover: n[0] ||= (...e) => I(i) && I(i)(...e)
		}, [I(t).filteredNotes.length === 0 && !I(t).isLoadingNotes ? (V(), H("div", Hg, [
			W("div", Ug, [I(t).searchQuery ? (V(), U(I(Uu), {
				key: 0,
				class: "empty-icon animate-pulse"
			})) : (V(), U(I(Yu), {
				key: 1,
				class: "empty-icon"
			}))]),
			W("h3", Wg, j(I(t).searchQuery ? "没有找到匹配的便签" : "当前分类空空如也"), 1),
			W("p", Gg, j(I(t).searchQuery ? "尝试换个关键词搜索，或者清除搜索条件。" : "在这个分类下还没有记录任何便签。"), 1),
			!I(t).searchQuery && I(t).currentCategoryId !== "trash" && I(t).currentCategoryId !== "recent" ? (V(), H("button", {
				key: 0,
				class: "create-first-btn",
				onClick: c
			}, [G(I(zu), { class: "btn-icon" }), n[1] ||= W("span", null, "添加第一张便签", -1)])) : K("", !0)
		])) : (V(), U(vs, {
			key: 1,
			name: "notes-list",
			tag: "div",
			class: "notes-grid",
			style: D(s.value)
		}, {
			default: R(() => [(V(!0), H(B, null, $r(I(t).filteredNotes, (e) => (V(), U(Vg, {
				key: e.id,
				note: e
			}, null, 8, ["note"]))), 128))]),
			_: 1
		}, 8, ["style"]))], 544));
	}
}), [["__scopeId", "data-v-9d5c9090"]]), qg = { class: "toast-text" }, Jg = /*#__PURE__*/ Z(/* @__PURE__ */ z({
	__name: "Toast",
	setup(e) {
		let t = Wl(), n = q(() => !!t.toastMessage), r = q(() => t.toastMessage), i = q(() => t.toastType), a = q(() => t.toastPosition), o = q(() => {
			switch (i.value) {
				case "success": return lu;
				case "info": return Tu;
				case "warning": return Qu;
				case "error": return uu;
				default: return Tu;
			}
		});
		return (e, t) => (V(), U(wo, { name: `toast-${a.value}` }, {
			default: R(() => [n.value ? (V(), H("div", {
				key: 0,
				class: O(["toast-container", [`toast-${i.value}`, `position-${a.value}`]])
			}, [(V(), U(Xr(o.value), { class: "toast-icon" })), W("span", qg, j(r.value), 1)], 2)) : K("", !0)]),
			_: 1
		}, 8, ["name"]));
	}
}), [["__scopeId", "data-v-6b48d4c5"]]), Yg = { class: "modal-header" }, Xg = { class: "warning-icon-wrapper" }, Zg = { class: "modal-title" }, Qg = { class: "modal-body" }, $g = { class: "modal-message" }, e_ = /*#__PURE__*/ Z(/* @__PURE__ */ z({
	__name: "ConfirmModal",
	setup(e) {
		let t = Wl(), n = q(() => t.confirmState.show), r = q(() => t.confirmState.title || "操作确认"), i = q(() => t.confirmState.message || "确定要进行此操作吗？"), a = () => {
			t.handleConfirmResult(!1);
		}, o = () => {
			t.handleConfirmResult(!0);
		}, s = (e) => {
			e.key === "Enter" ? (o(), e.preventDefault()) : e.key === "Escape" && (a(), e.preventDefault());
		};
		return Gn(n, (e) => {
			e ? window.addEventListener("keydown", s) : window.removeEventListener("keydown", s);
		}, { immediate: !0 }), Hr(() => {
			window.removeEventListener("keydown", s);
		}), (e, t) => (V(), U(wo, { name: "modal-fade" }, {
			default: R(() => [n.value ? (V(), H("div", {
				key: 0,
				class: "modal-overlay",
				onClick: a
			}, [W("div", {
				class: "modal-container",
				onClick: t[0] ||= J(() => {}, ["stop"])
			}, [
				W("div", Yg, [W("div", Xg, [G(I(Qu), { class: "warning-icon" })]), W("h3", Zg, j(r.value), 1)]),
				W("div", Qg, [W("p", $g, j(i.value), 1)]),
				W("div", { class: "modal-footer" }, [W("button", {
					class: "modal-btn cancel",
					onClick: a
				}, " 取消 "), W("button", {
					class: "modal-btn confirm",
					onClick: o
				}, " 确定 ")])
			])])) : K("", !0)]),
			_: 1
		}));
	}
}), [["__scopeId", "data-v-fdea4c1b"]]);
//#endregion
//#region src/modules/SettingsModal/useSettings.ts
function t_() {
	let e = Wl(), t = Il(), n = /* @__PURE__ */ F("general"), r = /* @__PURE__ */ F(null), i = (n) => q({
		get() {
			let r = t.shortcuts.find((e) => e.id === n);
			return r ? r.currentKey : e[n];
		},
		set(r) {
			if (t.shortcuts.find((e) => e.id === n)) {
				t.updateShortcut(n, r);
				return;
			}
			n === "isDark" ? e.isDark !== r && e.toggleTheme() : n === "gridColumns" ? e.setGridColumns(r) : n === "minNoteWidth" ? e.setMinNoteWidth(r) : n === "noteMaxHeight" ? e.setNoteMaxHeight(r) : n === "enabledActionBarButtons" ? e.setEnabledActionBarButtons(r) : n === "sortMode" ? e.setSortMode(r) : n === "sortOrder" ? (e.sortOrder = r, Y.setItem("sticky_notes_sort_order", r)) : n === "dateFormat" ? e.setDateFormat(r) : n === "defaultNoteColor" ? e.setDefaultNoteColor(r) : n === "defaultNoteType" ? e.setDefaultNoteType(r) : n === "defaultEditMode" ? e.setDefaultEditMode(r) : n === "doubleClickNoteAction" ? e.setDoubleClickNoteAction(r) : n === "superPanelDefaultCategory" ? e.setSuperPanelDefaultCategory(r) : n === "startPageMode" ? e.setStartPageMode(r) : n === "enableHoverAnimation" ? e.setEnableHoverAnimation(r) : n === "showNoteCount" ? e.setShowNoteCount(r) : n === "prefixTagWithHash" ? e.setPrefixTagWithHash(r) : n === "skipDeleteConfirm" ? e.setSkipDeleteConfirm(r) : n === "enableImmersiveFullscreen" ? e.setEnableImmersiveFullscreen(r) : n === "categoryIndependentToolbar" ? e.setCategoryIndependentToolbar(r) : e[n] = r;
		}
	}), a = () => {
		r.value?.click();
	}, o = (t) => {
		let n = t.target, r = n.files?.[0];
		r && (e.prepareImportFile(r), n.value = "");
	}, s = () => {
		e.openExportModal();
	}, c = async () => {
		if (e.currentCategoryId === "trash") {
			await e.askConfirm("确认清空便签吗？", "⚠️ 警告：清空便签将彻底从设备删除其中所有的便签，此操作不可逆，数据无法找回！") && e.clearTrash();
			return;
		}
		let t = e.categories.find((t) => t.id === e.currentCategoryId), n = e.currentCategoryId === "all" ? "\"全部便签\"" : t ? `"${t.name}"` : "当前分类";
		await e.askConfirm("确认删除便签", `⚠️ 警告：确定要清空 ${n} 下的所有便签吗？这些便签将被移动到最近删除。`) && (e.clearNotes(e.currentCategoryId), e.showToast("已将所有便签移至最近删除"));
	}, l = () => {
		e.addNote(e.currentCategoryId, "", ""), e.showToast("已新建空便签，可以直接编辑");
	}, u = () => {
		e.closeSettings();
	}, d = (t) => {
		t.key === "Escape" && e.showSettings && u();
	};
	return Rr(() => window.addEventListener("keydown", d)), Hr(() => window.removeEventListener("keydown", d)), {
		store: e,
		activeTab: n,
		fileInputRef: r,
		getSettingValue: i,
		triggerFileInput: a,
		handleFileImport: o,
		exportBackup: s,
		handleClear: c,
		handleAddNote: l,
		close: u
	};
}
//#endregion
//#region src/modules/SettingsModal/controls/SettingWrapper.vue?vue&type=script&setup=true&lang.ts
var n_ = {
	key: 0,
	class: "item-header"
}, r_ = ["data-tooltip", "data-tooltip-custom"], i_ = {
	key: 1,
	class: "item-desc"
}, a_ = /*#__PURE__*/ Z(/* @__PURE__ */ z({
	__name: "SettingWrapper",
	props: {
		item: {},
		showHeader: {
			type: Boolean,
			default: !0
		}
	},
	setup(e) {
		let t = e, n = /* @__PURE__ */ F(!1), r = null, i = () => {
			r &&= (clearTimeout(r), null), n.value = !0;
		}, a = () => {
			r = window.setTimeout(() => {
				n.value = !1;
			}, 200);
		}, o = q(() => t.item.showHeader === void 0 ? t.item.hideHeader === void 0 ? t.showHeader : !t.item.hideHeader : t.item.showHeader), s = (e) => {
			if (e.default === void 0) return;
			let t = "", n = Wl(), r = typeof e.options == "function" ? e.options(n) : e.options || [];
			if (r && r.length > 0) if (Array.isArray(e.default)) t = r.filter((t) => e.default.includes(t.value)).map((e) => e.label).join(", ");
			else {
				let n = r.find((t) => t.value === e.default);
				t = n ? n.label : String(e.default);
			}
			else t = e.type === "switch" ? e.default ? "开启" : "关闭" : String(e.default);
			return `默认值: ${t}`;
		}, c = q(() => {
			if (!t.item.width) return {};
			if (t.item.width.endsWith("%")) {
				let e = parseFloat(t.item.width);
				return { width: `calc(${e}% - ${(1 - e / 100) * 16}px)` };
			}
			return { width: t.item.width };
		}), l = q(() => {
			let e = {};
			if (t.item.controlWidth) e.width = t.item.controlWidth;
			else {
				let n = t.item.props || {};
				n.width && (e.width = n.width);
			}
			return e;
		});
		return (t, r) => (V(), H("div", {
			class: O(["setting-item", [`type-${e.item.type}`, { "is-partial-width": e.item.width && e.item.width !== "100%" }]]),
			style: D(c.value)
		}, [
			o.value && (e.item.label || e.item.desc) ? (V(), H("div", n_, [e.item.label ? (V(), H("div", {
				key: 0,
				class: "item-label",
				"data-tooltip": e.item.tooltip,
				"data-tooltip-custom": e.item.key === "dateFormat" ? "" : void 0,
				onMouseenter: r[0] ||= (t) => e.item.key === "dateFormat" && i(),
				onMouseleave: r[1] ||= (t) => e.item.key === "dateFormat" && a()
			}, j(e.item.label), 41, r_)) : K("", !0), e.item.desc ? (V(), H("div", i_, j(e.item.desc), 1)) : K("", !0)])) : K("", !0),
			e.item.type === "component" ? ei(t.$slots, "default", { key: 1 }, void 0, !0) : (V(), H("div", {
				key: 2,
				class: "item-control",
				style: D(l.value)
			}, [ei(t.$slots, "default", { defaultTooltip: s(e.item) }, void 0, !0)], 4)),
			n.value && e.item.key === "dateFormat" ? (V(), U(or, {
				key: 3,
				to: "#global-tooltip"
			}, [r[2] ||= W("div", { class: "tooltip-table-container" }, [
				W("div", { class: "tooltip-title" }, " 支持的格式说明 "),
				W("table", { class: "tooltip-table" }, [W("thead", null, [W("tr", null, [
					W("th", null, "单位"),
					W("th", null, "长格式 (补零)"),
					W("th", null, "短格式 (不补零)")
				])]), W("tbody", null, [
					W("tr", null, [
						W("td", null, "年 (Year)"),
						W("td", null, [W("code", null, "YYYY"), Na(" (如 2026)")]),
						W("td", null, [W("code", null, "YY"), Na(" (如 26)")])
					]),
					W("tr", null, [
						W("td", null, "月 (Month)"),
						W("td", null, [W("code", null, "MM"), Na(" (01-12)")]),
						W("td", null, [W("code", null, "M"), Na(" (1-12)")])
					]),
					W("tr", null, [
						W("td", null, "日 (Day)"),
						W("td", null, [W("code", null, "DD"), Na(" (01-31)")]),
						W("td", null, [W("code", null, "D"), Na(" (1-31)")])
					]),
					W("tr", null, [
						W("td", null, "小时 (24h)"),
						W("td", null, [W("code", null, "HH"), Na(" (00-23)")]),
						W("td", null, [W("code", null, "H"), Na(" (0-23)")])
					]),
					W("tr", null, [
						W("td", null, "小时 (12h)"),
						W("td", null, [W("code", null, "hh"), Na(" (01-12)")]),
						W("td", null, [W("code", null, "h"), Na(" (1-12)")])
					]),
					W("tr", null, [
						W("td", null, "分钟 (Min)"),
						W("td", null, [W("code", null, "mm"), Na(" (00-59)")]),
						W("td", null, [W("code", null, "m"), Na(" (0-59)")])
					]),
					W("tr", null, [
						W("td", null, "秒数 (Sec)"),
						W("td", null, [W("code", null, "ss"), Na(" (00-59)")]),
						W("td", null, [W("code", null, "s"), Na(" (0-59)")])
					]),
					W("tr", null, [
						W("td", null, "上下午"),
						W("td", null, [W("code", null, "A"), Na(" (AM/PM)")]),
						W("td", null, [W("code", null, "a"), Na(" (上午/下午)")])
					])
				])]),
				W("div", { class: "tooltip-footer" }, " 示例: YYYY-MM-DD HH:mm:ss 或 YYYY/MM/DD ")
			], -1)])) : K("", !0)
		], 6));
	}
}), [["__scopeId", "data-v-aba8af24"]]), o_ = { class: "group-control button-row" }, s_ = /*#__PURE__*/ Z(/* @__PURE__ */ z({
	__name: "DataPanel",
	props: { item: {} },
	setup(e) {
		let { fileInputRef: t, triggerFileInput: n, handleFileImport: r, exportBackup: i } = t_();
		return (a, o) => (V(), U(a_, { item: e.item }, {
			default: R(() => [W("div", o_, [
				W("input", {
					ref_key: "fileInputRef",
					ref: t,
					type: "file",
					accept: ".json",
					class: "hidden-file-input",
					onChange: o[0] ||= (...e) => I(r) && I(r)(...e)
				}, null, 544),
				W("button", {
					class: "action-btn",
					onClick: o[1] ||= (...e) => I(i) && I(i)(...e)
				}, [G(I(hu), { class: "control-icon" }), o[3] ||= W("span", null, "导出数据备份", -1)]),
				W("button", {
					class: "action-btn",
					onClick: o[2] ||= (...e) => I(n) && I(n)(...e)
				}, [G(I(ed), { class: "control-icon" }), o[4] ||= W("span", null, "导入数据恢复", -1)])
			])]),
			_: 1
		}, 8, ["item"]));
	}
}), [["__scopeId", "data-v-ec9a612e"]]), c_ = { class: "webdav-settings-panel" }, l_ = { class: "status-left" }, u_ = { class: "status-icon-box" }, d_ = { class: "status-info" }, f_ = { class: "status-title" }, p_ = { class: "status-sub" }, m_ = ["disabled"], h_ = { class: "form-container" }, g_ = { class: "setting-row" }, __ = { class: "switch-control" }, v_ = {
	key: 0,
	class: "fields-group"
}, y_ = { class: "input-field-item" }, b_ = { class: "field-row-double" }, x_ = { class: "input-field-item" }, S_ = { class: "input-field-item" }, C_ = { class: "password-wrapper" }, w_ = ["type"], T_ = { class: "input-field-item" }, E_ = { class: "setting-row sub-row" }, D_ = { class: "switch-control" }, O_ = {
	key: 0,
	class: "input-field-item"
}, k_ = { class: "setting-row sub-row" }, A_ = { class: "switch-control" }, j_ = { class: "input-field-item" }, M_ = { class: "setting-row sub-row" }, N_ = { class: "switch-control" }, P_ = { class: "setting-row sub-row" }, F_ = ["disabled"], I_ = { class: "tombstone-info-box" }, L_ = { class: "actions-row" }, R_ = ["disabled"], z_ = ["disabled"], B_ = /*#__PURE__*/ Z(/* @__PURE__ */ z({
	__name: "WebdavPanel",
	setup(e) {
		let t = Wl(), n = el(), r = dl.config, i = dl.syncState, a = /* @__PURE__ */ F(!1), o = /* @__PURE__ */ F(!1), s = /* @__PURE__ */ F(null), c = q(() => r.value.lastSyncTime ? new Date(r.value.lastSyncTime).toLocaleString() : "尚未同步"), l = () => {
			dl.saveConfig(r.value);
		}, u = async () => {
			o.value = !0, s.value = null, l();
			try {
				let e = await new ul(r.value).testConnection();
				s.value = e, e.success ? n.showToast("✅ WebDAV 连接测试成功！") : n.showToast(`❌ ${e.message}`);
			} catch (e) {
				s.value = {
					success: !1,
					message: e.message || "网络连接异常"
				}, n.showToast(`❌ 连接失败: ${e.message}`);
			} finally {
				o.value = !1;
			}
		}, d = async (e = "smart") => {
			l(), e === "forcePush" ? n.showToast("正在全量上传覆盖远端...") : e === "forcePull" ? n.showToast("正在从远端拉取覆盖本地...") : n.showToast("正在进行智能双向墓碑合并同步...");
			let r = await t.syncWithWebdav({
				forcePush: e === "forcePush",
				forcePull: e === "forcePull"
			});
			r.success ? n.showToast(`✅ ${r.message}`) : n.showToast(`❌ ${r.message}`);
		}, f = /* @__PURE__ */ F(!1), p = async () => {
			if (!f.value) {
				f.value = !0, n.showToast("正在执行孤儿图片扫描与垃圾回收...");
				try {
					let e = new ul(r.value), i = await sl.performImageGC(t.allNotes, r.value.enabled ? e : void 0, {
						gracePeriodDays: 7,
						remoteDir: r.value.imagesRemoteDir || "/toolkit/moment_notes_images"
					});
					n.showToast(`清理完成：本地已清理 ${i.cleanedLocal} 张，远端已清理 ${i.cleanedRemote} 张 (有效引用 ${i.activeCount} 张)`, "success");
				} catch (e) {
					n.showToast(`清理失败: ${e.message}`, "error");
				} finally {
					f.value = !1;
				}
			}
		};
		return (e, t) => (V(), H("div", c_, [W("div", { class: O(["sync-status-card", I(i)]) }, [W("div", l_, [W("div", u_, [I(i) === "idle" ? (V(), U(I(du), {
			key: 0,
			class: "icon-idle"
		})) : I(i) === "syncing" ? (V(), U(I(Vu), {
			key: 1,
			class: "icon-syncing spin"
		})) : I(i) === "success" ? (V(), U(I(lu), {
			key: 2,
			class: "icon-success"
		})) : (V(), U(I(ou), {
			key: 3,
			class: "icon-error"
		}))]), W("div", d_, [W("div", f_, j(I(i) === "syncing" ? "正在与云端同步..." : I(i) === "success" ? "WebDAV 云端已连接" : I(i) === "error" ? "同步出现异常" : "WebDAV 云同步"), 1), W("div", p_, " 上次同步：" + j(c.value), 1)])]), W("button", {
			class: "sync-now-btn",
			disabled: !I(r).enabled || I(i) === "syncing",
			onClick: t[0] ||= () => d("smart")
		}, [G(I(Vu), { class: O(["btn-icon", { spin: I(i) === "syncing" }]) }, null, 8, ["class"]), t[15] ||= W("span", null, "立即同步", -1)], 8, m_)], 2), W("div", h_, [W("div", g_, [t[17] ||= W("div", { class: "row-label-group" }, [W("span", { class: "row-title" }, "启用 WebDAV 同步"), W("span", { class: "row-desc" }, "开启后便签与分类将自动同步至您的专属云盘")], -1), W("label", __, [Ln(W("input", {
			"onUpdate:modelValue": t[1] ||= (e) => I(r).enabled = e,
			type: "checkbox",
			onChange: l
		}, null, 544), [[As, I(r).enabled]]), t[16] ||= W("span", { class: "slider" }, null, -1)])]), I(r).enabled ? (V(), H("div", v_, [
			W("div", y_, [
				t[18] ||= W("label", { class: "field-label" }, "WebDAV 服务器地址 (URL)", -1),
				Ln(W("input", {
					"onUpdate:modelValue": t[2] ||= (e) => I(r).serverUrl = e,
					type: "text",
					placeholder: "如: https://dav.jianguoyun.com/dav/",
					class: "text-input",
					onBlur: l
				}, null, 544), [[ks, I(r).serverUrl]]),
				t[19] ||= W("span", { class: "field-hint" }, " 支持坚果云、Nextcloud、群晖 NAS、AList、InfiniCLOUD 等标准 WebDAV。 ", -1)
			]),
			W("div", b_, [W("div", x_, [t[20] ||= W("label", { class: "field-label" }, "账号 / 用户名", -1), Ln(W("input", {
				"onUpdate:modelValue": t[3] ||= (e) => I(r).username = e,
				type: "text",
				placeholder: "WebDAV 用户名",
				class: "text-input",
				onBlur: l
			}, null, 544), [[ks, I(r).username]])]), W("div", S_, [t[21] ||= W("label", { class: "field-label" }, "应用密码 / Token", -1), W("div", C_, [Ln(W("input", {
				"onUpdate:modelValue": t[4] ||= (e) => I(r).password = e,
				type: a.value ? "text" : "password",
				placeholder: "应用授权专用密码",
				class: "text-input pwd-input",
				onBlur: l
			}, null, 40, w_), [[Ls, I(r).password]]), W("button", {
				class: "eye-btn",
				type: "button",
				onClick: t[5] ||= (e) => a.value = !a.value
			}, [a.value ? (V(), U(I(_u), {
				key: 0,
				class: "eye-icon"
			})) : (V(), U(I(vu), {
				key: 1,
				class: "eye-icon"
			}))])])])]),
			W("div", T_, [
				t[22] ||= W("label", { class: "field-label" }, "云端存储路径 (JSON 文件)", -1),
				Ln(W("input", {
					"onUpdate:modelValue": t[6] ||= (e) => I(r).remotePath = e,
					type: "text",
					placeholder: "/ScriptKit/moment_notes.json",
					class: "text-input",
					onBlur: l
				}, null, 544), [[ks, I(r).remotePath]]),
				t[23] ||= W("span", { class: "field-hint" }, "云端将以标准 JSON 结构备份所有便签、分类与偏好设置", -1)
			]),
			W("div", E_, [t[25] ||= W("div", { class: "row-label-group" }, [W("span", { class: "row-title" }, "自动静默同步"), W("span", { class: "row-desc" }, "启动时自动拉取最新便签，编辑修改后 3 秒自动保存至云端")], -1), W("label", D_, [Ln(W("input", {
				"onUpdate:modelValue": t[7] ||= (e) => I(r).autoSync = e,
				type: "checkbox",
				onChange: l
			}, null, 544), [[As, I(r).autoSync]]), t[24] ||= W("span", { class: "slider" }, null, -1)])]),
			I(r).autoSync ? (V(), H("div", O_, [
				t[26] ||= W("label", { class: "field-label" }, "后台静默轮询间隔 (分钟)", -1),
				Ln(W("input", {
					"onUpdate:modelValue": t[8] ||= (e) => I(r).syncIntervalMinutes = e,
					type: "number",
					min: "1",
					max: "60",
					class: "text-input",
					style: { width: "140px" },
					onBlur: l
				}, null, 544), [[
					ks,
					I(r).syncIntervalMinutes,
					void 0,
					{ number: !0 }
				]]),
				t[27] ||= W("span", { class: "field-hint" }, "后台常驻期间定期检查并双向同步云端改动 (默认 5 分钟)", -1)
			])) : K("", !0),
			W("div", k_, [t[29] ||= W("div", { class: "row-label-group" }, [W("span", { class: "row-title" }, "同步便签图片与附件"), W("span", { class: "row-desc" }, "将便签中粘贴的截图独立保存至 WebDAV 文件夹，跨设备漫游并按需懒加载")], -1), W("label", A_, [Ln(W("input", {
				"onUpdate:modelValue": t[9] ||= (e) => I(r).syncImages = e,
				type: "checkbox",
				onChange: l
			}, null, 544), [[As, I(r).syncImages]]), t[28] ||= W("span", { class: "slider" }, null, -1)])]),
			I(r).syncImages === !1 ? K("", !0) : (V(), H(B, { key: 1 }, [
				W("div", j_, [
					t[30] ||= W("label", { class: "field-label" }, "云端图片存放目录", -1),
					Ln(W("input", {
						"onUpdate:modelValue": t[10] ||= (e) => I(r).imagesRemoteDir = e,
						type: "text",
						class: "text-input",
						placeholder: "/toolkit/moment_notes_images",
						onBlur: l
					}, null, 544), [[ks, I(r).imagesRemoteDir]]),
					t[31] ||= W("span", { class: "field-hint" }, "WebDAV 远端存储图片的独立目录，默认 /toolkit/moment_notes_images", -1)
				]),
				W("div", M_, [t[33] ||= W("div", { class: "row-label-group" }, [W("span", { class: "row-title" }, "粘贴时自动压缩大图"), W("span", { class: "row-desc" }, "超过 5MB 的大图在客户端自动等比降采样，节省云盘空间与传输带宽")], -1), W("label", N_, [Ln(W("input", {
					"onUpdate:modelValue": t[11] ||= (e) => I(r).autoCompressImages = e,
					type: "checkbox",
					onChange: l
				}, null, 544), [[As, I(r).autoCompressImages]]), t[32] ||= W("span", { class: "slider" }, null, -1)])]),
				W("div", P_, [t[34] ||= W("div", { class: "row-label-group" }, [W("span", { class: "row-title" }, "图片生命周期垃圾回收 (GC)"), W("span", { class: "row-desc" }, "扫描并清理超过 7 天且未被任何便签引用的无主孤儿图片")], -1), W("button", {
					class: "tool-btn test-btn",
					disabled: f.value,
					onClick: p
				}, [G(I(Zu), { class: "btn-icon" }), W("span", null, j(f.value ? "清理中..." : "清理孤儿图片"), 1)], 8, F_)])
			], 64)),
			W("div", I_, [G(I(Ku), { class: "shield-icon" }), t[35] ||= W("div", { class: "info-content" }, [W("span", { class: "info-title" }, "已启用分布式墓碑同步 (Tombstone Merge)"), W("span", { class: "info-desc" }, "跨设备删除、编辑与新建自动比对时间戳进行安全双向合并，彻底杜绝单侧删除后便签复活问题。")], -1)]),
			W("div", L_, [
				W("button", {
					class: "tool-btn test-btn",
					disabled: o.value,
					onClick: u
				}, [G(I(Ru), { class: "btn-icon" }), W("span", null, j(o.value ? "测试中..." : "测试连接"), 1)], 8, R_),
				W("button", {
					class: "tool-btn sync-btn",
					disabled: I(i) === "syncing",
					onClick: t[12] ||= () => d("smart")
				}, [G(I(Vu), { class: O(["btn-icon", { spin: I(i) === "syncing" }]) }, null, 8, ["class"]), t[36] ||= W("span", null, "双向智能同步", -1)], 8, z_),
				W("button", {
					class: "tool-btn force-btn",
					onClick: t[13] ||= () => d("forcePush")
				}, [G(I(cu), { class: "btn-icon" }), t[37] ||= W("span", null, "覆盖推送到云端", -1)]),
				W("button", {
					class: "tool-btn pull-btn",
					onClick: t[14] ||= () => d("forcePull")
				}, [G(I(su), { class: "btn-icon" }), t[38] ||= W("span", null, "从云端强制拉取", -1)])
			]),
			s.value ? (V(), H("div", {
				key: 2,
				class: O(["test-result-box", {
					success: s.value.success,
					error: !s.value.success
				}])
			}, [(V(), U(Xr(s.value.success ? I(lu) : I(ou)), { class: "res-icon" })), W("span", null, j(s.value.message), 1)], 2)) : K("", !0)
		])) : K("", !0)])]));
	}
}), [["__scopeId", "data-v-fc620bcb"]]), V_ = { class: "about-wrapper" }, H_ = { class: "about-card" }, U_ = ["src"], W_ = { class: "about-info" }, G_ = { class: "app-version" }, K_ = /*#__PURE__*/ Z(/* @__PURE__ */ z({
	__name: "AboutPanel",
	props: { item: {} },
	setup(e) {
		return (t, n) => (V(), U(a_, { item: e.item }, {
			default: R(() => [W("div", V_, [W("div", H_, [W("img", {
				src: I(pd),
				class: "about-logo",
				alt: "logo"
			}, null, 8, U_), W("div", W_, [n[0] ||= W("h5", { class: "app-name" }, " 拾光便签 ", -1), W("p", G_, " Version " + j(I("1.7.0")), 1)])]), n[1] ||= W("div", { class: "about-desc" }, [
				Na(" 拾光便签是专为 "),
				W("strong", null, "uTools"),
				Na(" 打造的轻量便签工具。界面清爽干净，动效丝滑流畅，方便您随时记录工作、学习与生活中的点滴想法。 ")
			], -1)])]),
			_: 1
		}, 8, ["item"]));
	}
}), [["__scopeId", "data-v-9f151106"]]);
//#endregion
//#region src/modules/SettingsModal/settingsConfig.ts
function q_(e, t) {
	return e === void 0 ? !0 : typeof e == "function" ? e(t) : !!e;
}
var J_ = [
	{
		id: "general",
		title: "常规偏好设置",
		tabTitle: "常规设置",
		icon: Gt(Gu),
		items: [
			{
				key: "enabledActionBarButtons",
				label: "右上角功能按钮管理",
				type: "multiselect",
				desc: "配置要在右上角操作栏中显示的功能按钮。",
				default: [
					"theme-toggle",
					"sort-select",
					"columns-select",
					"clear-notes"
				],
				controlWidth: "320px",
				options: [
					{
						label: "切换主题",
						value: "theme-toggle"
					},
					{
						label: "排序方式",
						value: "sort-select"
					},
					{
						label: "列数设置",
						value: "columns-select"
					},
					{
						label: "清空分类",
						value: "clear-notes"
					}
				]
			},
			{
				key: "categoryIndependentToolbar",
				label: "分类独立视图设置",
				type: "switch",
				desc: "开启后，右上角工具栏的排序方式、排序顺序及布局列数设置将仅对当前选中的分类生效，各分类可拥有独立的显示偏好。关闭时全局统一。",
				default: !1
			},
			{
				key: "isDark",
				label: "个性化主题",
				type: "radio",
				desc: "设置界面的显示主题。在 uTools 插件模式下，主题将自动根据 uTools 的偏好设置进行贴合与变换。",
				default: !1,
				options: [{
					label: "浅色模式",
					value: !1,
					icon: Gt(Xu)
				}, {
					label: "深色模式",
					value: !0,
					icon: Gt(ju)
				}]
			},
			{
				key: "enableHoverAnimation",
				label: "便签悬浮动画效果",
				type: "switch",
				desc: "控制当鼠标悬停在便签卡片上时，是否显示向上浮动和阴影渐变的动效。",
				default: !0
			},
			{
				key: "enableAutoCopySelection",
				label: "划词自动复制文本",
				type: "switch",
				desc: "开启后，在浏览便签时划词选中文本即可自动复制到剪贴板。",
				default: !0
			},
			{
				key: "doubleClickNoteAction",
				label: "双击便签响应动作",
				type: "select",
				desc: "设置双击便签卡片时触发的操作。",
				default: Yc.defaultValue,
				controlWidth: "240px",
				options: Gc.map((e) => ({
					label: e.label,
					value: e.id,
					tooltip: "tooltip" in e ? e.tooltip : void 0
				}))
			},
			{
				key: "skipDeleteConfirm",
				label: "删除便签免确认",
				type: "switch",
				desc: "开启后，点击便签的删除按钮时将直接删除，不显示确认弹窗。",
				default: !1
			},
			{
				key: "showNoteCount",
				label: "显示分类便签数",
				type: "switch",
				desc: "控制左侧分类列表中每一项右侧是否显示便签数量。",
				default: !0
			},
			{
				key: "prefixTagWithHash",
				label: "标签前显示 # 符号",
				type: "switch",
				desc: "控制在便签卡片上显示标签时，标签文字前面是否自动添加 # 符号。",
				default: !0
			},
			{
				key: "gridColumns",
				label: "便签展示列数",
				type: "radio",
				desc: "调整便签卡片在右侧展示区的排列列数。选择“自适应”将根据界面宽度自动计算最合适的排布数量。",
				default: "auto",
				options: [
					{
						label: "自适应",
						value: "auto",
						icon: Gt(fu)
					},
					{
						label: "1 列",
						value: 1,
						icon: Gt(fu)
					},
					{
						label: "2 列",
						value: 2,
						icon: Gt(fu)
					},
					{
						label: "3 列",
						value: 3,
						icon: Gt(fu)
					},
					{
						label: "4 列",
						value: 4,
						icon: Gt(fu)
					}
				]
			},
			{
				key: "minNoteWidth",
				label: "便签自适应最小宽度",
				type: "slider",
				desc: "在“自适应”展示列数模式下生效，单个便签卡片的最小宽度限制。默认值为 260，允许设置范围为 100 - 1000。",
				default: 260,
				controlWidth: "280px",
				props: {
					min: 100,
					max: 1e3,
					step: 5
				},
				visible: (e) => e.gridColumns === "auto"
			},
			{
				key: "noteMaxHeight",
				label: "便签卡片最大高度",
				type: "slider",
				desc: "限制单个便签卡片在浏览模式下的最大展示高度。超出此限制时内部会自动出现滚动条。",
				default: 300,
				controlWidth: "280px",
				props: {
					min: 150,
					max: 600,
					step: 5
				}
			},
			{
				key: "sortMode",
				label: "默认便签排序方式",
				type: "select",
				desc: "设置默认的便签排序规则。",
				default: "date",
				width: "58%",
				controlWidth: "240px",
				options: [
					{
						label: "按日期排序",
						value: "date"
					},
					{
						label: "按标题首字母",
						value: "title"
					},
					{
						label: "按标签排序",
						value: "tag"
					},
					{
						label: "按使用次数",
						value: "useCount"
					},
					{
						label: "自定义排序",
						value: "custom"
					}
				]
			},
			{
				key: "sortOrder",
				label: "默认排序顺序",
				type: "radio",
				desc: "设置列表的默认排列顺序。",
				default: "desc",
				width: "42%",
				options: [{
					label: "升序",
					value: "asc"
				}, {
					label: "降序",
					value: "desc"
				}]
			},
			{
				key: "dateFormat",
				label: "自定义便签日期格式",
				type: "input",
				desc: "自定义便签卡片底部显示的更新日期格式。",
				default: "YYYY.MM.DD HH:mm",
				placeholder: "YYYY.MM.DD HH:mm",
				tooltip: "支持的格式说明:\nYYYY - 四位年 (如 2026)\nYY - 两位年 (如 26)\nMM - 两位月 (01-12)\nM - 一位月 (1-12)\nDD - 两位日 (01-31)\nD - 一位日 (1-31)\nHH - 两位24小时制小时 (00-23)\nH - 一位24小时制小时 (0-23)\nhh - 两位12小时制小时 (01-12)\nh - 一位12小时制小时 (1-12)\nmm - 两位分钟 (00-59)\nm - 一位分钟 (0-59)\nss - 两位秒数 (00-59)\ns - 一位秒数 (0-59)\nA - 上下午标记 (AM/PM)\na - 中文上下午标记 (上午/下午)\n示例: YYYY-MM-DD HH:mm:ss 或 YYYY/MM/DD",
				controlWidth: "240px",
				props: { type: "text" }
			},
			{
				key: "defaultNoteColor",
				label: "默认便签颜色",
				type: "select",
				desc: "新建便签或从外部捕获时，默认的卡片背景色。",
				default: "random",
				controlWidth: "240px",
				options: [
					{
						label: "随机颜色",
						value: "random",
						color: "random",
						html: "<span style=\"font-weight: 500;\">随机颜色</span>"
					},
					{
						label: "暖阳黄",
						value: "yellow",
						color: "yellow",
						html: "<span style=\"font-weight: 500;\">暖阳黄</span>"
					},
					{
						label: "薄荷绿",
						value: "green",
						color: "green",
						html: "<span style=\"font-weight: 500;\">薄荷绿</span>"
					},
					{
						label: "晴空蓝",
						value: "blue",
						color: "blue",
						html: "<span style=\"font-weight: 500;\">晴空蓝</span>"
					},
					{
						label: "蔷薇粉",
						value: "pink",
						color: "pink",
						html: "<span style=\"font-weight: 500;\">蔷薇粉</span>"
					},
					{
						label: "熏衣紫",
						value: "purple",
						color: "purple",
						html: "<span style=\"font-weight: 500;\">熏衣紫</span>"
					},
					{
						label: "极简灰",
						value: "gray",
						color: "gray",
						html: "<span style=\"font-weight: 500;\">极简灰</span>"
					}
				]
			},
			{
				key: "defaultNoteType",
				label: "新增便签默认格式",
				type: "select",
				desc: "新建便签或从外部捕获文本时，默认的卡片内容展示格式。",
				default: "text",
				controlWidth: "240px",
				options: [{
					label: "纯文本",
					value: "text"
				}, {
					label: "Markdown 格式",
					value: "markdown"
				}]
			},
			{
				key: "defaultEditMode",
				label: "默认便签编辑方式",
				type: "select",
				desc: "设置新建便签或点击编辑便签时的默认视图模式。",
				default: "inline",
				controlWidth: "240px",
				options: [{
					label: "卡片编辑",
					value: "inline"
				}, {
					label: "全屏编辑",
					value: "fullscreen"
				}]
			},
			{
				key: "enableImmersiveFullscreen",
				label: "全屏模式铺满整个窗口",
				type: "switch",
				desc: "开启后，点击便签全屏按钮将铺满整个窗口并移除边框与圆角，而非以居中弹窗形式展示。",
				default: !1
			},
			{
				key: "startPageMode",
				label: "启动默认展示分类",
				type: "radio",
				desc: "设置直接打开此插件时，是恢复展示上次离开时的分类，还是展示预设的默认分类。",
				default: "last",
				options: [{
					label: "上次分类",
					value: "last"
				}, {
					label: "默认分类",
					value: "default"
				}]
			},
			{
				key: "superPanelDefaultCategory",
				label: "超级面板默认分类",
				type: "select",
				desc: "配置直接打开插件（选择默认分类时）或通过 uTools 超级面板唤醒插件时，默认自动跳转并切换到的分类。",
				default: "all",
				controlWidth: "240px",
				options: (e) => e.categoryOptions,
				visible: (e) => e.startPageMode === "default"
			},
			{
				key: "quickActions",
				label: "快捷操作",
				type: "button-group",
				desc: "在设置中快速执行清空当前分类或清空最近删除等管理动作。",
				buttons: [{
					label: (e) => e.currentCategoryId === "trash" ? "清空最近删除" : e.currentCategoryId === "all" ? "清空所有便签" : "清空当前分类便签",
					icon: Gt(Zu),
					variant: "danger",
					width: "auto",
					minWidth: "100px",
					actionKey: "clearNotes",
					disabled: (e) => e.filteredNotes.length === 0
				}]
			}
		]
	},
	{
		id: "data",
		title: "数据备份与恢复",
		tabTitle: "数据管理",
		icon: Gt(mu),
		items: [{
			key: "backupRestore",
			label: "备份操作",
			type: "component",
			desc: "导出备份能将当前所有的便签及分类列表转换为备份文件；导入恢复能从 JSON 备份中加载数据。",
			component: Gt(s_)
		}]
	},
	{
		id: "webdav",
		title: "WebDAV 云同步",
		tabTitle: "云端同步",
		icon: Gt(du),
		items: [{
			key: "webdavSettings",
			label: "",
			type: "component",
			component: Gt(B_)
		}]
	},
	{
		id: "shortcuts",
		title: "快捷键与快捷操作",
		tabTitle: "快捷设置",
		icon: Gt(Eu),
		items: [
			{
				key: "addNote",
				label: "新建便签",
				type: "shortcut",
				tooltip: "在当前所在分类下极速新建一个空白便签",
				controlWidth: "80%"
			},
			{
				key: "focusSearch",
				label: "聚焦搜索",
				type: "shortcut",
				tooltip: "一键将输入光标聚焦到顶部的搜索框中",
				controlWidth: "80%"
			},
			{
				key: "saveEdit",
				label: "保存编辑",
				type: "shortcut",
				tooltip: "在编辑便签内容时，快捷保存并结束编辑状态",
				controlWidth: "80%"
			},
			{
				key: "cancelEdit",
				label: "取消编辑",
				type: "shortcut",
				tooltip: "在编辑便签内容时，取消修改并退出编辑状态",
				controlWidth: "80%"
			},
			{
				key: "shortcutTips",
				label: "快捷操作指南",
				type: "text",
				content: "<ul>\n          <li><strong>双击隐藏粘贴：</strong>双击便签卡片会直接自动收起窗口，并自动将便签内容填至您原先光标所在的输入位置。</li>\n          <li><strong>捕获外部文本：</strong>在 uTools 的超级面板中，可以直接选中文本一键导入并创建新便签。</li>\n        </ul>"
			}
		]
	},
	{
		id: "about",
		title: "关于拾光便签",
		tabTitle: "关于插件",
		icon: Gt(Tu),
		items: [{
			key: "aboutInfo",
			label: "",
			type: "component",
			component: Gt(K_)
		}]
	}
], Y_ = { class: "setting-input-wrapper" }, X_ = [
	"value",
	"type",
	"placeholder",
	"min",
	"max",
	"step",
	"data-tooltip"
], Z_ = /*#__PURE__*/ Z(/* @__PURE__ */ z({
	inheritAttrs: !1,
	__name: "SettingInput",
	props: {
		modelValue: {},
		item: {}
	},
	emits: ["update:modelValue"],
	setup(e, { emit: t }) {
		let n = e, r = t, i = q(() => n.item.props || {}), a = q(() => i.value.type === "number"), o = /* @__PURE__ */ F(n.modelValue), s = null;
		Gn(() => n.modelValue, (e) => {
			s === null && (o.value = e);
		});
		let c = (e) => {
			s && clearTimeout(s), s = setTimeout(() => {
				r("update:modelValue", e), s = null;
			}, 300);
		}, l = (e) => {
			let t = e.target.value;
			o.value = t, a.value ? c(t === "" ? "" : Number(t)) : r("update:modelValue", t);
		}, u = (e) => {
			if (!a.value || [
				"Backspace",
				"Delete",
				"ArrowLeft",
				"ArrowRight",
				"Tab",
				"Enter",
				"Home",
				"End"
			].includes(e.key) || e.ctrlKey || e.metaKey || e.altKey || /^[0-9]$/.test(e.key)) return;
			let t = i.value.min;
			if (e.key === "-" && (t === void 0 || t < 0)) {
				let t = e.target;
				if (!t.value.includes("-") && t.selectionStart === 0) return;
			}
			let n = i.value.step, r = n ? n % 1 != 0 : !0;
			e.key === "." && r && !e.target.value.includes(".") || e.preventDefault();
		}, d = (e) => {
			if (!a.value) return;
			s &&= (clearTimeout(s), null);
			let t = e.target, n = t.value.trim(), c = i.value.min, l = i.value.max;
			if (n === "") {
				let e = c === void 0 ? 0 : c;
				o.value = e, t.value = String(e), r("update:modelValue", e);
				return;
			}
			let u = Number(n);
			isNaN(u) && (u = c === void 0 ? 0 : c), c !== void 0 && u < c && (u = c), l !== void 0 && u > l && (u = l), o.value = u, t.value = String(u), r("update:modelValue", u);
		}, f = (e) => {
			if (!a.value) return;
			let t = e.target;
			if (document.activeElement !== t) return;
			let n = Number(o.value), r = i.value.min, s = i.value.max, l = i.value.step;
			isNaN(n) && (n = r === void 0 ? 0 : r);
			let u = 1;
			e.ctrlKey ? u = 100 : e.shiftKey ? u = 10 : l !== void 0 && (u = l);
			let d = e.deltaY < 0 ? 1 : -1, f = n + d * u;
			r !== void 0 && f < r && (f = r), s !== void 0 && f > s && (f = s), o.value = f, t.value = String(f), c(f);
		};
		return Hr(() => {
			if (s) {
				if (clearTimeout(s), a.value) {
					let e = String(o.value).trim(), t = e === "" ? 0 : Number(e);
					r("update:modelValue", isNaN(t) ? 0 : t);
				}
				s = null;
			}
		}), (t, n) => (V(), U(a_, { item: e.item }, {
			default: R(({ defaultTooltip: t }) => [W("div", Y_, [W("input", {
				value: o.value,
				type: i.value.type || "text",
				placeholder: e.item.placeholder,
				min: i.value.min,
				max: i.value.max,
				step: i.value.step,
				style: D(i.value.style),
				class: "setting-input",
				"data-tooltip": t,
				onInput: l,
				onKeydown: u,
				onBlur: d,
				onWheel: J(f, ["prevent"])
			}, null, 44, X_)])]),
			_: 1
		}, 8, ["item"]));
	}
}), [["__scopeId", "data-v-046f66af"]]), Q_ = { class: "setting-textarea-wrapper" }, $_ = [
	"placeholder",
	"rows",
	"data-tooltip"
], ev = /*#__PURE__*/ Z(/* @__PURE__ */ z({
	inheritAttrs: !1,
	__name: "SettingTextarea",
	props: {
		modelValue: {},
		item: {}
	},
	emits: ["update:modelValue"],
	setup(e, { emit: t }) {
		let n = e, r = t, i = q({
			get: () => n.modelValue,
			set: (e) => r("update:modelValue", e)
		}), a = q(() => n.item.props || {});
		return (t, n) => (V(), U(a_, { item: e.item }, {
			default: R(({ defaultTooltip: t }) => [W("div", Q_, [Ln(W("textarea", {
				"onUpdate:modelValue": n[0] ||= (e) => i.value = e,
				placeholder: e.item.placeholder,
				rows: a.value.rows || 3,
				style: D(a.value.style),
				class: "setting-textarea",
				"data-tooltip": t
			}, null, 12, $_), [[ks, i.value]])])]),
			_: 1
		}, 8, ["item"]));
	}
}), [["__scopeId", "data-v-fcaf2087"]]), tv = ["data-tooltip"], nv = { class: "trigger-content" }, rv = ["innerHTML"], iv = {
	key: 2,
	class: "trigger-text"
}, av = {
	key: 0,
	class: "select-dropdown"
}, ov = ["data-tooltip", "onClick"], sv = { class: "item-content-wrapper" }, cv = ["innerHTML"], lv = {
	key: 2,
	class: "item-label"
}, uv = /*#__PURE__*/ Z(/* @__PURE__ */ z({
	inheritAttrs: !1,
	__name: "SettingSelect",
	props: {
		modelValue: {},
		item: {},
		options: {}
	},
	emits: ["update:modelValue"],
	setup(e, { emit: t }) {
		let n = e, r = t, i = /* @__PURE__ */ F(!1), a = /* @__PURE__ */ F(null), o = Wl(), s = q(() => n.options || []), c = q(() => n.item.type === "multiselect"), l = q(() => n.item.placeholder || "请选择..."), u = q(() => n.item.props || {}), d = () => {
			i.value = !i.value;
		}, f = () => {
			i.value = !1;
		}, p = (e) => {
			a.value && !a.value.contains(e.target) && f();
		};
		Rr(() => {
			document.addEventListener("click", p, !0);
		}), Hr(() => {
			document.removeEventListener("click", p, !0);
		});
		let m = (e) => c.value ? Array.isArray(n.modelValue) && n.modelValue.includes(e) : n.modelValue === e, h = (e) => {
			if (c.value) {
				let t = Array.isArray(n.modelValue) ? [...n.modelValue] : [], i = t.indexOf(e.value);
				i > -1 ? t.splice(i, 1) : t.push(e.value), r("update:modelValue", t);
			} else r("update:modelValue", e.value), f();
		}, g = q(() => c.value ? null : s.value.find((e) => e.value === n.modelValue) || null), _ = (e) => {
			if (e === "random") return {
				background: "linear-gradient(135deg, #ff7675, #74b9ff, #55efc4)",
				borderColor: "rgba(255, 255, 255, 0.2)",
				borderWidth: "1px",
				borderStyle: "solid"
			};
			let t = tl[e];
			if (!t) return {};
			let n = o.isDark;
			return {
				backgroundColor: n ? t.darkBg : t.lightBg,
				borderColor: n ? t.darkBorder : t.lightBorder,
				borderWidth: "1px",
				borderStyle: "solid"
			};
		}, v = q(() => {
			if (c.value) {
				let e = Array.isArray(n.modelValue) ? n.modelValue : [];
				return e.length === 0 ? l.value : s.value.filter((t) => e.includes(t.value)).map((e) => e.label).join(", ");
			} else {
				let e = s.value.find((e) => e.value === n.modelValue);
				return e ? e.label : l.value;
			}
		});
		return (t, n) => (V(), U(a_, { item: e.item }, {
			default: R(({ defaultTooltip: t }) => [W("div", {
				ref_key: "selectRef",
				ref: a,
				class: "custom-select-container",
				"data-tooltip": t,
				style: D(u.value.style)
			}, [W("div", {
				class: O(["select-trigger", { open: i.value }]),
				onClick: d
			}, [W("div", nv, [!c.value && g.value && g.value.color ? (V(), H("span", {
				key: 0,
				class: "color-badge-dot",
				style: D(_(g.value.color))
			}, null, 4)) : K("", !0), !c.value && g.value && g.value.html ? (V(), H("span", {
				key: 1,
				class: "trigger-text",
				innerHTML: g.value.html
			}, null, 8, rv)) : !c.value && g.value ? (V(), H("span", iv, j(g.value.label), 1)) : (V(), H("span", {
				key: 3,
				class: O(["trigger-text", { placeholder: e.modelValue === void 0 || e.modelValue === "" || c.value && (!e.modelValue || e.modelValue.length === 0) }])
			}, j(v.value), 3))]), G(I(ru), { class: O(["arrow-icon", { rotate: i.value }]) }, null, 8, ["class"])], 2), G(wo, { name: "slide-up" }, {
				default: R(() => [i.value ? (V(), H("div", av, [(V(!0), H(B, null, $r(s.value, (e) => (V(), H("div", {
					key: e.value,
					class: O(["dropdown-item", { active: m(e.value) }]),
					"data-tooltip": e.tooltip || e.label,
					onClick: (t) => h(e)
				}, [W("div", sv, [e.color ? (V(), H("span", {
					key: 0,
					class: "color-badge-dot",
					style: D(_(e.color))
				}, null, 4)) : K("", !0), e.html ? (V(), H("span", {
					key: 1,
					class: "item-label",
					innerHTML: e.html
				}, null, 8, cv)) : (V(), H("span", lv, j(e.label), 1))]), m(e.value) ? (V(), U(I(nu), {
					key: 0,
					class: "check-icon"
				})) : K("", !0)], 10, ov))), 128))])) : K("", !0)]),
				_: 1
			})], 12, tv)]),
			_: 1
		}, 8, ["item"]));
	}
}), [["__scopeId", "data-v-ca7f9b55"]]), dv = ["data-tooltip"], fv = ["onClick"], pv = /*#__PURE__*/ Z(/* @__PURE__ */ z({
	__name: "SettingRadio",
	props: {
		modelValue: {},
		item: {}
	},
	emits: ["update:modelValue"],
	setup(e, { emit: t }) {
		let n = e, r = t, i = q(() => n.item.options || []), a = q(() => n.item.props || {}), o = (e) => {
			r("update:modelValue", e);
		};
		return (t, n) => (V(), U(a_, { item: e.item }, {
			default: R(({ defaultTooltip: t }) => [W("div", {
				class: "setting-radio-group",
				"data-tooltip": t,
				style: D(a.value.style)
			}, [(V(!0), H(B, null, $r(i.value, (t) => (V(), H("button", {
				key: t.value,
				class: O(["radio-btn", { active: e.modelValue === t.value }]),
				onClick: (e) => o(t.value)
			}, [t.icon ? (V(), U(Xr(t.icon), {
				key: 0,
				class: "control-icon"
			})) : K("", !0), W("span", null, j(t.label), 1)], 10, fv))), 128))], 12, dv)]),
			_: 1
		}, 8, ["item"]));
	}
}), [["__scopeId", "data-v-3a9334ad"]]), mv = ["disabled"], hv = /*#__PURE__*/ Z(/* @__PURE__ */ z({
	__name: "SettingButton",
	props: {
		width: { default: void 0 },
		minWidth: { default: void 0 },
		variant: { default: "primary" },
		disabled: {
			type: Boolean,
			default: !1
		},
		color: { default: void 0 }
	},
	emits: ["click"],
	setup(e, { emit: t }) {
		let n = e, r = t, i = q(() => {
			let e = {};
			return n.width && (e.width = n.width), n.minWidth && (e.minWidth = n.minWidth), n.color && (e["--custom-btn-color"] = n.color), e;
		});
		return (t, n) => (V(), H("button", {
			class: O(["setting-btn", [`variant-${e.variant}`, { "has-custom-color": !!e.color }]]),
			style: D(i.value),
			disabled: e.disabled,
			onClick: n[0] ||= (e) => r("click", e)
		}, [ei(t.$slots, "default", {}, void 0, !0)], 14, mv));
	}
}), [["__scopeId", "data-v-f0bed8f6"]]), gv = { class: "shortcut-input-group" }, _v = { class: "shortcut-text" }, vv = {
	key: 0,
	class: "rec-badge"
}, yv = ["disabled"], bv = ["disabled"], xv = /*#__PURE__*/ Z(/* @__PURE__ */ z({
	__name: "ShortcutInput",
	props: {
		modelValue: {},
		item: {},
		disabled: { type: Boolean }
	},
	emits: ["update:modelValue", "error"],
	setup(e, { emit: t }) {
		let n = e, r = t, i = Il(), a = /* @__PURE__ */ F(!1), o = n.item.key;
		Gn(a, (e) => {
			i.isRecording = e;
		});
		let s = (e) => {
			if (!a.value) return;
			e.preventDefault(), e.stopPropagation();
			let t = e.key;
			if ([
				"Control",
				"Shift",
				"Alt",
				"Meta"
			].includes(t)) return;
			if (t === "Escape") {
				a.value = !1;
				return;
			}
			let n = [];
			(e.ctrlKey || e.metaKey) && n.push("Ctrl"), e.shiftKey && n.push("Shift"), e.altKey && n.push("Alt");
			let s = t;
			t === " " ? s = "Space" : t === "ArrowLeft" ? s = "Left" : t === "ArrowRight" ? s = "Right" : t === "ArrowUp" ? s = "Up" : t === "ArrowDown" ? s = "Down" : t.length === 1 && (s = t.toUpperCase()), n.push(s);
			let c = n.join("+"), l = i.updateShortcut(o, c);
			l.success ? r("update:modelValue", c) : r("error", l.message || "快捷键冲突"), a.value = !1;
		}, c = () => {
			n.disabled || (a.value = !0);
		}, l = () => {
			a.value = !1;
		}, u = () => {
			i.resetShortcut(o);
			let e = i.shortcuts.find((e) => e.id === o);
			e && r("update:modelValue", e.currentKey);
		}, d = () => {
			i.clearShortcut(o), r("update:modelValue", "");
		};
		return (t, n) => (V(), U(a_, { item: e.item }, {
			default: R(() => [W("div", gv, [
				W("div", {
					tabindex: "0",
					class: O(["shortcut-input-box", {
						recording: a.value,
						disabled: e.disabled
					}]),
					onClick: c,
					onKeydown: s,
					onBlur: l
				}, [W("span", _v, j(a.value ? "正在录制..." : e.modelValue || "无"), 1), a.value ? (V(), H("span", vv, "REC")) : K("", !0)], 34),
				W("button", {
					class: "control-btn",
					"data-tooltip": "重置为默认值",
					disabled: e.disabled,
					onClick: u
				}, [G(I(Vu), { class: "control-icon" })], 8, yv),
				W("button", {
					class: "control-btn danger",
					"data-tooltip": "清除快捷键",
					disabled: e.disabled || !e.modelValue,
					onClick: d
				}, [G(I(td), { class: "control-icon" })], 8, bv)
			])]),
			_: 1
		}, 8, ["item"]));
	}
}), [["__scopeId", "data-v-3481f3a1"]]), Sv = { class: "setting-slider-container" }, Cv = [
	"value",
	"min",
	"max",
	"step",
	"data-tooltip"
], wv = { class: "setting-slider-value" }, Tv = /*#__PURE__*/ Z(/* @__PURE__ */ z({
	__name: "SettingSlider",
	props: {
		modelValue: {},
		item: {}
	},
	emits: ["update:modelValue"],
	setup(e, { emit: t }) {
		let n = e, r = t, i = q(() => n.item.props || {}), a = q(() => i.value.min === void 0 ? 0 : i.value.min), o = q(() => i.value.max === void 0 ? 100 : i.value.max), s = q(() => i.value.step === void 0 ? 1 : i.value.step), c = /* @__PURE__ */ F(n.modelValue), l = null;
		Gn(() => n.modelValue, (e) => {
			l === null && (c.value = e);
		});
		let u = (e) => {
			l && clearTimeout(l), l = setTimeout(() => {
				r("update:modelValue", e), l = null;
			}, 300);
		}, d = (e) => {
			let t = e.target, n = Number(t.value);
			c.value = n, u(n);
		}, f = (e) => {
			let t = e.target;
			if (document.activeElement !== t) return;
			let n = Number(c.value) + (e.deltaY < 0 ? 1 : -1) * s.value;
			n < a.value && (n = a.value), n > o.value && (n = o.value), c.value = n, u(n);
		};
		return Hr(() => {
			l &&= (clearTimeout(l), r("update:modelValue", c.value), null);
		}), (t, n) => (V(), U(a_, { item: e.item }, {
			default: R(({ defaultTooltip: e }) => [W("div", Sv, [W("input", {
				type: "range",
				value: c.value,
				min: a.value,
				max: o.value,
				step: s.value,
				class: "setting-range-input",
				"data-tooltip": e,
				onInput: d,
				onWheel: J(f, ["prevent"])
			}, null, 40, Cv), W("span", wv, j(c.value), 1)])]),
			_: 1
		}, 8, ["item"]));
	}
}), [["__scopeId", "data-v-9193e12a"]]), Ev = ["data-tooltip"], Dv = ["aria-checked"], Ov = /*#__PURE__*/ Z(/* @__PURE__ */ z({
	__name: "SettingSwitch",
	props: {
		modelValue: { type: Boolean },
		item: {}
	},
	emits: ["update:modelValue"],
	setup(e, { emit: t }) {
		let n = e, r = t, i = q({
			get: () => !!n.modelValue,
			set: (e) => r("update:modelValue", e)
		}), a = () => {
			i.value = !i.value;
		};
		return (t, n) => (V(), U(a_, { item: e.item }, {
			default: R(({ defaultTooltip: e }) => [W("div", {
				class: "setting-switch-container",
				"data-tooltip": e,
				onClick: a
			}, [W("button", {
				type: "button",
				class: O(["switch-track", { checked: i.value }]),
				role: "switch",
				"aria-checked": i.value
			}, [...n[0] ||= [W("span", { class: "switch-thumb" }, null, -1)]], 10, Dv)], 8, Ev)]),
			_: 1
		}, 8, ["item"]));
	}
}), [["__scopeId", "data-v-c6d0f8ca"]]), kv = {
	key: 0,
	class: "setting-control-container"
}, Av = { class: "quick-actions-row" }, jv = ["innerHTML"], Mv = /*#__PURE__*/ Z(/* @__PURE__ */ z({
	__name: "SettingControl",
	props: {
		modelValue: {},
		item: {}
	},
	emits: ["update:modelValue", "action"],
	setup(e, { emit: t }) {
		let n = e, r = t, i = Wl(), a = q({
			get: () => n.modelValue,
			set: (e) => r("update:modelValue", e)
		}), o = (e) => typeof e.label == "function" ? e.label(i) : e.label, s = (e) => typeof e.disabled == "function" ? e.disabled(i) : !!e.disabled, c = (e) => q_(e.visible, i), l = q(() => q_(n.item.visible, i)), u = q(() => typeof n.item.options == "function" ? n.item.options(i) : n.item.options || []), d = q(() => ({
			...n.item,
			options: u.value
		}));
		return (t, n) => l.value ? (V(), H("div", kv, [e.item.type === "input" ? (V(), U(Z_, Ra({
			key: 0,
			modelValue: a.value,
			"onUpdate:modelValue": n[0] ||= (e) => a.value = e,
			item: e.item,
			placeholder: e.item.placeholder
		}, e.item.props), null, 16, [
			"modelValue",
			"item",
			"placeholder"
		])) : e.item.type === "textarea" ? (V(), U(ev, Ra({
			key: 1,
			modelValue: a.value,
			"onUpdate:modelValue": n[1] ||= (e) => a.value = e,
			item: e.item,
			placeholder: e.item.placeholder
		}, e.item.props), null, 16, [
			"modelValue",
			"item",
			"placeholder"
		])) : e.item.type === "select" || e.item.type === "multiselect" ? (V(), U(uv, Ra({
			key: 2,
			modelValue: a.value,
			"onUpdate:modelValue": n[2] ||= (e) => a.value = e,
			item: d.value,
			options: u.value,
			multiple: e.item.type === "multiselect",
			placeholder: e.item.placeholder
		}, e.item.props), null, 16, [
			"modelValue",
			"item",
			"options",
			"multiple",
			"placeholder"
		])) : e.item.type === "radio" ? (V(), U(pv, {
			key: 3,
			modelValue: a.value,
			"onUpdate:modelValue": n[3] ||= (e) => a.value = e,
			item: d.value,
			options: u.value
		}, null, 8, [
			"modelValue",
			"item",
			"options"
		])) : e.item.type === "switch" ? (V(), U(Ov, {
			key: 4,
			modelValue: a.value,
			"onUpdate:modelValue": n[4] ||= (e) => a.value = e,
			item: e.item
		}, null, 8, ["modelValue", "item"])) : e.item.type === "button-group" ? (V(), U(a_, {
			key: 5,
			item: e.item
		}, {
			default: R(() => [W("div", Av, [(V(!0), H(B, null, $r(e.item.buttons, (e) => (V(), H(B, { key: e.actionKey }, [c(e) ? (V(), U(hv, {
				key: 0,
				variant: e.variant,
				width: e.width,
				"min-width": e.minWidth,
				color: e.color,
				disabled: s(e),
				onClick: (t) => r("action", e.actionKey)
			}, {
				default: R(() => [e.icon ? (V(), U(Xr(e.icon), {
					key: 0,
					class: "control-icon"
				})) : K("", !0), W("span", null, j(o(e)), 1)]),
				_: 2
			}, 1032, [
				"variant",
				"width",
				"min-width",
				"color",
				"disabled",
				"onClick"
			])) : K("", !0)], 64))), 128))])]),
			_: 1
		}, 8, ["item"])) : e.item.type === "slider" ? (V(), U(Tv, {
			key: 6,
			modelValue: a.value,
			"onUpdate:modelValue": n[5] ||= (e) => a.value = e,
			item: e.item
		}, null, 8, ["modelValue", "item"])) : e.item.type === "shortcut" ? (V(), U(xv, {
			key: 7,
			modelValue: a.value,
			"onUpdate:modelValue": n[6] ||= (e) => a.value = e,
			item: e.item,
			"shortcut-id": e.item.key,
			onError: n[7] ||= (e) => I(i).showToast(e, "warning")
		}, null, 8, [
			"modelValue",
			"item",
			"shortcut-id"
		])) : e.item.type === "text" ? (V(), U(a_, {
			key: 8,
			item: e.item
		}, {
			default: R(() => [W("div", {
				class: "setting-text-content",
				innerHTML: e.item.content
			}, null, 8, jv)]),
			_: 1
		}, 8, ["item"])) : e.item.type === "component" && e.item.component ? (V(), U(Xr(e.item.component), {
			key: 9,
			item: e.item
		}, null, 8, ["item"])) : K("", !0)])) : K("", !0);
	}
}), [["__scopeId", "data-v-e378b87f"]]), Nv = { class: "modal-header" }, Pv = { class: "header-title-area" }, Fv = { class: "modal-body" }, Iv = { class: "tab-sidebar" }, Lv = ["onClick"], Rv = { class: "settings-content" }, zv = {
	key: 0,
	class: "settings-panel"
}, Bv = { class: "panel-title" }, Vv = /*#__PURE__*/ Z(/* @__PURE__ */ z({
	__name: "SettingsModal",
	setup(e) {
		let { store: t, activeTab: n, getSettingValue: r, handleClear: i, handleAddNote: a, close: o } = t_(), s = (e) => {
			e === "addNote" ? a() : e === "clearNotes" && i();
		};
		return (e, i) => (V(), U(wo, { name: "modal-fade" }, {
			default: R(() => [I(t).showSettings ? (V(), H("div", {
				key: 0,
				class: "modal-overlay",
				onClick: i[2] ||= (...e) => I(o) && I(o)(...e)
			}, [W("div", {
				class: "modal-container",
				onClick: i[1] ||= J(() => {}, ["stop"])
			}, [W("div", Nv, [W("div", Pv, [G(I(Gu), { class: "header-icon" }), i[3] ||= W("h3", null, "设置", -1)]), W("button", {
				class: "close-btn",
				onClick: i[0] ||= (...e) => I(o) && I(o)(...e)
			}, [G(I(td), { class: "close-icon" })])]), W("div", Fv, [W("div", Iv, [(V(!0), H(B, null, $r(I(J_), (e) => (V(), H(B, { key: e.id }, [I(q_)(e.visible, I(t)) ? (V(), H("button", {
				key: 0,
				class: O(["tab-item", { active: I(n) === e.id }]),
				onClick: (t) => n.value = e.id
			}, [e.icon ? (V(), U(Xr(e.icon), {
				key: 0,
				class: "tab-icon"
			})) : K("", !0), W("span", null, j(e.tabTitle || e.title), 1)], 10, Lv)) : K("", !0)], 64))), 128))]), W("div", Rv, [(V(!0), H(B, null, $r(I(J_), (e) => (V(), H("div", { key: e.id }, [I(n) === e.id && I(q_)(e.visible, I(t)) ? (V(), H("div", zv, [W("h4", Bv, j(e.title), 1), (V(!0), H(B, null, $r(e.items, (e) => (V(), U(Mv, {
				key: e.key,
				modelValue: I(r)(e.key).value,
				"onUpdate:modelValue": (t) => I(r)(e.key).value = t,
				item: e,
				onAction: s
			}, null, 8, [
				"modelValue",
				"onUpdate:modelValue",
				"item"
			]))), 128))])) : K("", !0)]))), 128))])])])])) : K("", !0)]),
			_: 1
		}));
	}
}), [["__scopeId", "data-v-d4e116ee"]]), Hv = { class: "tree-node-wrapper" }, Uv = { class: "item-left" }, Wv = ["data-tooltip"], Gv = {
	key: 1,
	class: "collapse-spacer"
}, Kv = { class: "cat-name" }, qv = { class: "badge" }, Jv = {
	key: 0,
	class: "tree-children"
}, Yv = /*#__PURE__*/ Z(/* @__PURE__ */ z({
	__name: "DataCategoryTreeItem",
	props: {
		node: {},
		selectedCategoryIds: {},
		noteCountMap: {}
	},
	emits: ["toggleCategory"],
	setup(e, { emit: t }) {
		let n = e, r = t, i = /* @__PURE__ */ F(!1), a = q(() => n.node.children && n.node.children.length > 0), o = q(() => n.selectedCategoryIds.includes(n.node.id)), s = (e) => {
			let t = [e.id], n = (e) => {
				e.forEach((e) => {
					t.push(e.id), e.children && e.children.length > 0 && n(e.children);
				});
			};
			return e.children && n(e.children), t;
		}, c = () => {
			let e = s(n.node);
			r("toggleCategory", n.node.id, e);
		}, l = (e) => {
			e.stopPropagation(), i.value = !i.value;
		};
		return (t, n) => {
			let s = Jr("DataCategoryTreeItem", !0);
			return V(), H("div", Hv, [W("div", {
				class: O(["category-item", { active: o.value }]),
				style: D({ paddingLeft: `calc(10px + ${e.node.level * 16}px)` }),
				onClick: c
			}, [W("div", Uv, [
				a.value ? (V(), H("span", {
					key: 0,
					class: "collapse-toggle",
					"data-tooltip": i.value ? "展开子分类" : "折叠子分类",
					onClick: l
				}, [G(I(au), { class: O(["toggle-icon", { "is-expanded": !i.value }]) }, null, 8, ["class"])], 8, Wv)) : (V(), H("span", Gv)),
				o.value ? (V(), U(I(qu), {
					key: 2,
					class: "checkbox-icon checked"
				})) : (V(), U(I(Ju), {
					key: 3,
					class: "checkbox-icon"
				})),
				G(I(Su), { class: "folder-icon" }),
				W("span", Kv, j(e.node.name), 1)
			]), W("span", qv, j(e.noteCountMap[e.node.id] || 0), 1)], 6), a.value && !i.value ? (V(), H("div", Jv, [(V(!0), H(B, null, $r(e.node.children, (t) => (V(), U(s, {
				key: t.id,
				node: t,
				"selected-category-ids": e.selectedCategoryIds,
				"note-count-map": e.noteCountMap,
				onToggleCategory: n[0] ||= (e, t) => r("toggleCategory", e, t)
			}, null, 8, [
				"node",
				"selected-category-ids",
				"note-count-map"
			]))), 128))])) : K("", !0)]);
		};
	}
}), [["__scopeId", "data-v-7a5b65dc"]]), Xv = { class: "category-selector-section" }, Zv = { class: "selection-toolbar" }, Qv = { class: "sub-title" }, $v = { class: "category-list custom-scrollbar" }, ey = { class: "item-left" }, ty = { class: "cat-name" }, ny = { class: "badge" }, ry = /*#__PURE__*/ Z(/* @__PURE__ */ z({
	__name: "DataCategorySelector",
	props: {
		categories: {},
		selectedCategoryIds: {},
		noteCountMap: {},
		isAllSelected: { type: Boolean },
		title: { default: "分类数据" },
		selectedCount: { default: void 0 },
		totalCount: { default: void 0 },
		showUncategorized: {
			type: Boolean,
			default: !1
		},
		isUncategorizedSelected: {
			type: Boolean,
			default: !1
		},
		uncategorizedLabel: { default: "未分类便签" },
		categoryOrder: { default: () => [] }
	},
	emits: [
		"toggleCategory",
		"toggleSelectAll",
		"toggleUncategorized"
	],
	setup(e, { emit: t }) {
		let n = e, r = t, i = q(() => {
			let e = /* @__PURE__ */ new Map();
			n.categories.forEach((t) => {
				e.set(t.id, {
					...t,
					children: [],
					level: 0
				});
			});
			let t = [];
			if (n.categories.forEach((n) => {
				let r = e.get(n.id);
				n.parentId && e.has(n.parentId) ? e.get(n.parentId).children.push(r) : t.push(r);
			}), n.categoryOrder && n.categoryOrder.length > 0) {
				let r = (e) => {
					let t = n.categoryOrder.indexOf(e);
					return t === -1 ? Infinity : t;
				}, i = (e, t) => r(e.id) - r(t.id);
				t.sort(i), e.forEach((e) => {
					e.children.sort(i);
				});
			}
			let r = (e, t) => {
				e.forEach((e) => {
					e.level = t, e.children.length > 0 && r(e.children, t + 1);
				});
			};
			return r(t, 0), t;
		});
		return (e, t) => (V(), H("div", Xv, [W("div", Zv, [W("span", Qv, j(n.title) + " (" + j(n.selectedCount ?? n.selectedCategoryIds.length) + "/" + j(n.totalCount ?? n.categories.length) + ") ", 1), n.categories.length > 0 ? (V(), H("button", {
			key: 0,
			class: "text-action-btn",
			onClick: t[0] ||= (e) => r("toggleSelectAll")
		}, j(n.isAllSelected ? "取消全选" : "全选"), 1)) : K("", !0)]), W("div", $v, [(V(!0), H(B, null, $r(i.value, (e) => (V(), U(Yv, {
			key: e.id,
			node: e,
			"selected-category-ids": n.selectedCategoryIds,
			"note-count-map": n.noteCountMap,
			onToggleCategory: t[1] ||= (e, t) => r("toggleCategory", e, t)
		}, null, 8, [
			"node",
			"selected-category-ids",
			"note-count-map"
		]))), 128)), n.showUncategorized ? (V(), H("div", {
			key: 0,
			class: O(["category-item uncategorized-item", { active: n.isUncategorizedSelected }]),
			onClick: t[2] ||= (e) => r("toggleUncategorized")
		}, [W("div", ey, [
			t[3] ||= W("span", { class: "collapse-spacer" }, null, -1),
			n.isUncategorizedSelected ? (V(), U(I(qu), {
				key: 0,
				class: "checkbox-icon checked"
			})) : (V(), U(I(Ju), {
				key: 1,
				class: "checkbox-icon"
			})),
			G(I(bu), { class: "folder-icon" }),
			W("span", ty, j(n.uncategorizedLabel), 1)
		]), W("span", ny, j(n.noteCountMap.uncategorized || 0), 1)], 2)) : K("", !0)])]));
	}
}), [["__scopeId", "data-v-68819e8b"]]), iy = { class: "modal-card" }, ay = { class: "modal-header" }, oy = { class: "header-title" }, sy = { class: "modal-body" }, cy = { class: "options-section" }, ly = { class: "modal-footer" }, uy = { class: "summary-info" }, dy = { class: "footer-actions" }, fy = ["disabled"], py = /*#__PURE__*/ Z(/* @__PURE__ */ z({
	__name: "ExportModal",
	setup(e) {
		let t = Wl(), n = /* @__PURE__ */ F([]), r = /* @__PURE__ */ F(!0), i = /* @__PURE__ */ F(!1), a = q(() => t.categories.filter((e) => !e.isDeleted)), o = q(() => {
			let e = {};
			return a.value.forEach((t) => {
				e[t.id] = 0;
			}), e.uncategorized = 0, t.allNotes.forEach((t) => {
				if (t.isDeleted && !i.value) return;
				let n = t.categoryId || "all";
				n !== "all" && e[n] !== void 0 ? e[n]++ : e.uncategorized++;
			}), e;
		}), s = () => {
			let e = a.value.map((e) => e.id);
			o.value.uncategorized > 0 && e.push("uncategorized"), n.value = e;
		};
		Gn(() => t.showExportModal, (e) => {
			e && s();
		}, { immediate: !0 });
		let c = q(() => {
			let e = a.value.length + +(o.value.uncategorized > 0);
			return e > 0 && n.value.length === e;
		}), l = () => {
			c.value ? n.value = [] : s();
		}, u = (e, t) => {
			let r = t && t.length > 0 ? t : [e];
			if (n.value.includes(e)) n.value = n.value.filter((e) => !r.includes(e));
			else {
				let e = new Set([...n.value, ...r]);
				n.value = Array.from(e);
			}
		}, d = q(() => {
			let e = new Set(n.value);
			return t.allNotes.filter((t) => {
				if (t.isDeleted && !i.value) return !1;
				let n = t.categoryId || "all";
				return n === "all" ? e.has("uncategorized") : e.has(n);
			}).length;
		}), f = () => {
			let e = {
				categoryIds: n.value,
				includeSettings: r.value,
				includeTrash: i.value
			};
			t.exportSelectedBackup(e), t.closeExportModal();
		}, p = (e) => {
			e.key === "Escape" && t.showExportModal && t.closeExportModal();
		};
		return Rr(() => window.addEventListener("keydown", p)), Hr(() => window.removeEventListener("keydown", p)), (e, s) => (V(), U(or, { to: "body" }, [G(wo, { name: "modal-fade" }, {
			default: R(() => [I(t).showExportModal ? (V(), H("div", {
				key: 0,
				class: "modal-backdrop",
				onClick: s[5] ||= J((...e) => I(t).closeExportModal && I(t).closeExportModal(...e), ["self"])
			}, [W("div", iy, [
				W("div", ay, [W("div", oy, [G(I(hu), { class: "header-icon" }), s[6] ||= W("span", null, "选择导出数据", -1)]), W("button", {
					class: "close-btn",
					"data-tooltip": "关闭",
					onClick: s[0] ||= (...e) => I(t).closeExportModal && I(t).closeExportModal(...e)
				}, [G(I(td), { class: "close-icon" })])]),
				W("div", sy, [
					s[9] ||= W("p", { class: "section-desc" }, " 请选择需要包含在备份 JSON 文件中的分类与数据： ", -1),
					G(ry, {
						title: "分类数据",
						categories: a.value,
						"category-order": I(t).categoryOrder,
						"selected-category-ids": n.value,
						"note-count-map": o.value,
						"is-all-selected": c.value,
						"total-count": a.value.length + +(o.value.uncategorized > 0),
						"show-uncategorized": o.value.uncategorized > 0,
						"is-uncategorized-selected": n.value.includes("uncategorized"),
						"uncategorized-label": "未分类/全部便签",
						onToggleCategory: u,
						onToggleSelectAll: l,
						onToggleUncategorized: s[1] ||= (e) => u("uncategorized")
					}, null, 8, [
						"categories",
						"category-order",
						"selected-category-ids",
						"note-count-map",
						"is-all-selected",
						"total-count",
						"show-uncategorized",
						"is-uncategorized-selected"
					]),
					W("div", cy, [W("div", {
						class: "option-item",
						onClick: s[2] ||= (e) => r.value = !r.value
					}, [
						r.value ? (V(), U(I(qu), {
							key: 0,
							class: "checkbox-icon checked"
						})) : (V(), U(I(Ju), {
							key: 1,
							class: "checkbox-icon"
						})),
						G(I(Gu), { class: "option-icon" }),
						s[7] ||= W("span", { class: "option-label" }, "包含系统与偏好设置 (主题/布局/快捷键等)", -1)
					]), W("div", {
						class: "option-item",
						onClick: s[3] ||= (e) => i.value = !i.value
					}, [
						i.value ? (V(), U(I(qu), {
							key: 0,
							class: "checkbox-icon checked"
						})) : (V(), U(I(Ju), {
							key: 1,
							class: "checkbox-icon"
						})),
						G(I(Zu), { class: "option-icon" }),
						s[8] ||= W("span", { class: "option-label" }, "包含已放入回收站的便签", -1)
					])])
				]),
				W("div", ly, [W("div", uy, [
					s[10] ||= Na(" 共选择 ", -1),
					W("strong", null, j(d.value), 1),
					s[11] ||= Na(" 张便签 ", -1)
				]), W("div", dy, [W("button", {
					class: "btn btn-cancel",
					onClick: s[4] ||= (...e) => I(t).closeExportModal && I(t).closeExportModal(...e)
				}, " 取消 "), W("button", {
					class: "btn btn-primary",
					disabled: n.value.length === 0 && !r.value,
					onClick: f
				}, [G(I(hu), { class: "btn-icon" }), s[12] ||= W("span", null, "导出备份", -1)], 8, fy)])])
			])])) : K("", !0)]),
			_: 1
		})]));
	}
}), [["__scopeId", "data-v-55cadf58"]]), my = { class: "file-info-card" }, hy = { class: "info-meta" }, gy = { class: "meta-item" }, _y = { class: "meta-item" }, vy = { class: "info-stats" }, yy = /*#__PURE__*/ Z(/* @__PURE__ */ z({
	__name: "ImportFileInfoCard",
	props: {
		version: {},
		formattedTime: {},
		categoriesCount: {},
		notesCount: {},
		hasSettings: { type: Boolean }
	},
	setup(e) {
		let t = e;
		return (e, n) => (V(), H("div", my, [W("div", hy, [W("div", gy, [G(I(yu), { class: "meta-icon" }), W("span", null, [n[0] ||= Na("版本: ", -1), W("strong", null, j(t.version || "未知"), 1)])]), W("div", _y, [G(I(tu), { class: "meta-icon" }), W("span", null, "生成时间: " + j(t.formattedTime), 1)])]), W("div", vy, [
			W("span", null, "包含 " + j(t.categoriesCount) + " 个分类", 1),
			n[3] ||= W("span", null, "•", -1),
			W("span", null, j(t.notesCount) + " 张便签", 1),
			t.hasSettings ? (V(), H(B, { key: 0 }, [n[1] ||= W("span", null, "•", -1), n[2] ||= W("span", null, "包含偏好设置", -1)], 64)) : K("", !0)
		])]));
	}
}), [["__scopeId", "data-v-35d9eb71"]]), by = { class: "section-container" }, xy = { class: "mode-grid" }, Sy = { class: "mode-header" }, Cy = { class: "mode-header" }, wy = /*#__PURE__*/ Z(/* @__PURE__ */ z({
	__name: "ImportModeSelector",
	props: { modelValue: {} },
	emits: ["update:modelValue"],
	setup(e, { emit: t }) {
		let n = e, r = t, i = (e) => {
			r("update:modelValue", e);
		};
		return (e, t) => (V(), H("div", by, [t[6] ||= W("div", { class: "section-title" }, " 选择导入方式 ", -1), W("div", xy, [W("div", {
			class: O(["mode-card", { active: n.modelValue === "merge" }]),
			onClick: t[0] ||= (e) => i("merge")
		}, [W("div", Sy, [G(I(Cu), { class: "mode-icon merge" }), t[2] ||= W("span", { class: "mode-name" }, "增量合并", -1)]), t[3] ||= W("p", { class: "mode-desc" }, " 保留现有数据，仅追加新项并更新相同 ID 项 ", -1)], 2), W("div", {
			class: O(["mode-card danger", { active: n.modelValue === "overwrite" }]),
			onClick: t[1] ||= (e) => i("overwrite")
		}, [W("div", Cy, [G(I(Hu), { class: "mode-icon overwrite" }), t[4] ||= W("span", { class: "mode-name" }, "覆盖已有", -1)]), t[5] ||= W("p", { class: "mode-desc" }, " ⚠️ 清空当前全部数据，完全替换为导入内容 ", -1)], 2)])]));
	}
}), [["__scopeId", "data-v-763fbc99"]]), Ty = { class: "modal-card" }, Ey = { class: "modal-header" }, Dy = { class: "header-title" }, Oy = { class: "modal-body custom-scrollbar" }, ky = { class: "section-container" }, Ay = {
	key: 0,
	class: "options-section"
}, jy = { class: "modal-footer" }, My = { class: "summary-info" }, Ny = { class: "footer-actions" }, Py = ["disabled"], Fy = /*#__PURE__*/ Z(/* @__PURE__ */ z({
	__name: "ImportModal",
	setup(e) {
		let t = Wl(), n = /* @__PURE__ */ F("merge"), r = /* @__PURE__ */ F([]), i = /* @__PURE__ */ F(!0), a = /* @__PURE__ */ F(!0), o = q(() => t.pendingImportData), s = q(() => {
			if (!o.value) return {};
			let e = {}, t = Array.isArray(o.value.categories) ? o.value.categories : [], n = Array.isArray(o.value.notes) ? o.value.notes : [];
			return t.forEach((t) => {
				e[t.id] = 0;
			}), e.uncategorized = 0, n.forEach((t) => {
				let n = t.categoryId || "all";
				n !== "all" && e[n] !== void 0 ? e[n]++ : e.uncategorized++;
			}), e;
		}), c = () => {
			o.value && (r.value = (Array.isArray(o.value.categories) ? o.value.categories : []).map((e) => e.id), i.value = (s.value.uncategorized || 0) > 0, a.value = !!o.value.settings);
		};
		Gn(() => t.showImportModal, (e) => {
			e && (n.value = "merge", c());
		}, { immediate: !0 });
		let l = q(() => Array.isArray(o.value?.categories) ? o.value.categories : []), u = q(() => {
			let e = l.value.length;
			return e > 0 && r.value.length === e;
		}), d = () => {
			u.value ? r.value = [] : r.value = l.value.map((e) => e.id);
		}, f = (e, t) => {
			let n = t && t.length > 0 ? t : [e];
			if (r.value.includes(e)) r.value = r.value.filter((e) => !n.includes(e));
			else {
				let e = new Set([...r.value, ...n]);
				r.value = Array.from(e);
			}
		}, p = q(() => {
			if (!o.value?.timestamp) return "未知时间";
			let e = new Date(o.value.timestamp), t = (e) => String(e).padStart(2, "0");
			return `${e.getFullYear()}-${t(e.getMonth() + 1)}-${t(e.getDate())} ${t(e.getHours())}:${t(e.getMinutes())}`;
		}), m = q(() => {
			if (!o.value) return 0;
			let e = Array.isArray(o.value.notes) ? o.value.notes : [], t = new Set(r.value);
			return e.filter((e) => {
				let n = e.categoryId || "all";
				return !!(n !== "all" && t.has(n) || (n === "all" || !n) && i.value);
			}).length;
		}), h = async () => {
			if (n.value === "overwrite" && !await t.askConfirm("确认覆盖数据？", "⚠️ 警告：选择“覆盖已有”将会清空您现有的全部分类与便签数据，完全替换为所选导入的内容，此操作无法撤销！")) return;
			let e = {
				mode: n.value,
				categoryIds: r.value,
				importUncategorized: i.value,
				importSettings: a.value
			};
			t.importSelectedBackup(e);
		}, g = (e) => {
			e.key === "Escape" && t.showImportModal && t.closeImportModal();
		};
		return Rr(() => window.addEventListener("keydown", g)), Hr(() => window.removeEventListener("keydown", g)), (e, c) => (V(), U(or, { to: "body" }, [G(wo, { name: "modal-fade" }, {
			default: R(() => [I(t).showImportModal && o.value ? (V(), H("div", {
				key: 0,
				class: "modal-backdrop",
				onClick: c[5] ||= J((...e) => I(t).closeImportModal && I(t).closeImportModal(...e), ["self"])
			}, [W("div", Ty, [
				W("div", Ey, [W("div", Dy, [G(I(ed), { class: "header-icon" }), c[6] ||= W("span", null, "导入数据恢复", -1)]), W("button", {
					class: "close-btn",
					"data-tooltip": "关闭",
					onClick: c[0] ||= (...e) => I(t).closeImportModal && I(t).closeImportModal(...e)
				}, [G(I(td), { class: "close-icon" })])]),
				W("div", Oy, [
					G(yy, {
						version: o.value.version,
						"formatted-time": p.value,
						"categories-count": l.value.length,
						"notes-count": o.value.notes?.length || 0,
						"has-settings": !!o.value.settings
					}, null, 8, [
						"version",
						"formatted-time",
						"categories-count",
						"notes-count",
						"has-settings"
					]),
					G(wy, {
						modelValue: n.value,
						"onUpdate:modelValue": c[1] ||= (e) => n.value = e
					}, null, 8, ["modelValue"]),
					W("div", ky, [G(ry, {
						title: "选择导入分类",
						categories: l.value,
						"selected-category-ids": r.value,
						"note-count-map": s.value,
						"is-all-selected": u.value,
						"show-uncategorized": (s.value.uncategorized || 0) > 0,
						"is-uncategorized-selected": i.value,
						"uncategorized-label": "未分类/全域便签",
						onToggleCategory: f,
						onToggleSelectAll: d,
						onToggleUncategorized: c[2] ||= (e) => i.value = !i.value
					}, null, 8, [
						"categories",
						"selected-category-ids",
						"note-count-map",
						"is-all-selected",
						"show-uncategorized",
						"is-uncategorized-selected"
					]), o.value.settings ? (V(), H("div", Ay, [W("div", {
						class: "option-item",
						onClick: c[3] ||= (e) => a.value = !a.value
					}, [
						a.value ? (V(), U(I(qu), {
							key: 0,
							class: "checkbox-icon checked"
						})) : (V(), U(I(Ju), {
							key: 1,
							class: "checkbox-icon"
						})),
						G(I(Gu), { class: "option-icon" }),
						c[7] ||= W("span", { class: "option-label" }, "同时导入并覆盖系统偏好设置 (主题/布局等)", -1)
					])])) : K("", !0)])
				]),
				W("div", jy, [W("div", My, [
					c[8] ||= Na(" 将导入 ", -1),
					W("strong", null, j(m.value), 1),
					c[9] ||= Na(" 张便签 ", -1)
				]), W("div", Ny, [W("button", {
					class: "btn btn-cancel",
					onClick: c[4] ||= (...e) => I(t).closeImportModal && I(t).closeImportModal(...e)
				}, " 取消 "), W("button", {
					class: O(["btn", n.value === "overwrite" ? "btn-danger" : "btn-primary"]),
					disabled: r.value.length === 0 && !i.value && !a.value,
					onClick: h
				}, [n.value === "overwrite" ? (V(), U(I(Qu), {
					key: 0,
					class: "btn-icon"
				})) : (V(), U(I(ed), {
					key: 1,
					class: "btn-icon"
				})), W("span", null, j(n.value === "overwrite" ? "确认覆盖导入" : "确认增量导入"), 1)], 10, Py)])])
			])])) : K("", !0)]),
			_: 1
		})]));
	}
}), [["__scopeId", "data-v-feff713e"]]), Iy = { class: "nav-tab-wrapper" }, Ly = { class: "center-fab-wrapper" }, Ry = { class: "tab-label" }, zy = /*#__PURE__*/ Z(/* @__PURE__ */ z({
	__name: "MobileBottomBar",
	setup(e) {
		let t = Wl(), n = /* @__PURE__ */ F(!1), r = () => {
			n.value = !n.value;
		}, i = () => {
			n.value = !1;
		}, a = () => {
			t.addNote(t.currentCategoryId, "", ""), t.showToast("已新建空便签，可以直接编辑");
		};
		return Rr(() => {
			document.addEventListener("click", i);
		}), Hr(() => {
			document.removeEventListener("click", i);
		}), (e, o) => (V(), H("nav", {
			class: "mobile-bottom-bar",
			onClick: o[3] ||= J(() => {}, ["stop"])
		}, [
			W("button", {
				class: O(["nav-tab-btn", { active: I(t).isMobileSidebarOpen }]),
				onClick: o[0] ||= (...e) => I(t).toggleMobileSidebar && I(t).toggleMobileSidebar(...e)
			}, [G(I(Su), { class: "tab-icon" }), o[4] ||= W("span", { class: "tab-label" }, "分类", -1)], 2),
			W("div", Iy, [G(lf, {
				"is-open": n.value,
				placement: "top",
				onToggle: r,
				onClose: i
			}, null, 8, ["is-open"]), o[5] ||= W("span", { class: "tab-label" }, "排序", -1)]),
			W("div", Ly, [W("button", {
				class: "center-fab-btn",
				"aria-label": "新建便签",
				"data-tooltip": "新建便签",
				onClick: a
			}, [G(I(zu), { class: "fab-icon" })])]),
			W("button", {
				class: "nav-tab-btn",
				onClick: o[1] ||= (...e) => I(t).toggleTheme && I(t).toggleTheme(...e)
			}, [I(t).isDark ? (V(), U(I(Xu), {
				key: 0,
				class: "tab-icon"
			})) : (V(), U(I(ju), {
				key: 1,
				class: "tab-icon"
			})), W("span", Ry, j(I(t).isDark ? "浅色" : "深色"), 1)]),
			W("button", {
				class: "nav-tab-btn",
				onClick: o[2] ||= (...e) => I(t).openSettings && I(t).openSettings(...e)
			}, [G(I(Gu), { class: "tab-icon" }), o[6] ||= W("span", { class: "tab-label" }, "设置", -1)])
		]));
	}
}), [["__scopeId", "data-v-0aafe83f"]]), By = { class: "dashboard-layout" }, Vy = { class: "main-panel" }, Hy = /*#__PURE__*/ Z(/* @__PURE__ */ z({
	__name: "Dashboard",
	setup(e) {
		let t = Wl(), n = Il(), r = (e) => {
			n.handleKeyDown(e);
		};
		return Rr(() => {
			t.loadData(), window.addEventListener("keydown", r);
		}), Hr(() => {
			window.removeEventListener("keydown", r);
		}), (e, n) => (V(), H("div", By, [
			G(wo, { name: "drawer-fade" }, {
				default: R(() => [I(t).isMobileSidebarOpen ? (V(), H("div", {
					key: 0,
					class: "mobile-sidebar-backdrop",
					onClick: n[0] ||= (...e) => I(t).closeMobileSidebar && I(t).closeMobileSidebar(...e)
				})) : K("", !0)]),
				_: 1
			}),
			G(qd),
			W("main", Vy, [
				G(xf),
				G(wo, {
					name: "fade-slide",
					mode: "out-in"
				}, {
					default: R(() => [I(t).isInitialized ? (V(), U(Kg, { key: I(t).currentCategoryId })) : K("", !0)]),
					_: 1
				}),
				G(zy)
			]),
			G(Jg),
			G(e_),
			G(Vv),
			G(py),
			G(Fy)
		]));
	}
}), [["__scopeId", "data-v-50e44fed"]]), Uy = { class: "scale-text" }, Wy = { class: "image-counter" }, Gy = ["src"], Ky = /*#__PURE__*/ Z(/* @__PURE__ */ z({
	__name: "ImagePreviewModal",
	setup(e) {
		let t = /* @__PURE__ */ F(1), n = /* @__PURE__ */ F(0), r = /* @__PURE__ */ F(0), i = /* @__PURE__ */ F(0), a = /* @__PURE__ */ F(!1), o = /* @__PURE__ */ F(0), s = /* @__PURE__ */ F(0), c = /* @__PURE__ */ F(0), l = /* @__PURE__ */ F(0), u = () => {
			t.value = 1, n.value = 0, r.value = 0, i.value = 0;
		}, d = () => {
			Kf(), u();
		}, f = () => {
			qf(), u();
		};
		Gn(Vf, (e) => {
			e && u();
		});
		let p = (e, n, a) => {
			let o = t.value, s = Number(Math.min(Math.max(e, .05), 10).toFixed(3));
			if (Math.abs(s - o) < .001) return;
			let c = n ?? window.innerWidth / 2, l = a ?? window.innerHeight / 2, u = s / o, d = window.innerWidth / 2, f = window.innerHeight / 2;
			r.value += (c - d - r.value) * (1 - u), i.value += (l - f - i.value) * (1 - u), t.value = s;
		}, m = () => {
			p(t.value * 1.25);
		}, h = () => {
			p(t.value / 1.25);
		}, g = () => {
			n.value = (n.value - 90) % 360;
		}, _ = () => {
			n.value = (n.value + 90) % 360;
		}, v = (e) => {
			if (!a.value) return;
			let t = e.clientX - o.value, n = e.clientY - s.value;
			r.value = c.value + t, i.value = l.value + n;
		}, y = () => {
			a.value && (a.value = !1, window.removeEventListener("mousemove", v), window.removeEventListener("mouseup", y));
		}, b = (e) => {
			e.button === 0 && (e.preventDefault(), e.stopPropagation(), a.value = !0, o.value = e.clientX, s.value = e.clientY, c.value = r.value, l.value = i.value, window.addEventListener("mousemove", v), window.addEventListener("mouseup", y));
		}, x = (e) => {
			e.preventDefault();
			let n = 1.15 ** (-e.deltaY / 100), r = Math.min(Math.max(n, .75), 1.35);
			p(t.value * r, e.clientX, e.clientY);
		}, S = (e) => {
			Vf.value && (e.key === "Escape" ? Jf() : e.key === "ArrowLeft" ? d() : e.key === "ArrowRight" && f());
		};
		return Rr(() => {
			window.addEventListener("keydown", S);
		}), Hr(() => {
			window.removeEventListener("keydown", S), y();
		}), (e, o) => (V(), U(or, { to: "body" }, [G(wo, { name: "modal-fade" }, {
			default: R(() => [I(Vf) ? (V(), H("div", {
				key: 0,
				class: "image-preview-overlay",
				onClick: o[4] ||= (...e) => I(Jf) && I(Jf)(...e),
				onWheel: J(x, ["prevent"])
			}, [
				W("button", {
					class: "page-close-btn",
					"data-tooltip": "关闭预览 (Esc)",
					onClick: o[0] ||= J((...e) => I(Jf) && I(Jf)(...e), ["stop"])
				}, [G(I(td), { class: "close-icon" })]),
				I(Uf).length > 1 ? (V(), H("button", {
					key: 0,
					class: "nav-btn prev-btn",
					"data-tooltip": "上一张 (←)",
					onClick: J(d, ["stop"])
				}, [G(I(iu), { class: "nav-icon" })])) : K("", !0),
				I(Uf).length > 1 ? (V(), H("button", {
					key: 1,
					class: "nav-btn next-btn",
					"data-tooltip": "下一张 (→)",
					onClick: J(f, ["stop"])
				}, [G(I(au), { class: "nav-icon" })])) : K("", !0),
				W("div", {
					class: "preview-toolbar",
					onClick: o[1] ||= J(() => {}, ["stop"])
				}, [
					W("button", {
						class: "tool-btn",
						"data-tooltip": "放大",
						onClick: m
					}, [G(I(rd), { class: "tool-icon" })]),
					W("button", {
						class: "tool-btn",
						"data-tooltip": "缩小",
						onClick: h
					}, [G(I(nd), { class: "tool-icon" })]),
					W("button", {
						class: "tool-btn",
						"data-tooltip": "向左旋转 90°",
						onClick: g
					}, [G(I($u), { class: "tool-icon" })]),
					W("button", {
						class: "tool-btn",
						"data-tooltip": "向右旋转 90°",
						onClick: _
					}, [G(I(Bu), { class: "tool-icon" })]),
					W("button", {
						class: "tool-btn",
						"data-tooltip": "重置",
						onClick: u
					}, [G(I(Hu), { class: "tool-icon" })]),
					W("span", Uy, j(Math.round(t.value * 100)) + "%", 1),
					I(Uf).length > 1 ? (V(), H(B, { key: 0 }, [o[5] ||= W("div", { class: "counter-divider" }, null, -1), W("span", Wy, j(I(Wf) + 1) + " / " + j(I(Uf).length), 1)], 64)) : K("", !0)
				]),
				W("div", {
					class: "image-container",
					onClick: o[3] ||= J(() => {}, ["stop"])
				}, [W("img", {
					src: I(Hf),
					alt: "图片预览",
					class: O(["preview-img", { "is-dragging": a.value }]),
					draggable: "false",
					style: D({ transform: `translate3d(${r.value}px, ${i.value}px, 0) scale(${t.value}) rotate(${n.value}deg)` }),
					onDragstart: o[2] ||= J(() => {}, ["prevent"]),
					onMousedown: b,
					onDblclick: u
				}, null, 46, Gy)])
			], 32)) : K("", !0)]),
			_: 1
		})]));
	}
}), [["__scopeId", "data-v-a2450027"]]), qy = /*#__PURE__*/ Z(/* @__PURE__ */ z({
	__name: "NotePreviewModal",
	setup(e) {
		let t = Wl(), n = q(() => t.previewNoteId && t.allNotes.find((e) => e.id === t.previewNoteId) || null), r = q(() => !!n.value), i = () => {
			t.closeNotePreview();
		}, a = (e) => {
			r.value && e.key === "Escape" && i();
		};
		return Rr(() => {
			window.addEventListener("keydown", a);
		}), Hr(() => {
			window.removeEventListener("keydown", a);
		}), (e, a) => (V(), U(or, { to: "body" }, [G(wo, { name: "preview-modal-fade" }, {
			default: R(() => [r.value && n.value ? (V(), H("div", {
				key: 0,
				class: O(["note-preview-overlay", { "is-immersive": I(t).enableImmersiveFullscreen }]),
				onClick: i
			}, [W("button", {
				class: "page-close-btn",
				"data-tooltip": "关闭全屏 (Esc)",
				onClick: J(i, ["stop"])
			}, [G(I(td), { class: "close-icon" })]), W("div", {
				class: O(["note-preview-content", { "is-immersive": I(t).enableImmersiveFullscreen }]),
				onClick: a[0] ||= J(() => {}, ["stop"])
			}, [G(Vg, {
				note: n.value,
				"is-full-screen": !0,
				"is-immersive-full-screen": I(t).enableImmersiveFullscreen
			}, null, 8, ["note", "is-immersive-full-screen"])], 2)], 2)) : K("", !0)]),
			_: 1
		})]));
	}
}), [["__scopeId", "data-v-a45284cc"]]), Jy = { class: "app-wrapper" }, Yy = /* @__PURE__ */ z({
	__name: "App",
	setup(e) {
		let t = Wl(), n = [];
		return Rr(async () => {
			(window.location.hostname === "localhost" || window.location.hostname === "127.0.0.1") && (window.resetTags = t.devResetTags, window.resetNotes = t.devResetNotes, window.resetAllData = t.devResetAllData, console.log("%c[Dev Helper] 已挂载开发重置控制台指令: ", "color: #3b82f6; font-weight: bold;"), console.log("- resetTags(): 清空所有便签的标签(tags)"), console.log("- resetNotes(): 重置所有便签内容为默认欢迎便签"), console.log("- resetAllData(): 清空缓存，完全重置分类与便签数据")), t.loadData(), t.initTheme(), Nc().then(() => {
				t.reloadNotes();
			}).catch(() => {});
			let e = Ac();
			e?.bus && e.bus.subscribe("moment-notes:sync-check", () => {
				dl.triggerSyncCheck({
					silent: !0,
					minIntervalMs: 5e3
				}).catch(() => {});
			}), od() && ad.value && cd(!0).catch(() => {});
			let r = null, i = () => {
				od() && (ad.value || window.__isFileDialogActive || (r && clearTimeout(r), r = window.setTimeout(async () => {
					r = null, typeof document < "u" && !document.hasFocus() && !ad.value && !window.__isFileDialogActive && await ud();
				}, 120)));
			}, a = () => {
				r &&= (clearTimeout(r), null), typeof document < "u" && document.visibilityState === "visible" && dl.triggerSyncCheck({
					silent: !0,
					minIntervalMs: 15e3
				}).catch(() => {});
			}, o = (e) => {
				e.key === "Escape" && od() && !document.querySelector(".modal-backdrop, .preview-modal-overlay, .image-preview-overlay") && !ad.value && !t.editingNoteId && ud();
			};
			document.addEventListener("visibilitychange", a), window.addEventListener("focus", a), window.addEventListener("blur", i), window.addEventListener("keydown", o), n.push(() => {
				r && clearTimeout(r), document.removeEventListener("visibilitychange", a), window.removeEventListener("focus", a), window.removeEventListener("blur", i), window.removeEventListener("keydown", o);
			}), n.push(Ff(() => {
				t.reloadNotes();
			}, (e) => {
				t.reloadNotes(), Nf();
			})), n.push(Uc.subscribe("NOTE_CREATED", Nf), Uc.subscribe("NOTE_UPDATED", Nf), Uc.subscribe("NOTE_DELETED", Nf), Uc.subscribe("NOTE_RESTORED", Nf));
		}), Hr(() => {
			n.splice(0).forEach((e) => e());
		}), (e, t) => (V(), H("div", Jy, [
			G(Hy),
			G(Ky),
			G(qy)
		]));
	}
}), Xy = { class: "window-controls" }, Zy = ["aria-label", "data-tooltip"], Qy = ["aria-label", "data-tooltip"], $y = {
	key: 0,
	class: "note-window-content"
}, eb = {
	key: 1,
	class: "note-missing-state"
}, tb = /*#__PURE__*/ Z(/* @__PURE__ */ z({
	__name: "DetachedNoteWindow",
	setup(e) {
		let t = Wl(), n = Of(), r = /* @__PURE__ */ F(!1), i = /* @__PURE__ */ F(!1), a = /* @__PURE__ */ F(!1), o = [], s = q(() => n && t.allNotes.find((e) => e.id === n && !e.isDeleted) || null), c = q(() => {
			let e = tl[s.value?.color || "yellow"] || tl.yellow;
			return {
				"--detached-note-bg": e.lightBg,
				"--detached-note-bg-dark": e.darkBg,
				"--detached-note-border": e.lightBorder,
				"--detached-note-border-dark": e.darkBorder,
				"--detached-note-text": e.lightText,
				"--detached-note-text-dark": e.darkText,
				"--detached-note-btn-hover-bg": e.lightBtnHoverBg,
				"--detached-note-btn-hover-color": e.lightBtnHoverColor,
				"--detached-note-btn-hover-bg-dark": e.darkBtnHoverBg,
				"--detached-note-btn-hover-color-dark": e.darkBtnHoverColor
			};
		}), l = () => {
			dd();
		}, u = () => {
			if (!n) return;
			i.value = !i.value;
			let e = Ac(), t = `plugin-moment-notes-note-${n}`;
			e?.windows ? e.windows.control(t, "alwaysOnTop", i.value).catch(() => {}) : e?.bus && e.bus.publish("moment-notes:control-window", {
				label: t,
				op: "alwaysOnTop",
				value: i.value
			}).catch(() => {});
		}, d = () => {
			document.fullscreenElement ? document.exitFullscreen?.().catch(() => {
				a.value = !1;
			}) : document.documentElement.requestFullscreen?.().catch(() => {
				a.value = !a.value;
			});
		}, f = () => {
			n && Pf(n);
		}, p = (e) => {
			sd(e);
		};
		return Rr(async () => {
			document.documentElement.classList.add("detached-note-window"), document.body.classList.add("detached-note-window"), t.loadData(), t.initTheme(), r.value = !0, Nc().then(() => {
				t.reloadNotes();
			}).catch(() => {}), o.push(Ff(() => {
				t.reloadNotes();
			}));
			let e = () => {
				a.value = !!document.fullscreenElement;
			};
			document.addEventListener("fullscreenchange", e), o.push(() => document.removeEventListener("fullscreenchange", e)), o.push(Uc.subscribe("NOTE_UPDATED", (e) => {
				e.payload.id === n && f();
			}), Uc.subscribe("NOTE_DELETED", (e) => {
				e.payload === n && (f(), window.setTimeout(l, 0));
			}));
		}), Hr(() => {
			o.splice(0).forEach((e) => e()), document.documentElement.classList.remove("detached-note-window"), document.body.classList.remove("detached-note-window");
		}), (e, t) => (V(), H("main", {
			class: O(["detached-note-shell", { "is-maximized": a.value }]),
			style: D(c.value)
		}, [
			W("div", {
				class: "window-drag-region",
				"aria-hidden": "true",
				"data-tauri-drag-region": "",
				onMousedown: p
			}, null, 32),
			W("div", Xy, [
				I(jc)() ? (V(), H("button", {
					key: 0,
					class: O(["window-control pin-btn", { active: i.value }]),
					"aria-label": i.value ? "取消窗口置顶" : "窗口置顶",
					"data-tooltip": i.value ? "取消窗口置顶" : "窗口置顶",
					onClick: u
				}, [G(I(Lu), { class: "window-control-icon pin-icon" })], 10, Zy)) : K("", !0),
				W("button", {
					class: O(["window-control maximize-btn", { active: a.value }]),
					"aria-label": a.value ? "向下还原" : "最大化",
					"data-tooltip": a.value ? "向下还原" : "最大化",
					onClick: d
				}, [a.value ? (V(), U(I(pu), {
					key: 0,
					class: "window-control-icon restore-icon"
				})) : (V(), U(I(Ju), {
					key: 1,
					class: "window-control-icon maximize-icon"
				}))], 10, Qy),
				W("button", {
					class: "window-control close-btn",
					"aria-label": "关闭便签",
					"data-tooltip": "关闭便签",
					onClick: l
				}, [G(I(td), { class: "window-control-icon" })])
			]),
			r.value && s.value ? (V(), H("div", $y, [G(Vg, {
				note: s.value,
				"is-full-screen": !0
			}, null, 8, ["note"])])) : r.value ? (V(), H("div", eb, [t[0] ||= W("p", null, "便签不存在或已被删除", -1), W("button", {
				class: "close-missing-btn",
				onClick: l
			}, " 关闭 ")])) : K("", !0),
			G(Jg),
			G(e_),
			G(Ky)
		], 6));
	}
}), [["__scopeId", "data-v-a8a11bf6"]]), nb = {
	class: "tb-pane tb-pane-pad",
	style: {
		"max-width": "860px",
		margin: "0 auto",
		"line-height": "1.5"
	}
}, rb = {
	class: "tb-card tb-card-body",
	style: { "margin-bottom": "16px" }
}, ib = { style: {
	display: "flex",
	"align-items": "center",
	gap: "16px",
	"margin-top": "14px",
	"font-size": "13px"
} }, ab = { style: {
	display: "flex",
	"align-items": "center",
	gap: "6px"
} }, ob = {
	key: 0,
	class: "tb-badge tb-badge-warn"
}, sb = {
	key: 1,
	class: "tb-badge tb-badge-ok"
}, cb = {
	key: 2,
	class: "tb-badge tb-badge-bad"
}, lb = {
	key: 3,
	class: "tb-badge tb-badge-ok"
}, ub = {
	key: 0,
	style: {
		display: "flex",
		"align-items": "center",
		gap: "6px"
	}
}, db = {
	class: "tb-card",
	style: { "margin-bottom": "16px" }
}, fb = {
	class: "tb-card-head",
	style: {
		display: "flex",
		"align-items": "center",
		"justify-content": "space-between"
	}
}, pb = { style: {
	display: "flex",
	"align-items": "center",
	gap: "8px",
	cursor: "pointer"
} }, mb = {
	class: "tb-card-body",
	style: {
		display: "flex",
		"flex-direction": "column",
		gap: "12px"
	}
}, hb = { class: "tb-field" }, gb = { style: {
	display: "grid",
	"grid-template-columns": "1fr 1fr",
	gap: "12px"
} }, _b = { class: "tb-field" }, vb = { class: "tb-field" }, yb = { style: {
	display: "flex",
	gap: "6px"
} }, bb = ["type"], xb = { style: {
	display: "grid",
	"grid-template-columns": "2fr 1fr",
	gap: "12px"
} }, Sb = { class: "tb-field" }, Cb = { class: "tb-field" }, wb = { style: {
	display: "grid",
	"grid-template-columns": "1fr 2fr",
	gap: "12px",
	"align-items": "center"
} }, Tb = { style: {
	display: "flex",
	"align-items": "center",
	gap: "8px",
	cursor: "pointer"
} }, Eb = {
	key: 0,
	class: "tb-field",
	style: { margin: "0" }
}, Db = { style: {
	display: "flex",
	"align-items": "center",
	"justify-content": "space-between",
	"flex-wrap": "wrap",
	gap: "10px",
	"margin-top": "6px"
} }, Ob = { style: {
	display: "flex",
	"align-items": "center",
	gap: "8px"
} }, kb = ["disabled"], Ab = {
	class: "tb-hint",
	style: { "font-size": "12px" }
}, jb = {
	class: "tb-card",
	style: { "margin-bottom": "16px" }
}, Mb = {
	class: "tb-card-body",
	style: {
		display: "flex",
		"flex-direction": "column",
		gap: "10px"
	}
}, Nb = { style: {
	display: "flex",
	"align-items": "center",
	"justify-content": "space-between",
	gap: "16px"
} }, Pb = { style: {
	display: "flex",
	"align-items": "center",
	cursor: "pointer",
	"flex-shrink": "0"
} }, Fb = "moment_notes_memory_destroy_on_hide", Ib = /* @__PURE__ */ z({
	__name: "ToolkitSettingsView",
	setup(e) {
		let t = Ac(), n = dl.config, r = dl.syncState, i = /* @__PURE__ */ F(!1), a = /* @__PURE__ */ F(!1), o = /* @__PURE__ */ F(""), s = /* @__PURE__ */ F(null), c = /* @__PURE__ */ F(Bc.hasUnsyncedChanges()), l = () => {
			c.value = Bc.hasUnsyncedChanges();
		}, u = q(() => n.value.lastSyncTime ? new Date(n.value.lastSyncTime).toLocaleString() : "尚未同步"), d = () => {
			dl.saveConfig(n.value), o.value = "配置已保存", s.value = !0, setTimeout(() => {
				o.value === "配置已保存" && (o.value = "");
			}, 2500);
		}, f = async () => {
			a.value = !0, o.value = "", s.value = null, d();
			try {
				let e = await new ul(n.value).testConnection();
				s.value = e.success, o.value = e.message;
			} catch (e) {
				s.value = !1, o.value = e.message || "网络连接失败";
			} finally {
				a.value = !1;
			}
		}, p = async () => {
			d(), o.value = "正在向 WebDAV 同步...", s.value = null;
			try {
				let e = await dl.performSync(() => ({
					version: "2.0.0",
					timestamp: Date.now(),
					categories: Hc.getAll(),
					notes: Vc.getAll()
				}), (e) => {
					e?.categories && Hc.saveAll(e.categories), e?.notes && Vc.saveAll(e.notes), Bc.markSynced();
				}, { silent: !1 });
				s.value = e.success, o.value = e.message, l();
			} catch (e) {
				s.value = !1, o.value = e.message || "同步异常";
			}
		}, m = () => {
			Bc.clearDraft(), l(), o.value = "本地临时草稿已清空", s.value = !0;
		}, h = /* @__PURE__ */ F(typeof localStorage < "u" ? localStorage.getItem(Fb) === "true" : !1), g = () => {
			typeof localStorage < "u" && localStorage.setItem(Fb, String(h.value)), t?.bus?.publish?.("moment-notes:config-changed", {
				key: Fb,
				value: h.value
			}), o.value = h.value ? "已开启省内存模式：窗口不可见时将直接销毁" : "已关闭省内存模式：窗口隐藏时常驻后台以加快响应", s.value = !0, setTimeout(() => {
				o.value.startsWith("已") && (o.value = "");
			}, 3e3);
		}, _ = async () => {
			if (t?.bus) t.bus.publish("moment-notes:open-window", { type: "main" });
			else if (t?.windows) try {
				let e = "plugin-moment-notes-main", n = `pluginwin.html?plugin=${encodeURIComponent(t.id || "custom.moment-notes")}&label=plugin-moment-notes-main`;
				await t.windows.create(e, {
					url: n,
					title: "拾光便签",
					width: 1020,
					height: 720,
					center: !0,
					decorations: !1,
					transparent: !0,
					shadow: !0,
					skipTaskbar: !0,
					resizable: !0
				}), await t.windows.control?.(e, "raise", !0), t.log?.info?.("Notes window summoned");
			} catch (e) {
				console.error("[Settings] Failed to open main notes window:", e);
			}
		};
		return Rr(() => {
			l();
		}), (e, t) => (V(), H("div", nb, [
			W("div", rb, [W("div", { style: {
				display: "flex",
				"align-items": "center",
				"justify-content": "space-between",
				"flex-wrap": "wrap",
				gap: "12px"
			} }, [t[10] ||= W("div", null, [W("h2", {
				class: "tb-screen-title",
				style: {
					margin: "0",
					"font-size": "20px",
					"font-weight": "600"
				}
			}, " 拾光便签 · 控制台 "), W("div", {
				class: "tb-hint",
				style: { "margin-top": "4px" }
			}, " 便签主界面将以独立窗口运行，可自绘置顶并多窗口并排使用。 ")], -1), W("div", { style: {
				display: "flex",
				"align-items": "center",
				gap: "10px"
			} }, [W("button", {
				class: "tb-btn tb-btn-primary",
				style: {
					padding: "8px 18px",
					"font-weight": "500"
				},
				onClick: _
			}, " 🚀 打开便签独立窗口 ")])]), W("div", ib, [
				t[13] ||= W("div", { style: {
					display: "flex",
					"align-items": "center",
					gap: "6px"
				} }, [W("span", null, "全局呼出热键:"), W("span", { class: "tb-kbd" }, "Ctrl+Alt+N")], -1),
				t[14] ||= W("div", {
					class: "tb-divider",
					style: {
						height: "14px",
						width: "1px",
						margin: "0 4px"
					}
				}, null, -1),
				W("div", ab, [t[11] ||= W("span", null, "云同步状态:", -1), I(n).enabled ? I(r) === "syncing" ? (V(), H("span", sb, "正在同步...")) : I(r) === "error" ? (V(), H("span", cb, "同步异常")) : (V(), H("span", lb, "正常运行")) : (V(), H("span", ob, "未启用"))]),
				c.value ? (V(), H("div", ub, [...t[12] ||= [W("span", { class: "tb-badge tb-badge-warn" }, "有未提交草稿", -1)]])) : K("", !0)
			])]),
			W("div", db, [W("div", fb, [t[16] ||= W("div", {
				class: "tb-section-title",
				style: { margin: "0" }
			}, " ☁️ WebDAV 云同步配置 ", -1), W("label", pb, [Ln(W("input", {
				"onUpdate:modelValue": t[0] ||= (e) => I(n).enabled = e,
				type: "checkbox",
				style: { "accent-color": "var(--color-brand)" },
				onChange: d
			}, null, 544), [[As, I(n).enabled]]), t[15] ||= W("span", {
				class: "tb-label",
				style: { margin: "0" }
			}, "启用 WebDAV 云同步", -1)])]), W("div", mb, [
				W("div", hb, [
					t[17] ||= W("span", { class: "tb-label" }, "WebDAV 服务器地址", -1),
					Ln(W("input", {
						"onUpdate:modelValue": t[1] ||= (e) => I(n).serverUrl = e,
						class: "tb-input",
						type: "text",
						placeholder: "例如: https://dav.jianguoyun.com/dav/ 或 http://192.168.1.100:5244/dav/",
						onBlur: d
					}, null, 544), [[ks, I(n).serverUrl]]),
					t[18] ||= W("div", { class: "tb-hint" }, "支持坚果云、Nextcloud、AList、InfiniCLOUD 等标准 WebDAV 服务", -1)
				]),
				W("div", gb, [W("div", _b, [t[19] ||= W("span", { class: "tb-label" }, "账号 / 用户名", -1), Ln(W("input", {
					"onUpdate:modelValue": t[2] ||= (e) => I(n).username = e,
					class: "tb-input",
					type: "text",
					placeholder: "WebDAV 用户名",
					onBlur: d
				}, null, 544), [[ks, I(n).username]])]), W("div", vb, [t[20] ||= W("span", { class: "tb-label" }, "密码 / 应用专有密码", -1), W("div", yb, [Ln(W("input", {
					"onUpdate:modelValue": t[3] ||= (e) => I(n).password = e,
					class: "tb-input",
					type: i.value ? "text" : "password",
					placeholder: "密码或应用授权码",
					style: { flex: "1" },
					onBlur: d
				}, null, 40, bb), [[Ls, I(n).password]]), W("button", {
					class: "tb-btn tb-btn-ghost",
					type: "button",
					onClick: t[4] ||= (e) => i.value = !i.value
				}, j(i.value ? "隐藏" : "显示"), 1)])])]),
				W("div", xb, [W("div", Sb, [t[21] ||= W("span", { class: "tb-label" }, "远端存储路径", -1), Ln(W("input", {
					"onUpdate:modelValue": t[5] ||= (e) => I(n).remotePath = e,
					class: "tb-input",
					type: "text",
					placeholder: "/toolkit/moment_notes.json",
					onBlur: d
				}, null, 544), [[ks, I(n).remotePath]])]), W("div", Cb, [t[22] ||= W("span", { class: "tb-label" }, "自动同步间隔 (分钟)", -1), Ln(W("input", {
					"onUpdate:modelValue": t[6] ||= (e) => I(n).syncIntervalMinutes = e,
					class: "tb-input",
					type: "number",
					min: "1",
					max: "60",
					onBlur: d
				}, null, 544), [[
					ks,
					I(n).syncIntervalMinutes,
					void 0,
					{ number: !0 }
				]])])]),
				W("div", wb, [W("label", Tb, [Ln(W("input", {
					"onUpdate:modelValue": t[7] ||= (e) => I(n).syncImages = e,
					type: "checkbox",
					style: { "accent-color": "var(--color-brand)" },
					onChange: d
				}, null, 544), [[As, I(n).syncImages]]), t[23] ||= W("span", {
					class: "tb-label",
					style: { margin: "0" }
				}, "同步便签图片", -1)]), I(n).syncImages === !1 ? K("", !0) : (V(), H("div", Eb, [Ln(W("input", {
					"onUpdate:modelValue": t[8] ||= (e) => I(n).imagesRemoteDir = e,
					class: "tb-input",
					type: "text",
					placeholder: "/toolkit/moment_notes_images",
					onBlur: d
				}, null, 544), [[ks, I(n).imagesRemoteDir]])]))]),
				W("div", Db, [W("div", Ob, [
					W("button", {
						class: "tb-btn tb-btn-primary",
						disabled: a.value,
						onClick: f
					}, j(a.value ? "正在测试..." : "测试连接"), 9, kb),
					W("button", {
						class: "tb-btn",
						onClick: p
					}, " 立即同步 "),
					W("button", {
						class: "tb-btn tb-btn-ghost",
						onClick: d
					}, " 保存配置 ")
				]), W("div", Ab, " 上次同步: " + j(u.value), 1)]),
				o.value ? (V(), H("div", {
					key: 0,
					class: O(["tb-badge", s.value === !0 ? "tb-badge-ok" : s.value === !1 ? "tb-badge-bad" : "tb-badge-warn"]),
					style: {
						padding: "6px 12px",
						"margin-top": "4px",
						"font-size": "13px"
					}
				}, j(o.value), 3)) : K("", !0)
			])]),
			W("div", jb, [t[25] ||= W("div", { class: "tb-card-head" }, [W("div", {
				class: "tb-section-title",
				style: { margin: "0" }
			}, " ⚡ 性能与内存占用优化 ")], -1), W("div", Mb, [W("div", Nb, [t[24] ||= W("div", null, [W("div", { style: {
				"font-weight": "500",
				"font-size": "13.5px"
			} }, "不可见时彻底销毁窗口 (极致省内存)"), W("div", {
				class: "tb-hint",
				style: {
					"font-size": "12px",
					"margin-top": "4px",
					"line-height": "1.5"
				}
			}, " 开启后，便签主悬浮窗在失焦或隐藏时将直接销毁 Webview 进程以彻底释放系统内存；每次通过全局快捷键（Ctrl+Alt+N）或控制台呼出时将重新创建并渲染窗口。关闭后窗口常驻后台仅执行隐藏，呼出更敏捷。 ")], -1), W("label", Pb, [Ln(W("input", {
				"onUpdate:modelValue": t[9] ||= (e) => h.value = e,
				type: "checkbox",
				style: {
					width: "18px",
					height: "18px",
					"accent-color": "var(--color-brand)",
					cursor: "pointer"
				},
				onChange: g
			}, null, 544), [[As, h.value]])])])])]),
			t[28] ||= Pa("<div class=\"tb-card\" style=\"margin-bottom:16px;\"><div class=\"tb-card-head\"><div class=\"tb-section-title\" style=\"margin:0;\"> ⌨️ 快捷键指南 </div></div><div class=\"tb-card-body\" style=\"padding:0;\"><div class=\"tb-row\"><span class=\"tb-row-label\">全局呼出 / 切换便签窗口</span><span class=\"tb-kbd\">Ctrl+Alt+N</span></div><div class=\"tb-row\"><span class=\"tb-row-label\">便签窗口内新建便签</span><span class=\"tb-kbd\">Ctrl+N</span></div><div class=\"tb-row\"><span class=\"tb-row-label\">聚焦搜索输入框</span><span class=\"tb-kbd\">Ctrl+F</span></div><div class=\"tb-row\"><span class=\"tb-row-label\">保存便签编辑</span><span class=\"tb-kbd\">Ctrl+S</span></div><div class=\"tb-row\"><span class=\"tb-row-label\">取消编辑 / 退出弹窗</span><span class=\"tb-kbd\">Esc</span></div></div></div>", 1),
			W("div", { class: "tb-card" }, [t[27] ||= W("div", { class: "tb-card-head" }, [W("div", {
				class: "tb-section-title",
				style: { margin: "0" }
			}, " 📦 数据安全与存储 ")], -1), W("div", {
				class: "tb-card-body",
				style: {
					display: "flex",
					"flex-direction": "column",
					gap: "8px"
				}
			}, [t[26] ||= W("div", {
				class: "tb-hint",
				style: { "line-height": "1.6" }
			}, [
				Na(" • 主数据以 "),
				W("b", null, "WebDAV"),
				Na(" 云端作为唯一权威持久化源。"),
				W("br"),
				Na(" • 本地未提交修改暂存于宿主独立沙箱："),
				W("code", null, "%APPDATA%\\com.tan18.toolbox\\plugin-data\\custom.moment-notes\\data.json"),
				Na("，安全隔离且不受浏览器缓存清理影响。 ")
			], -1), W("div", { style: { "margin-top": "6px" } }, [W("button", {
				class: "tb-btn tb-btn-danger tb-btn-sm",
				onClick: m
			}, " 清空本地未同步草稿缓冲 ")])])])
		]));
	}
}), Lb = null, Rb = null, zb = null, Bb = null;
function Vb() {
	return Lb || (Lb = document.createElement("div"), Lb.id = "global-tooltip", Lb.className = "global-tooltip", document.body.appendChild(Lb), Bb = new MutationObserver(() => {
		Lb && (Lb.textContent && Lb.textContent.trim().length > 0 || Lb.children.length > 0 || Wb());
	}), Bb.observe(Lb, {
		childList: !0,
		characterData: !0,
		subtree: !0
	}), Lb);
}
function Hb(e, t) {
	t.hasAttribute("data-tooltip-custom") || (e.textContent = t.getAttribute("data-tooltip") || "");
}
function Ub() {
	Vb(), document.addEventListener("mouseover", (e) => {
		let t = e.target.closest("[data-tooltip], [data-tooltip-custom]");
		if (!t) {
			Rb && Wb();
			return;
		}
		let n = t.getAttribute("data-tooltip"), r = t.hasAttribute("data-tooltip-custom");
		if (!n && !r) {
			Rb === t && Wb();
			return;
		}
		if (t.hasAttribute("data-tooltip-only-overflow") && t.scrollWidth <= t.clientWidth) {
			Rb === t && Wb();
			return;
		}
		let i = Vb();
		if (Rb === t) {
			i.classList.contains("show") && !r && i.textContent !== n && (i.textContent = n || "", Gb(t, i));
			return;
		}
		Rb && Wb(), Rb = t, zb = window.setTimeout(() => {
			if (Rb === t) {
				if (Hb(i, t), !(i.textContent && i.textContent.trim().length > 0 || i.children.length > 0)) {
					Wb();
					return;
				}
				i.classList.add("show"), Gb(t, i);
			}
		}, 550);
	}), document.addEventListener("mouseout", (e) => {
		let t = e.target.closest("[data-tooltip], [data-tooltip-custom]");
		if (!t || t !== Rb) return;
		let n = e.relatedTarget;
		n && n.closest("[data-tooltip], [data-tooltip-custom]") === Rb || Wb();
	}), document.addEventListener("click", Wb), window.addEventListener("scroll", Wb, {
		capture: !0,
		passive: !0
	});
}
function Wb() {
	Rb = null, zb &&= (clearTimeout(zb), null), Lb && Lb.classList.remove("show");
}
function Gb(e, t) {
	let n = e.getBoundingClientRect(), r = t.offsetWidth, i = t.offsetHeight, a = n.left + (n.width - r) / 2, o = n.top - i - 8;
	o < 8 && (o = n.bottom + 8);
	let s = window.innerWidth - r - 8;
	a = Math.max(8, Math.min(a, s)), t.style.left = `${a}px`, t.style.top = `${o}px`;
}
//#endregion
//#region src/entry-toolkit.ts
var Kb = {
	id: "custom.moment-notes",
	name: "拾光便签",
	version: "2.0.0",
	api: 3,
	description: "高颜值 WebDAV 便签，支持独立置顶悬浮窗与跨窗口双向同步",
	contributes: {
		views: [{
			id: "main",
			slot: "tool",
			title: "拾光便签",
			icon: "lucide:sticky-note"
		}],
		hotkeys: [{
			key: "ctrl+alt+n",
			action: "open"
		}]
	},
	permissions: [
		"rpc:storage",
		"rpc:bus",
		"win:manage"
	]
}, qb = null, Jb = !1, Yb = "moment_notes_memory_destroy_on_hide", Xb = typeof localStorage < "u" ? localStorage.getItem(Yb) === "true" : !1;
function Zb() {
	return typeof localStorage < "u" ? localStorage.getItem(Yb) === "true" : Xb;
}
async function Qb(e) {
	if (!e?.windows) return;
	let t = "plugin-moment-notes-main";
	try {
		if (!await e.windows.exists?.(t)) {
			let n = `pluginwin.html?plugin=${encodeURIComponent(e.id || "custom.moment-notes")}&label=plugin-moment-notes-main`;
			await e.windows.create(t, {
				url: n,
				title: "拾光便签",
				width: 1020,
				height: 720,
				center: !0,
				decorations: !1,
				transparent: !0,
				shadow: !0,
				skipTaskbar: !0,
				resizable: !0
			});
		}
		await e.windows.control(t, "raise", !0), Jb = !0, e.log?.info?.("Notes floating window summoned");
	} catch (t) {
		e.log?.error?.(`Failed to open main floating window: ${t}`);
	}
}
async function $b(e) {
	if (!e?.windows) return;
	let t = "plugin-moment-notes-main";
	try {
		if (!await e.windows.exists?.(t)) {
			await Qb(e);
			return;
		}
		Jb ? Zb() ? (await e.windows.control(t, "close"), Jb = !1, e.log?.info?.("Notes floating window destroyed via hotkey (memory saving)")) : (await e.windows.control(t, "hide"), Jb = !1, e.log?.info?.("Notes floating window hidden via hotkey")) : (await e.windows.control(t, "raise", !0), Jb = !0, e.log?.info?.("Notes floating window raised via hotkey"));
	} catch (t) {
		e.log?.error?.(`Failed to toggle main window: ${t}`), Jb = !1, await Qb(e);
	}
}
async function ex(e, t, n) {
	if (!e?.windows) return;
	let r = `plugin-moment-notes-note-${t}`;
	try {
		if (await e.windows.exists?.(r)) {
			await e.windows.control(r, "raise", !0);
			return;
		}
		let i = `pluginwin.html?plugin=${encodeURIComponent(e.id || "custom.moment-notes")}&label=${encodeURIComponent(r)}&view=detached-note&noteId=${encodeURIComponent(t)}`;
		await e.windows.create(r, {
			url: i,
			title: n || "拾光便签",
			width: 520,
			height: 640,
			center: !0,
			decorations: !1,
			transparent: !0,
			shadow: !0,
			alwaysOnTop: !0,
			resizable: !0
		}), await e.windows.control(r, "raise", !0), e.log?.info?.(`Detached note window created for ${t}`);
	} catch (t) {
		e.log?.error?.(`Failed to open detached note window: ${t}`);
	}
}
var tx = {
	manifest: Kb,
	async activate(e) {
		window.__TOOLKIT_CTX__ = e, await Nc(e);
		let t = () => {
			e.log?.info?.("Summon hotkey triggered"), $b(e), e.bus?.publish?.("moment-notes:sync-check", { timestamp: Date.now() });
		};
		e.onHotkey?.("open", t), e.onHotkey?.("quick-note", t), e.bus?.subscribe?.("moment-notes:open-window", (t) => {
			let { type: n, noteId: r, title: i } = (t?.p ?? t?.payload ?? t) || {};
			n === "main" ? Qb(e) : n === "detached" && r && ex(e, r, i);
		}), e.bus?.subscribe?.("moment-notes:close-window", async (t) => {
			let n = (t?.p ?? t?.payload ?? t)?.label;
			if (n && e?.windows) try {
				await e.windows.control(n, "close"), e.log?.info?.(`Closed window ${n} via bus control`), n === "plugin-moment-notes-main" && (Jb = !1);
			} catch (t) {
				e.log?.warn?.(`Failed to close window ${n}: ${t}`);
			}
		}), e.bus?.subscribe?.("moment-notes:control-window", async (t) => {
			let { label: n, op: r, value: i } = (t?.p ?? t?.payload ?? t) || {};
			if (n && r && e?.windows) try {
				if (n === "plugin-moment-notes-main" && r === "hide") {
					if (Zb()) {
						await e.windows.control(n, "close"), Jb = !1, e.log?.info?.(`Window ${n} closed on hide to optimize memory`);
						return;
					}
					await e.windows.control(n, "hide"), Jb = !1;
					return;
				}
				await e.windows.control(n, r, i), n === "plugin-moment-notes-main" && (r === "show" || r === "raise") && (Jb = !0);
			} catch (t) {
				e.log?.warn?.(`Failed to control window ${n} (${r}): ${t}`);
			}
		}), e.bus?.subscribe?.("moment-notes:config-changed", (t) => {
			let n = t?.p ?? t?.payload ?? t;
			n?.key === Yb && (Xb = !!n.value, e.log?.info?.(`[Toolkit] Memory destroy on hide setting updated: ${Xb}`));
		}), e.registerView("main", (e) => {
			qb &&= (qb.unmount(), null), e.innerHTML = "";
			let t = document.createElement("div");
			t.className = "moment-notes-plugin-root", t.style.width = "100%", t.style.height = "100%", t.style.overflowY = "auto", e.appendChild(t);
			let n = qs(Ib);
			n.mount(t), qb = n;
		});
	},
	deactivate() {
		qb &&= (qb.unmount(), null), window.__TOOLKIT_CTX__ = null;
	}
};
async function nx(e) {
	window.bridge = e, window.__TOOLKIT_CTX__ = e, typeof window.__injectMomentNotesStyles == "function" && window.__injectMomentNotesStyles(document), Nc(e).catch((e) => console.warn("[Mount] initStorage background error:", e));
	let t = new URLSearchParams(window.location.search).get("view") === "detached-note" || e?.label?.startsWith("plugin-moment-notes-note-") || e?.label?.includes("detached");
	document.body.innerHTML = "", document.body.style.cssText = "margin:0;padding:0;width:100vw;height:100vh;overflow:hidden;background:transparent;", document.documentElement.style.background = "transparent";
	let n = document.createElement("div");
	n.id = "moment-notes-app-root", n.style.cssText = "width:100%;height:100%;overflow:hidden;background:transparent;", document.body.appendChild(n);
	let r = Yy;
	t ? (document.documentElement.classList.add("detached-note-window"), document.body.classList.add("detached-note-window"), r = tb) : (document.documentElement.classList.add("moment-notes-main-window"), document.body.classList.add("moment-notes-main-window"), r = Yy);
	let i = qs(r), a = mc();
	i.use(a), Ub(), i.mount(n), typeof e?.cleanup == "function" && e.cleanup(() => {
		try {
			i.unmount();
		} catch {}
	});
}
//#endregion
export { tx as default, Kb as manifest, nx as mountWindow };
